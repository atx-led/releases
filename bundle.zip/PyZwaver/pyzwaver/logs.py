import logging
import time

class ListHandler(logging.Handler):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.records = []
    def handle(self, record):
        logging.getLogger().handle(record)
        # Append the record, and manually mark the time
        ts = time.strftime('%Y%m%d %H:%M:%S')
        self.records.append((ts, record))

ZWAVE_HANDLER = ListHandler(level=logging.INFO)

def get_log_records():
    return ZWAVE_HANDLER.records

zwave_logger = logging.Logger('zwave')
zwave_logger.addHandler(ZWAVE_HANDLER)

debug = zwave_logger.debug
info = zwave_logger.info
warning = zwave_logger.warning
error = zwave_logger.error
critical = zwave_logger.critical
