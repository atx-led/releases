from protocols import yeelight, tasmota, native_single, native_multi

protocols = [yeelight, tasmota, native_single, native_multi]
