import copy
import json
import logging
import requests
import socket

from protocols.native_single import find_hosts
from functions import generate_unique_id, light_types, pretty_json

def set_light(address, light, data):
    data['name'] = light['name']
    data['address'] = address["light_nr"]
    print('SET:', data)
    state = requests.put("http://"+address["ip"]+"/lights/state", json=data, timeout=3)
    return state.text

def get_light_state(address, light):
    addr_type, addr_id = address["light_nr"]
    url = "http://%s/lights/state?type=%s&id=%s" % (address["ip"], addr_type, addr_id)
    state = requests.get(url, timeout=3)
    print('STATE:', url, state.text)
    return json.loads(state.text)

# Discovery utilities

DEFAULT_STATE = {"on": False, "bri": 200, "colormode": "ct", "reachable": True}
DEFAULT_TYPE = "ATX LED Light"
DEFAULT_SWVERSION = "0.01"

def discover(args):
    device_ips = find_hosts(args, 80)
    logging.info(pretty_json(device_ips))
    for ip in device_ips:
        try:
            response = requests.get("http://" + ip + "/lights/discover", timeout=3)
            if response.status_code != 200:
                continue

            # XXX JSON validation
            device_data = json.loads(response.text)
            logging.info(pretty_json(device_data))

            assert device_data.get("protocol") == 'atx_led'

            assert "lights" in device_data

            for item in device_data['lights']:
                default_state = copy.deepcopy(DEFAULT_STATE)
                light = {
                    "state": default_state,
                    "type": item['type'],
                    "name": item['name'],
                    "uniqueid": generate_unique_id(),
                    "modelid": item['modelid'],
                    "manufacturername": "Philips",
                    "swversion": DEFAULT_SWVERSION,
                }
                light_address = {
                    "ip": ip,
                    "light_nr": item['light_nr'],
                    "protocol": device_data['protocol'],
                    "mac": device_data["mac"],
                    "version": device_data.get("version"),
                    "type": device_data.get("type"),
                    "name": device_data.get("name"),
                }
                yield (light, light_address)

        except Exception as e:
            logging.info("ip %s is unknown device: %s", ip, e)
            #raise
