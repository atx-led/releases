import json
import random

def nextFreeId(bridge_config, element):
    i = 1
    while (str(i)) in bridge_config[element]:
        i += 1
    return str(i)

def pretty_json(data):
    return json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))

def generate_unique_id():
    rand_bytes = [random.randrange(0, 256) for _ in range(3)]
    return "00:17:88:01:00:%02x:%02x:%02x-0b" % (*rand_bytes,)

#light_types = {"LCT015": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Extended color light", "swversion": "1.29.0_r21169"}, "LST002": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Color light", "swversion": "5.105.0.21169"}, "LWB010": {"state": {"on": False, "bri": 254,"alert": "none", "reachable": True}, "type": "Dimmable light", "swversion": "1.15.0_r18729"}, "LTW001": {"state": {"on": False, "colormode": "ct", "alert": "none", "reachable": True, "bri": 254, "ct": 230}, "type": "Color temperature light", "swversion": "5.50.1.19085"}, "Plug 01": {"state": {"on": False, "alert": "none", "reachable": True}, "type": "On/Off plug-in unit", "swversion": "V1.04.12"}}
light_types = {
    "Tasmota": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "alert": "none", "effect": "none", "colormode": "xy", "reachable": True}, "type": "Extended color light", "swversion": "1.46.13_r26312"},
    "LCT015": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Extended color light", "swversion": "1.46.13_r26312"},
    "LST002": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Color light", "swversion": "5.127.1.26581"},
    "LWB010": {"state": {"on": False, "bri": 254,"alert": "none", "reachable": True}, "type": "Dimmable light", "swversion": "1.46.13_r26312"},
    "LTW001": {"state": {"on": False, "colormode": "ct", "alert": "none", "reachable": True, "bri": 254, "ct": 230}, "type": "Color temperature light", "swversion": "1.46.13_r26312"},
    "Plug 01": {"state": {"on": False, "alert": "none", "reachable": True}, "type": "On/Off plug-in unit", "swversion": "V1.04.12"},
    "ATX-LED": {"state": {"on": False, "bri": 200, "colormode": "ct", "reachable": True}, "type": "ATX LED Light", "swversion": "0.01"},
    "ATX-LED-COLOR": {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "colormode": "ct", "reachable": True}, "type": "ATX LED Light", "swversion": "0.01"},
}

light_types["ATX-LED"] = {"type": "Dimmable light", "swversion": "1.50.2_r30933", "manufacturername": "Signify Netherlands B.V.", "productid": "Philips-LWB010-1-A19DLv4"}
light_types["ATX-LED"]["swupdate"] = {"state": "noupdates","lastinstall": "2020-12-09T19:13:52"}
light_types["ATX-LED"]["config"] = {"archetype": "classicbulb", "function": "mixed", "direction": "omnidirectional", "startup":{"mode":"safety","configured":True}}
light_types["ATX-LED"]["capabilities"] = {"certified": True,"control": {"mindimlevel": 5000, "maxlumen": 806}, "streaming": {"renderer": False, "proxy": False}}
light_types["ATX-LED"]["device"] = {"certified": True, "manufacturer_name": "Signify Netherlands B.V.", "product_archetype": "classic_bulb", "product_name": "Color temperature light", "software_version": "1.104.2"}
light_types["ATX-LED"]["state"] = {"on": False, "bri": 254,"alert": "none", "mode": "homeautomation", "reachable": True}
light_types["ATX-LED"]["dynamics"] = {"speed": 0, "speed_valid": False, "status": "none", "status_values": ["none", "dynamic_palette"]}

light_types["ATX-LED-CT"] = {"type": "Color temperature light", "manufacturername": "Signify Netherlands B.V.", "swversion": "1.104.2"}
light_types["ATX-LED-CT"]["swupdate"] = {"state": "noupdates","lastinstall": "2020-12-09T19:13:52"}
light_types["ATX-LED-CT"]["capabilities"] = {"certified": True,"control": {"mindimlevel": 1000,"maxlumen": 806,"ct": {"min": 153,"max": 454}},"streaming": {"renderer": False,"proxy": False}}
light_types["ATX-LED-CT"]["config"] = {"archetype": "classicbulb","function": "functional","direction": "omnidirectional", "startup":{"mode":"safety","configured":True}}
light_types["ATX-LED-CT"]["device"] = {"certified": True, "manufacturer_name": "Signify Netherlands B.V.", "product_archetype": "classic_bulb", "product_name": "Dimmable light", "software_version": "1.76.6"}
light_types["ATX-LED-CT"]["state"] = {"on": False, "colormode": "ct", "alert": "none", "mode": "homeautomation", "reachable": True, "bri": 254, "ct": 230}
light_types["ATX-LED-CT"]["dynamics"] = {"speed": 0, "speed_valid": False, "status": "none", "status_values": ["none", "dynamic_palette"]}


light_types["ATX-LED-COLOR"] = {"type":"Extended color light", "manufacturername": "Signify Netherlands B.V.", "swversion": "1.104.2"}
light_types["ATX-LED-COLOR"]["swupdate"] = {"state": "noupdates","lastinstall": "2020-12-09T19:13:52"}
light_types["ATX-LED-COLOR"]["capabilities"] = {"certified": True,"control": {"colorgamut": [[0.675,0.322],[0.409,0.518],[0.167,0.04]],"colorgamuttype": "B","ct": {"max": 500,"min": 153},"maxlumen": 600,"mindimlevel": 5000},"streaming": {"proxy": False,"renderer": True}}
light_types["ATX-LED-COLOR"]["device"] = {"certified": True,"manufacturer_name": "Signify Netherlands B.V.","product_archetype": "sultan_bulb","product_name": "Hue color lamp","software_version": "1.104.2"}
light_types["ATX-LED-COLOR"]["state"] = {"alert": "none", "bri":0, "colormode": "xy", "effect": "none","hue": 0, "mode": "homeautomation","on": False,"reachable": True, "sat": 0,"xy": [0.408,0.517]}
light_types["ATX-LED-COLOR"]["config"] = {"archetype": "sultanbulb","direction": "omnidirectional","function": "mixed","startup": {"configured": True, "mode": "safety"}}
light_types["ATX-LED-COLOR"]["dynamics"] = {"speed": 0, "speed_valid": False, "status": "none", "status_values": ["none", "dynamic_palette"]}