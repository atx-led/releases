import socket

def iter_ips(args, port):
    host = args.ip.split('.')
    if args.scan_on_host_ip:
        yield ('127.0.0.1', port)
        return
    for addr in range(args.ip_range_start, args.ip_range_end + 1):
        host[3] = str(addr)
        test_host = '%s.%s.%s.%s' % (*host,)
        if test_host != args.ip:
            yield (test_host, port)

def scan_host(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.02) # Very short timeout. If scanning fails this could be increased
    result = sock.connect_ex((host, port))
    sock.close()
    return result

def find_hosts(args, port):
    validHosts = []
    for host, port in iter_ips(args, port):
        if scan_host(host, port) == 0:
            hostWithPort = '%s:%s' % (host, port)
            validHosts.append(hostWithPort)
    return validHosts
