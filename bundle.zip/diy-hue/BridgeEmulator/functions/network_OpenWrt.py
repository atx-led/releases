import logging
import socket
import sys

def getIpAddress():
   return "192.168.8.1"