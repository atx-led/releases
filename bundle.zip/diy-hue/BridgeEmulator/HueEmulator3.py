#!/usr/bin/python3
import argparse
import base64
import hashlib
import json
import logging
import os
import random
import socket
import ssl
import sys
import threading

import flask
import requests

from collections import defaultdict
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from subprocess import Popen, check_output, call
from threading import Thread
from time import sleep, strftime
from urllib.parse import parse_qs, urlparse
from functions import generate_unique_id, nextFreeId, pretty_json
from functions.colors import convert_rgb_xy, convert_xy, hsv_to_rgb
from functions.html import (description, webform_hue, webform_linkbutton,
                            webform_milight, webformDeconz, webformTradfri, lightsHttp)
from functions.ssdp import ssdpBroadcast, ssdpSearch
from functions.network import getIpAddress
from functions.docker import dockerSetup
from functions.entertainment import entertainmentService
from functions.email import sendEmail
from functions.request import sendRequest
from functions.lightRequest import sendLightRequest, syncWithLights
from functions.updateGroup import updateGroupStats
from protocols import protocols, yeelight, tasmota, native_single, native_multi

update_lights_on_startup = False # if set to true all lights will be updated with last know state on startup.

ap = argparse.ArgumentParser()

# Arguements can also be passed as Environment Variables.
ap.add_argument("--ip", help="The IP address of the host system", type=str)
ap.add_argument("--http-port", help="The port to listen on for HTTP", type=int)
ap.add_argument("--mac", help="The MAC address of the host system", type=str)
ap.add_argument("--no-serve-https", action='store_true', help="Don't listen on port 443 with SSL")
ap.add_argument("--debug", action='store_true', help="Enables debug output")
ap.add_argument("--docker", action='store_true', help="Enables setup for use in docker container")
ap.add_argument("--ip-range", help="Set IP range for light discovery. Format: <START_IP>,<STOP_IP>", type=str)
ap.add_argument("--scan-on-host-ip", action='store_true', help="Scan the local IP address when discovering new lights")
ap.add_argument("--deconz", help="Provide the IP address of your Deconz host. 127.0.0.1 by default.", type=str)
ap.add_argument("--no-link-button", action='store_true', help="DANGEROUS! Don't require the link button to be pressed to pair the Hue app, just allow any app to connect")
ap.add_argument("--config-dir", help="The directory to store config.json and backups in", type=str)

args = ap.parse_args()

if args.debug or (os.getenv('DEBUG') and (os.getenv('DEBUG') == "true" or os.getenv('DEBUG') == "True")):
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    root.addHandler(ch)

if args.ip:
    pass
elif os.getenv('IP'):
    args.ip = os.getenv('IP')
else:
    args.ip = getIpAddress()

if args.http_port:
    pass
elif os.getenv('HTTP_PORT'):
    args.http_port = os.getenv('HTTP_PORT')
else:
    args.http_port = 80
args.https_port = 443 # Hardcoded for now

logging.info("Using Host %s:%s" % (args.ip, args.http_port))

if args.mac:
    dockerMAC = args.mac
    mac = str(args.mac).replace(":","")
    print("Host MAC given as " + mac)
elif os.getenv('MAC'):
    dockerMAC = os.getenv('MAC')
    mac = str(dockerMAC).replace(":","")
    print("Host MAC given as " + mac)
else:
    dockerMAC = check_output("cat /sys/class/net/$(ip -o addr | grep %s | awk '{print $2}')/address" % args.ip, shell=True).decode('utf-8')[:-1]
    mac = check_output("cat /sys/class/net/$(ip -o addr | grep %s | awk '{print $2}')/address" % args.ip, shell=True).decode('utf-8').replace(":","")[:-1]
logging.info(mac)

if args.docker or (os.getenv('DOCKER') and os.getenv('DOCKER') == "true"):
    print("Docker Setup Initiated")
    docker = True
    dockerSetup(dockerMAC)
    print("Docker Setup Complete")
elif os.getenv('MAC'):
    dockerMAC = os.getenv('MAC')
    mac = str(dockerMAC).replace(":","")
    print("Host MAC given as " + mac)
else:
    docker = False

if args.ip_range:
    ranges = args.ip_range.split(',')
    if ranges[0] and int(ranges[0]) >= 0:
        args.ip_range_start = int(ranges[0])
    else:
        args.ip_range_start = 0

    if ranges[1] and int(ranges[1]) > 0:
        args.ip_range_end = int(ranges[1])
    else:
        args.ip_range_end = 255
elif os.getenv('IP_RANGE'):
    ranges = os.getenv('IP_RANGE').split(',')
    if ranges[0] and int(ranges[0]) >= 0:
        args.ip_range_start = int(ranges[0])
    else:
        args.ip_range_start = 0

    if ranges[1] and int(ranges[1]) > 0:
        args.ip_range_end = int(ranges[1])
    else:
        args.ip_range_end = 255
else:
    args.ip_range_start = os.getenv('IP_RANGE_START', 0)
    args.ip_range_end = os.getenv('IP_RANGE_END', 255)
logging.info("IP range for light discovery: "+str(args.ip_range_start)+"-"+str(args.ip_range_end))

if args.deconz:
  deconz_ip = args.deconz
  print("Deconz IP given as " + deconz_ip)
elif os.getenv('DECONZ'):
  deconz_ip = os.getenv('DECONZ')
  print("Deconz IP given as " + deconz_ip)
else:
  deconz_ip = "127.0.0.1"
logging.info(deconz_ip)

protocols = [yeelight, tasmota, native_single, native_multi]

cwd = os.path.split(os.path.abspath(__file__))[0]
if not args.config_dir:
    args.config_dir = cwd

# Flask setup
WEBUI_FOLDER = '%s/web-ui/' % cwd
logging.warning(WEBUI_FOLDER)
app = flask.Flask(__name__, static_folder='%s/static' % WEBUI_FOLDER, static_url_path='/static/')

run_service = True

def initialize():
    global bridge_config, new_lights, sensors_state
    new_lights = {}
    sensors_state = {}

    try:
        path = args.config_dir + '/config.json'
        if os.path.exists(path):
            bridge_config = load_config(path)
            logging.info("Config loaded")
        else:
            logging.info("Config not found, creating new config from default settings")
            bridge_config = load_config(cwd + '/default-config.json')
            saveConfig()
    except Exception:
        logging.exception("CRITICAL! Config file was not loaded")
        sys.exit(1)

    ip_pices = args.ip.split(".")
    bridge_config["config"]["ipaddress"] = args.ip
    bridge_config["config"]["gateway"] = ip_pices[0] + "." +  ip_pices[1] + "." + ip_pices[2] + ".1"
    bridge_config["config"]["mac"] = mac[0] + mac[1] + ":" + mac[2] + mac[3] + ":" + mac[4] + mac[5] + ":" + mac[6] + mac[7] + ":" + mac[8] + mac[9] + ":" + mac[10] + mac[11]
    bridge_config["config"]["bridgeid"] = (mac[:6] + 'FFFE' + mac[6:]).upper()

    load_alarm_config()
    generateSensorsState()

def getLightsVersions():
    lights = {}
    githubCatalog = json.loads(requests.get('https://raw.githubusercontent.com/diyhue/Lights/master/catalog.json').text)
    for light in bridge_config["lights_address"].keys():
        if bridge_config["lights_address"][light]["protocol"] in ["native_single", "native_multi"]:
            if "light_nr" not in bridge_config["lights_address"][light] or bridge_config["lights_address"][light]["light_nr"] == 1:
                currentData = json.loads(requests.get('http://' + bridge_config["lights_address"][light]["ip"] + '/detect', timeout=3).text)
                lights[light] = {"name": currentData["name"], "currentVersion": currentData["version"], "lastVersion": githubCatalog[currentData["type"]]["version"], "firmware": githubCatalog[currentData["type"]]["filename"]}
    return lights

def updateLight(light, filename):
    firmware = requests.get('https://github.com/diyhue/Lights/raw/master/Arduino/bin/' + filename, allow_redirects=True)
    open('/tmp/' + filename, 'wb').write(firmware.content)
    file = {'update': open('/tmp/' + filename,'rb')}
    update = requests.post('http://' + bridge_config["lights_address"][light]["ip"] + '/update', files=file)

def try_fix_light(light):

    # HACK: add a bunch of default shit to try and make sure Alexa allows
    # color tuning
    light = {
        "swupdate":{"state":"noupdates",
            "lastinstall":"2020-03-15T19:21:27"},
        "type":"Color temperature light",
        "modelid":"LTW015",
        "manufacturername":"Signify Netherlands B.V.",
        "productname":"Hue ambiance lamp",
        "capabilities":{
            "certified":True,
            "control":{"mindimlevel":1000,
                "maxlumen":800,
                "ct":{"min":153,
                    "max":454}
                },
            "streaming":{"renderer":False,
                    "proxy":False}
            },
        "config":{"archetype":"sultanbulb",
            "function":"functional",
            "direction":"omnidirectional",
            "startup":{"mode":"safety",
                "configured":True}
            },
        **light
    }

    if "ct" in light['state'] and 'capabilities' not in light:
        light["capabilities"] = { "certified":True,
                "control": {"mindimlevel": 1000,
            "maxlumen": 800, "ct": {"min": 153, "max": 588}}}
        light['type'] = "Color temperature light"
    if 'ok' in light['state']:
        light['state']['ok'] = True
    light['state']["mode"] = "homeautomation"
    light['state']["alert"] = "select"
    light.update({
        "type":"Color temperature light",
        "modelid":"LTW015",
        "manufacturername":"Signify Netherlands B.V.",
        "productname":"Hue ambiance lamp",
        "swversion":"1.50.2_r30933",
        "swconfigid":"72630961",
        "productid":"Philips-LTW015-1-A19CTv2",
    })
    return light

# Make various updates to the config JSON structure to maintain backwards compatibility with old configs
def updateConfig():
    # Update swversion
    # XXX Hue app seems forward compatible with version numbers much bigger than the official
    # version. Just set these way forward so we don't have to deal with it for a while
    #if int(bridge_config["config"]["swversion"]) <= 1937113020:
    #    bridge_config["config"]["swversion"] = "1937113020"
    #    bridge_config["config"]["apiversion"] = "1.35.0"
    if int(bridge_config["config"]["swversion"]) < 1967113020:
        bridge_config["config"]["swversion"] = "1967113020"
        bridge_config["config"]["apiversion"] = "1.65.0"

    if 'alexa_enabled' not in bridge_config['config']:
        bridge_config['config']['alexa_enabled'] = False

    if "emulator" not in bridge_config:
        bridge_config["emulator"] = {"lights": {}, "sensors": {}}

    # Update deCONZ sensors
    for sensor_id, sensor in bridge_config["deconz"]["sensors"].items():
        if "modelid" not in sensor:
            sensor["modelid"] = bridge_config["sensors"][sensor["bridgeid"]]["modelid"]
        if sensor["modelid"] == "TRADFRI motion sensor":
            if "lightsensor" not in sensor:
                sensor["lightsensor"] = "internal"

    # Update sensors
    for sensor_id, sensor in bridge_config["sensors"].items():
        if sensor["type"] == "CLIPGenericStatus":
            sensor["state"]["status"] = 0

    # Update lights
    for light_id, light_address in bridge_config["lights_address"].items():
        light = bridge_config["lights"][light_id]

        if light_address["protocol"] == "native" and "mac" not in light_address:
            light_address["mac"] = light["uniqueid"][:17]
            light["uniqueid"] = generate_unique_id()

        if light_address["protocol"] == "atx_led":
            light_address['protocol'] = 'native_multi'
            addr_type, addr_id = light_address['light_nr']
            light_address['light_nr'] = '%s_%s' % (addr_type[0], addr_id)

        light = try_fix_light(light)
        bridge_config["lights"][light_id] = light

        # Update deCONZ protocol lights
        if light_address["protocol"] == "deconz":
            # Delete old keys
            for key in list(light):
                if key in ["hascolor", "ctmax", "ctmin", "etag"]:
                    del light[key]

            if light["modelid"].startswith("TRADFRI"):
                light.update({"manufacturername": "Philips", "swversion": "1.46.13_r26312"})

                light["uniqueid"] = generate_unique_id()

                if light["type"] == "Color temperature light":
                    light["modelid"] = "LTW001"
                elif light["type"] == "Color light":
                    light["modelid"] = "LCT015"
                    light["type"] = "Extended color light"
                elif light["type"] == "Dimmable light":
                    light["modelid"] = "LWB010"

        # Update Philips lights firmware version
        if "manufacturername" in light and light["manufacturername"] == "Philips":
            swversion = "1.46.13_r26312"
            if light["modelid"] in ["LST002", "LCT015", "LTW001", "LWB010"]:
                # Update archetype for various Philips models
                if light["modelid"] in ["LTW001", "LWB010"]:
                    archetype = "classicbulb"
                elif light["modelid"] == "LCT015":
                    archetype = "sultanbulb"
                elif light["modelid"] == "LST002":
                    archetype = "huelightstrip"
                    swversion = "5.127.1.26581"

                light["config"] = {"archetype": archetype, "function": "mixed", "direction": "omnidirectional"}

                # Update startup config
                if "startup" not in light["config"]:
                    light["config"]["startup"] = {"mode": "safety", "configured": False}

            # Finally, update the software version
            light["swversion"] = swversion

    #set entertainment streaming to inactive on start/restart
    for group_id, group in bridge_config["groups"].items():
        if "type" in group and group["type"] == "Entertainment":
            group["stream"].update({"active": False, "owner": None})

    #fix timezones bug
    if "values" not in bridge_config["capabilities"]["timezones"]:
        timezones = bridge_config["capabilities"]["timezones"]
        bridge_config["capabilities"]["timezones"] = {"values": timezones}

def addTradfriDimmer(sensor_id, group_id):
    rules = [{ "actions":[{"address": "/groups/" + group_id + "/action", "body":{ "on":True, "bri":1 }, "method": "PUT" }], "conditions":[{ "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx"}, { "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2002" }, { "address": "/groups/" + group_id + "/state/any_on", "operator": "eq", "value": "false" }], "name": "Remote " + sensor_id + " turn on" },{"actions":[{"address":"/groups/" + group_id + "/action", "body":{ "on": False}, "method":"PUT"}], "conditions":[{ "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }, { "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4002" }, { "address": "/groups/" + group_id + "/state/any_on", "operator": "eq", "value": "true" }, { "address": "/groups/" + group_id + "/action/bri", "operator": "eq", "value": "1"}], "name":"Dimmer Switch " + sensor_id + " off"}, { "actions":[{ "address": "/groups/" + group_id + "/action", "body":{ "on":False }, "method": "PUT" }], "conditions":[{ "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }, { "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3002" }, { "address": "/groups/" + group_id + "/state/any_on", "operator": "eq", "value": "true" }, { "address": "/groups/" + group_id + "/action/bri", "operator": "eq", "value": "1"}], "name": "Remote " + sensor_id + " turn off" }, { "actions": [{"address": "/groups/" + group_id + "/action", "body":{"bri_inc": 32, "transitiontime": 9}, "method": "PUT" }], "conditions": [{ "address": "/groups/" + group_id + "/state/any_on", "operator": "eq", "value": "true" },{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2002" }, {"address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx"}], "name": "Dimmer Switch " + sensor_id + " rotate right"}, { "actions": [{"address": "/groups/" + group_id + "/action", "body":{"bri_inc": 56, "transitiontime": 9}, "method": "PUT" }], "conditions": [{ "address": "/groups/" + group_id + "/state/any_on", "operator": "eq", "value": "true" },{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "1002" }, {"address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx"}], "name": "Dimmer Switch " + sensor_id + " rotate fast right"}, {"actions": [{"address": "/groups/" + group_id + "/action", "body": {"bri_inc": -32, "transitiontime": 9}, "method": "PUT"}], "conditions": [{ "address": "/groups/" + group_id + "/action/bri", "operator": "gt", "value": "1"},{"address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3002"}, {"address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx"}], "name": "Dimmer Switch " + sensor_id + " rotate left"}, {"actions": [{"address": "/groups/" + group_id + "/action", "body": {"bri_inc": -56, "transitiontime": 9}, "method": "PUT"}], "conditions": [{ "address": "/groups/" + group_id + "/action/bri", "operator": "gt", "value": "1"},{"address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4002"}, {"address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx"}], "name": "Dimmer Switch " + sensor_id + " rotate left"}]
    resourcelinkId = nextFreeId(bridge_config, "resourcelinks")
    bridge_config["resourcelinks"][resourcelinkId] = {"classid": 15555,"description": "Rules for sensor " + sensor_id, "links": ["/sensors/" + sensor_id], "name": "Emulator rules " + sensor_id,"owner": list(bridge_config["config"]["whitelist"])[0]}
    for rule in rules:
        ruleId = nextFreeId(bridge_config, "rules")
        bridge_config["rules"][ruleId] = rule
        bridge_config["rules"][ruleId].update({"created": get_utc_timestamp(), "lasttriggered": None, "owner": list(bridge_config["config"]["whitelist"])[0], "recycle": True, "status": "enabled", "timestriggered": 0})
        bridge_config["resourcelinks"][resourcelinkId]["links"].append("/rules/" + ruleId)

def addTradfriCtRemote(sensor_id, group_id):
    rules = [{"actions": [{"address": "/groups/" + group_id + "/action","body": {"on": True},"method": "PUT"}],"conditions": [{"address": "/sensors/" + sensor_id + "/state/lastupdated","operator": "dx"},{"address": "/sensors/" + sensor_id + "/state/buttonevent","operator": "eq","value": "1002"},{"address": "/groups/" + group_id + "/state/any_on","operator": "eq","value": "false"}],"name": "Remote " + sensor_id + " button on"}, {"actions": [{"address": "/groups/" + group_id + "/action","body": {"on": False},"method": "PUT"}],"conditions": [{"address": "/sensors/" + sensor_id + "/state/lastupdated","operator": "dx"},{"address": "/sensors/" + sensor_id + "/state/buttonevent","operator": "eq","value": "1002"},{"address": "/groups/" + group_id + "/state/any_on","operator": "eq","value": "true"}],"name": "Remote " + sensor_id + " button off"},{ "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": 30, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " up-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": 56, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " up-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": -30, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " dn-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": -56, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " dn-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "ct_inc": 50, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ctl-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "ct_inc": 100, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ctl-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "ct_inc": -50, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "5002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ct-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "ct_inc": -100, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "5001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ct-long" }]
    resourcelinkId = nextFreeId(bridge_config, "resourcelinks")
    bridge_config["resourcelinks"][resourcelinkId] = {"classid": 15555,"description": "Rules for sensor " + sensor_id, "links": ["/sensors/" + sensor_id], "name": "Emulator rules " + sensor_id,"owner": list(bridge_config["config"]["whitelist"])[0]}
    for rule in rules:
        ruleId = nextFreeId(bridge_config, "rules")
        bridge_config["rules"][ruleId] = rule
        bridge_config["rules"][ruleId].update({"created": get_utc_timestamp(), "lasttriggered": None, "owner": list(bridge_config["config"]["whitelist"])[0], "recycle": True, "status": "enabled", "timestriggered": 0})
        bridge_config["resourcelinks"][resourcelinkId]["links"].append("/rules/" + ruleId)

def addTradfriSceneRemote(sensor_id, group_id):
    rules = [{"actions": [{"address": "/groups/" + group_id + "/action","body": {"on": True},"method": "PUT"}],"conditions": [{"address": "/sensors/" + sensor_id + "/state/lastupdated","operator": "dx"},{"address": "/sensors/" + sensor_id + "/state/buttonevent","operator": "eq","value": "1002"},{"address": "/groups/" + group_id + "/state/any_on","operator": "eq","value": "false"}],"name": "Remote " + sensor_id + " button on"}, {"actions": [{"address": "/groups/" + group_id + "/action","body": {"on": False},"method": "PUT"}],"conditions": [{"address": "/sensors/" + sensor_id + "/state/lastupdated","operator": "dx"},{"address": "/sensors/" + sensor_id + "/state/buttonevent","operator": "eq","value": "1002"},{"address": "/groups/" + group_id + "/state/any_on","operator": "eq","value": "true"}],"name": "Remote " + sensor_id + " button off"},{ "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": 30, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " up-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": 56, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "2001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " up-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": -30, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " dn-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "bri_inc": -56, "transitiontime": 9 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "3001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " dn-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "scene_inc": -1 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ctl-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "scene_inc": -1 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "4001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ctl-long" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "scene_inc": 1 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "5002" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ct-press" }, { "actions": [{ "address": "/groups/" + group_id + "/action", "body": { "scene_inc": 1 }, "method": "PUT" }], "conditions": [{ "address": "/sensors/" + sensor_id + "/state/buttonevent", "operator": "eq", "value": "5001" }, { "address": "/sensors/" + sensor_id + "/state/lastupdated", "operator": "dx" }], "name": "Dimmer Switch " + sensor_id + " ct-long" }]
    resourcelinkId = nextFreeId(bridge_config, "resourcelinks")
    bridge_config["resourcelinks"][resourcelinkId] = {"classid": 15555,"description": "Rules for sensor " + sensor_id, "links": ["/sensors/" + sensor_id], "name": "Emulator rules " + sensor_id,"owner": list(bridge_config["config"]["whitelist"])[0]}
    for rule in rules:
        ruleId = nextFreeId(bridge_config, "rules")
        bridge_config["rules"][ruleId] = rule
        bridge_config["rules"][ruleId].update({"created": get_utc_timestamp(), "lasttriggered": None, "owner": list(bridge_config["config"]["whitelist"])[0], "recycle": True, "status": "enabled", "timestriggered": 0})
        bridge_config["resourcelinks"][resourcelinkId]["links"].append("/rules/" + ruleId)

def addHueMotionSensor(uniqueid, name="Hue motion sensor"):
    new_sensor_id = nextFreeId(bridge_config, "sensors")
    if uniqueid == "":
        uniqueid = "00:17:88:01:02:"
        if len(new_sensor_id) == 1:
            uniqueid += "0" + new_sensor_id
        else:
            uniqueid += new_sensor_id
    bridge_config["sensors"][nextFreeId(bridge_config, "sensors")] = {"name": "Hue temperature sensor 1", "uniqueid": uniqueid + ":d0:5b-02-0402", "type": "ZLLTemperature", "swversion": "6.1.0.18912", "state": {"temperature": None, "lastupdated": "none"}, "manufacturername": "Philips", "config": {"on": False, "battery": 100, "reachable": True, "alert":"none", "ledindication": False, "usertest": False, "pending": []}, "modelid": "SML001"}
    motion_sensor = nextFreeId(bridge_config, "sensors")
    bridge_config["sensors"][motion_sensor] = {"name": name, "uniqueid": uniqueid + ":d0:5b-02-0406", "type": "ZLLPresence", "swversion": "6.1.0.18912", "state": {"lastupdated": "none", "presence": None}, "manufacturername": "Philips", "config": {"on": False,"battery": 100,"reachable": True, "alert": "lselect", "ledindication": False, "usertest": False, "sensitivity": 2, "sensitivitymax": 2,"pending": []}, "modelid": "SML001"}
    bridge_config["sensors"][nextFreeId(bridge_config, "sensors")] = {"name": "Hue ambient light sensor", "uniqueid": uniqueid + ":d0:5b-02-0400", "type": "ZLLLightLevel", "swversion": "6.1.0.18912", "state": {"dark": True, "daylight": False, "lightlevel": 6000, "lastupdated": "none"}, "manufacturername": "Philips", "config": {"on": False,"battery": 100, "reachable": True, "alert": "none", "tholddark": 21597, "tholdoffset": 7000, "ledindication": False, "usertest": False, "pending": []}, "modelid": "SML001"}
    return(motion_sensor)

def addHueSwitch(uniqueid, sensorsType):
    new_sensor_id = nextFreeId(bridge_config, "sensors")
    if uniqueid == "":
        uniqueid = "00:17:88:01:02:"
        if len(new_sensor_id) == 1:
            uniqueid += "0" + new_sensor_id + ":4d:c6-02-fc00"
        else:
            uniqueid += new_sensor_id + ":4d:c6-02-fc00"
    bridge_config["sensors"][new_sensor_id] = {"state": {"buttonevent": 0, "lastupdated": "none"}, "config": {"on": True, "battery": 100, "reachable": True}, "name": "Dimmer Switch" if sensorsType == "ZLLSwitch" else "Tap Switch", "type": sensorsType, "modelid": "RWL021" if sensorsType == "ZLLSwitch" else "ZGPSWITCH", "manufacturername": "Philips", "swversion": "5.45.1.17846" if sensorsType == "ZLLSwitch" else "", "uniqueid": uniqueid}
    return(new_sensor_id)

#load config files
def load_config(path):
    with open(path, 'r', encoding="utf-8") as fp:
        return json.load(fp)

def resourceRecycle():
    sleep(5) #give time to application to delete all resources, then start the cleanup
    resourcelinks = {"groups": [],"lights": [], "sensors": [], "rules": [], "scenes": [], "schedules": []}
    for resourcelink in bridge_config["resourcelinks"].keys():
        for link in bridge_config["resourcelinks"][resourcelink]["links"]:
            link_parts = link.split("/")
            resourcelinks[link_parts[1]].append(link_parts[2])

    for resource in resourcelinks.keys():
        for key in list(bridge_config[resource]):
            if "recycle" in bridge_config[resource][key] and bridge_config[resource][key]["recycle"] and key not in resourcelinks[resource]:
                logging.info("delete " + resource + " / " + key)
                del bridge_config[resource][key]


def load_alarm_config():  #load and configure alarm virtual light
    if bridge_config["alarm_config"]["mail_username"] != "":
        logging.info("E-mail account configured")
        if "virtual_light" not in bridge_config["alarm_config"]:
            logging.info("Send test email")
            if sendEmail(bridge_config["alarm_config"], "dummy test"):
                logging.info("Mail succesfully sent\nCreate alarm virtual light")
                new_light_id = nextFreeId(bridge_config, "lights")
                bridge_config["lights"][new_light_id] = {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.690456, 0.295907], "ct": 461, "alert": "none", "effect": "none", "colormode": "xy", "reachable": True}, "type": "Extended color light", "name": "Alarm", "uniqueid": "1234567ffffff", "modelid": "LLC012", "swversion": "66009461"}
                bridge_config["alarm_config"]["virtual_light"] = new_light_id
            else:
                logging.info("Mail test failed")

def saveConfig(filename='config.json'):
    path = args.config_dir + '/' + filename
    with open(path, 'w', encoding="utf-8") as fp:
        json.dump(bridge_config, fp, sort_keys=True, indent=4, separators=(',', ': '))
    if docker:
        Popen(["cp", path, cwd + '/' + 'export/'])
    return path

def generateSensorsState():
    for sensor in bridge_config["sensors"]:
        if sensor not in sensors_state and "state" in bridge_config["sensors"][sensor]:
            sensors_state[sensor] = {"state": {}}
            for key in bridge_config["sensors"][sensor]["state"].keys():
                if key in ["lastupdated", "presence", "flag", "dark", "daylight", "status"]:
                    sensors_state[sensor]["state"].update({key: datetime.now()})


def schedulerProcessor():
    while run_service:
        for schedule_id, schedule in bridge_config["schedules"].items():
            try:
                delay = 0
                if schedule["status"] == "enabled":
                    ltime = schedule["localtime"]
                    if 'A' in ltime:
                        index = ltime.index('A')
                        [h, m, s] = [int(x) for x in ltime[index+1:].split(':')]
                        delay = random.randrange(0, h * 3600 + m * 60 + s)
                        schedule_time = ltime[:-9]
                    else:
                        schedule_time = ltime

                    execute = False
                    if schedule_time.startswith("W"):
                        pices = schedule_time.split('/T')
                        if int(pices[0][1:]) & (1 << 6 - datetime.today().weekday()):
                            if pices[1] == datetime.now().strftime("%H:%M:%S"):
                                logging.info("execute schedule: " + schedule_id + " withe delay " + str(delay))
                                execute = True
                    elif schedule_time.startswith("PT"):
                        timer = schedule_time[2:]
                        (h, m, s) = timer.split(':')
                        d = timedelta(hours=int(h), minutes=int(m), seconds=int(s))
                        if schedule["starttime"] == (datetime.utcnow() - d).strftime("%Y-%m-%dT%H:%M:%S"):
                            logging.info("execute timer: " + schedule_id + " withe delay " + str(delay))
                            execute = True
                            schedule["status"] = "disabled"
                    elif schedule_time == get_timestamp():
                        logging.info("execute schedule: " + schedule_id + " withe delay " + str(delay))
                        execute = True
                        if schedule["autodelete"]:
                            del bridge_config["schedules"][schedule_id]

                    if execute:
                        sendRequest(schedule["command"]["address"],
                                schedule["command"]["method"],
                                json.dumps(schedule["command"]["body"]),
                                1, delay)

            except Exception as e:
                logging.info("Exception while processing the schedule " + schedule_id + " | " + str(e))

        if (datetime.now().strftime("%M:%S") == "00:10"): #auto save configuration every hour
            saveConfig()
            Thread(target=daylightSensor).start()
            if (datetime.now().strftime("%H") == "23" and datetime.now().strftime("%A") == "Sunday"): #backup config every Sunday at 23:00:10
                saveConfig("config-backup-" + datetime.now().strftime("%Y-%m-%d") + ".json")
        sleep(1)

def switchScene(group, direction):
    group_scenes = []
    current_position = -1
    possible_current_position = -1 # used in case the brigtness was changes and will be no perfect match (scene lightstates vs light states)
    break_next = False
    for scene in bridge_config["scenes"]:
        if bridge_config["groups"][group]["lights"][0] in bridge_config["scenes"][scene]["lights"]:
            group_scenes.append(scene)
            if break_next: # don't lose time as this is the scene we need
                break
            is_current_scene = True
            is_possible_current_scene = True
            for light in bridge_config["scenes"][scene]["lightstates"]:
                for key in bridge_config["scenes"][scene]["lightstates"][light].keys():
                    if key == "xy":
                        if not bridge_config["scenes"][scene]["lightstates"][light]["xy"][0] == bridge_config["lights"][light]["state"]["xy"][0] and not bridge_config["scenes"][scene]["lightstates"][light]["xy"][1] == bridge_config["lights"][light]["state"]["xy"][1]:
                            is_current_scene = False
                    else:
                        if not bridge_config["scenes"][scene]["lightstates"][light][key] == bridge_config["lights"][light]["state"][key]:
                            is_current_scene = False
                            if not key == "bri":
                                is_possible_current_scene = False
            if is_current_scene:
                current_position = len(group_scenes) -1
                if direction == -1 and len(group_scenes) != 1:
                    break
                elif len(group_scenes) != 1:
                    break_next = True
            elif  is_possible_current_scene:
                possible_current_position = len(group_scenes) -1

    matched_scene = ""
    if current_position + possible_current_position == -2:
        logging.info("current scene not found, reset to zero")
        if len(group_scenes) != 0:
            matched_scene = group_scenes[0]
        else:
            logging.info("error, no scenes found")
            return
    elif current_position != -1:
        if len(group_scenes) -1 < current_position + direction:
            matched_scene = group_scenes[0]
        else:
            matched_scene = group_scenes[current_position + direction]
    elif possible_current_position != -1:
        if len(group_scenes) -1 < possible_current_position + direction:
            matched_scene = group_scenes[0]
        else:
            matched_scene = group_scenes[possible_current_position + direction]
    logging.info("matched scene " + bridge_config["scenes"][matched_scene]["name"])

    for light in bridge_config["scenes"][matched_scene]["lights"]:
        bridge_config["lights"][light]["state"].update(bridge_config["scenes"][matched_scene]["lightstates"][light])
        if "xy" in bridge_config["scenes"][matched_scene]["lightstates"][light]:
            bridge_config["lights"][light]["state"]["colormode"] = "xy"
        elif "ct" in bridge_config["scenes"][matched_scene]["lightstates"][light]:
            bridge_config["lights"][light]["state"]["colormode"] = "ct"
        elif "hue" or "sat" in bridge_config["scenes"][matched_scene]["lightstates"][light]:
            bridge_config["lights"][light]["state"]["colormode"] = "hs"
        sendLightRequest(light, bridge_config["scenes"][matched_scene]["lightstates"][light], bridge_config["lights"], bridge_config["lights_address"])
        updateGroupStats(light, bridge_config["lights"], bridge_config["groups"])


def checkRuleConditions(rule, sensor, current_time, ignore_ddx=False):
    ddx = 0
    sensor_found = False
    ddx_sensor = []
    for condition in bridge_config["rules"][rule]["conditions"]:
        try:
            url_pices = condition["address"].split('/')
            if url_pices[1] == "sensors" and sensor == url_pices[2]:
                sensor_found = True
            value = bridge_config[url_pices[1]][url_pices[2]][url_pices[3]][url_pices[4]]
            if condition["operator"] == "eq":
                if condition["value"] == "true":
                    if not value:
                        return [False, 0]
                elif condition["value"] == "false":
                    if value:
                        return [False, 0]
                else:
                    if not int(value) == int(condition["value"]):
                        return [False, 0]
            elif condition["operator"] == "gt":
                if not int(value) > int(condition["value"]):
                    return [False, 0]
            elif condition["operator"] == "lt":
                if not int(value) < int(condition["value"]):
                    return [False, 0]
            elif condition["operator"] == "dx":
                if not sensors_state[url_pices[2]][url_pices[3]][url_pices[4]] == current_time:
                    return [False, 0]
            elif condition["operator"] == "in":
                periods = condition["value"].split('/')
                if condition["value"][0] == "T":
                    timeStart = datetime.strptime(periods[0], "T%H:%M:%S").time()
                    timeEnd = datetime.strptime(periods[1], "T%H:%M:%S").time()
                    now_time = datetime.now().time()
                    if timeStart < timeEnd:
                        if not timeStart <= now_time <= timeEnd:
                            return [False, 0]
                    else:
                        if not (timeStart <= now_time or now_time <= timeEnd):
                            return [False, 0]
            elif condition["operator"] == "ddx" and ignore_ddx is False:
                if not sensors_state[url_pices[2]][url_pices[3]][url_pices[4]] == current_time:
                    return [False, 0]
                else:
                    ddx = int(condition["value"][2:4]) * 3600 + int(condition["value"][5:7]) * 60 + int(condition["value"][-2:])
                    ddx_sensor = url_pices
        except Exception as e:
            logging.info("rule " + rule + " failed, reason:" + str(e))


    if sensor_found:
        return [True, ddx, ddx_sensor]
    else:
        return [False]

def ddxRecheck(rule, sensor, current_time, ddx_delay, ddx_sensor):
    for x in range(ddx_delay):
        if current_time != sensors_state[ddx_sensor[2]][ddx_sensor[3]][ddx_sensor[4]]:
            logging.info("ddx rule " + rule + " canceled after " + str(x) + " seconds")
            return # rule not valid anymore because sensor state changed while waiting for ddx delay
        sleep(1)
    current_time = datetime.now()
    rule_state = checkRuleConditions(rule, sensor, current_time, True)
    if rule_state[0]: #if all conditions are meet again
        logging.info("delayed rule " + rule + " is triggered")
        bridge_config["rules"][rule]["lasttriggered"] = current_time.strftime("%Y-%m-%dT%H:%M:%S")
        bridge_config["rules"][rule]["timestriggered"] += 1
        for action in bridge_config["rules"][rule]["actions"]:
            sendRequest("/api/" + bridge_config["rules"][rule]["owner"] + action["address"], action["method"], json.dumps(action["body"]))

def rulesProcessor(sensor, current_time):
    bridge_config["config"]["localtime"] = current_time.strftime("%Y-%m-%dT%H:%M:%S") #required for operator dx to address /config/localtime
    actionsToExecute = []
    for rule in bridge_config["rules"].keys():
        if bridge_config["rules"][rule]["status"] == "enabled":
            rule_result = checkRuleConditions(rule, sensor, current_time)
            if rule_result[0]:
                if rule_result[1] == 0: #is not ddx rule
                    logging.info("rule " + rule + " is triggered")
                    bridge_config["rules"][rule]["lasttriggered"] = current_time.strftime("%Y-%m-%dT%H:%M:%S")
                    bridge_config["rules"][rule]["timestriggered"] += 1
                    for action in bridge_config["rules"][rule]["actions"]:
                        actionsToExecute.append(action)
                else: #if ddx rule
                    logging.info("ddx rule " + rule + " will be re validated after " + str(rule_result[1]) + " seconds")
                    Thread(target=ddxRecheck, args=[rule, sensor, current_time, rule_result[1], rule_result[2]]).start()
    for action in actionsToExecute:
        sendRequest("/api/" +    list(bridge_config["config"]["whitelist"])[0] + action["address"], action["method"], json.dumps(action["body"]))


def find_light_in_config_from_address(bridge_config, address):
    for light_id, light_address in bridge_config["lights_address"].items():
        if (light_address["protocol"] == address['protocol'] and light_address["mac"] == address['mac'] and
                light_address["light_nr"] == address['light_nr']):
            return light_id
    return None

def find_light_in_config_from_uid(bridge_config, unique_id):
    for light in bridge_config["lights"].keys():
        if bridge_config["lights"][light]["uniqueid"] == unique_id:
            return light
    return None

def scan_for_lights(): #scan for ESP8266 lights and strips
    #Thread(target=yeelight.discover, args=[bridge_config, new_lights]).start()
    #Thread(target=tasmota.discover, args=[bridge_config, new_lights]).start()

    for protocol in [native_single]:
        for light, light_address in protocol.discover(args):
            light_name = light['name']

            light = try_fix_light(light)

            # Try to find light in existing config
            light_id = find_light_in_config_from_address(bridge_config, light_address)

            if light_id:
                logging.info("Updating old light: " + light_name)
                # Light found, update config
                old_address = bridge_config["lights_address"][light_id]
                old_address.update(light_address)
            else:
                # Light not found, add to config
                logging.info("Add new light: " + light_name)

                new_light_id = nextFreeId(bridge_config, "lights")
                bridge_config["lights"][new_light_id] = light
                bridge_config["lights_address"][new_light_id] = light_address
                new_lights.update({new_light_id: {"name": light_name}})

    #scanDeconz()
    #scanTradfri()
    saveConfig()


def longPressButton(sensor, buttonevent):
    logging.info("long press detected")
    sleep(1)
    while bridge_config["sensors"][sensor]["state"]["buttonevent"] == buttonevent:
        logging.info("still pressed")
        current_time =  datetime.now()
        sensors_state[sensor]["state"]["lastupdated"] = current_time
        rulesProcessor(sensor, current_time)
        sleep(0.5)
    return


def motionDetected(sensor):
    logging.info("monitoring motion sensor " + sensor)
    while bridge_config["sensors"][sensor]["state"]["presence"] == True:
        if datetime.utcnow() - datetime.strptime(bridge_config["sensors"][sensor]["state"]["lastupdated"], "%Y-%m-%dT%H:%M:%S") > timedelta(seconds=30):
            bridge_config["sensors"][sensor]["state"]["presence"] = False
            bridge_config["sensors"][sensor]["state"]["lastupdated"] = get_utc_timestamp()
            current_time =  datetime.now()
            sensors_state[sensor]["state"]["presence"] = current_time
            rulesProcessor(sensor, current_time)
        sleep(1)
    logging.info("set motion sensor " + sensor + " to motion = False")
    return


def scanTradfri():
    if "tradfri" in bridge_config:
        tradri_devices = json.loads(check_output("./coap-client-linux -m get -u \"" + bridge_config["tradfri"]["identity"] + "\" -k \"" + bridge_config["tradfri"]["psk"] + "\" \"coaps://" + bridge_config["tradfri"]["ip"] + ":5684/15001\"", shell=True).decode('utf-8').rstrip('\n').split("\n")[-1])
        logging.info(pretty_json(tradri_devices))
        lights_found = 0
        for device in tradri_devices:
            device_parameters = json.loads(check_output("./coap-client-linux -m get -u \"" + bridge_config["tradfri"]["identity"] + "\" -k \"" + bridge_config["tradfri"]["psk"] + "\" \"coaps://" + bridge_config["tradfri"]["ip"] + ":5684/15001/" + str(device) +"\"", shell=True).decode('utf-8').rstrip('\n').split("\n")[-1])
            if "3311" in device_parameters:
                new_light = True
                for light in bridge_config["lights_address"]:
                    if bridge_config["lights_address"][light]["protocol"] == "ikea_tradfri" and bridge_config["lights_address"][light]["device_id"] == device:
                        new_light = False
                        break
                if new_light:
                    lights_found += 1
                    #register new tradfri lightdevice_id
                    logging.info("register tradfi light " + device_parameters["9001"])
                    new_light_id = nextFreeId(bridge_config, "lights")
                    bridge_config["lights"][new_light_id] = {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Extended color light", "name": device_parameters["9001"], "uniqueid": "1234567" + str(device), "modelid": "LLM010", "swversion": "66009461", "manufacturername": "Philips"}
                    new_lights.update({new_light_id: {"name": device_parameters["9001"]}})
                    bridge_config["lights_address"][new_light_id] = {"device_id": device, "preshared_key": bridge_config["tradfri"]["psk"], "identity": bridge_config["tradfri"]["identity"], "ip": bridge_config["tradfri"]["ip"], "protocol": "ikea_tradfri"}
        return lights_found
    else:
        return 0

def websocketClient():
    from ws4py.client.threadedclient import WebSocketClient
    class EchoClient(WebSocketClient):
        def opened(self):
            self.send("hello")

        def closed(self, code, reason=None):
            logging.info(("deconz websocket disconnected", code, reason))
            del bridge_config["deconz"]["websocketport"]

        def received_message(self, m):
            logging.info(m)
            message = json.loads(str(m))
            try:
                if message["r"] == "sensors":
                    bridge_sensor_id = bridge_config["deconz"]["sensors"][message["id"]]["bridgeid"]
                    if "state" in message and bridge_config["sensors"][bridge_sensor_id]["config"]["on"]:

                        #change codes for emulated hue Switches
                        if "hueType" in bridge_config["deconz"]["sensors"][message["id"]]:
                            rewriteDict = {"ZGPSwitch": {1002: 34, 3002: 16, 4002: 17, 5002: 18}, "ZLLSwitch" : {1002 : 1000, 2002: 2000, 2001: 2001, 2003: 2002, 3001: 3001, 3002: 3000, 3003: 3002, 4002: 4000, 5002: 4000} }
                            message["state"]["buttonevent"] = rewriteDict[bridge_config["deconz"]["sensors"][message["id"]]["hueType"]][message["state"]["buttonevent"]]
                        #end change codes for emulated hue Switches

                        #convert tradfri motion sensor notification to look like Hue Motion Sensor
                        if message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["modelid"] == "TRADFRI motion sensor":
                            #find the light sensor id
                            light_sensor = "0"
                            for sensor in bridge_config["sensors"].keys():
                                if bridge_config["sensors"][sensor]["type"] == "ZLLLightLevel" and bridge_config["sensors"][sensor]["uniqueid"] == bridge_config["sensors"][bridge_sensor_id]["uniqueid"][:-1] + "0":
                                    light_sensor = sensor
                                    break
                            if bridge_config["deconz"]["sensors"][message["id"]]["lightsensor"] == "none":
                                message["state"].update({"dark": True})
                            elif bridge_config["deconz"]["sensors"][message["id"]]["lightsensor"] == "astral":
                                message["state"]["dark"] = not bridge_config["sensors"]["1"]["state"]["daylight"]

                            elif bridge_config["deconz"]["sensors"][message["id"]]["lightsensor"] == "combined":
                                if not bridge_config["sensors"]["1"]["state"]["daylight"]:
                                    message["state"]["dark"] = True
                                elif (datetime.strptime(message["state"]["lastupdated"], "%Y-%m-%dT%H:%M:%S") - datetime.strptime(bridge_config["sensors"][light_sensor]["state"]["lastupdated"], "%Y-%m-%dT%H:%M:%S")).total_seconds() > 1200:
                                    message["state"]["dark"] = False

                            if  message["state"]["dark"]:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 6000
                            else:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 25000
                            bridge_config["sensors"][light_sensor]["state"]["dark"] = message["state"]["dark"]
                            bridge_config["sensors"][light_sensor]["state"]["daylight"] = not message["state"]["dark"]
                            bridge_config["sensors"][light_sensor]["state"]["lastupdated"] = message["state"]["lastupdated"]

                        #Xiaomi motion w/o light level sensor
                        if message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["modelid"] == "lumi.sensor_motion":
                            for sensor in bridge_config["sensors"].keys():
                                if bridge_config["sensors"][sensor]["type"] == "ZLLLightLevel" and bridge_config["sensors"][sensor]["uniqueid"] == bridge_config["sensors"][bridge_sensor_id]["uniqueid"][:-1] + "0":
                                    light_sensor = sensor
                                    break

                            if bridge_config["sensors"]["1"]["modelid"] == "PHDL00" and bridge_config["sensors"]["1"]["state"]["daylight"]:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 25000
                                bridge_config["sensors"][light_sensor]["state"]["dark"] = False
                            else:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 6000
                                bridge_config["sensors"][light_sensor]["state"]["dark"] = True

                        #convert xiaomi motion sensor to hue sensor
                        if message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["modelid"] == "lumi.sensor_motion.aq2" and message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["type"] == "ZHALightLevel":
                            bridge_config["sensors"][bridge_sensor_id]["state"].update(message["state"])
                            return
                        ##############

                        ##convert xiaomi vibration sensor states to hue motion sensor
                        if message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["modelid"] == "lumi.vibration.aq1":
                            #find the light sensor id
                            light_sensor = "0"
                            for sensor in bridge_config["sensors"].keys():
                                if bridge_config["sensors"][sensor]["type"] == "ZLLLightLevel" and bridge_config["sensors"][sensor]["uniqueid"] == bridge_config["sensors"][bridge_sensor_id]["uniqueid"][:-1] + "0":
                                    light_sensor = sensor
                                    break
                            logging.info("Vibration: emulated light sensor id is  " + light_sensor)
                            if bridge_config["deconz"]["sensors"][message["id"]]["lightsensor"] == "none":
                                message["state"].update({"dark": True})
                                logging.info("Vibration: set light sensor to dark because 'lightsensor' = 'none' ")
                            elif bridge_config["deconz"]["sensors"][message["id"]]["lightsensor"] == "astral":
                                message["state"]["dark"] = not bridge_config["sensors"]["1"]["state"]["daylight"]
                                logging.info("Vibration: set light sensor to " + str(not bridge_config["sensors"]["1"]["state"]["daylight"]) + " because 'lightsensor' = 'astral' ")

                            if  message["state"]["dark"]:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 6000
                            else:
                                bridge_config["sensors"][light_sensor]["state"]["lightlevel"] = 25000
                            bridge_config["sensors"][light_sensor]["state"]["dark"] = message["state"]["dark"]
                            bridge_config["sensors"][light_sensor]["state"]["daylight"] = not message["state"]["dark"]
                            bridge_config["sensors"][light_sensor]["state"]["lastupdated"] = message["state"]["lastupdated"]
                            message["state"] = {"motion": True, "lastupdated": message["state"]["lastupdated"]} #empty the message state for non Hue motion states (we need to know there was an event only)
                            logging.info("Vibration: set motion = True")
                            Thread(target=motionDetected, args=[bridge_sensor_id]).start()


                        bridge_config["sensors"][bridge_sensor_id]["state"].update(message["state"])
                        current_time = datetime.now()
                        for key in message["state"].keys():
                            sensors_state[bridge_sensor_id]["state"][key] = current_time
                        rulesProcessor(bridge_sensor_id, current_time)
                        if "buttonevent" in message["state"] and bridge_config["deconz"]["sensors"][message["id"]]["modelid"] in ["TRADFRI remote control","RWL021"]:
                            if message["state"]["buttonevent"] in [2001, 3001, 4001, 5001]:
                                Thread(target=longPressButton, args=[bridge_sensor_id, message["state"]["buttonevent"]]).start()
                        if "presence" in message["state"] and message["state"]["presence"] and "virtual_light" in bridge_config["alarm_config"] and bridge_config["lights"][bridge_config["alarm_config"]["virtual_light"]]["state"]["on"]:
                            sendEmail(bridge_config["alarm_config"], bridge_config["sensors"][bridge_sensor_id]["name"])
                            bridge_config["alarm_config"]["virtual_light"]
                    elif "config" in message and bridge_config["sensors"][bridge_sensor_id]["config"]["on"]:
                        bridge_config["sensors"][bridge_sensor_id]["config"].update(message["config"])
                elif message["r"] == "lights":
                    bridge_light_id = bridge_config["deconz"]["lights"][message["id"]]["bridgeid"]
                    if "state" in message and "colormode" not in message["state"]:
                        bridge_config["lights"][bridge_light_id]["state"].update(message["state"])
                        updateGroupStats(bridge_light_id, bridge_config["lights"], bridge_config["groups"])
            except Exception as e:
                logging.info("unable to process the request" + str(e))

    try:
        ws = EchoClient('ws://' + deconz_ip + ':' + str(bridge_config["deconz"]["websocketport"]))
        ws.connect()
        ws.run_forever()
    except KeyboardInterrupt:
        ws.close()

def scanDeconz():
    if not bridge_config["deconz"]["enabled"]:
        if "username" not in bridge_config["deconz"]:
            try:
                registration = json.loads(sendRequest("http://" + deconz_ip + ":" + str(bridge_config["deconz"]["port"]) + "/api", "POST", "{\"username\": \"283145a4e198cc6535\", \"devicetype\":\"Hue Emulator\"}"))
            except:
                logging.info("registration fail, is the link button pressed?")
                return
            if "success" in registration[0]:
                bridge_config["deconz"]["username"] = registration[0]["success"]["username"]
                bridge_config["deconz"]["enabled"] = True
    if "username" in bridge_config["deconz"]:
        deconz_config = json.loads(sendRequest("http://" + deconz_ip + ":" + str(bridge_config["deconz"]["port"]) + "/api/" + bridge_config["deconz"]["username"] + "/config", "GET", "{}"))
        bridge_config["deconz"]["websocketport"] = deconz_config["websocketport"]

        #lights
        deconz_lights = json.loads(sendRequest("http://" + deconz_ip + ":" + str(bridge_config["deconz"]["port"]) + "/api/" + bridge_config["deconz"]["username"] + "/lights", "GET", "{}"))
        for light in deconz_lights:
            if light not in bridge_config["deconz"]["lights"] and "modelid" in deconz_lights[light]:
                new_light_id = nextFreeId(bridge_config, "lights")
                logging.info("register new light " + new_light_id)
                bridge_config["lights"][new_light_id] = deconz_lights[light]
                bridge_config["lights_address"][new_light_id] = {"username": bridge_config["deconz"]["username"], "light_id": light, "ip": deconz_ip + ":" + str(bridge_config["deconz"]["port"]), "protocol": "deconz"}
                bridge_config["deconz"]["lights"][light] = {"bridgeid": new_light_id, "modelid": deconz_lights[light]["modelid"], "type": deconz_lights[light]["type"]}

        #sensors
        deconz_sensors = json.loads(sendRequest("http://" + deconz_ip + ":" + str(bridge_config["deconz"]["port"]) + "/api/" + bridge_config["deconz"]["username"] + "/sensors", "GET", "{}"))
        for sensor in deconz_sensors:
            if sensor not in bridge_config["deconz"]["sensors"] and "modelid" in deconz_sensors[sensor]:
                new_sensor_id = nextFreeId(bridge_config, "sensors")
                if deconz_sensors[sensor]["modelid"] in ["TRADFRI remote control", "TRADFRI wireless dimmer"]:
                    logging.info("register new " + deconz_sensors[sensor]["modelid"])
                    bridge_config["sensors"][new_sensor_id] = {"config": deconz_sensors[sensor]["config"], "manufacturername": deconz_sensors[sensor]["manufacturername"], "modelid": deconz_sensors[sensor]["modelid"], "name": deconz_sensors[sensor]["name"], "state": deconz_sensors[sensor]["state"], "type": deconz_sensors[sensor]["type"], "uniqueid": deconz_sensors[sensor]["uniqueid"]}
                    if "swversion" in  deconz_sensors[sensor]:
                        bridge_config["sensors"][new_sensor_id]["swversion"] = deconz_sensors[sensor]["swversion"]
                    bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": new_sensor_id, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"]}
                elif deconz_sensors[sensor]["modelid"] == "TRADFRI motion sensor":
                    logging.info("register TRADFRI motion sensor as Philips Motion Sensor")
                    newMotionSensorId = addHueMotionSensor("", deconz_sensors[sensor]["name"])
                    bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": newMotionSensorId, "triggered": False, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"], "lightsensor": "internal"}
                elif deconz_sensors[sensor]["modelid"] == "lumi.vibration.aq1":
                    logging.info("register Xiaomi Vibration sensor as Philips Motion Sensor")
                    newMotionSensorId = addHueMotionSensor("", deconz_sensors[sensor]["name"])
                    bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": newMotionSensorId, "triggered": False, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"], "lightsensor": "astral"}
                elif deconz_sensors[sensor]["modelid"] == "lumi.sensor_motion.aq2":
                    if deconz_sensors[sensor]["type"] == "ZHALightLevel":
                        logging.info("register new Xiaomi light sensor")
                        bridge_config["sensors"][new_sensor_id] = {"name": "Hue ambient light sensor 1", "uniqueid": "00:17:88:01:02:" + deconz_sensors[sensor]["uniqueid"][12:], "type": "ZLLLightLevel", "swversion": "6.1.0.18912", "state": {"dark": True, "daylight": False, "lightlevel": 6000, "lastupdated": "none"}, "manufacturername": "Philips", "config": {"on": False,"battery": 100, "reachable": True, "alert": "none", "tholddark": 21597, "tholdoffset": 7000, "ledindication": False, "usertest": False, "pending": []}, "modelid": "SML001"}
                        bridge_config["sensors"][nextFreeId(bridge_config, "sensors")] = {"name": "Hue temperature sensor 1", "uniqueid": "00:17:88:01:02:" + deconz_sensors[sensor]["uniqueid"][12:-1] + "2", "type": "ZLLTemperature", "swversion": "6.1.0.18912", "state": {"temperature": None, "lastupdated": "none"}, "manufacturername": "Philips", "config": {"on": False, "battery": 100, "reachable": True, "alert":"none", "ledindication": False, "usertest": False, "pending": []}, "modelid": "SML001"}
                        bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": new_sensor_id, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"]}
                    elif deconz_sensors[sensor]["type"] == "ZHAPresence":
                        logging.info("register new Xiaomi motion sensor")
                        bridge_config["sensors"][new_sensor_id] = {"name": deconz_sensors[sensor]["name"], "uniqueid": "00:17:88:01:02:" + deconz_sensors[sensor]["uniqueid"][12:], "type": "ZLLPresence", "swversion": "6.1.0.18912", "state": {"lastupdated": "none", "presence": None}, "manufacturername": "Philips", "config": {"on": False,"battery": 100,"reachable": True, "alert": "lselect", "ledindication": False, "usertest": False, "sensitivity": 2, "sensitivitymax": 2,"pending": []}, "modelid": "SML001"}
                        bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": new_sensor_id, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"]}
                elif deconz_sensors[sensor]["modelid"] == "lumi.sensor_motion":
                    logging.info("register Xiaomi Motion sensor w/o light sensor")
                    newMotionSensorId = addHueMotionSensor("", deconz_sensors[sensor]["name"])
                    bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": newMotionSensorId, "triggered": False, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"]}
                else:
                    bridge_config["sensors"][new_sensor_id] = deconz_sensors[sensor]
                    bridge_config["deconz"]["sensors"][sensor] = {"bridgeid": new_sensor_id, "modelid": deconz_sensors[sensor]["modelid"], "type": deconz_sensors[sensor]["type"]}

            else: #temporary patch for config compatibility with new release
                bridge_config["deconz"]["sensors"][sensor]["modelid"] = deconz_sensors[sensor]["modelid"]
                bridge_config["deconz"]["sensors"][sensor]["type"] = deconz_sensors[sensor]["type"]
        generateSensorsState()

        if "websocketport" in bridge_config["deconz"]:
            logging.info("Starting deconz websocket")
            Thread(target=websocketClient).start()


def updateAllLights():
    ## apply last state on startup to all bulbs, usefull if there was a power outage
    if bridge_config["deconz"]["enabled"]:
        sleep(60) #give 1 minute for deconz to have ZigBee network ready
    for light in bridge_config["lights_address"]:
        payload = {}
        payload["on"] = bridge_config["lights"][light]["state"]["on"]
        if payload["on"] and "bri" in bridge_config["lights"][light]["state"]:
            payload["bri"] = bridge_config["lights"][light]["state"]["bri"]
        sendLightRequest(light, payload, bridge_config["lights"], bridge_config["lights_address"])
        sleep(0.5)
        logging.info("update status for light " + light)

def manageDeviceLights(lights_state):
    protocol = bridge_config["lights_address"][list(lights_state.keys())[0]]["protocol"]
    payload = {}
    for light in lights_state.keys():
        if protocol == "native_multi":
            payload[bridge_config["lights_address"][light]["light_nr"]] = lights_state[light]
        elif protocol in ["native", "native_single", "milight"]:
            sendLightRequest(light, lights_state[light], bridge_config["lights"], bridge_config["lights_address"])
            if protocol == "milight": #hotfix to avoid milight hub overload
                sleep(0.05)
        else:
            Thread(target=sendLightRequest, args=[light, lights_state[light], bridge_config["lights"], bridge_config["lights_address"]]).start()
            sleep(0.1)
    if protocol == "native_multi":
        requests.put("http://"+bridge_config["lights_address"][list(lights_state.keys())[0]]["ip"]+"/state", json=payload, timeout=3)



def splitLightsToDevices(group, state, scene={}):
    groups = []
    if group == "0":
        for grp in bridge_config["groups"].keys():
            groups.append(grp)
    else:
        groups.append(group)

    lightsData = {}
    if len(scene) == 0:
        for grp in groups:
            if "bri_inc" in state:
                bridge_config["groups"][grp]["action"]["bri"] += int(state["bri_inc"])
                if bridge_config["groups"][grp]["action"]["bri"] > 254:
                    bridge_config["groups"][grp]["action"]["bri"] = 254
                elif bridge_config["groups"][grp]["action"]["bri"] < 1:
                    bridge_config["groups"][grp]["action"]["bri"] = 1
                bridge_config["groups"][grp]["state"]["bri"] = bridge_config["groups"][grp]["action"]["bri"]
                del state["bri_inc"]
                state.update({"bri": bridge_config["groups"][grp]["action"]["bri"]})
            elif "ct_inc" in state:
                bridge_config["groups"][grp]["action"]["ct"] += int(state["ct_inc"])
                if bridge_config["groups"][grp]["action"]["ct"] > 500:
                    bridge_config["groups"][grp]["action"]["ct"] = 500
                elif bridge_config["groups"][grp]["action"]["ct"] < 153:
                    bridge_config["groups"][grp]["action"]["ct"] = 153
                bridge_config["groups"][grp]["state"]["ct"] = bridge_config["groups"][grp]["action"]["ct"]
                del state["ct_inc"]
                state.update({"ct": bridge_config["groups"][grp]["action"]["ct"]})
            for light in bridge_config["groups"][grp]["lights"]:
                lightsData[light] = state
    else:
        lightsData = scene

    # Make sure any lights haven't been deleted
    lightsData = {k: v for k, v in lightsData.items() if k in bridge_config["lights_address"]}

    deviceIp = {}
    for light in lightsData.keys():
        if bridge_config["lights_address"][light]["ip"] not in deviceIp:
            deviceIp[bridge_config["lights_address"][light]["ip"]] = {}
        deviceIp[bridge_config["lights_address"][light]["ip"]][light] = lightsData[light]
    for ip in deviceIp:
        Thread(target=manageDeviceLights, args=[deviceIp[ip]]).start()
    ### update light details
    for light in lightsData.keys():
        if "xy" in lightsData[light]:
            bridge_config["lights"][light]["state"]["colormode"] = "xy"
        elif "ct" in lightsData[light]:
            bridge_config["lights"][light]["state"]["colormode"] = "ct"
        elif "hue" in lightsData[light]:
            bridge_config["lights"][light]["state"]["colormode"] = "hs"
        if "transitiontime" in lightsData[light]:
            del lightsData[light]["transitiontime"]
        bridge_config["lights"][light]["state"].update(lightsData[light])
    updateGroupStats(list(lightsData.keys())[0], bridge_config["lights"], bridge_config["groups"])


def groupZero(state):
    lightsData = {}
    for light in bridge_config["lights"].keys():
        if "virtual_light" not in bridge_config["alarm_config"] or light != bridge_config["alarm_config"]["virtual_light"]:
            lightsData[light] = state
    Thread(target=splitLightsToDevices, args=["0", {}, lightsData]).start()
    for group in bridge_config["groups"].keys():
        bridge_config["groups"][group]["action"].update(state)
        if "on" in state:
            bridge_config["groups"][group]["state"]["any_on"] = state["on"]
            bridge_config["groups"][group]["state"]["all_on"] = state["on"]


def get_timestamp():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

def get_utc_timestamp():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")

def daylightSensor():
    if bridge_config["sensors"]["1"]["modelid"] != "PHDL00" or not bridge_config["sensors"]["1"]["config"]["configured"]:
        return

    import pytz, astral
    from astral import Astral, Location
    a = Astral()
    a.solar_depression = 'civil'
    loc = Location(('Current', bridge_config["config"]["timezone"].split("/")[1], float(bridge_config["sensors"]["1"]["config"]["lat"][:-1]), float(bridge_config["sensors"]["1"]["config"]["long"][:-1]), bridge_config["config"]["timezone"], 0))
    sun = loc.sun(date=datetime.now(), local=True)
    deltaSunset = sun['sunset'].replace(tzinfo=None) - datetime.now()
    deltaSunrise = sun['sunrise'].replace(tzinfo=None) - datetime.now()
    deltaSunsetOffset = deltaSunset.total_seconds() + bridge_config["sensors"]["1"]["config"]["sunsetoffset"] * 60
    deltaSunriseOffset = deltaSunrise.total_seconds() + bridge_config["sensors"]["1"]["config"]["sunriseoffset"] * 60
    logging.info("deltaSunsetOffset: " + str(deltaSunsetOffset))
    logging.info("deltaSunriseOffset: " + str(deltaSunriseOffset))
    current_time = datetime.now()
    current_time_str = get_timestamp()
    if deltaSunriseOffset < 0 and deltaSunsetOffset > 0:
        bridge_config["sensors"]["1"]["state"] = {"daylight":True,"lastupdated": current_time_str}
        logging.info("set daylight sensor to true")
    else:
        bridge_config["sensors"]["1"]["state"] = {"daylight":False,"lastupdated": current_time_str}
        logging.info("set daylight sensor to false")
    if deltaSunsetOffset > 0 and deltaSunsetOffset < 3600:
        logging.info("will start the sleep for sunset")
        sleep(deltaSunsetOffset)
        logging.info("sleep finish at " + current_time_str)
        bridge_config["sensors"]["1"]["state"] = {"daylight":False,"lastupdated": current_time_str}
        sensors_state["1"]["state"]["daylight"] = current_time
        rulesProcessor("1", current_time)
    if deltaSunriseOffset > 0 and deltaSunriseOffset < 3600:
        logging.info("will start the sleep for sunrise")
        sleep(deltaSunriseOffset)
        logging.info("sleep finish at " + current_time_str)
        bridge_config["sensors"]["1"]["state"] = {"daylight":True,"lastupdated": current_time_str}
        sensors_state["1"]["state"]["daylight"] = current_time
        rulesProcessor("1", current_time)

# Get query string as a dict. Ignores duplicate keys!
def get_query_string():
    query = parse_qs(flask.request.query_string.decode('ascii'))
    return {k: v[0] for k, v in query.items()}

MIME_TYPES = {"json": "application/json", "map": "application/json", "html": "text/html", "xml": "application/xml", "js": "text/javascript", "css": "text/css", "png": "image/png"}

@app.route('/')
@app.route('/index.html')
@app.route('/<path:path>.css', defaults={'ext': '.css'})
@app.route('/<path:path>.map', defaults={'ext': '.map'})
@app.route('/<path:path>.png', defaults={'ext': '.png'})
@app.route('/<path:path>.js', defaults={'ext': '.js'})
def get_static_file(path='index.html', ext=''):
    path = path + ext
    return flask.send_from_directory(WEBUI_FOLDER, path)

@app.route('/config.js')
def get_config_js(path='index.html', ext=''):
    #create a new user key in case none is available
    if len(bridge_config["config"]["whitelist"]) == 0:
        timestamp = get_timestamp()
        user = {
            "create date": timestamp,
            "last use date": timestamp,
            "name": "WebGui User"
        }
        bridge_config["config"]["whitelist"]["web-ui-" + str(random.randrange(0, 99999))] = user
    # XXX We're sending out random API keys here?? Does it matter?
    config = list(bridge_config["config"]["whitelist"].keys())[0]
    resp = 'window.config = { API_KEY: "%s",};' % config

    headers = {'Content-Type': MIME_TYPES['js']}

    return (resp.encode('utf-8'), headers)

@app.route('/api/config')
@app.route('/api/nouser/config')
def get_nouser_config():
    keys = ['apiversion', 'bridgeid', 'datastoreversion', 'mac',
        'modelid', 'name', 'swversion']
    data = {key: bridge_config['config'][key] for key in keys}
    data.update({'factorynew': False, 'replacesbridgeid': None,
        'starterkitid': ''})
    return flask.jsonify(data)

@app.route('/debug/clip.html')
def get_debug_clip():
    return flask.send_file('%s/debug/clip.html' % cwd)

@app.route('/factory-reset')
def factory_reset():
    backup_path = saveConfig('before-reset.json')
    bridge_config = load_config(cwd + '/default-config.json')
    saveConfig()
    return flask.jsonify([{"success":{"configuration":"reset","backup-filename":backup_path}}])

@app.route('/description.xml')
def get_description_xml():
    headers = {'Content-Type': MIME_TYPES['xml']}
    resp = description(bridge_config["config"]["ipaddress"], mac, bridge_config["config"]["name"])
    return (resp, headers)

@app.route('/lights.json')
def get_lights_json():
    return flask.jsonify(getLightsVersions())

@app.route('/lights')
def get_lights():
    get_parameters = get_query_string()
    if "light" in get_parameters:
        updateLight(get_parameters["light"], get_parameters["filename"])
    return lightsHttp()

@app.route('/save')
def save():
    save_path = saveConfig()
    return flask.jsonify([{"success":{"configuration":"saved","filename": save_path}}])

@app.route('/mark-alexa-enabled', methods=['POST'])
def mark_alexa_enabled():
    bridge_config['config']['alexa_enabled'] = True
    save_path = saveConfig()
    return flask.jsonify({'ok':True})

class S:
    protocol_version = 'HTTP/1.1'
    server_version = 'nginx'
    sys_version = ''

    def send_header(self, header, value):
        self.resp_headers[header] = value

    def _set_headers(self):
        self.resp_status_code = 200
        if self.path.endswith((".html",".json",".css",".map",".png",".js", ".xml")):
            self.send_header('Content-type', MIME_TYPES[self.path.split(".")[-1]])
        elif self.path.startswith("/api"):
            self.send_header('Content-type', MIME_TYPES["json"])
        else:
            self.send_header('Content-type', MIME_TYPES["html"])

    def _set_AUTHHEAD(self):
        self.resp_status_code = 401
        self.send_header('WWW-Authenticate', 'Basic realm=\"Hue\"')
        self.send_header('Content-type', 'text/html')

    def _set_end_headers(self, data):
        self.resp_body = data

    def do_GET(self):
        #Some older Philips Tv's sent non-standard HTTP GET requests with a Content-Lenght and a
        # body. The HTTP body needs to be consumed and ignored in order to request be handle correctly.
        global bridge_config
        self.read_http_request_body()

        if self.path.startswith("/tradfri"): #setup Tradfri gateway
            self._set_headers()
            get_parameters = parse_qs(urlparse(self.path).query)
            if "code" in get_parameters:
                #register new identity
                new_identity = "Hue-Emulator-" + str(random.randrange(0, 999))
                registration = json.loads(check_output("./coap-client-linux -m post -u \"Client_identity\" -k \"" + get_parameters["code"][0] + "\" -e '{\"9090\":\"" + new_identity + "\"}' \"coaps://" + get_parameters["ip"][0] + ":5684/15011/9063\"", shell=True).decode('utf-8').rstrip('\n').split("\n")[-1])
                bridge_config["tradfri"] = {"psk": registration["9091"], "ip": get_parameters["ip"][0], "identity": new_identity}
                lights_found = scanTradfri()
                if lights_found == 0:
                    self._set_end_headers(bytes(webformTradfri() + "<br> No lights where found", "utf8"))
                else:
                    self._set_end_headers(bytes(webformTradfri() + "<br> " + str(lights_found) + " lights where found", "utf8"))
            else:
                self._set_end_headers(bytes(webformTradfri(), "utf8"))
        elif self.path.startswith("/milight"): #setup milight bulb
            self._set_headers()
            get_parameters = parse_qs(urlparse(self.path).query)
            if "device_id" in get_parameters:
                #register new mi-light
                new_light_id = nextFreeId(bridge_config, "lights")
                bridge_config["lights"][new_light_id] = {"state": {"on": False, "bri": 200, "hue": 0, "sat": 0, "xy": [0.0, 0.0], "ct": 461, "alert": "none", "effect": "none", "colormode": "ct", "reachable": True}, "type": "Extended color light", "name": "MiLight " + get_parameters["mode"][0] + " " + get_parameters["device_id"][0], "uniqueid": "1a2b3c4" + str(random.randrange(0, 99)), "modelid": "LCT001", "swversion": "66009461"}
                new_lights.update({new_light_id: {"name": "MiLight " + get_parameters["mode"][0] + " " + get_parameters["device_id"][0]}})
                bridge_config["lights_address"][new_light_id] = {"device_id": get_parameters["device_id"][0], "mode": get_parameters["mode"][0], "group": int(get_parameters["group"][0]), "ip": get_parameters["ip"][0], "protocol": "milight"}
                self._set_end_headers(bytes(webform_milight() + "<br> Light added", "utf8"))
            else:
                self._set_end_headers(bytes(webform_milight(), "utf8"))
        elif self.path.startswith("/hue"): #setup hue bridge
            if "linkbutton" in self.path: #Hub button emulated
                if self.headers.get('Authorization') is None:
                    self._set_AUTHHEAD()
                    self._set_end_headers(bytes('You are not authenticated', "utf8"))
                    pass
                elif self.headers['Authorization'] == 'Basic ' + bridge_config["linkbutton"]["linkbutton_auth"]:
                    get_parameters = parse_qs(urlparse(self.path).query)
                    if "action=Activate" in self.path:
                        self._set_headers()
                        bridge_config["config"]["linkbutton"] = False
                        bridge_config["linkbutton"]["lastlinkbuttonpushed"] = datetime.now().strftime("%s")
                        saveConfig()
                        self._set_end_headers(bytes(webform_linkbutton() + "<br> You have 30 sec to connect your device", "utf8"))
                    elif "action=Exit" in self.path:
                        self._set_AUTHHEAD()
                        self._set_end_headers(bytes('You are succesfully disconnected', "utf8"))
                    elif "action=ChangePassword" in self.path:
                        self._set_headers()
                        tmp_password = str(base64.b64encode(bytes(get_parameters["username"][0] + ":" + get_parameters["password"][0], "utf8"))).split('\'')
                        bridge_config["linkbutton"]["linkbutton_auth"] = tmp_password[1]
                        saveConfig()
                        self._set_end_headers(bytes(webform_linkbutton() + '<br> Your credentials are succesfully change. Please logout then login again', "utf8"))
                    else:
                        self._set_headers()
                        self._set_end_headers(bytes(webform_linkbutton(), "utf8"))
                    pass
                else:
                    self._set_AUTHHEAD()
                    self._set_end_headers(bytes(self.headers['Authorization'], "utf8"))
                    self._set_end_headers(bytes('not authenticated', "utf8"))
                    pass
            else:
                self._set_headers()
                get_parameters = parse_qs(urlparse(self.path).query)
                if "ip" in get_parameters:
                    response = json.loads(sendRequest("http://" + get_parameters["ip"][0] + "/api/", "POST", "{\"devicetype\":\"Hue Emulator\"}"))
                    if "success" in response[0]:
                        hue_lights = json.loads(sendRequest("http://" + get_parameters["ip"][0] + "/api/" + response[0]["success"]["username"] + "/lights", "GET", "{}"))
                        logging.debug('Got response from hue bridge: %s', hue_lights)

                        # Look through all lights in the response, and check if we've seen them before
                        lights_found = 0
                        for light_nr, data in hue_lights.items():
                            light_id = find_light_in_config_from_uid(bridge_config, data['uniqueid'])
                            if light_id is None:
                                light_id = nextFreeId(bridge_config, "lights")
                                logging.info('Found new light: %s %s', light_id, data)
                                lights_found += 1
                                bridge_config["lights_address"][light_id] = {
                                    "username": response[0]["success"]["username"],
                                    "light_id": light_nr,
                                    "ip": get_parameters["ip"][0],
                                    "protocol": "hue"
                                }
                            else:
                                logging.info('Found duplicate light: %s %s', light_id, data)
                            bridge_config["lights"][light_id] = data

                        if lights_found == 0:
                            self._set_end_headers(bytes(webform_hue() + "<br> No lights where found", "utf8"))
                        else:
                            saveConfig()
                            self._set_end_headers(bytes(webform_hue() + "<br> " + str(lights_found) + " lights were found", "utf8"))
                    else:
                        self._set_end_headers(bytes(webform_hue() + "<br> unable to connect to hue bridge", "utf8"))
                else:
                    self._set_end_headers(bytes(webform_hue(), "utf8"))
        elif self.path.startswith("/deconz"): #setup imported deconz sensors
            self._set_headers()
            get_parameters = parse_qs(urlparse(self.path).query)
            #clean all rules related to deconz Switches
            if get_parameters:
                emulator_resourcelinkes = []
                for resourcelink in bridge_config["resourcelinks"].keys(): # delete all previews rules of IKEA remotes
                    if bridge_config["resourcelinks"][resourcelink]["classid"] == 15555:
                        emulator_resourcelinkes.append(resourcelink)
                        for link in bridge_config["resourcelinks"][resourcelink]["links"]:
                            pices = link.split('/')
                            if pices[1] == "rules":
                                try:
                                    del bridge_config["rules"][pices[2]]
                                except:
                                    logging.info("unable to delete the rule " + pices[2])
                for resourcelink in emulator_resourcelinkes:
                    del bridge_config["resourcelinks"][resourcelink]
                for key in get_parameters.keys():
                    if get_parameters[key][0] in ["ZLLSwitch", "ZGPSwitch"]:
                        try:
                            del bridge_config["sensors"][key]
                        except:
                            pass
                        hueSwitchId = addHueSwitch("", get_parameters[key][0])
                        for sensor in bridge_config["deconz"]["sensors"].keys():
                            if bridge_config["deconz"]["sensors"][sensor]["bridgeid"] == key:
                                bridge_config["deconz"]["sensors"][sensor] = {"hueType": get_parameters[key][0], "bridgeid": hueSwitchId}
                    else:
                        if not key.startswith("mode_"):
                            if bridge_config["sensors"][key]["modelid"] == "TRADFRI remote control":
                                if get_parameters["mode_" + key][0]  == "CT":
                                    addTradfriCtRemote(key, get_parameters[key][0])
                                elif get_parameters["mode_" + key][0]  == "SCENE":
                                    addTradfriSceneRemote(key, get_parameters[key][0])
                            elif bridge_config["sensors"][key]["modelid"] == "TRADFRI wireless dimmer":
                                addTradfriDimmer(key, get_parameters[key][0])
                            elif bridge_config["deconz"]["sensors"][key]["modelid"] == "TRADFRI motion sensor":
                                bridge_config["deconz"]["sensors"][key]["lightsensor"] = get_parameters[key][0]
                            #store room id in deconz sensors
                            for sensor in bridge_config["deconz"]["sensors"].keys():
                                if bridge_config["deconz"]["sensors"][sensor]["bridgeid"] == key:
                                    bridge_config["deconz"]["sensors"][sensor]["room"] = get_parameters[key][0]
                                    if bridge_config["sensors"][key]["modelid"] == "TRADFRI remote control":
                                        bridge_config["deconz"]["sensors"][sensor]["opmode"] = get_parameters["mode_" + key][0]

            else:
                scanDeconz()
            self._set_end_headers(bytes(webformDeconz({"deconz": bridge_config["deconz"], "sensors": bridge_config["sensors"], "groups": bridge_config["groups"]}), "utf8"))
        elif self.path.startswith("/switch"): #request from an ESP8266 switch or sensor
            self._set_headers()
            get_parameters = parse_qs(urlparse(self.path).query)
            logging.info(pretty_json(get_parameters))
            if "devicetype" in get_parameters and get_parameters["mac"][0] not in bridge_config["emulator"]["sensors"]: #register device request
                logging.info("registering new sensor " + get_parameters["devicetype"][0])
                if get_parameters["devicetype"][0] in ["ZLLSwitch","ZGPSwitch"]:
                    logging.info(get_parameters["devicetype"][0])
                    bridge_config["emulator"]["sensors"][get_parameters["mac"][0]] = {"bridgeId": addHueSwitch("", get_parameters["devicetype"][0])}
                elif get_parameters["devicetype"][0] == "ZLLPresence":
                    logging.info("ZLLPresence")
                    bridge_config["emulator"]["sensors"][get_parameters["mac"][0]] = {"bridgeId": addHueMotionSensor(""), "lightSensorId": "0"}
                    ### detect light sensor id and save it to update directly the lightdata
                    for sensor in bridge_config["sensors"].keys():
                        if bridge_config["sensors"][sensor]["type"] == "ZLLLightLevel" and bridge_config["sensors"][sensor]["uniqueid"] == bridge_config["sensors"][bridge_config["emulator"]["sensors"][get_parameters["mac"][0]]["bridgeId"]]["uniqueid"][:-1] + "0":
                            bridge_config["emulator"]["sensors"][get_parameters["mac"][0]]["lightSensorId"] = sensor
                            break
                    generateSensorsState()
            else: #switch action request
                if get_parameters["mac"][0] in bridge_config["emulator"]["sensors"]:
                    sensorId = bridge_config["emulator"]["sensors"][get_parameters["mac"][0]]["bridgeId"]
                    logging.info("match sensor " + sensorId)
                    if bridge_config["sensors"][sensorId]["config"]["on"]: #match senser id based on mac address
                        current_time = datetime.now()
                        if bridge_config["sensors"][sensorId]["type"] in ["ZLLSwitch","ZGPSwitch"]:
                            bridge_config["sensors"][sensorId]["state"].update({"buttonevent": get_parameters["button"][0], "lastupdated": get_utc_timestamp()})
                            sensors_state[sensorId]["state"]["lastupdated"] = current_time
                        elif bridge_config["sensors"][sensorId]["type"] == "ZLLPresence":
                            lightSensorId = bridge_config["emulator"]["sensors"][get_parameters["mac"][0]]["lightSensorId"]
                            if bridge_config["sensors"][sensorId]["state"]["presence"] != True:
                                bridge_config["sensors"][sensorId]["state"]["presence"] = True
                                sensors_state[sensorId]["state"]["presence"] = current_time
                            bridge_config["sensors"][sensorId]["state"]["lastupdated"] = get_utc_timestamp()
                            Thread(target=motionDetected, args=[sensorId]).start()

                            if "lightlevel" in get_parameters:
                                bridge_config["sensors"][lightSensorId]["state"].update({"lightlevel": get_parameters["lightlevel"][0], "dark": get_parameters["dark"][0], "daylight": get_parameters["daylight"][0], "lastupdated": get_utc_timestamp()})
                            else:
                                if bridge_config["sensors"]["1"]["modelid"] == "PHDL00" and bridge_config["sensors"]["1"]["state"]["daylight"]:
                                    bridge_config["sensors"][lightSensorId]["state"].update({"lightlevel": 25000, "dark": False, "daylight": True, "lastupdated": get_utc_timestamp() })
                                else:
                                    bridge_config["sensors"][lightSensorId]["state"].update({"lightlevel": 6000, "dark": True, "daylight": False, "lastupdated": get_utc_timestamp() })

                            #if alarm is activ trigger the alarm
                            if "virtual_light" in bridge_config["alarm_config"] and bridge_config["lights"][bridge_config["alarm_config"]["virtual_light"]]["state"]["on"] and bridge_config["sensors"][sensorId]["state"]["presence"] == True:
                                sendEmail(bridge_config["alarm_config"], bridge_config["sensors"][sensorId]["name"])
                                #triger_horn() need development
                        rulesProcessor(sensorId, current_time) #process the rules to perform the action configured by application
            self._set_end_headers(bytes("done", "utf8"))
        elif self.path.startswith("/scan"): # rescan
            self._set_headers()
            scan_for_lights()
            self._set_end_headers(bytes("done", "utf8"))
        else:
            url_pices = self.path.rstrip('/').split('/')
            if len(url_pices) < 3:
                #self._set_headers_error()
                self.response = ('not found: %s' % self.path, 404)
                return
            else:
                self._set_headers()
            if url_pices[2] in bridge_config["config"]["whitelist"]: #if username is in whitelist
                bridge_config["config"]["UTC"] = get_utc_timestamp()
                bridge_config["config"]["localtime"] = get_timestamp()
                bridge_config["config"]["whitelist"][url_pices[2]]["last use date"] = get_timestamp()
                bridge_config["config"]["linkbutton"] = int(bridge_config["linkbutton"]["lastlinkbuttonpushed"]) + 30 >= int(datetime.now().strftime("%s"))
                if len(url_pices) == 3: #print entire config
                    self._set_end_headers(bytes(json.dumps({"lights": bridge_config["lights"], "groups": bridge_config["groups"], "config": bridge_config["config"], "scenes": bridge_config["scenes"], "schedules": bridge_config["schedules"], "rules": bridge_config["rules"], "sensors": bridge_config["sensors"], "resourcelinks": bridge_config["resourcelinks"]},separators=(',', ':'),ensure_ascii=False), "utf8"))
                elif len(url_pices) == 4: #print specified object config
                    self._set_end_headers(bytes(json.dumps(bridge_config[url_pices[3]],separators=(',', ':'),ensure_ascii=False), "utf8"))
                elif (len(url_pices) == 5 or (len(url_pices) == 6 and url_pices[5] == 'state')):
                    if url_pices[4] == "new": #return new lights and sensors only
                        new_lights.update({"lastscan": get_timestamp()})
                        self._set_end_headers(bytes(json.dumps(new_lights ,separators=(',', ':'),ensure_ascii=False), "utf8"))
                        new_lights.clear()
                    elif url_pices[3] == "groups" and url_pices[4] == "0":
                        any_on = False
                        all_on = True
                        for group_state in bridge_config["groups"].keys():
                            if bridge_config["groups"][group_state]["state"]["any_on"] == True:
                                any_on = True
                            else:
                                all_on = False
                        self._set_end_headers(bytes(json.dumps({"name":"Group 0","lights": [l for l in bridge_config["lights"]],"sensors": [s for s in bridge_config["sensors"]],"type":"LightGroup","state":{"all_on":all_on,"any_on":any_on},"recycle":False,"action":{"on":False,"alert":"none"}},separators=(',', ':'),ensure_ascii=False), "utf8"))
                    elif url_pices[3] == "info" and url_pices[4] == "timezones":
                        self._set_end_headers(bytes(json.dumps(bridge_config["capabilities"][url_pices[4]]["values"],separators=(',', ':'),ensure_ascii=False), "utf8"),ensure_ascii=False)
                    else:
                        if url_pices[4] not in bridge_config[url_pices[3]]:
                            self.response = ('not found: %s' % self.path, 404)
                            return
                        self._set_end_headers(bytes(json.dumps(bridge_config[url_pices[3]][url_pices[4]],separators=(',', ':'),ensure_ascii=False), "utf8"))
            else: #user is not in whitelist
                self._set_end_headers(bytes(json.dumps([{"error": {"type": 1, "address": self.path, "description": "unauthorized user" }}],separators=(',', ':'),ensure_ascii=False), "utf8"))

    def read_http_request_body(self):
        if self.headers.get('Content-Length') in (None, '0'):
            return b"{}" 
        return flask.request.get_data()

    def do_POST(self):
        self._set_headers()
        logging.info("in post method")
        logging.info(self.path)
        self.data_string = self.read_http_request_body()
        if self.path == "/updater":
            update_data = json.loads(sendRequest("https://raw.githubusercontent.com/diyhue/diyHue/master/BridgeEmulator/updater", "GET", "{}"))
            logging.info("update data: %s", update_data)
            for category in update_data.keys():
                for key in update_data[category].keys():
                    logging.info("patch " + category + " -> " + key )
                    bridge_config[category][key] = update_data[category][key]
            self._set_end_headers(bytes(json.dumps([{"success": {"/config/swupdate/checkforupdate": True}}],separators=(',', ':'),ensure_ascii=False), "utf8"))
        else:
            raw_json = self.data_string.decode('utf8')
            raw_json = raw_json.replace("\t","")
            raw_json = raw_json.replace("\n","")
            post_dictionary = json.loads(raw_json)
            logging.info(self.data_string)
        url_pices = self.path.rstrip('/').split('/')
        if len(url_pices) == 4: #data was posted to a location
            if url_pices[2] in bridge_config["config"]["whitelist"]:
                if ((url_pices[3] == "lights" or url_pices[3] == "sensors") and not bool(post_dictionary)):
                    #if was a request to scan for lights of sensors
                    Thread(target=scan_for_lights).start()
                    sleep(7) #give no more than 5 seconds for light scanning (otherwise will face app disconnection timeout)
                    self._set_end_headers(bytes(json.dumps([{"success": {"/" + url_pices[3]: "Searching for new devices"}}],separators=(',', ':'),ensure_ascii=False), "utf8"))
                elif url_pices[3] == "":
                    self._set_end_headers(bytes(json.dumps([{"success": {"clientkey": "321c0c2ebfa7361e55491095b2f5f9db"}}],separators=(',', ':'),ensure_ascii=False), "utf8"))
                else: #create object
                    # find the first unused id for new object
                    new_object_id = nextFreeId(bridge_config, url_pices[3])
                    if url_pices[3] == "scenes":
                        defaults = {'lightstates': {}, 'version': 2, 'picture': '',
                                'lastupdated': get_utc_timestamp(), 'owner': url_pices[2]}
                        defaults.update(post_dictionary)
                        post_dictionary = defaults
                    elif url_pices[3] == "groups":
                        post_dictionary.update({"action": {"on": False}, "state": {"any_on": False, "all_on": False}})
                    elif url_pices[3] == "schedules":
                        try:
                            post_dictionary.update({"created": get_utc_timestamp(), "time": post_dictionary["localtime"]})
                        except KeyError:
                            post_dictionary.update({"created": get_utc_timestamp(), "localtime": post_dictionary["time"]})
                        if post_dictionary["localtime"].startswith("PT"):
                            post_dictionary.update({"starttime": get_utc_timestamp()})
                        if not "status" in post_dictionary:
                            post_dictionary.update({"status": "enabled"})
                    elif url_pices[3] == "rules":
                        post_dictionary.update({"owner": url_pices[2], "lasttriggered" : "none", "created": get_utc_timestamp(), "timestriggered": 0})
                        if not "status" in post_dictionary:
                            post_dictionary.update({"status": "enabled"})
                    elif url_pices[3] == "sensors":
                        if "state" not in post_dictionary:
                            post_dictionary["state"] = {}
                        if post_dictionary["modelid"] == "PHWA01":
                            post_dictionary.update({"state": {"status": 0}})
                        elif post_dictionary["modelid"] == "PHA_CTRL_START":
                            post_dictionary.update({"state": {"flag": False, "lastupdated": get_utc_timestamp()}, "config": {"on": True,"reachable": True}})
                    elif url_pices[3] == "resourcelinks":
                        post_dictionary.update({"owner" :url_pices[2]})
                    generateSensorsState()
                    bridge_config[url_pices[3]][new_object_id] = post_dictionary
                    logging.info(json.dumps([{"success": {"id": new_object_id}}], sort_keys=True, indent=4, separators=(',', ': ')))
                    self._set_end_headers(bytes(json.dumps([{"success": {"id": new_object_id}}], separators=(',', ':'),ensure_ascii=False), "utf8"))
            else:
                self._set_end_headers(bytes(json.dumps([{"error": {"type": 1, "address": self.path, "description": "unauthorized user" }}], separators=(',', ':'),ensure_ascii=False), "utf8"))
                logging.info(json.dumps([{"error": {"type": 1, "address": self.path, "description": "unauthorized user" }}],sort_keys=True, indent=4, separators=(',', ': ')))
        elif self.path.startswith("/api") and "devicetype" in post_dictionary: #new registration by linkbutton
            last_button_press = int(bridge_config["linkbutton"]["lastlinkbuttonpushed"])
            if (args.no_link_button or last_button_press+30 >= int(datetime.now().strftime("%s")) or
                    bridge_config["config"]["linkbutton"]):
                username = hashlib.new('ripemd160', post_dictionary["devicetype"][0].encode('utf-8')).hexdigest()[:32]
                bridge_config["config"]["whitelist"][username] = {"last use date": get_utc_timestamp(),"create date": get_utc_timestamp(),"name": post_dictionary["devicetype"]}
                response = [{"success": {"username": username}}]
                if "generateclientkey" in post_dictionary and post_dictionary["generateclientkey"]:
                    response[0]["success"]["clientkey"] = "321c0c2ebfa7361e55491095b2f5f9db"
                self._set_end_headers(bytes(json.dumps(response,separators=(',', ':'),ensure_ascii=False), "utf8"))
                logging.info(json.dumps(response, sort_keys=True, indent=4, separators=(',', ': ')))
            else:
                self._set_end_headers(bytes(json.dumps([{"error": {"type": 101, "address": self.path, "description": "link button not pressed" }}], separators=(',', ':'),ensure_ascii=False), "utf8"))
        saveConfig()

    def do_PUT(self):
        self._set_headers()
        logging.info("in PUT method")
        self.data_string = self.read_http_request_body()
        put_dictionary = json.loads(self.data_string.decode('utf8'))
        url_pices = self.path.rstrip('/').split('/')
        logging.info(self.path)
        logging.info(self.data_string)
        if url_pices[2] in bridge_config["config"]["whitelist"]:
            if len(url_pices) == 4:
                bridge_config[url_pices[3]].update(put_dictionary)
                response_location = "/" + url_pices[3] + "/"
            if len(url_pices) == 5:
                if url_pices[3] == "schedules":
                    if "status" in put_dictionary and put_dictionary["status"] == "enabled" and bridge_config["schedules"][url_pices[4]]["localtime"].startswith("PT"):
                        put_dictionary.update({"starttime": (datetime.utcnow()).strftime("%Y-%m-%dT%H:%M:%S")})
                elif url_pices[3] == "scenes":
                    if "storelightstate" in put_dictionary:
                        scene_states = bridge_config["scenes"][url_pices[4]]["lightstates"]
                        for light, state in scene_states.items():
                            state = bridge_config["lights"][light]["state"]
                            scene_states[light] = {}
                            scene_states[light]["on"] = state["on"]
                            scene_states[light]["bri"] = state["bri"]
                            if "colormode" in state:
                                if state["colormode"] in ["ct", "xy"]:
                                    scene_states[light][state["colormode"]] = state[state["colormode"]]
                                elif state["colormode"] == "hs" and "hue" in scene_states[light]:
                                    scene_states[light]["hue"] = state["hue"]
                                    scene_states[light]["sat"] = state["sat"]
                if url_pices[3] == "sensors":
                    current_time = datetime.now()
                    for key, value in put_dictionary.items():
                        if key not in sensors_state[url_pices[4]]:
                            sensors_state[url_pices[4]][key] = {}
                        if type(value) is dict:
                            bridge_config["sensors"][url_pices[4]][key].update(value)
                            for element in value.keys():
                                sensors_state[url_pices[4]][key][element] = current_time
                        else:
                            bridge_config["sensors"][url_pices[4]][key] = value
                            sensors_state[url_pices[4]][key] = current_time
                    rulesProcessor(url_pices[4], current_time)
                    if url_pices[4] == "1" and bridge_config[url_pices[3]][url_pices[4]]["modelid"] == "PHDL00":
                        bridge_config["sensors"]["1"]["config"]["configured"] = True ##mark daylight sensor as configured
                elif url_pices[3] == "groups" and "stream" in put_dictionary:
                    if "active" in put_dictionary["stream"]:
                        if put_dictionary["stream"]["active"]:
                            logging.info("start hue entertainment")
                            Popen(["/opt/hue-emulator/entertainment-srv", "server_port=2100", "dtls=1", "psk_list=" + url_pices[2] + ",321c0c2ebfa7361e55491095b2f5f9db"])
                            sleep(0.2)
                            bridge_config["groups"][url_pices[4]]["stream"].update({"active": True, "owner": url_pices[2], "proxymode": "auto", "proxynode": "/bridge"})
                        else:
                            logging.info("stop hue entertainent")
                            Popen(["killall", "entertainment-srv"])
                            bridge_config["groups"][url_pices[4]]["stream"].update({"active": False, "owner": None})
                    else:
                        bridge_config[url_pices[3]][url_pices[4]].update(put_dictionary)
                elif url_pices[3] == "lights" and "config" in put_dictionary:
                    bridge_config["lights"][url_pices[4]]["config"].update(put_dictionary["config"])
                    if "startup" in put_dictionary["config"] and bridge_config["lights_address"][url_pices[4]]["protocol"] == "native":
                        if put_dictionary["config"]["startup"]["mode"] == "safety":
                            sendRequest("http://" + bridge_config["lights_address"][url_pices[4]]["ip"] + "/", "POST", {"startup": 1})
                        elif put_dictionary["config"]["startup"]["mode"] == "powerfail":
                            sendRequest("http://" + bridge_config["lights_address"][url_pices[4]]["ip"] + "/", "POST", {"startup": 0})

                        #add exception on json output as this dictionary has tree levels
                        response_dictionary = {"success":{"/lights/" + url_pices[4] + "/config/startup": {"mode": put_dictionary["config"]["startup"]["mode"]}}}
                        self._set_end_headers(bytes(json.dumps(response_dictionary,separators=(',', ':'),ensure_ascii=False), "utf8"))
                        logging.info(json.dumps(response_dictionary, sort_keys=True, indent=4, separators=(',', ': ')))
                        return
                elif url_pices[3] == "lights" and "name" in put_dictionary:
                    bridge_config[url_pices[3]][url_pices[4]].update(put_dictionary)
                    light_dict = {'name': put_dictionary['name']}
                    sendLightRequest(url_pices[4], light_dict, bridge_config["lights"], bridge_config["lights_address"])
                else:
                    bridge_config[url_pices[3]][url_pices[4]].update(put_dictionary)

                response_location = "/" + url_pices[3] + "/" + url_pices[4] + "/"
            if len(url_pices) == 6:
                if url_pices[3] == "groups": #state is applied to a group
                    if url_pices[5] == "stream":
                        if "active" in put_dictionary:
                            if put_dictionary["active"]:
                                logging.info("start hue entertainment")
                                Popen(["/opt/hue-emulator/entertainment-srv", "server_port=2100", "dtls=1", "psk_list=" + url_pices[2] + ",321c0c2ebfa7361e55491095b2f5f9db"])
                                sleep(0.2)
                                bridge_config["groups"][url_pices[4]]["stream"].update({"active": True, "owner": url_pices[2], "proxymode": "auto", "proxynode": "/bridge"})
                            else:
                                Popen(["killall", "entertainment-srv"])
                                bridge_config["groups"][url_pices[4]]["stream"].update({"active": False, "owner": None})
                    elif "scene" in put_dictionary: #scene applied to group
                        splitLightsToDevices(url_pices[4], {}, bridge_config["scenes"][put_dictionary["scene"]]["lightstates"])

                    elif "bri_inc" in put_dictionary or "ct_inc" in put_dictionary:
                        splitLightsToDevices(url_pices[4], put_dictionary)
                    elif "scene_inc" in put_dictionary:
                        switchScene(url_pices[4], put_dictionary["scene_inc"])
                    elif url_pices[4] == "0": #if group is 0 the scene applied to all lights
                        groupZero(put_dictionary)
                    else: # the state is applied to particular group (url_pices[4])
                        if "on" in put_dictionary:
                            bridge_config["groups"][url_pices[4]]["state"]["any_on"] = put_dictionary["on"]
                            bridge_config["groups"][url_pices[4]]["state"]["all_on"] = put_dictionary["on"]
                        bridge_config["groups"][url_pices[4]][url_pices[5]].update(put_dictionary)
                        splitLightsToDevices(url_pices[4], put_dictionary)
                elif url_pices[3] == "lights": #state is applied to a light
                    for key in put_dictionary.keys():
                        if key in ["ct", "xy"]: #colormode must be set by bridge
                            bridge_config["lights"][url_pices[4]]["state"]["colormode"] = key
                        elif key in ["hue", "sat"]:
                            bridge_config["lights"][url_pices[4]]["state"]["colormode"] = "hs"

                    updateGroupStats(url_pices[4], bridge_config["lights"], bridge_config["groups"])
                    sendLightRequest(url_pices[4], put_dictionary, bridge_config["lights"], bridge_config["lights_address"])
                if not url_pices[4] == "0": #group 0 is virtual, must not be saved in bridge configuration
                    try:
                        bridge_config[url_pices[3]][url_pices[4]][url_pices[5]].update(put_dictionary)
                    except KeyError:
                        bridge_config[url_pices[3]][url_pices[4]][url_pices[5]] = put_dictionary
                if url_pices[3] == "sensors" and url_pices[5] == "state":
                    current_time = datetime.now()
                    for key in put_dictionary.keys():
                        sensors_state[url_pices[4]]["state"].update({key: current_time})
                    rulesProcessor(url_pices[4], current_time)
                response_location = "/" + url_pices[3] + "/" + url_pices[4] + "/" + url_pices[5] + "/"
            if len(url_pices) == 7:
                try:
                    bridge_config[url_pices[3]][url_pices[4]][url_pices[5]][url_pices[6]].update(put_dictionary)
                except KeyError:
                    bridge_config[url_pices[3]][url_pices[4]][url_pices[5]][url_pices[6]] = put_dictionary
                bridge_config[url_pices[3]][url_pices[4]][url_pices[5]][url_pices[6]] = put_dictionary
                response_location = "/" + url_pices[3] + "/" + url_pices[4] + "/" + url_pices[5] + "/" + url_pices[6] + "/"
            response_dictionary = []
            for key, value in put_dictionary.items():
                response_dictionary.append({"success":{response_location + key: value}})
            self._set_end_headers(bytes(json.dumps(response_dictionary,separators=(',', ':'),ensure_ascii=False), "utf8"))
            logging.info(json.dumps(response_dictionary, sort_keys=True, indent=4, separators=(',', ': ')))
        else:
            self._set_end_headers(bytes(json.dumps([{"error": {"type": 1, "address": self.path, "description": "unauthorized user" }}],separators=(',', ':'),ensure_ascii=False), "utf8"))

    def do_DELETE(self):
        self._set_headers()
        url_pices = self.path.rstrip('/').split('/')
        if url_pices[2] in bridge_config["config"]["whitelist"]:
            if len(url_pices) == 6:
                del bridge_config[url_pices[3]][url_pices[4]][url_pices[5]]
            else:
                if url_pices[3] == "resourcelinks":
                    Thread(target=resourceRecycle).start()
                elif url_pices[3] == "sensors":
                    ## delete also related sensors
                    for sensor in list(bridge_config["sensors"]):
                        if sensor != url_pices[4] and "uniqueid" in bridge_config["sensors"][sensor] and bridge_config["sensors"][sensor]["uniqueid"].startswith(bridge_config["sensors"][url_pices[4]]["uniqueid"][:26]):
                            del bridge_config["sensors"][sensor]
                            logging.info('Delete related sensor ' + sensor)
                del bridge_config[url_pices[3]][url_pices[4]]
            if url_pices[3] == "lights":
                del_light = url_pices[4]

                # Delete the light address
                del bridge_config["lights_address"][del_light]

                # Remove this light from every group
                for group_id, group in bridge_config["groups"].items():
                    if "lights" in group and del_light in group["lights"]:
                        group["lights"].remove(del_light)

                # Delete the light from the deCONZ config
                for light in list(bridge_config["deconz"]["lights"]):
                    if bridge_config["deconz"]["lights"][light]["bridgeid"] == del_light:
                        del bridge_config["deconz"]["lights"][light]

                # Delete the light from any scenes
                for scene in list(bridge_config["scenes"]):
                    if "lights" in bridge_config["scenes"][scene] and del_light in bridge_config["scenes"][scene]["lights"]:
                        bridge_config["scenes"][scene]["lights"].remove(del_light)
                        del bridge_config["scenes"][scene]["lightstates"][del_light]
                        if len(bridge_config["scenes"][scene]["lights"]) == 0:
                            del bridge_config["scenes"][scene]
            elif url_pices[3] == "sensors":
                for sensor in list(bridge_config["deconz"]["sensors"]):
                    if bridge_config["deconz"]["sensors"][sensor]["bridgeid"] == url_pices[4]:
                        del bridge_config["deconz"]["sensors"][sensor]
            self._set_end_headers(bytes(json.dumps([{"success": "/" + url_pices[3] + "/" + url_pices[4] + " deleted."}],separators=(',', ':'),ensure_ascii=False), "utf8"))

@app.route('/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def route_all_paths(path=''):
    # Set up local variables in the handler class to match BaseHTTPRequestHandler
    s = S()
    s.path = '/' + path
    s.headers = flask.request.headers
    s.resp_body = None
    s.resp_status_code = None
    s.resp_headers = {}
    s.response = None

    # Call out the appropriate method depending on HTTP method
    if flask.request.method == 'GET':
        s.do_GET()
    elif flask.request.method == 'POST':
        s.do_POST()
    elif flask.request.method == 'PUT':
        s.do_PUT()
    elif flask.request.method == 'DELETE':
        s.do_DELETE()

    if s.response is None:
        s.response = (s.resp_body, s.resp_status_code, s.resp_headers)
    return s.response

def filter_user_agents():
    # Hack: ignore requests from Alexa/Echo, which apparently no longer
    # send user agent strings, if the Alexa skill is enabled
    if bridge_config['config'].get('alexa_enabled'):
        return
    if len(flask.request.headers.get('User-Agent', '')) < 2:
        flask.abort(400)

class ThreadingSimpleServer(ThreadingMixIn, HTTPServer):
    pass

def run(https):
    if https:
        port = args.https_port
        ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        ctx.load_cert_chain(certfile="./cert.pem")
        ctx.options |= ssl.OP_NO_TLSv1
        ctx.options |= ssl.OP_NO_TLSv1_1
        ctx.options |= ssl.OP_CIPHER_SERVER_PREFERENCE
        ctx.set_ciphers('ECDHE-ECDSA-AES128-GCM-SHA256')
        ctx.set_ecdh_curve('prime256v1')
        #ctx.set_alpn_protocols(['h2', 'http/1.1'])
        logging.info('Starting ssl httpd...')
    else:
        port = args.http_port
        ctx = None
        logging.info('Starting httpd...')

    app.before_request(filter_user_agents)

    app.run(debug=False, port=port, ssl_context=ctx)

if __name__ == "__main__":
    initialize()
    updateConfig()
    Thread(target=resourceRecycle).start()
    if bridge_config["deconz"]["enabled"]:
        scanDeconz()
    try:
        if update_lights_on_startup:
            Thread(target=updateAllLights, daemon=True).start()
        Thread(target=ssdpSearch, args=[args.ip, mac], daemon=True).start()
        #Thread(target=ssdpBroadcast, args=[args.ip, mac]).start()
        Thread(target=schedulerProcessor, daemon=True).start()
        Thread(target=syncWithLights, args=[bridge_config["lights"], bridge_config["lights_address"], bridge_config["config"]["whitelist"], bridge_config["groups"]], daemon=True).start()
        #Thread(target=entertainmentService, args=[bridge_config["lights"], bridge_config["lights_address"], bridge_config["groups"]]).start()
        #Thread(target=run, args=[False]).start()
        #if not args.no_serve_https:
        #    Thread(target=run, args=[True]).start()
        #Thread(target=daylightSensor).start()
        run(False)
        #while True:
        #    sleep(10)
    except Exception:
        logging.exception("server stopped ")
    finally:
        run_service = False
        saveConfig()
        logging.info('config saved')
        sys.exit(0)
