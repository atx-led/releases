#!/usr/bin/python3
import collections
import io
import hashlib
import json
import logging
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
import urllib
import zipfile
from datetime import date, datetime, timezone, timedelta

import flask

app = flask.Flask(__name__)

os.chdir(sys.path[0])
# os.chdir('/home/pi')

NETWORK_CONFIG = None
LAST_USE_TIME = None
CHECK_LOOP_THREAD = None
CHECK_LOOP_LAST_PROGRESS = None
CHECK_LOOP_MAX_AGE = 10 * 60

USER_DATA_PATH = "/home/pi/atxled/user-data"
DB_PATH = "%s/zpds.db" % USER_DATA_PATH
STATIC_IP_PATH = "%s/static-ip.txt" % USER_DATA_PATH
INSTALLED_TAG_PATH = "%s/../releases/tag" % USER_DATA_PATH
BRANCH_PATH = "%s/../branch" % USER_DATA_PATH

OFFLINE_MODE = False
OFFLINE_MODE_FILEPATH = "%s/../offline_mode" % USER_DATA_PATH

# Configuration: load this from the main user database
CRON_BOOM_CONFIG = {}

HOTSPOT_ENABLED = True
HOTSPOT_STATUS_FILE = "%s/../hotspot_status.txt" % USER_DATA_PATH
HOTPSOT_HAS_BEEN_RUN = False


def check_status():
    global OFFLINE_MODE
    try:
        with open(OFFLINE_MODE_FILEPATH, "r") as file:
            content = file.read().strip()
            if content == "offline mode=True":
                OFFLINE_MODE = True
            else:
                OFFLINE_MODE = False
    except FileNotFoundError:
        OFFLINE_MODE = False
    except Exception as e:
        print("An error occurred: {}".format(e))
        OFFLINE_MODE = False


def check_hotspot_status():
    global HOTSPOT_ENABLED
    try:
        with open(HOTSPOT_STATUS_FILE, "r") as file:
            content = file.read().strip()
            if content.lower() == "hotspot is disabled":
                HOTSPOT_ENABLED = False
            else:
                HOTSPOT_ENABLED = True
    except FileNotFoundError:
        # File does not exist, default to HOTSPOT_ENABLED = True
        HOTSPOT_ENABLED = True
    except Exception as e:
        print("An error occurred: {}".format(e))
        # In case of any other error, you can decide how to set HOTSPOT_ENABLED
        # For this example, I'm leaving it as True
        HOTSPOT_ENABLED = True


check_hotspot_status()


def reload_config():
    global CRON_BOOM_CONFIG, DB_PATH
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT enable_backups, site_name, addtl_settings "
                "FROM site_settings"
            )
            row = cursor.fetchone()
            addtl_settings = json.loads(row[2]) if row[2] else {}
            CRON_BOOM_CONFIG = {
                "enable_backups": row[0],
                "site_name": row[1],
                "block_remote_dataplicity_install": addtl_settings.get(
                    "block_remote_dataplicity_install", True
                ),
            }
    except Exception as e:
        logging.error("got exception loading config: %s", e)


def get_mac_address():
    # Get the mac of the wifi adapter. RPi specific-ish
    with open("/sys/class/net/wlan0/address") as f:
        return f.read().strip().replace(":", "")


def get_default_gateway():
    try:
        result = subprocess.run(
            ["ip", "route", "show", "default"], capture_output=True, text=True
        )
        if result.returncode != 0:
            return None

        # Extract the gateway IP
        pattern = r"default via (\d+\.\d+\.\d+\.\d+)"
        match = re.search(pattern, result.stdout)
        if match:
            return match.group(1)
    except Exception as e:
        print(f"Error getting default gateway: {e}")

    return None


def can_ping(host):
    try:
        if not host:
            return False
        subprocess.run(["ping", "-c", "4", host], stdout=subprocess.DEVNULL, check=True)
        return True
    except subprocess.CalledProcessError:
        return False


def get_internet_status():
    try:
        mac = get_mac_address()
        # Get IP addresses and corresponding interfaces
        result = subprocess.run(["ip", "-4", "addr"], capture_output=True, text=True)
        output = result.stdout
        ip_regex = r"inet (\d+\.\d+\.\d+\.\d+)/\d+.* (wlan0|eth0)"
        matches = re.findall(ip_regex, output)

        if not matches:
            logging.warning("No valid IP address found")
            return None

        # Choose the first valid IP and its corresponding interface
        new_ip, interface = matches[0]
        if interface == "eth0":
            return {"mac": mac, "ip": new_ip}

        # Check for link-local address (no internet)
        if new_ip.startswith("169.254."):
            logging.warning("Link-local IP address detected, likely no internet")
            return None

        default_gateway = get_default_gateway()
        if default_gateway is None:
            logging.warning("No default gateway found")
            return None
        elif not can_ping(default_gateway):
            logging.warning("Cannot ping default gateway")
            return None

        return {"mac": mac, "ip": new_ip}

    except Exception as e:
        logging.error("Error getting internet status: %s", e)
        return None


# Return backup of user data as a BytesIO containing a zip file


def get_db_backup():
    # Create database backup bundle
    backup = io.BytesIO()
    with zipfile.ZipFile(
        backup, mode="w", compression=zipfile.ZIP_DEFLATED
    ) as backup_zip:
        paths = [
            "%s/%s" % (USER_DATA_PATH, path)
            for path in ["config.json", "zpds-config.json", "zpds.db"]
        ]
        paths += ["/etc/wpa_supplicant/wpa_supplicant.conf"]
        for path in paths:
            status = "doesn't exist"
            if os.path.exists(path):
                backup_zip.write(path)
                with open(path, "rb") as f:
                    status = "%s bytes" % len(f.read())
            logging.info("file %s: %s", path, status)

    backup.seek(0, 2)
    logging.info("Backing up user data, %s bytes.", backup.tell())
    backup.seek(0)
    return backup


def check_dataplicity_installed():
    dataplicity_path = "/opt/dataplicity/tuxtunnel/auth"
    dataplicity_code_path = "/home/pi/atxled/user-data/dataplicity_code"
    if os.path.exists(dataplicity_path):
        # return the name of the last dataplicity code used, if it exists
        if os.path.exists(dataplicity_code_path):
            with open(dataplicity_code_path, "r") as f:
                return f.read().strip()
        else:
            return "no code found"
    else:
        return False


def remove_dataplicity():
    logging.info("Removing dataplicity")
    if not check_dataplicity_installed():
        logging.info("dataplicity not installed, nothing to remove")
    else:
        run_cmd("sudo", "rm", "-rf", "/opt/dataplicity")
        run_cmd("sudo", "apt", "purge", "-y", "supervisor")
        run_cmd("sudo", "rm", "-rf", "/etc/supervisor")
        # Remove the code used to install dataplicity
        if os.path.exists("/home/pi/atxled/user-data/dataplicity_code"):
            os.remove("/home/pi/atxled/user-data/dataplicity_code")


def pause_dataplicity():
    # check if dataplicity is installed, and then check if it's paused
    if not check_dataplicity_installed():
        logging.info("dataplicity not installed, nothing to pause")
        return

    if not os.path.exists("/etc/supervisor/conf.d/tuxtunnel.conf"):
        logging.info("dataplicity already paused, skipping")
        return

    logging.info("Pausing dataplicity")
    run_cmd(
        "sudo",
        "mv",
        "/etc/supervisor/conf.d/tuxtunnel.conf",
        "/etc/supervisor/conf.d/tuxtunnel.conf.bak",
    )
    run_cmd("sudo", "supervisorctl", "stop", "tuxtunnel")


def unpause_dataplicity():
    # check if dataplicity is installed, and then check if it's paused
    if not check_dataplicity_installed():
        logging.info("dataplicity not installed, nothing to unpause")
        return

    if not os.path.exists("/etc/supervisor/conf.d/tuxtunnel.conf.bak"):
        logging.info("dataplicity already unpaused, skipping")
        return

    logging.info("Unpausing dataplicity")
    run_cmd(
        "sudo",
        "mv",
        "/etc/supervisor/conf.d/tuxtunnel.conf.bak",
        "/etc/supervisor/conf.d/tuxtunnel.conf",
    )
    run_cmd("sudo", "supervisorctl", "start", "tuxtunnel")


def install_dataplicity(response_text):
    logging.info("Installing dataplicity")
    match = re.search(r"DP_install=(.*\.py)", response_text)
    if match:
        dataplicity_code = match.group(1)
        dataplicity_installed = check_dataplicity_installed()
        if dataplicity_installed:
            logging.info(
                "dataplicity already installed with code: %s", dataplicity_installed
            )
            if dataplicity_installed == dataplicity_code:
                logging.info(
                    "dataplicity already installed with the same code, skipping"
                )
                return True
            remove_dataplicity()
        try:
            command = (
                "curl -ks https://api.dataplicity.com/%s | sudo python"
                % dataplicity_code
            )
            logging.info("command: %s", command)
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            logging.info("STDOUT: %s", result.stdout)
            logging.info("STDERR: %s", result.stderr)
            # Save the code used to install dataplicity, deleting the old one if it exists
            with open("/home/pi/atxled/user-data/dataplicity_code", "w") as f:
                f.write(dataplicity_code)
        except Exception as e:
            logging.exception("exception installing dataplicity [%s]: ", e)
            return False
    else:
        logging.error("dataplicity code not found in response text")
        return False
    return True


# Send ip/map to me.dalihub.com for local redirection
LAST_DATA = None
LAST_UPDATE_TIME = 0
LAST_TIMEZONE_UPDATE_TIME = 0
TWO_WEEKS = 14 * 24 * 60 * 60
ONE_DAY = 24 * 60 * 60


def update_boom(internet_data):
    global LAST_DATA, LAST_UPDATE_TIME, LAST_TIMEZONE_UPDATE_TIME

    import requests

    # Reload the config from the database in case it's changed, and check
    # for database backup opt-out. Return True if opted out so we don't check
    # for two weeks
    reload_config()

    # Check the modification time on the ZPDS database, and backup if it's recent.
    # Otherwise, we only backup if our ip has changed, or two weeks have passed
    db_path = "%s/zpds.db" % USER_DATA_PATH
    try:
        mtime = os.stat(db_path).st_mtime
    except Exception:
        mtime = 0
    now = time.time()
    delta = now - LAST_UPDATE_TIME
    # Check if it's after 5:00 am CST and before 6:00 am CST on Sunday (tm_wday=6)

    if mtime < LAST_UPDATE_TIME and internet_data == LAST_DATA and delta < TWO_WEEKS:
        return True
    # Now we're sending the version tag installed as a release
    logging.info(
        "mtime: %s, LAST_TIMEZONE_UPDATE_TIME: %s, LAST_UPDATE_TIME: %s, LAST_USE_TIME: %s, internet_data: %s, LAST_DATA: %s, delta: %s, TWO_WEEKS: %s"
        % (
            mtime,
            LAST_TIMEZONE_UPDATE_TIME,
            LAST_UPDATE_TIME,
            LAST_USE_TIME,
            internet_data,
            LAST_DATA,
            delta,
            TWO_WEEKS,
        )
    )
    branch = "prod"
    try:
        with open(INSTALLED_TAG_PATH) as f:
            tag = f.read().strip()[:12]
        logging.info("Updating boomerang service: version tag=%s", tag)

    except Exception as e:
        logging.error("error getting tag info: %s", e)
        tag = None
    try:
        with open(BRANCH_PATH, encoding="utf-8") as f:
            branch = f.read().strip()

        logging.info("Updating boomerang service: branch=%s", branch)
    except Exception as e:
        logging.error("error reading branch file assume prod environment: %s", e)

    try:
        # Set site_name if available and last 4 of mac if not
        if CRON_BOOM_CONFIG.get("site_name"):
            site_name = CRON_BOOM_CONFIG.get("site_name")
        else:
            site_name = internet_data["mac"][-4:]
        logging.info("Updating boomerang service: site name=%s", site_name)
    except Exception as e:
        logging.error("error getting site_name info: %s", e)
        site_name = None

    try:
        logging.info("Updating boomerang service: %s", internet_data)

        backup = None
        if CRON_BOOM_CONFIG.get("enable_backups"):
            backup = get_db_backup()
        else:
            logging.info("Skipping backup, opted out...")

        boomerang_URL = "https://me.dalihub.com/up/?lan=%s&mac=%s" % (
            internet_data["ip"],
            internet_data["mac"],
        )
        if tag:
            boomerang_URL += "&tag=%s" % tag
        if site_name:
            boomerang_URL += "&site=%s" % site_name
        if branch:
            boomerang_URL += "&branch=%s" % branch

        logging.info("boomerang_URL= %s", boomerang_URL)
        check_status()
        if OFFLINE_MODE:
            return True
        response = requests.put(boomerang_URL, data=backup, timeout=60)
        if response.status_code != 200:
            logging.info(
                "could not update boomerang service[%s]: %s",
                response.status_code,
                response.text,
            )
            return False
    except Exception as e:
        logging.exception("Could not update boomerang service")
        return False

    # The response from me.dalihub.com will indicate whether the public IP
    # has changed. If it's changed, notify zpds that we should refresh the
    # sunrise/sunset data. We try up to 3 times with a sleep between in case
    # the server is down for some reason (this is fairly likely to happen
    # right when the server starts up, cron-boom starts faster than zpds)

    logging.info("response text: %s", response.text)
    if "branch=prod" in response.text:
        logging.info("Response indicates branch=prod, setting server to prod")
        try:
            branch_upgrade_response = requests.post(
                "http://localhost/dali/api/update-branch/prod", timeout=5
            )
            assert branch_upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                branch_upgrade_response.status_code,
                branch_upgrade_response.text,
            )
            return False

    if "branch=alpha" in response.text:
        logging.info("Response indicates setting server to alpha")
        try:
            branch_upgrade_response = requests.post(
                "http://localhost/dali/api/update-branch/alpha", timeout=5
            )
            assert branch_upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                branch_upgrade_response.status_code,
                branch_upgrade_response.text,
            )
            return False

    if "branch=beta" in response.text:
        logging.info("Response indicates setting server to beta")
        try:
            branch_upgrade_response = requests.post(
                "http://localhost/dali/api/update-branch/beta", timeout=5
            )
            assert branch_upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                branch_upgrade_response.status_code,
                branch_upgrade_response.text,
            )
            return False

    if "branch=test" in response.text:
        logging.info("Response indicates set server to test")
        try:
            branch_upgrade_response = requests.post(
                "http://localhost/dali/api/update-branch/test", timeout=5
            )
            assert branch_upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                branch_upgrade_response.status_code,
                branch_upgrade_response.text,
            )
            return False

    if "branch=cleanlife" in response.text:
        logging.info("Response indicates set server to cleanlife")
        try:
            branch_upgrade_response = requests.post(
                "http://localhost/dali/api/update-branch/cleanlife", timeout=5
            )
            assert branch_upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                branch_upgrade_response.status_code,
                branch_upgrade_response.text,
            )
            return False

    if "known" in response.text:
        logging.info("Response indicates known IP")

    if "upgrade=1" in response.text:
        logging.info("Response indicates upgrade=1")
        try:
            upgrade_response = requests.post(
                "http://localhost/dali/api/update-server", timeout=5
            )
            assert upgrade_response.status_code == 200
            logging.info("successfully upgrading")
        except Exception:
            logging.exception(
                "exception upgrading [%s]: %r",
                upgrade_response.status_code,
                upgrade_response.text,
            )
            return False

    if "password=reset" in response.text:
        logging.info("Response indicates password=reset")
        try:
            reset_response = requests.post(
                "http://localhost/dali/api/reset-password", timeout=5
            )
            assert reset_response.status_code == 200
            logging.info("Password reset request successful")
        except Exception:
            logging.exception(
                "Password reset request failed [%s]: %r",
                reset_response.status_code,
                reset_response.text,
            )
    # knownip=2 -- office, knownip=0 refresh gps, knownip=1 do nothing
    if "unknown" in response.text or "knownip=0" in response.text:
        logging.info("IP has changed, refreshing GPS")
        for _ in range(3):
            try:
                response = requests.post(
                    "http://localhost/dali/api/clear-gps-cache", timeout=5
                )
                assert response.status_code == 200
            except Exception:
                logging.exception(
                    "got error refreshing GPS cache [%s]: %r",
                    response.status_code,
                    response.text,
                )
                time.sleep(10)
                continue
            # Successfully cleared cache, break out
            else:
                break
        else:
            return False

    if "dataplicity=DP_remove" in response.text:
        logging.info("Response indicates dataplicity=DP_remove")
        try:
            remove_dataplicity()
        except Exception as e:
            logging.exception("exception removing dataplicity [%s]: ", e)
            return False
    if "dataplicity=DP_pause" in response.text:
        logging.info("Response indicates dataplicity=DP_pause")
        try:
            pause_dataplicity()
        except Exception as e:
            logging.exception("exception pausing dataplicity [%s]: ", e)
            return False
    if "dataplicity=DP_unpause" in response.text:
        logging.info("Response indicates dataplicity=DP_unpause")
        try:
            unpause_dataplicity()
        except Exception as e:
            logging.exception("exception unpausing dataplicity [%s]: ", e)
            return False
    if "DP_install" in response.text:
        reload_config()
        if CRON_BOOM_CONFIG.get("block_remote_dataplicity_install"):
            logging.warning(
                "Ignoring remote Dataplicity installation because it is blocked"
            )
        else:
            logging.info("Response indicates dataplicity=DP_install")
            try:
                install_dataplicity(response.text)
            except Exception as e:
                logging.exception("exception installing dataplicity [%s]: ", e)
                return False

    # interval=time (seconds) between heartbeats

    # Remember when/what we last backed up
    LAST_DATA = internet_data
    LAST_UPDATE_TIME = now

    return True


def run_cmd(*cmd):
    return subprocess.check_call(cmd)


def run_cmd_out(*cmd):
    return subprocess.check_output(cmd).decode("utf-8")


def run_wpa_cli(*args):
    return run_cmd_out("wpa_cli", "-iwlan0", *args)


# Run wpa_cli status and parse the output into a dict


def get_wpa_status():
    result = {}
    for line in run_wpa_cli("status").splitlines():
        k, _, v = line.partition("=")
        result[k] = v
    return result


# Get wifi SSIDs currently being broadcasted


def scan_wifi():
    try:
        run_cmd("sudo", "iwlist", "wlan0", "scan")
    except Exception as e:
        logging.error("error with iwlist command necessary for some hardware: %s", e)
    finally:
        pass

    try:
        scan = run_wpa_cli("scan_results")
        networks = collections.defaultdict(lambda: -100000)
        for line in scan.splitlines():
            try:
                _, _, signal, _, ssid = line.split("\t")
                # Get the maximum signal level for all the networks with the
                # same name
                networks[ssid] = max(networks[ssid], int(signal))
            except Exception:
                pass

        networks = [
            ssid
            for [ssid, signal] in sorted(networks.items(), key=lambda i: i[1])
            if ssid
        ]
        return networks
    except Exception as e:
        logging.error("error getting scanned networks: %s", e)
        return []


def get_conf_networks():
    try:
        network_lines = run_wpa_cli("list_networks").splitlines()
        conf_networks = {}
        for line in network_lines[1:]:
            net_id, ssid, _, _ = line.split("\t")
            conf_networks[ssid] = net_id
        return conf_networks
    except Exception as e:
        logging.error("error getting configured networks: %s", e)
        return {}


# While in hotspot mode, we can still scan for networks. Check if we see
# a network being broadcast that we have a configured password for, so
# we can try connecting to it


def check_maybe_connectable():
    conf_networks = set(get_conf_networks().values())
    avail_networks = set(scan_wifi())

    # Return whether there's any overlap between the two sets
    return conf_networks & avail_networks


# Start up a wifi hotspot


def start_hotspot():
    global NETWORK_CONFIG, HOTPSOT_HAS_BEEN_RUN

    if NETWORK_CONFIG is not None:
        return

    logging.info("Starting wifi hotspot!")

    run_wpa_cli("disconnect")
    run_cmd("sudo", "cp", "./data/dhcpcd.hotspot", "/etc/dhcpcd.conf")
    run_cmd("sudo", "cp", "./data/hostapd.conf", "/etc/hostapd/hostapd.conf")
    run_cmd("sudo", "cp", "./data/dnsmasq.conf", "/etc/dnsmasq.conf")
    run_cmd("sudo", "systemctl", "stop", "dnsmasq")
    run_cmd("sudo", "systemctl", "restart", "dhcpcd")
    # Meh, we need dhcpcd to assign the static IP before we start dnsmasq,
    # but the assignment happens after dhcpcd has gone to the background
    time.sleep(30)
    run_cmd("sudo", "systemctl", "restart", "dnsmasq")
    # Start this up last, otherwise we get this error:
    #  hostapd.service: Can't open PID file /run/hostapd.pid (yet?) after
    #  start: No such file or directory
    # I don't know what this means!
    run_cmd("sudo", "systemctl", "restart", "hostapd")
    HOTPSOT_HAS_BEEN_RUN = True



# Bring down the wifi hotspot, resume normal operation


def stop_hotspot():
    global NETWORK_CONFIG
    logging.info("Stopping wifi hotspot!")

    try:
        # Bring down the AP first, so we don't try to connect to ourselves
        run_cmd("sudo", "systemctl", "stop", "dnsmasq", "hostapd")
        # run_cmd('sudo', 'systemctl', 'stop', 'dhcpcd')

        # Remove this network from the configuration if it already exists
        if NETWORK_CONFIG is not None:
            ssid = NETWORK_CONFIG["ssid"]
            password = NETWORK_CONFIG["password"]
            conf_networks = get_conf_networks()
            if ssid in conf_networks:
                net_id = conf_networks[ssid]
                run_wpa_cli("remove_network", net_id)

            # Set the network up and save the config
            net_id = run_wpa_cli("add_network")
            run_wpa_cli("set_network", net_id, "ssid", '"%s"' % ssid)
            run_wpa_cli("set_network", net_id, "priority", str(int(time.time())))
            if password:
                run_wpa_cli("set_network", net_id, "psk", '"%s"' % password)
                run_wpa_cli("set_network", net_id, "key_mgmt", "WPA-PSK")
            elif ssid:
                run_wpa_cli("set_network", net_id, "key_mgmt", "NONE")

            run_wpa_cli("enable_network", net_id)
            run_wpa_cli("save_config")

            NETWORK_CONFIG = None

        run_cmd("sudo", "cp", "./data/dhcpcd.normal", "/etc/dhcpcd.conf")

        # Handle static IP address.
        static_ip = get_static_ip()
        if static_ip:
            dhcpcd_data = """
# Set static IP address, added by cron-boom.py
interface wlan0
#nohook wpa_supplicant
static ip_address={ip}/{mask}
static routers={router}
static domain_name_servers={dns}
""".format(
                **static_ip
            )
            # Annoying: we need sudo access to append to this file, and
            # so we have to spawn two subshells so the shell redirection
            # happens under sudo. The format of the static IP has been checked
            # in get_static_ip() so no need to escape or anything
            run_cmd("sudo", "sh", "-c", 'echo "%s" >> /etc/dhcpcd.conf' % dhcpcd_data)

        run_cmd("sudo", "cp", "./data/wlan0.atxled", "/etc/network/interfaces.d/")
        run_cmd("sudo", "ip", "link", "set", "wlan0", "down")
        run_cmd("sudo", "ip", "link", "set", "wlan0", "up")
        run_cmd("sudo", "systemctl", "restart", "dhcpcd")
        time.sleep(2)
        run_wpa_cli("reassociate")
        return True
    except Exception:
        logging.exception("got exception stopping hotspot")
    return False

def _run(*args):
    return subprocess.run(args, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def _systemd_active(unit):
    # True if unit is running (active)
    return _run("systemctl", "is-active", "--quiet", unit).returncode == 0

def _file_sha256(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except FileNotFoundError:
        return None

def _wlan_mode(dev="wlan0"):
    # Returns "AP", "station", or None
    p = _run("iw", "dev", dev, "info")
    if p.returncode != 0:
        return None
    out = p.stdout
    # Look for "type AP" or "type managed"
    if " type AP" in out:
        return "AP"
    if " type managed" in out:
        return "station"
    return None

def _wlan_ipv4(dev="wlan0"):
    p = _run("ip", "-4", "-o", "addr", "show", "dev", dev)
    if p.returncode != 0:
        return None
    # Example line: "3: wlan0    inet 192.168.4.1/24 brd 192.168.4.255 scope global wlan0"
    parts = p.stdout.strip().split()
    try:
        idx = parts.index("inet")
        return parts[idx+1]  # e.g. "192.168.4.1/24"
    except Exception:
        return None

def _listening_dnsmasq():
    # Is dnsmasq listening on DHCP/DNS ports?
    p = _run("ss", "-lunp")  # UDP listeners with process names
    if p.returncode != 0:
        return False
    out = p.stdout
    return ("dnsmasq" in out) and (":67 " in out or ":53 " in out)

def files_identical(a, b):
    ha, hb = _file_sha256(a), _file_sha256(b)
    return ha is not None and hb is not None and ha == hb

def check_hotspot_state(
    dev="wlan0",
    hotspot_ip_prefix=("192.168.10.",),
    dhcpcd_hotspot="./data/dhcpcd.hotspot",
    dhcpcd_current="/etc/dhcpcd.conf",
):
    hostapd_active   = _systemd_active("hostapd")
    dnsmasq_active   = _systemd_active("dnsmasq")
    wpa_active       = _systemd_active("wpa_supplicant")
    mode             = _wlan_mode(dev)
    ipv4             = _wlan_ipv4(dev)
    using_hotspot_cf = files_identical(dhcpcd_current, dhcpcd_hotspot)
    hostapd_pid      = os.path.exists("/run/hostapd.pid") or os.path.exists("/run/hostapd/hostapd.pid")
    dnsmasq_listen   = _listening_dnsmasq()

    ip_looks_hotspot = False
    if ipv4:
        ip_looks_hotspot = any(ipv4.startswith(pfx) for pfx in hotspot_ip_prefix)

    # Consider hotspot "active" if any strong signal says so
    active_signals = [
        hostapd_active,
        dnsmasq_active and dnsmasq_listen,
        mode == "AP",
        hostapd_pid,
        using_hotspot_cf,
        ip_looks_hotspot,
    ]
    is_active = any(active_signals)

    info = {
        "hostapd_active": hostapd_active,
        "dnsmasq_active": dnsmasq_active,
        "wpa_supplicant_active": wpa_active,
        "wlan_mode": mode,
        "wlan_ipv4": ipv4,
        "dnsmasq_listening": dnsmasq_listen,
        "hostapd_pid_present": hostapd_pid,
        "dhcpcd_conf_matches_hotspot": using_hotspot_cf,
        "inferred_hotspot_active": is_active,
    }
    return is_active, info


def get_static_ip():
    info = None
    try:
        if os.path.exists(STATIC_IP_PATH):
            with open(STATIC_IP_PATH) as f:
                info = json.load(f)
                assert isinstance(info, dict)
                for [k, v] in info.items():
                    assert k in ["ip", "mask", "router", "dns"]
                    assert isinstance(v, str)
                    assert re.match("^[0-9a-f.:,]+$", v)
                return info
    except Exception:
        logging.error("bad ip address format: %s", info)
    return None


def set_static_ip(ip):
    if not ip:
        if os.path.exists(STATIC_IP_PATH):
            os.unlink(STATIC_IP_PATH)
        return
    with open(STATIC_IP_PATH, "w") as f:
        f.write(ip)


# Sleep for X seconds, while checking a condition every 5 seconds


def mark_check_loop_progress():
    global CHECK_LOOP_LAST_PROGRESS
    CHECK_LOOP_LAST_PROGRESS = time.monotonic()


def sleep_check(seconds):
    global NETWORK_CONFIG
    mark_check_loop_progress()
    while seconds > 5:
        time.sleep(5)
        mark_check_loop_progress()
        seconds -= 5
        if NETWORK_CONFIG is not None:
            return True
    time.sleep(seconds)
    mark_check_loop_progress()
    return NETWORK_CONFIG is not None


def run_hotspot_mode():
    start_hotspot()

    time_slept = 0

    while True:
        # Sleep for 20 minutes, waiting for updates from the web interface
        sleep_time = 20 * 60
        if sleep_check(sleep_time):
            break
        time_slept += sleep_time

        # Check if there's regular internet connectivity (like through a
        # wired connection)
        internet_data = get_internet_status()
        if internet_data:
            logging.info("Got network connection")
            break

        if not LAST_USE_TIME or (time.time() - LAST_USE_TIME) > 4 * 60:
            # No updates for five minutes, check if we can see a network that
            # we already have configured
            logging.info("Checking for any wifi networks we can connect to...")
            connectable = check_maybe_connectable()
            if connectable:
                logging.info("Found networks with configuration: %s", connectable)
                break

        # Fail safe: if we're in hotspot mode for over an hour, and we haven't
        # gotten any user input, reboot. This is to prevent hotspot mode accidentally
        # putting the pi into a state where it can't reconnect to the internet,
        # which happened a few times during testing for unknown reasons
        # XXX taking out reboot for now, this triggered on Stuart's system and
        # the pi apparently didn't come back up, and the hotspot errors are
        # quite possibly all fixed
        # if time_slept >= 60*60 and (not LAST_USE_TIME or (time.time() - LAST_USE_TIME) > 20*60):
        #    logging.error('Stopping wifi hotspot AND REBOOTING!')
        #    stop_hotspot()
        #    run_cmd('sudo', 'reboot')

        # This reboots the pi after the 10 minutes of waiting above.
        # This is the current best answer for the state of the code and understanding of
        # networking in python and on the pi.
        logging.error("Stopping wifi hotspot and rebooting.")
        is_active, info = check_hotspot_state()
        if is_active:
            logging.info("Hotspot state before stopping: %s", info)
        stop_hotspot()
    is_active, info = check_hotspot_state()
    if is_active:
        logging.info("Hotspot state before stopping: %s", info)
    stop_hotspot()


def check_zpds():
    import requests

    try:
        response = requests.get("http://localhost/dali/api/server-status", timeout=5)
        if response.status_code != 200 or response.text != '{"ok":true}\n':
            logging.info(
                "got bad ZPDS status[%s]: %r", response.status_code, response.text
            )
            return False
    except Exception as e:
        logging.exception("exception getting ZPDS status")
        return False
    return True


def post_watchdog_failure_message():
    import requests

    try:
        mac = get_mac_address()

        response = requests.post(
            "https://me.dalihub.com/why.php?value=watchdog&" "mac=%s" % mac,
            timeout=10,
        )
        if response.status_code != 200:
            logging.info(
                "could not send watchdog fail message [%s]: %s",
                response.status_code,
                response.text,
            )
    except Exception as e:
        pass


# This loop is the main internet health check.


def check_internet_loop():
    global HOTSPOT_ENABLED, HOTPSOT_HAS_BEEN_RUN
    n_fails = 0
    n_status_fails = 0
    logging.info("starting check loop")
    while True:
        # Always start with a sleep
        sleep_check(30)

        # 4 fails in a row
        check_hotspot_status()

        # This is a local health check and must not depend on Internet access or
        # the external check-in service being available.
        if not check_zpds():
            n_status_fails += 1
            if n_status_fails > 10:
                n_status_fails = 0
                logging.error("watchdog failure, restarting")

                post_watchdog_failure_message()

                # Restart ZPDS directly. Its ExecStartPre still invokes the
                # structural backup-update check before starting the app.
                run_cmd(
                    "sudo",
                    "systemctl",
                    "restart",
                    "--no-block",
                    "zpds.service",
                )
                sleep_check(5 * 60)
            continue
        n_status_fails = 0

        if HOTSPOT_ENABLED and not HOTPSOT_HAS_BEEN_RUN:
            if n_fails > 5:
                run_hotspot_mode()
                n_fails = 0
                continue

        internet_data = get_internet_status()
        if not internet_data:
            logging.error("error getting LAN info (n_fails=%s)", n_fails)
            n_fails += 1
            continue

        # Send a backup if necessary. update_boom() makes sure we're sending fresh
        # data before actually backing up.
        if not update_boom(internet_data):
            n_fails += 1
            continue

        n_fails = 0

        sleep_check(3 * 60 - 30)


def run_check_loop():
    while True:
        try:
            check_internet_loop()
        except Exception:
            logging.exception("Got error in check loop!")


@app.before_request
def update_user_time():
    global LAST_USE_TIME
    if flask.request.path != "/health":
        LAST_USE_TIME = time.time()


@app.route("/")
@app.route("/<path:path>")
def get_wifi_setup(**kwargs):
    networks = scan_wifi()
    return flask.render_template("wifi.html", networks=networks)


@app.route("/setup", methods=["POST"])
def post_wifi_setup():
    global NETWORK_CONFIG

    if "save" in flask.request.form:
        assert NETWORK_CONFIG is None
        ssid = flask.request.form["ssid"] or flask.request.form["ssid-manual"]
        # From what I can gather, wpa_supplicant.conf doesn't allow any
        # escaping, but takes every byte between the first and last quotes on
        # a line, so we basically just have to filter newlines
        ssid = ssid.replace("\n", "")
        password = flask.request.form["password"].replace("\n", "")

        # Remove static IP address, since we have a new network config
        set_static_ip(None)

        NETWORK_CONFIG = {"ssid": ssid, "password": password}

        return flask.render_template("wifi-done.html")

    elif "rescan" in flask.request.form:
        networks = scan_wifi()
        return flask.render_template("wifi.html", networks=networks)


@app.route("/status")
def get_status():
    internet_data = get_internet_status()
    status = get_wpa_status()
    scan = run_wpa_cli("scan_results")

    return "<html><pre>%s\n%s\n%s" % (internet_data, status, scan)


@app.route("/health")
def health():
    thread_alive = CHECK_LOOP_THREAD is not None and CHECK_LOOP_THREAD.is_alive()
    progress_age = None
    if CHECK_LOOP_LAST_PROGRESS is not None:
        progress_age = time.monotonic() - CHECK_LOOP_LAST_PROGRESS
    healthy = (
        thread_alive
        and progress_age is not None
        and progress_age <= CHECK_LOOP_MAX_AGE
    )
    return (
        flask.jsonify(
            {
                "ok": healthy,
                "check_loop_alive": thread_alive,
                "last_progress_age_seconds": (
                    round(progress_age, 1) if progress_age is not None else None
                ),
            }
        ),
        200 if healthy else 503,
    )


@app.route("/key")
def get_key_page():
    return flask.render_template("key.html")


@app.route("/key", methods=["POST"])
def post_key():
    key = flask.request.form["key"]
    # path = '/home/pi/atxled/key'
    path = "/tmp/atx-led-key"
    with open(path, "wt") as f:
        f.write(key)

    return "Done."


@app.route("/restart")
def restart():
    run_cmd("sudo", "systemctl", "restart", "atx-led-updater.service")
    return "Done."


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    if len(sys.argv) > 1:
        if sys.argv[1] == "start":
            start_hotspot()
        elif sys.argv[1] == "stop":
            stop_hotspot()
        elif sys.argv[1] == "backup":
            internet_data = get_internet_status()
            update_boom(internet_data)
        elif sys.argv[1] == "hotspot":
            threading.Thread(target=run_hotspot_mode).start()
            app.run("0.0.0.0", port=5100)
        elif sys.argv[1] == "set-static-ip":
            # Write the static IP to a file and then "stop hotspot", which puts
            # the internet back to normal mode, respecting the static IP
            set_static_ip(sys.argv[2])
            if not stop_hotspot():
                sys.exit(1)
        elif sys.argv[1] == "get-static-ip":
            ip = get_static_ip()
            if not ip:
                sys.exit(1)
            print(json.dumps(ip))
        else:
            assert 0, "bad argument: %s" % (sys.argv)
        sys.exit(0)

    # Make sure the hotspot isn't up
    check_hotspot_status()
    if HOTSPOT_ENABLED:
        is_active, info = check_hotspot_state()
        logging.info("Hotspot state on startup: %s", info)
        if is_active:
            logging.info("Hotspot detected on startup, stopping hotspot")
            stop_hotspot()
        else:
            logging.info("Hotspot disabled, not running")

    # launch a background thread to check internet status
    CHECK_LOOP_THREAD = threading.Thread(
        target=run_check_loop, name="Internet check loop"
    )
    CHECK_LOOP_THREAD.start()
    app.run("0.0.0.0", port=5100)
