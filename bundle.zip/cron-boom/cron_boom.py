#!/usr/bin/python3
import io
import logging
import os
import socket
import subprocess
import sys
import threading
import time
import zipfile

import flask
import requests

app = flask.Flask(__name__)

#os.chdir(sys.path[0])
os.chdir('/home/pi')

NETWORK_CONFIG = None
LAST_USE_TIME = None

#HOTSPOT_MODE = True
HOTSPOT_MODE = False

# Get ip/mac addresses
def get_internet_status():
    try:
        # Get the mac of the wifi adapter. RPi specific-ish
        with open('/sys/class/net/wlan0/address') as f:
            mac = f.read().strip().replace(':', '')

        # Kinda hacky: just use the first IP returned by hostname -I, even though
        # they say "Do not make any assumptions about the order of the output"
        ips = subprocess.check_output(['hostname', '-I']).decode('utf-8')
        ip = ips.split()[0]

        return {'mac': mac, 'ip': ip}
    except Exception as e:
        logging.error('error getting LAN info: %s', e)
        return None

# Return backup of user data as a BytesIO containing a zip file
def get_db_backup():
    # Create database backup bundle
    backup = io.BytesIO()
    with zipfile.ZipFile(backup, mode='w',
            compression=zipfile.ZIP_DEFLATED) as backup_zip:
        paths = ['config.json', 'zpds-config.json', 'zpds.db']
        for path in paths:
            path = 'atxled/user-data/%s' % path
            status = "doesn't exist"
            if os.path.exists(path):
                backup_zip.write(path)
                with open(path, 'rb') as f:
                    status = '%s bytes' % len(f.read())
            logging.info('file %s: %s', path, status)

    backup.seek(0, 2)
    logging.info('Backing up user data, %s bytes.', backup.tell())
    backup.seek(0)
    return backup

# Send ip/map to me.atxled.com for local redirection
def update_boom(data):
    try:
        logging.info('Updating boomerang service: %s', data)

        backup = get_db_backup()

        response = requests.put('http://me.atxled.com/up/?lan=%s&mac=%s' %
                (data['ip'], data['mac']), data=backup)
        if response.status_code != 200:
            logging.info('could not update boomerang service[%s]: %s',
                    response.status_code, response.text)
            return False
    except Exception as e:
        logging.exception('Could not update boomerang service')
        return False
    return True

def run_cmd(*cmd):
    return subprocess.check_call(cmd)

def run_wpa_cli(*args):
    cmd = ['wpa_cli', '-iwlan0', *args]
    return subprocess.check_output(cmd).decode('utf-8')

# Run wpa_cli status and parse the output into a dict
def get_wpa_status():
    result = {}
    for line in run_wpa_cli('status').splitlines():
        k, _, v = line.partition('=')
        result[k] = v
    return result

# Get wifi SSIDs currently being broadcasted
def scan_wifi():
    try:
        scan = run_wpa_cli('scan_results')
        networks = []
        for line in scan.splitlines():
            try:
                _, _, signal, _, ssid = line.split('\t')
                networks.append((-int(signal), ssid))
            except Exception:
                pass

        networks = [ssid for signal, ssid in sorted(networks) if ssid]
        return networks
    except Exception as e:
        logging.error('error getting scanned networks: %s', e)
        return []

def get_conf_networks():
    try:
        network_lines = run_wpa_cli('list_networks').splitlines()
        conf_networks = {}
        for line in network_lines[1:]:
            net_id, ssid, _, _ = line.split('\t')
            conf_networks[ssid] = net_id
        return conf_networks
    except Exception as e:
        logging.error('error getting configured networks: %s', e)
        return {}

# While in hotspot mode, we can still scan for networks. Check if we see
# a network being broadcast that we have a configured password for, so
# we can try connecting to it
def check_maybe_connectable():
    conf_networks = set(get_conf_networks().values())
    avail_networks = set(scan_wifi())

    # Return whether there's any overlap between the two sets
    return conf_networks & avail_networks

# Start up a wifi hotspot
def start_hotspot():
    global NETWORK_CONFIG

    if NETWORK_CONFIG is not None:
        return

    logging.info('Starting wifi hotspot!')

    run_wpa_cli('disconnect')
    run_cmd('sudo', 'cp', './data/dhcpcd.hotspot', '/etc/dhcpcd.conf')
    run_cmd('sudo', 'cp', './data/hostapd.conf', '/etc/hostapd/hostapd.conf')
    run_cmd('sudo', 'cp', './data/dnsmasq.conf', '/etc/dnsmasq.conf')
    run_cmd('sudo', 'systemctl', 'stop', 'dnsmasq')
    run_cmd('sudo', 'systemctl', 'restart', 'dhcpcd')
    run_cmd('sudo', 'systemctl', 'restart', 'hostapd')
    # Meh, we need dhcpcd to assign the static IP before we start dnsmasq,
    # but the assignment happens after dhcpcd has gone to the background
    time.sleep(30)
    run_cmd('sudo', 'systemctl', 'restart', 'dnsmasq')

# Bring down the wifi hotspot, resume normal operation
def stop_hotspot():
    global NETWORK_CONFIG
    # Bring down the AP first, so we don't try to connect to ourselves
    run_cmd('sudo', 'systemctl', 'stop', 'dnsmasq', 'hostapd')
    #run_cmd('sudo', 'systemctl', 'stop', 'dhcpcd')

    # Remove this network from the configuration if it already exists
    if NETWORK_CONFIG is not None:
        ssid = NETWORK_CONFIG['ssid']
        password = NETWORK_CONFIG['password']
        conf_networks = get_conf_networks()
        if ssid in conf_networks:
            net_id = conf_networks[ssid]
            run_wpa_cli('remove_network', net_id)

        # Set the network up and 
        net_id = run_wpa_cli('add_network')
        run_wpa_cli('set_network', net_id, 'ssid', '"%s"' % ssid)
        run_wpa_cli('set_network', net_id, 'psk', '"%s"' % password)
        run_wpa_cli('set_network', net_id, 'key_mgmt', 'WPA-PSK')
        run_wpa_cli('enable_network', net_id)
        run_wpa_cli('save_config')

        NETWORK_CONFIG = None

    run_cmd('sudo', 'cp', './data/dhcpcd.normal', '/etc/dhcpcd.conf')
    run_cmd('sudo', 'systemctl', 'restart', 'dhcpcd')
    run_wpa_cli('reassociate')

# Sleep for X seconds, while checking a condition every 5 seconds
def sleep_check(seconds):
    global NETWORK_CONFIG
    while seconds > 5:
        time.sleep(5)
        seconds -= 5
        if NETWORK_CONFIG is not None:
            return True
    time.sleep(seconds)
    return NETWORK_CONFIG is not None

def run_hotspot_mode():
    start_hotspot()

    while True:
        # Sleep for five minutes, waiting for updates from the web interface
        if sleep_check(5*60):
            break

        if not LAST_USE_TIME or (time.time() - LAST_USE_TIME) > 4*60:
            # No updates for five minutes, check if we can see a network that
            # we already have configured
            logging.info('Checking for networks with configuration...')
            connectable = check_maybe_connectable()
            if connectable:
                logging.info('Found networks with configuration: %s', connectable)
                break

    logging.info('Stopping wifi hotspot!')
    stop_hotspot()

# This loop is the main internet health check.
def check_internet_loop():
    last_data = None
    last_update_time = 0
    TWO_WEEKS = 14*24*60*60
    n_fails = 0
    logging.info('starting check loop')
    while True:
        # 4 fails in a row
        if HOTSPOT_MODE:
            if n_fails > 3:
                run_hotspot_mode()
                n_fails = 0
                continue

        data = get_internet_status()
        if not data:
            logging.error('error getting LAN info (n_fails=%s)', n_fails)
            n_fails += 1
            sleep_check(30)
            continue

        # Only send a request if our local ip has changed, or two weeks have passed
        now = time.time()
        delta = now - last_update_time
        if (data != last_data or delta > TWO_WEEKS) and not update_boom(data):
            n_fails += 1
            sleep_check(30)
            continue

        n_fails = 0
        last_data = data
        last_update_time = now
        sleep_check(3*60)

def run_check_loop():
    while True:
        try:
            check_internet_loop()
        except Exception:
            logging.exception('Got error in check loop!')

@app.before_request
def update_user_time():
    global LAST_USE_TIME
    LAST_USE_TIME = time.time()

@app.route('/')
@app.route('/<path:path>')
def get_wifi_setup(**kwargs):
    networks = scan_wifi()
    return flask.render_template('wifi.html', networks=networks)

@app.route('/setup', methods=['POST'])
def post_wifi_setup():
    global NETWORK_CONFIG

    assert NETWORK_CONFIG is None
    ssid = flask.request.form['ssid'] or flask.request.form['ssid-manual']
    # From what I can gather, wpa_supplicant.conf doesn't allow any
    # escaping, but takes every byte between the first and last quotes on
    # a line, so we basically just have to filter newlines
    ssid = ssid.replace('\n', '')
    password = flask.request.form['password'].replace('\n', '')

    NETWORK_CONFIG = {'ssid': ssid, 'password': password}

    return flask.render_template('wifi-done.html')

@app.route('/status')
def get_status():
    data = get_internet_status()
    status = get_wpa_status()
    scan = run_wpa_cli('scan_results')

    return '<html><pre>%s\n%s\n%s' % (data, status, scan)

@app.route('/key')
def get_key_page():
    return flask.render_template('key.html')

@app.route('/key', methods=['POST'])
def post_key():
    key = flask.request.form['key']
    #path = '/home/pi/atxled/key'
    path = '/tmp/atx-led-key'
    with open(path, 'wt') as f:
        f.write(key)

    return 'Done.'

@app.route('/restart')
def restart():
    run_cmd('sudo', 'systemctl', 'restart', 'atx-led-updater.service')
    return 'Done.'

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    if len(sys.argv) > 1:
        if sys.argv[1] == 'start':
            start_hotspot()
        elif sys.argv[1] == 'stop':
            stop_hotspot()
        elif sys.argv[1] == 'backup':
            data = get_internet_status()
            update_boom(data)
        elif sys.argv[1] == 'hotspot':
            threading.Thread(target=run_hotspot_mode).start()
            app.run('0.0.0.0', port=5100)
        else:
            assert 0, 'bad argument: %s' % (sys.argv)
        sys.exit(0)

    # Make sure the hotspot isn't up
    if HOTSPOT_MODE:
        stop_hotspot()

    # Launch a background thread to check internet status
    threading.Thread(target=run_check_loop).start()
    app.run('0.0.0.0', port=5100)
