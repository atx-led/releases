#!/bin/sh

#wpa_cli -iwlan0 -a./wpa_update.sh -B

curl --data-raw interface="$1" --data-raw cmd="$2" http://localhost/wpa-update
