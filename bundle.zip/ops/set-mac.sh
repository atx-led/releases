echo "last: $1"
sudo ifconfig wlan0 down
sudo ifconfig wlan0 hw ether 00:17:88:00:44:$1
sudo ifconfig wlan0 up

