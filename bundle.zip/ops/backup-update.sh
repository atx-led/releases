#!/bin/sh
set -e

BASE=/home/pi/atxled
RELEASES_DIR=$BASE/releases
INSTALL_DIR=$BASE/hue
WORK_DIR=$BASE/backup-update

check_release_files() {
    for path in choose.py setup.sh update.sh atx-led-updater.service load.py util.py expand.py bundle.zip zpds.bin tag; do
        if [ ! -s $RELEASES_DIR/$path ]; then
            echo "Release file is missing or empty: $RELEASES_DIR/$path"
            return 1
        fi
    done
    return 0
}

check_install_files() {
    for path in ops/install.py cron-boom/cron_boom.py sddp/sddp_wrapper.py zpds/run.sh; do
        if [ ! -s $INSTALL_DIR/$path ]; then
            echo "Install file is missing or empty: $INSTALL_DIR/$path"
            return 1
        fi
    done
    return 0
}

if check_release_files && check_install_files; then
    exit 0
fi

echo "Install is structurally broken; running backup update."

BRANCH=master
[ -f $BASE/branch ] && BRANCH=`cat $BASE/branch`
if [ "$BRANCH" = "cleanlife" ]; then
    echo "Normalizing cleanlife branch to master."
    rm -f $BASE/branch
    BRANCH=master
fi
: "${RELEASE_REPO_URL:=https://github.com/CleanLife-IT/Releases---atxlediot}"
URL=$RELEASE_REPO_URL/archive/$BRANCH.zip

rm -rf $WORK_DIR
mkdir -p $WORK_DIR
cd $WORK_DIR

DOWNLOAD_OK=0
for delay in 1 2 5 10 15; do
    if curl --fail -o releases.zip.tmp --location "$URL"; then
        if [ ! -s releases.zip.tmp ]; then
            echo "Download produced an empty releases.zip. Retrying in ${delay}s..."
            sleep $delay
            continue
        fi
        DOWNLOAD_OK=1
        break
    else
        echo "Download failed. Retrying in ${delay}s..."
        sleep $delay
    fi
done

if [ "$DOWNLOAD_OK" != "1" ]; then
    echo "Backup update failed to download release archive."
    exit 1
fi

mv -f releases.zip.tmp releases.zip
unzip -t releases.zip

mkdir new-releases
unzip -j releases.zip -d new-releases

for path in choose.py setup.sh update.sh atx-led-updater.service load.py util.py expand.py bundle.zip zpds.bin tag; do
    if [ ! -s new-releases/$path ]; then
        echo "Downloaded release is missing required file: $path"
        exit 1
    fi
done

unzip -t new-releases/bundle.zip

mkdir hue.new
unzip new-releases/bundle.zip -d hue.new

for path in ops/install.py cron-boom/cron_boom.py sddp/sddp_wrapper.py zpds/run.sh; do
    if [ ! -s hue.new/$path ]; then
        echo "Downloaded install is missing required file: $path"
        exit 1
    fi
done

rm -rf $BASE/releases.backup-bad $BASE/hue.backup-bad
[ -e $RELEASES_DIR ] && mv $RELEASES_DIR $BASE/releases.backup-bad
[ -e $INSTALL_DIR ] && mv $INSTALL_DIR $BASE/hue.backup-bad
mv new-releases $RELEASES_DIR
mv hue.new $INSTALL_DIR

rm -rf $WORK_DIR

echo "Backup update restored release and install files."
