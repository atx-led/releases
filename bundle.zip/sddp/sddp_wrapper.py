#!/usr/bin/env python3
import sys
import os
import time

def main():
    print('Service started for Python version %s' % (sys.version.split()[0]))
    if sys.version.startswith('3.9'):
        print('Running sddpd for Python 3.9')
        os.system('/home/pi/atxled/hue/sddp/sddpd -n -d ./')
    else:
        print('Python version is not 3.9, entering idle mode.')
        while True:
            time.sleep(3600)

if __name__ == "__main__":
    main()