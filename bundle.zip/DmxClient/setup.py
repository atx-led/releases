#!/usr/bin/env python3
import pathlib

from setuptools import find_packages, setup

HERE = pathlib.Path(__file__).parent

# The text of the README file

setup(
    name="dmx512-client",
    description="Consume DMX-512 feed over serial line (usualy over RS458 to RS232 converter)",
    url="https://github.com/smarek/dmx-python-client",
    author="Marek Sebera",
    author_email="marek.sebera@gmail.com",
    license="Apache License, Version 2.0",
    version="0.5",
    packages=["dmx_client", "dmx_client_callback"],
    zip_safe=True,
    scripts=[],
    keywords="dmx dmx512",
    python_requires="~=3.7",
    install_requires=["pyserial"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "License :: OSI Approved :: Apache Software License",
        "Environment :: Console",
        "Operating System :: POSIX :: Linux",
        "Typing :: Typed",
        "Natural Language :: English",
        "Programming Language :: Python :: 3.7",
    ],
)