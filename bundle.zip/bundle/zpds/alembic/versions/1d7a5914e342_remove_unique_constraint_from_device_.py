"""Remove unique constraint from device name

Revision ID: 1d7a5914e342
Revises: ded7af6d335e
Create Date: 2019-09-18 14:04:35.158140

"""
from alembic import op, context
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1d7a5914e342'
down_revision = 'ded7af6d335e'
branch_labels = None
depends_on = None

conv = context.config.naming_convention

def upgrade():
    with op.batch_alter_table('devices', naming_convention=conv) as batch_op:
        batch_op.drop_constraint('uq_devices_name', type_='unique')

def downgrade():
    with op.batch_alter_table('devices', naming_convention=conv) as batch_op:
        batch_op.create_unique_constraint('uq_devices_name', ['name'])
