import requests

base_url = 'https://cdnjs.cloudflare.com/ajax/libs/{project}/{name}.js'

deps = [
    ('react/', 'react/16.10.2/umd', 'react.production.min'),
    ('react/', 'react-dom/16.10.2/umd', 'react-dom.production.min'),
]

for subdir, project, name in deps:
    url = base_url.format(name=name, project=project)
    response = requests.get(url)
    response.raise_for_status()

    with open('./js/%s%s.js' % (subdir, name), 'wb') as f:
        f.write(response.content)
