import json
import random
import re
import subprocess
import threading
import time

import dali_cmds
import util

# Bus simulator! What's more exciting than a bus simulator???
# This one is for DALI though, not poor people.
#
# This file contains (or at least it will eventually) a simulation of
# as much of the DALI universe as we use. Ideally every piece of code
# in the system can be tested without needing to actually be hooked
# up to a serial interface.
#
# As a general rule, most code here for interpreting DALI should not
# be shared with the rest of the system, so we have an independent
# check on correctness.

# Dummy device (a light or something)
class FakeDevice:
    def __init__(self, short_addr=None, serial_nb=None, upc=None, is_passive=False,
            split_addr=None):
        self.short_addr = short_addr
        self.level = 0
        self.power_on = False
        self.groups = set()
        self.set_group_mask()

        self.long_addr = 0
        self.compare_addr = 0
        self.search_mode = False
        self.is_passive = is_passive

        self.set_split_mode(split_addr)
        self.split_level = 0
        self.split_dev_on = 0

        # Presumably we want more logic in setting these
        self.dev_status = 0
        self.cct_level = 0
        self.current_rgbwaf = [0, 0, 0, 0]
        self.dev_on = 0
        self.dali_version = 0
        self.dev_type = 8
        self.phy_min_level = 0
        self.max_level = 254
        self.min_level = 0
        self.power_on_level = 0
        self.fail_level = 0
        self.fade_up = 0
        self.fade_down = 0
        self.enable_extended = False
        self.scene_levels = [None] * 16
        self.scene_cct = [None] * 16

        # DR2G fake topology stuff
        self.dr2g_distance = 0
        self.dr2g_related_devs = []

        self.dtr_0 = 0
        self.dtr_1 = 0
        self.dtr_2 = 0
        self.cct_reg = 0
        self.color_rgb = [0, 0, 0]
        self.color_waf = [0, 0, 0]
        self.mem = [[0] * 256 for i in range(8)]
        self.write_enable = False

        if serial_nb is not None:
            self.mem[0][11:15] = dali_cmds.mem_from_int(serial_nb, 4)
        self.upc = upc
        if upc is not None:
            self.mem[0][3:9] = dali_cmds.mem_from_int(upc, 6)

        # Set up DR2F16/32-specific settings
        if upc in {dali_cmds.DR2F16_UPC, dali_cmds.DR2F32_UPC}:
            # Set firmware version
            self.mem[0][9] = 54
            # Set split address
            self.mem[5][29] = split_addr or 255
            # Set slider position
            self.mem[5][30] = 0
            # Set voltage limits
            self.mem[5][6:8] = [40, 56]
            # Set current limits
            # XXX disabled for now
            #self.mem[5][24:26] = dali_cmds.mem_from_int(20, 2, big_endian=False)
            #self.mem[5][26:28] = dali_cmds.mem_from_int(660, 2, big_endian=False)
            # Set fan options
            self.mem[5][20:24] = [10, 23, 0, 254]
            # Set # LEDs options
            self.mem[5][36:38] = dali_cmds.mem_from_int(2500, 2)
            self.mem[5][38:40] = dali_cmds.mem_from_int(2500, 2)
            self.mem[5][44] = 3
            self.mem[5][45] = 3

            if upc == dali_cmds.DR2F32_UPC:
                # Set left/right color values
                self.mem[5][10:11] = [208, 31]
                # Set dim to warm value
                self.mem[5][28] = 0xF5
            else:
                self.dev_type = 6

        if upc == dali_cmds.DR2G32_UPC:
            self.mem[5][44:46] = [12, 12]

        # Set up fake power readings
        if upc != dali_cmds.DR2F16_UPC:
            self.mem[4][3:5] = dali_cmds.mem_from_int(2001, 2, big_endian=False)
            self.mem[4][5:7] = dali_cmds.mem_from_int(1000, 2, big_endian=False)
            if upc == dali_cmds.DR2F32_UPC:
                self.mem[4][7:9] = dali_cmds.mem_from_int(801, 2, big_endian=False)
                self.mem[4][9] = 125
                self.mem[4][10] = 251
                self.mem[4][12] = 73
            else:
                self.mem[4][7:9] = dali_cmds.mem_from_int(501, 2, big_endian=False)
                self.mem[4][9] = 3
                self.mem[4][10] = 251

        # Set up RGB/CCT support
        self.color_mode = None
        self.color_status = 0x20
        if upc == dali_cmds.FAKE_RGB_DEVICE_UPC:
            self.color_mode = 0x72
            self.color_status = 0x80
        elif upc == dali_cmds.FAKE_RGBWAF_DEVICE_UPC:
            self.color_mode = 0xD2
            self.color_status = 0x80
        elif upc == dali_cmds.DR1_PIR_UPC:
            self.dev_type = 6
            self.mem[4][20] = 194
            self.mem[4][21] = 73
        # If there's a UPC but not the fake RGB device, assume ATX-LED,
        # and no color mode (F9) support
        elif upc is None:
            self.color_status = None
        else:
            self.color_mode = 0x02

        # Handle special behavior for other devices
        self.is_button_device = (upc in {dali_cmds.DALI_8B_UPC,
                dali_cmds.DALI_IO16_UPC, dali_cmds.DALI_RELAY8_UPC})
        if self.is_button_device:
            self.mem[0][16] = 8

        # Set up fake power readings etc. for PSE-4Ds
        if upc == dali_cmds.PSE_4D_UPC:
            # Power readings
            self.mem[4][7:31] = [72, 0, 187, 108, 84, 200, 5, 199, # Vin
                    225, 198, 146, 113, 45, 200, 141, 200, # Vout
                    2, 0, 1, 0, 32, 0, 2, 0] # Current
            self.mem[7][17:27] = [170, 95, 197, 93, 28, 136, 251, 197, 1, 0]
            # Fake topology
            for i in range(64):
                if random.randint(0, 1):
                    self.mem[6][i] = random.randint(12, 48)
                    self.mem[6][i+64] = random.randint(0, 3)

        if upc == dali_cmds.WS_010v_UPC:
            self.is_passive = True

    def set_group_mask(self):
        self.group_0_7 = sum(1 << i for i in range(8) if i in self.groups)
        self.group_8_15 = sum(1 << i for i in range(8) if (i + 8) in self.groups)

    def set_split_mode(self, split_addr):
        # 1-63 are short addresses (0 not allowed)
        if split_addr is not None and 1 <= split_addr < 64:
            self.split_addr = split_addr
            self.split_mode = 'single'
        # 64-79 are group addresses + 64
        elif split_addr is not None and 64 <= split_addr < 79:
            self.split_addr = split_addr - 64
            self.split_mode = 'group'
        else:
            self.split_addr = None
            self.split_mode = None

    def is_split_match(self, addr_type, addr_id):
        return (addr_type == self.split_mode and addr_id == self.split_addr)

    def is_match(self, addr_type, addr_id):
        if addr_type == 'single':
            return (addr_id == self.short_addr)
        elif addr_type == 'group':
            return (addr_id in self.groups)
        elif addr_type == 'all':
            return True
        assert False, addr_type

    def interpret_command(self, cmd_hi, cmd_lo, count=1):
        addr_type, addr_id = dali_cmds.parse_dali_addr(cmd_hi)

        # Interpret low-byte commands addressed to specific device(s)
        if addr_type is not None:
            # Check if this command is to our split address. We only support
            # a subset of commands here, ones that get/set the level
            if self.is_split_match(addr_type, addr_id):
                if (cmd_hi & 1) == 0:
                    self.split_level = cmd_lo
                elif cmd_lo in dali_cmds.DALI_GET_CMDS:
                    attr = dali_cmds.DALI_GET_CMDS[cmd_lo]
                    # Force device type 5
                    if attr == 'dev_type':
                        return 5
                    elif attr == 'level':
                        return self.split_level
                    elif attr == 'dev_on':
                        return self.split_dev_on
                elif cmd_lo == 0x00:
                    self.split_level = 0
                elif cmd_lo == 0x05:
                    self.split_level = self.max_level
                elif cmd_lo == 0x06:
                    self.split_level = self.min_level

                self.split_dev_on = int(self.split_level > 0)

                return None

            is_match = self.is_match(addr_type, addr_id)

            # Direct level set command
            if (cmd_hi & 1) == 0:
                if is_match:
                    self.level = cmd_lo
            # Standard get commands
            elif cmd_lo in dali_cmds.DALI_GET_CMDS:
                # Don't allow passive devices to respond here. It's not clear
                # what subset of commands passive devices should support, but
                # at least blocking this makes them not respond to level queries,
                # which is the main intention
                if not is_match or self.is_passive:
                    return None
                attr = dali_cmds.DALI_GET_CMDS[cmd_lo]
                assert hasattr(self, attr)

                # XXX simulate a possible bug in some 010v and DR2Fs:
                # responding as device type 8 requires an "enable device type
                # 8" first
                if (attr == 'dev_type' and self.upc == dali_cmds.DR2F16_UPC and
                        not self.enable_extended):
                    return 0

                return getattr(self, attr)
            # Standard set commands
            elif cmd_lo in dali_cmds.DALI_SET_CMDS:
                if not is_match:
                    return None
                attr = dali_cmds.DALI_SET_CMDS[cmd_lo]
                assert hasattr(self, attr)
                setattr(self, attr, self.dtr_0)
            # Weird commands

            # Turn off
            elif cmd_lo == 0x00:
                if is_match:
                    self.level = 0
            # Set to max level
            elif cmd_lo == 0x05:
                if is_match:
                    self.level = self.max_level
            # Set to min level
            elif cmd_lo == 0x06:
                if is_match:
                    self.level = self.min_level
            # Step up/down etc.
            # XXX this is hacky and incorrect
            elif cmd_lo in dali_cmds.LEVEL_INC_CMDS:
                if is_match:
                    step = dali_cmds.LEVEL_INC_CMDS[cmd_lo]
                    self.level = max(0, min(254, self.level + step))
            # Trigger scene
            elif (cmd_lo & 0xF0) == 0x10:
                if is_match:
                    level = self.scene_levels[cmd_lo & 0xF]
                    if level is not None and level != 255:
                        self.level = level
                    cct = self.scene_cct[cmd_lo & 0xF]
                    if cct is not None and cct != 700:
                        self.cct_level = cct
            # Reset light settings: no-op
            elif cmd_lo == 0x20 and count == 2:
                pass
            # Capture level as DTR
            elif cmd_lo == 0x21 and count == 2:
                if is_match:
                    self.dtr_0 = self.level
            # Reset level to switch position: no-op
            elif cmd_lo == 0x26:
                pass
            # Set DTR as scene
            elif (cmd_lo & 0xF0) == 0x40 and count == 2:
                if is_match:
                    self.scene_levels[cmd_lo & 0xF] = self.dtr_0
                    self.scene_cct[cmd_lo & 0xF] = self.cct_reg
            # Remove from scene
            elif (cmd_lo & 0xF0) == 0x50 and count == 2:
                if is_match:
                    self.scene_levels[cmd_lo & 0xF] = None
                    self.scene_cct[cmd_lo & 0xF] = None
            # Read scene levels
            elif (cmd_lo & 0xF0) == 0xB0:
                if is_match:
                    cct = self.scene_cct[cmd_lo & 0xF] or 700
                    self.dtr_1 = cct >> 8
                    self.dtr_0 = cct & 255
                    return self.scene_levels[cmd_lo & 0xF]
            # Add to group
            elif (cmd_lo & 0xF0) == 0x60 and count == 2:
                if is_match:
                    self.groups.add(cmd_lo & 0x0F)
                    self.set_group_mask()
            # Remove from group
            elif (cmd_lo & 0xF0) == 0x70 and count == 2:
                if is_match:
                    if cmd_lo & 0x0F in self.groups:
                        self.groups.remove(cmd_lo & 0x0F)
                        self.set_group_mask()
            # Query DTR
            elif cmd_lo == 0x98:
                if is_match:
                    return self.dtr_0
            # Get fade rates
            elif cmd_lo == 0xA5:
                if is_match:
                    return (self.fade_up << 4) | self.fade_down

            # XXX ATX-LED Extensions

            # Enable UPS mode, set max level to DTR
            elif cmd_lo == 0x31:
                if is_match:
                    self.max_level = self.dtr_0
            # Store DTR as short address
            elif cmd_lo == 0x80:
                if is_match:
                    self.short_addr = None if self.dtr_0 == 0xFF else self.dtr_0 >> 1
            # Write enable
            elif cmd_lo == 0x81 and count == 2:
                if is_match:
                    self.write_enable = True
            # Query DTR1
            elif cmd_lo == 0x9C:
                if is_match:
                    return self.dtr_1
            # Get passive level
            elif cmd_lo == 0xAB:
                if is_match and self.is_passive:
                    return self.level
            # Read memory, increment DTR
            elif cmd_lo == 0xC5:
                if is_match:
                    assert 0 <= self.dtr_1 < len(self.mem)
                    bank = self.mem[self.dtr_1]
                    if 0 <= self.dtr_0 < len(bank):
                        result = bank[self.dtr_0]
                        # Special memory values
                        if self.upc == dali_cmds.DR2G32_UPC:
                            # DR2G voltage readings
                            if self.dtr_1 == 4 and self.dtr_0 in {14, 15}:
                                voltage = 48
                                if self.level > 0 or any(dev.level > 0
                                        for dev in self.dr2g_related_devs):
                                    voltage -= (self.dr2g_distance * .013 + .08) * 48/25
                                voltage = int(voltage * 1000)
                                mem = dali_cmds.mem_from_int(voltage, 2, big_endian=False)
                                result = mem[self.dtr_0 - 14]
                            # DR2G wattage readings
                            elif self.dtr_1 == 4 and self.dtr_0 in {16, 17, 18, 19}:
                                wattage = 25 + random.randrange(0, 256) / 256
                                # Divide by 2 to balance left/right
                                wattage = int(wattage * 1000 / 2)
                                mem = dali_cmds.mem_from_int(wattage, 2, big_endian=False)
                                result = mem[self.dtr_0 & 1]

                        self.dtr_0 += 1
                        return result
            # Set CCT register
            elif cmd_lo == 0xE7:
                if is_match and self.enable_extended:
                    self.cct_reg = self.dtr_1 << 8 | self.dtr_0
            # Set CCT level
            elif cmd_lo == 0xE2:
                if is_match and self.enable_extended:
                    self.cct_level = self.cct_reg
                    self.current_rgbwaf = self.color_rgb + self.color_waf
            # Set RGB color from DTR 0/1/2
            elif cmd_lo == 0xEB:
                if is_match and self.enable_extended:
                    self.color_rgb = [self.dtr_0, self.dtr_1, self.dtr_2]
            # Set WAF color from DTR
            elif cmd_lo == 0xEC:
                if is_match and self.enable_extended:
                    self.color_waf = [self.dtr_0, self.dtr_1, self.dtr_2]
            # Set weird unknown RGB color attribute. This is probably
            # color mode, as queried in command F9
            elif cmd_lo == 0xED:
                if is_match and self.enable_extended:
                    self.color_weird_attr = self.dtr_0
            # Query color status
            elif cmd_lo == 0xF8:
                if is_match and self.enable_extended:
                    return self.color_status
            # Query color capability
            elif cmd_lo == 0xF9:
                if is_match and self.enable_extended:
                    return self.color_mode
            # Query CCT
            elif cmd_lo == 0xFA:
                if (is_match and self.upc and self.upc != dali_cmds.DR2F16_UPC
                        and self.dali_version != 8):
                    # Set DTR0/DTR1 to CCT value
                    # XXX is this correct? spec is confusing
                    if self.dtr_0 == 226:
                        self.dtr_1 = self.cct_level >> 8
                        self.dtr_0 = self.cct_level & 0xFF
                        return 0xFF
                    # Return RGB/WAF
                    elif 9 <= self.dtr_0 <= 11:
                        return self.color_rgb[self.dtr_0 - 9]
                    elif 12 <= self.dtr_0 <= 14:
                        return self.color_waf[self.dtr_0 - 12]

            # Query extended version number
            elif cmd_lo == 0xFF:
                if is_match:
                    if self.upc == dali_cmds.WS_010v_UPC:
                        return 209
                    return 2

            else:
                assert False, 'unknown command (count=%s): %02x %02x' % (count, cmd_hi, cmd_lo)

            # Ehh just stick this here to clip levels. Hacky but whatevs
            self.level = util.clip(self.level, self.min_level, self.max_level)
            self.dev_on = (self.level > 0)

        # High byte commands, addressed to every device on the bus
        else:
            # Terminate any special modes
            if cmd_hi == 0xA1:
                self.search_mode = False
                self.write_enable = False
            # Set DTR
            elif cmd_hi == 0xA3:
                self.dtr_0 = cmd_lo
            # Enable search mode
            elif cmd_hi == 0xA5 and count == 2:
                if (cmd_lo == 0 or (cmd_lo == 0xFF and self.short_addr is None) or
                        (cmd_lo & 1 and cmd_lo >> 1 == self.short_addr)):
                    self.search_mode = True
            # Randomize addresses
            elif cmd_hi == 0xA7 and count == 2:
                self.long_addr = random.randrange(0, 1<<24)
            # Compare addresses
            elif cmd_hi == 0xA9:
                #print('compare %s %s %s' % (self.search_mode, self.long_addr, self.compare_addr))
                if self.search_mode and self.long_addr <= self.compare_addr:
                    return 0xFF
            # Withdraw
            elif cmd_hi == 0xAB:
                if self.long_addr == self.compare_addr:
                    self.search_mode = False
            # Set high, middle, or low byte of compare address
            elif cmd_hi in {0xB1, 0xB3, 0xB5}:
                shift = {0xB1: 16, 0xB3: 8, 0xB5: 0}[cmd_hi]
                self.compare_addr &= ~(0xFF << shift)
                self.compare_addr |= (cmd_lo << shift)
            # Assign short address
            elif cmd_hi == 0xB7:
                if self.long_addr == self.compare_addr:
                    self.short_addr = cmd_lo >> 1
            # Query short address
            elif cmd_hi == 0xBB:
                if self.long_addr == self.compare_addr and self.short_addr is not None:
                    return (self.short_addr << 1) | 1
            # Enable device type X
            elif cmd_hi == 0xC1:
                self.enable_extended = (cmd_lo == self.dev_type)

            # XXX ATX-LED Extensions

            # Set DTR1
            elif cmd_hi == 0xC3:
                self.dtr_1 = cmd_lo
            # Set DTR2
            elif cmd_hi == 0xC5:
                self.dtr_2 = cmd_lo
            # Write memory
            elif cmd_hi in {0xC7, 0xC9}:
                if self.write_enable:
                    assert 0 <= self.dtr_1 < len(self.mem)
                    bank = self.mem[self.dtr_1]
                    assert 0 <= self.dtr_0 < len(bank)
                    bank[self.dtr_0] = cmd_lo
                    self.write_enable = False

                    # HACK: emulate device type changing from DR2F driver mode
                    if self.dtr_1 == 5 and self.dtr_0 == 9:
                        self.dev_type = 8 if cmd_lo == 3 else 6

                    # Handle split address changes
                    elif self.dtr_1 == 5 and self.dtr_0 == 29:
                        self.set_split_mode(cmd_lo)

                    if cmd_hi == 0xC7:
                        return cmd_lo
            else:
                assert False, 'unknown command (count=%s): %02x %02x' % (count, cmd_hi, cmd_lo)

            # Annoying: after each command (at least the ones that get here,
            # i.e. ones that don't trigger a response or error), reset the
            # extended device-type status. We skip the enable command too
            # obviously. This is done mostly to test that we send C108 before
            # the device type query to handle the 010v/DR2F bug described above
            if cmd_hi != 0xC1:
                self.enable_extended = False

build_lock = threading.Lock()

class FWSimDevice:
    def __init__(self, short_addr=None, seed=0):
        # Start up the run script, which builds and launches the firmware through the
        # Python FFI wrapper (sim.py). We hold a lock while this is happening, up
        # until the firmware is ready to go, so we avoid trying to build with more
        # than one process if a bunch of firmware sim devices get launched at once.
        with build_lock:
            cmd = ['/home/pi/hue/fw/dr2f32/run.sh', 'deb', 'run']
            if short_addr is not None:
                cmd += ['-s', str(short_addr)]
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    bufsize=0)

            # Wait til the firmware is ready
            while True:
                line = self.proc.stdout.readline().decode()
                assert line
                if line == 'sync\n':
                    break
                # Lines before 'sync' are generally build output, just echo them
                print(line.rstrip())

        # Create a lock to control multithreaded access to the process I/O
        self.device_lock = threading.Lock()

        self.send(b'seed %d\n' % seed)

    # Send a command, get back JSON
    def send(self, line):
        with self.device_lock:
            self.proc.stdin.write(line)
            self.proc.stdin.flush()
            resp = self.proc.stdout.readline().decode()
            return json.loads(resp)

    # Convert the JSON list of [direction, bits, value] tuples from the firmware
    # into Hat-compatible messages, like 'JFF\n'
    def fmt_resp(self, resp):
        lines = []
        for [direction, bits, value] in resp:
            assert direction == 'send'
            assert bits in {8, 16, 24, 25}, bits
            line = None
            if bits == 8:
                line = 'J%02X' % value
            elif bits == 16:
                line = 'H%04X' % value
            elif bits == 24:
                line = 'L%06X' % value
            elif bits == 25:
                line = 'M%08X' % value
            lines.append(line + '\n')
        return ''.join(lines)

    def interpret_command(self, cmd_hi, cmd_lo, count=1):
        cmd = cmd_hi << 8 | cmd_lo
        line = b'recv 16 0x%04x\n' % cmd
        for c in range(count):
            resp = self.send(line)
            assert len(resp) >= 1
            assert resp[0] == ['recv', 16, cmd], (resp, cmd)
            if len(resp) > 1:
                assert len(resp) == 2
                [direction, bits, value] = resp[1]
                assert direction == 'send'
                assert bits == 8
                return value

    def dump(self):
        return self.send(b'dump\n')

    def run_cmd(self, cmd):
        return self.fmt_resp(self.send(cmd))

DEFAULT_UPCS = [None, dali_cmds.DR2MX_UPC, dali_cmds.DR2F16_UPC,
        dali_cmds.DR2F32_UPC, dali_cmds.FAKE_RGB_DEVICE_UPC]

# Dummy bus to communicate with fake devices
class FakeSerialBus:
    def __init__(self, *, devices=None, assign_addresses=True, hat_hw_type=None,
            channels=1, active_channels=None, n_devices=10,
            upcs=None, fake_upcs=False, fw_sim=False):
        # Explicit device list passed in
        if devices is not None:
            # Only one channel for now
            self.devices = [devices]
            self.channels = 1
        # Create new devices based on the parameters. These try to get a nice
        # variety of different types of devices. Note that some tests depend on
        # the specific values here (mainly the sequence of UPCs assigned)
        else:
            if upcs:
                # Try parsing a string from the command line for UPCs. We
                # allow substrings of product names as long as they're unambiguous
                if isinstance(upcs, str):
                    products = upcs.split(',')
                    upcs = []
                    for p in products:
                        upc = None
                        for [k, v] in dali_cmds.UPC_TABLE.items():
                            if re.search(p.lower(), v.lower()):
                                assert upc is None, 'product %s is ambiguous' % p
                                upc = k
                        assert upc, 'product %s does not match' % p
                        upcs.append(upc)
                    print(upcs)
            elif fake_upcs:
                upcs = DEFAULT_UPCS
            else:
                upcs = [None]

            self.devices = []
            for c in range(channels):
                self.devices.append([])
                for i in range(n_devices):
                    short_addr = i if assign_addresses else None

                    # In firmware sim mode, spawn a subprocess through a shim
                    if fw_sim:
                        dev = FWSimDevice(short_addr=short_addr, seed=c*64+i)
                    # Normal dumb Python simulated device mode
                    else:
                        upc = upcs[i % len(upcs)]
                        dev = FakeDevice(short_addr=short_addr, upc=upc)

                    self.devices[c].append(dev)
            self.channels = channels

        if hat_hw_type is not None:
            self.hat_hw_type = hat_hw_type
        else:
            assert self.channels in {1, 2, 4}
            self.hat_hw_type = channels
        self.fw_sim = fw_sim
        self.response_buffer = []
        self.trace_log = []
        self.active_channels = active_channels
        if self.active_channels is None:
            self.active_channels = set(range(self.channels))
        self.power_mode = 0
        self.seq = 0
        self.noise = 0

    def write(self, buf, is_resend=False):
        buf = buf.decode('ascii')
        if not is_resend:
            self.trace_log.append(['send', buf])
        buf = buf.lower()
        channel = 0
        prefix = ''
        if buf[0].isdigit():
            prefix, buf = buf[0], buf[1:]
            channel = int(prefix)

        # Power status
        if buf[0] == 'd' or channel not in self.active_channels:
            status = 2 if channel in self.active_channels else 0
            self.response_buffer.extend('%sD%d%d\n' % (prefix, status, self.channels))
        elif buf[0] in ['h', 't']:
            assert len(buf) == 6
            assert buf[5] == '\n'
            cmd = int(buf[1:5], 16)
            cmd_hi = (cmd >> 8) & 0xFF
            cmd_lo = cmd & 0xFF

            count = 1 if buf[0] == 'h' else 2

            # See if any devices want to respond to this command
            response = None
            for dev in self.devices[channel]:
                resp = dev.interpret_command(cmd_hi, cmd_lo, count=count)
                # XXX Only one response per round--presumably for any response
                # traffic, when devices detect contention, they just don't bother
                # responding at all. This comes up in e.g. short address assignment,
                # where only one response to a compare query is expected
                if resp is not None:
                    if response is not None:
                        response = '%sX\n' % prefix
                        break
                    else:
                        response = '%sJ%02X\n' % (prefix, resp)
            if response is None:
                response = '%sN\n' % prefix

            # Always add the response exactly once to the trace log, so the tests that
            # check for exact trace matches all work regardless of any weird noise
            # injected below
            if not is_resend:
                self.trace_log.append(['recv', response])

            # Add responses to the queue
            for i in range(count):
                # Check for noise mode, and inject random crap into responses if so
                if self.noise and random.randint(0, self.noise) == 0:
                    sel = random.randint(0, 2)
                    # If sel==0, inject power thing but still respond
                    if sel == 0:
                        self.response_buffer.extend('P4764750\n')
                    # Otherwise, inject a send/recv bus conflict and don't respond
                    else:
                        conflict = 'X' if sel == 1 else 'Z'
                        self.response_buffer.extend('%s%s\n' % (prefix, conflict))
                        continue

                self.response_buffer.extend(response)

        # Firmware version
        elif buf[0] == 'v':
            assert channel == 0
            self.response_buffer.extend('V0233%02d\n' % self.hat_hw_type)
        # DALI bus power quality
        elif buf[0] == 'q':
            assert channel == 0
            if buf[1].isdigit():
                mode = int(buf[1]) & 7
                if mode < 4:
                    self.power_mode = mode
                elif mode == 4:
                    self.power_mode &= 3
                elif mode == 5:
                    self.power_mode |= 4
                elif mode == 6:
                    pass
                else:
                    assert False
            self.response_buffer.extend('Q%s157030840170164\n' % self.power_mode)
        # Remote device power status
        elif buf[0] == 'u':
            assert channel == 0
            self.response_buffer.extend('U0078005750000\n')
        # Hat power status
        elif buf[0] == 'p':
            assert channel == 0
            #self.response_buffer.extend('Q%s157030840170164\n' % self.power_mode)
            self.response_buffer.extend('P4764750\n')
        # Wattage readings
        elif buf[0] == 'w':
            assert channel == 0
            if buf[1] == '0':
                self.response_buffer.extend('W00142\n')
            elif buf[1] == '1':
                self.response_buffer.extend('W00800\n')
            elif buf[1] == '3':
                self.response_buffer.extend('W000333\n')
            elif buf[1] == '4':
                self.response_buffer.extend('W00800\n')
            else:
                assert False, 'bad w command: %s' % buf
        else:
            assert False, 'unknown command %s' % buf

    def read(self, n_bytes):
        if len(self.response_buffer) < n_bytes:
            # Before returning an empty response in firmware sim mode, run the
            # devices a bit so we can capture any output they initiate
            if self.fw_sim:
                self.run_idle_steps(1)

            # Sleep so running under simulation doesn't burn CPU.
            # XXX is there a better way? Will this impact e.g. tests?
            time.sleep(.2)
            return b''
        result = self.response_buffer[:n_bytes]
        del self.response_buffer[:n_bytes]
        resp = ''.join(result).encode('ascii')
        return resp

    def reset_input_buffer(self):
        # XXX throw buffer away for now
        self.response_buffer = []

    def reset_trace(self):
        old = self.trace_log
        self.trace_log = []
        return old

    # Firmware simulator helpers. These depend on the internals of FWSimDevice...

    def run_fw_cmd(self, cmd):
        assert self.fw_sim
        for channel in self.active_channels:
            for dev in self.devices[channel]:
                assert isinstance(dev, FWSimDevice)
                resp = dev.run_cmd(cmd)
                self.response_buffer.extend(resp)

    def run_idle_steps(self, n):
        return self.run_fw_cmd(b'run %d\n' % n)

    def run_stress_test(self, n):
        return self.run_fw_cmd(b'run-stress-test %d\n' % n)
