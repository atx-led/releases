import collections
import json
import logging
import threading
import time

import flask
import pyzwaver.node
from pyzwaver.command_translator import CommandTranslator
from pyzwaver.controller import Controller
from pyzwaver.driver import Driver, MakeSerialDevice
from pyzwaver import command
from pyzwaver import command_helper
from pyzwaver import zwave
from wss import websocket_server

# XXX Circular import! This is so we can update internal node data through set_dali_light_state().
# Figure out a better way!
import dali

import db
import util
from util import json_route

SERIAL_DEVICES = ['/dev/ttyACM0', '/dev/ttyACM1', '/dev/ttyUSB0']

PAIRING_TIMEOUT = 60

LOG = util.get_logger('zwave')
app = flask.Blueprint('zwave', __name__, static_folder=None)
wsr = websocket_server.WebSocketRouter('/zwave')

ZWAVE_HANDLER = None

ZWAVE_LOCK = threading.Lock()

ZWAVE_NODE_INFO = {}
PYZWAVER_NODES = {}
NODE_SEQ_ID = {}

RECENT_EVENTS = []

ON_OFF = ['off', 'on']

ZWAVE_LISTENER = None

# Log handler for this module, to push log lines to an EventStream
class ZWaveLogHandler(logging.Handler):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.log_stream = util.EventStream(history=200)
    def handle(self, record):
        # Append the record, and manually mark the time
        ts = time.strftime('%Y%m%d %H:%M:%S')
        data = {'ts': ts, 'message': record.getMessage(),
            'level': record.levelname}
        self.log_stream.push(data)

ZWAVE_LOG_HANDLER = ZWaveLogHandler(level=logging.INFO)
LOG.addHandler(ZWAVE_LOG_HANDLER)

# Two serial device classes for testing: the first is a tracer, that wraps
# a normal device and logs all traffic for later inspection/test creation.
# The second is a virtual device based on an existing trace that simulates
# the exact I/O to verify we behave correctly

class TracingDevice:
    def __init__(self, device):
        self.device = device
        self.lock = threading.Lock()
        self.trace = []
    def read(self, n_bytes):
        with self.lock:
            b = self.device.read(n_bytes)
            if not self.trace or self.trace[-1][0] != 'r':
                self.trace.append(('r', bytearray()))
            self.trace[-1][1].extend(b)
            #print('read', n_bytes, b)
            return b
    def write(self, buf):
        with self.lock:
            self.device.write(buf)
            self.trace.append(('w', buf))
    def dump(self, path):
        with self.lock:
            with open(path, 'w') as f:
                f.write('[\n')
                f.write('  ' + ',\n  '.join(str([d, list(b)])
                        for [d, b] in self.trace))
                f.write(']\n')
            self.trace = []
    # Flushes should be ignored for the trace... right?
    def flush(self):
        self.device.flush()
    def flushInput(self):
        self.device.flushInput()
    def flushOutput(self):
        self.device.flushOutput()

# The values from node.values.Values() can have sets internally, convert them to lists
def convert_to_json(value):
    if isinstance(value, dict):
        return {str(k): convert_to_json(v) for [k, v] in value.items()}
    elif isinstance(value, (tuple, list, set)):
        return [convert_to_json(v) for v in value]
    elif isinstance(value, bytes):
        return str(value)
    else:
        return value

# There's several places where zwave node state is stored: The pyzwaver library
# state, the PYZWAVER_NODES dict, our copy of the pyzwaver info
# (ZWAVE_NODE_INFO), the database, the DUMB_DB, and the nodes themselves. Yuck!
# The PYZWAVER_NODES dict is an exact copy of the pyzwaver's node info for
# easily mapping node_id -> node. ZWAVE_NODE_INFO mostly mirrors the pyzwaver
# information, but adds a name. The database in turn mirrors ZWAVE_NODE_INFO,
# persisting it as much of the information cannot be reproduced without
# contacting zwave nodes (which aren't always online). The DUMB_DB info is a
# translation of the node info into the same format used by all the DALI code.
# Below are several functions that keep these in sync. This should probably be
# cleaned up (of course)!

# Load ZWAVE_NODE_INFO from the database
def load_db_info():
    global ZWAVE_NODE_INFO

    # We use the controller's home ID as part of the key just in case somebody
    # is using multiple controllers
    home_id = ZWAVE_HANDLER.controller.props.home_id

    with db.db_session() as session:
        ZWAVE_NODE_INFO = {}
        for entry in session.query_all(db.ZWaveNode, home_id=home_id):
            ZWAVE_NODE_INFO[entry.node_id] = {'name': entry.name,
                    'values': entry.data or {}, 'hidden': entry.hidden}

    dali.DUMB_DB.scan_zwave_nodes()

def refresh_pyzwaver_nodes():
    global PYZWAVER_NODES
    nodes = {}
    for node in ZWAVE_HANDLER.controller.nodes.copy():
        nodes[node] = ZWAVE_HANDLER.nodeset.GetNode(node)
    PYZWAVER_NODES = nodes

# Update ZWAVE_NODE_INFO from pyzwaver info, for a single node
def update_node_info(node_id):
    refresh_pyzwaver_nodes()
    node = PYZWAVER_NODES[node_id]

    if node_id not in ZWAVE_NODE_INFO:
        ZWAVE_NODE_INFO[node_id] = {'values': {}}
    node_info = ZWAVE_NODE_INFO[node_id]

    values = node_info['values']
    for [cmd_bytes, cmd, v] in node.values.Values():
        values[cmd] = convert_to_json(v)

    # Update device type
    proto_info = values.get('_ProtocolInfo', {})
    dev_type = proto_info.get('device_type', [0, 0, 0])
    values['device_type_str'] = pyzwaver.command.NodeDescription(dev_type)

    # These probably should go in node_info not values
    values['is_light'] = (dev_type[1] in {0x10, 0x11})
    values['has_color_temp'] = any(cmd == zwave.ColorSwitch
            for [cmd, desc, version] in node.values.CommandVersions())

    node_info['config'] = convert_to_json(node.values.Configuration())
    node_info['commands'] = convert_to_json(node.values.CommandVersions())

    # Push the updates out to DUMB_DB
    if values['is_light']:
        update_node_state(node_id)

# ...and the same for all nodes
def update_all_node_info():
    for node_id in PYZWAVER_NODES.keys():
        update_node_info(node_id)

# Update DUMB_DB from ZWAVE_NODE_INFO for a single node
def update_node_state(node_id):
    values = ZWAVE_NODE_INFO[node_id]['values']
    address = (0, 'zwave', node_id)
    new_state = {}

    new_state['has_color_temp'] = values['has_color_temp']

    ml_data = values.get('SwitchMultilevel_Report')
    if ml_data:
        level = ml_data.get('level', 0)
        # Scale level from 0-100 to 0-254
        level = int(util.scale(level, 0, 100, 0, 254))
        new_state['level'] = util.clip(level, 0, 254)

    color_data = values.get('ColorSwitch_Report')
    if color_data:
        group = color_data.get('group', 0)
        if group in {0, 1}:
            level = color_data.get('level', 0)
            if group == 0:
                level = 255 - level
            new_state['color_temp_k'] = int(util.scale(level, 0, 255, 2700, 6500))

    dali.DUMB_DB.set_dali_light_state(address, new_state, update_bus=False)

# ...and for all nodes
def update_all_nodes_state():
    for node_id in ZWAVE_NODE_INFO:
        update_node_state(node_id)

# Persist data from the ZWAVE_NODE_INFO dict to the database. If a node set
# is given, only those nodes are updated
def update_db_info(nodes=None):
    if nodes is None:
        nodes = ZWAVE_NODE_INFO.keys() 

    # Get the controller's home ID, kinda gross
    home_id = ZWAVE_HANDLER.controller.props.home_id

    with db.db_session() as session:
        for node_id in nodes:
            data = ZWAVE_NODE_INFO[node_id]
            session.upsert(db.ZWaveNode, {'home_id': home_id, 'node_id': node_id},
                    data=data['values'], name=data['name'],
                    hidden=data.get('hidden', False))

# Get the initial DUMB_DB dictionary based on ZWAVE_NODE_INFO
def scan_zwave_nodes():
    nodes = {}
    for [node_id, data] in ZWAVE_NODE_INFO.items():
        # XXX Check if this node is a normal multilevel switch
        if not data['values'].get('is_light'):
            continue

        nodes[node_id] = {
            'channel': 0,
            'address': (0, 'zwave', node_id),
            'dev_name': get_node_name(node_id),
            'dev_on': False,
            'level': 0,
            'color_temp_k': 4000,
        }

    return nodes

def get_pyzwaver_nodes():
    return PYZWAVER_NODES

class ZWaveListener:
    def put(self, node_id, timestamp, cmd, values):
        global RECENT_EVENTS

        if cmd[0] is not None:
            cmd = command.StringifyCommand(cmd)

        LOG.info("received zwave command (node=%s): %s %s", node_id, cmd, values)

        if cmd == '_Application_Update':
            LOG.info('Supported command sets: %s', ', '.join(zwave.CMD_TO_STRING[c]
                for c in values['commands']))

        key = None
        desc = None
        fn_value = None
        if cmd == 'CentralScene_Notification':
            scene = values.get('scene')
            mode = values.get('mode')

            # XXX should maybe handle sequence counter/duplicate commands?
            # Weird chinese paw thing sends random low values for count
            #count = values.get('count')
            #NODE_SEQ_ID[node_id] = count

            key = ('scene', scene, mode)
            desc = 'scene: %s' % scene

        elif cmd == 'SwitchBinary_Report':
            on_off = int(values.get('level', 0) > 0)
            key = ('switch-binary', on_off)
            desc = 'switch %s' % ON_OFF[on_off]
        elif cmd == 'SensorBinary_Report':
            on_off = int(values.get('level', 0) > 0)
            key = ('sensor-binary', on_off)
            desc = 'sensor %s' % ON_OFF[on_off]
        elif cmd == 'SensorMultilevel_Report':
            value = values.get('value', {}).get('_value', 0)
            key = ('sensor-multilevel',)
            desc = 'sensor level %s' % value
            fn_value = value
        elif cmd == 'Basic_Set':
            level = values.get('level', 0)
            key = ('basic-set', level)
            desc = 'basic set %s' % level
        elif cmd == 'Alarm_Report':
            type = values.get('type', 0)
            level = values.get('level', 0)
            key = ('alarm', type, level)
            desc = 'alarm type %s, level %s' % (type, level)

        elif cmd == 'Association_Report':
            if values.get('group') == 1:
                nodes = values.get('nodes', [])
                if 1 not in nodes or 37 not in nodes:
                    node = get_pyzwaver_nodes()[node_id]
                    set_node_group(node, 1, [1, 37])

        # Add key to recent event log
        if key:
            desc = '%s, %s' % (get_node_name(node_id), desc)
            event = (desc, node_id, key)
            if event not in RECENT_EVENTS:
                RECENT_EVENTS = [event] + RECENT_EVENTS[:25]

            if ZWAVE_LISTENER:
                ZWAVE_LISTENER(node_id, key, values, fn_value=fn_value)

        # Update DUMB_DB for this node if it's a light
        #info = ZWAVE_NODE_INFO.get(node_id, {})
        #if info.get('is_light', False):
        #    update_node_state(node_id)

        update_node_info(node_id)
        # Un-hide this node in case it's hidden
        if ZWAVE_NODE_INFO[node_id].get('hidden'):
            ZWAVE_NODE_INFO[node_id]['hidden'] = False
            update_db_info(nodes=[node_id])

def cb_generic(*args):
    LOG.debug('GOT CALLBACK:', args)

def make_cb(*args):
    return lambda *a: cb_generic(*args, *a)

def submit_unfiltered(node, cmd, values):
    node._translator.SendCommand(node.n, cmd, values,
            pyzwaver.node.NodePriorityLo(node.n), pyzwaver.node.XMIT_OPTIONS)

def get_node_name(node_id):
    if node_id in ZWAVE_NODE_INFO:
        info = ZWAVE_NODE_INFO[node_id]
        name = info.get('name')
        if name:
            return name
    return 'Device %s' % node_id

def set_node_group(node, group_id, group_node_ids):
    node.BatchCommandSubmitFilteredFast([(zwave.Association_Set,
        {"group": group_id, "nodes": group_node_ids})])

def get_node_group(node, group_id):
    node.BatchCommandSubmitFilteredSlow([(zwave.Association_Get,
        {"group": group_id})])

# Send an update over ZWave to a node from a server command (through set_dali_light_state)
def send_node_state(node_id, attr, value):
    nodes = get_pyzwaver_nodes()
    if node_id not in nodes:
        LOG.warning('NODE NOT FOUND: %s', node_id)
        return
    node = nodes[node_id]
    info = ZWAVE_NODE_INFO[node_id]

    if attr == 'level':
        level = (value * 100) // 255
        node.BatchCommandSubmitFilteredFast([(zwave.SwitchMultilevel_Set, {'level': level, 'duration': 0})])
    elif attr == 'color_temp_k':
        color = (value - 1700) * 255 // (6500 - 1700)
        node.BatchCommandSubmitFilteredFast([(zwave.ColorSwitch_Set, {'colors': [(0, color)]})])
    elif attr == 'dev_name':
        info['name'] = value
        update_db_info(nodes=[node_id])
    else:
        assert False, attr

@app.route('/')
def main_page():
    zwave_found = bool(ZWAVE_HANDLER and ZWAVE_HANDLER.driver is not None)
    return flask.render_template('zwave.html', page='zwave', zwave_found=zwave_found)

@json_route(app, '/api/reset-controller', methods=['POST'])
def reset_controller():
    ZWAVE_HANDLER.controller.SoftReset()
    ZWAVE_HANDLER.init()
    return {'ok': True}

@app.route('/check-controller', methods=['POST'])
def check_controller():
    ZWAVE_HANDLER.init()
    return util.redirect('/dali/zwave/')

@app.route('/log')
def log_page():
    return flask.render_template('zwave-log.html', page='zwave-log')

@json_route(app, '/api/node-addresses')
def api_get_node_addresses():
    return [[node_id, get_node_name(node_id)] for node_id in ZWAVE_NODE_INFO]

@json_route(app, '/api/nodes')
def api_get_nodes():
    return ZWAVE_NODE_INFO

ZWAVE_NODE_SCHEMA = util.schema_obj({
    'name': {'type': 'string'},
    'hidden': {'type': 'boolean'},
})
@json_route(app, '/api/nodes/<int:node_id>', methods=['POST'], input_schema=ZWAVE_NODE_SCHEMA)
def api_set_node_info(node_id, data):
    assert node_id in ZWAVE_NODE_INFO
    keys = ['name', 'hidden']
    for key in keys:
        if key in data:
            ZWAVE_NODE_INFO[node_id][key] = data.pop(key)
    assert not data
    update_db_info(nodes=[node_id])
    return {'ok': True}

@json_route(app, '/api/recent-events')
def api_get_recent_events():
    return RECENT_EVENTS

@wsr.route('/log')
def ws_zwave_log(handler):
    with ZWAVE_LOG_HANDLER.log_stream.listen() as zwave_log:
        for data in util.ws_stream_queue(zwave_log, handler):
            handler.send_message(json.dumps(data))

@json_route(app, '/api/pair', methods=['POST'])
def pair():
    ZWAVE_HANDLER.pair_nodes()
    return {'ok': True,
        'message': 'Pair mode active for next %s seconds.' % PAIRING_TIMEOUT}

@json_route(app, '/api/unpair', methods=['POST'])
def unpair():
    ZWAVE_HANDLER.unpair_nodes()
    return {'ok': True,
        'message': 'Unpair mode active for next %s seconds.' % PAIRING_TIMEOUT}

@json_route(app, '/api/ping-nodes', methods=['POST'])
def ping_nodes():
    ZWAVE_HANDLER.ping_nodes()
    return {'ok': True, 'message': 'Pinging all nodes.'}

def firmware_upgrade(node):
    self.BatchCommandSubmitFilteredFast([(z.Firmware_MetadataGet, {})])

class ZWaveHandler:
    def init(self, device=None):
        if getattr(self, 'driver', None):
            LOG.info('terminating driver')
            self.driver.Terminate()

        self.driver = None
        if device:
            self.driver = Driver(device)
        else:
            for device in SERIAL_DEVICES:
                try:
                    self.device = MakeSerialDevice(device)
                    #self.device = TracingDevice(self.device)
                    self.driver = Driver(self.device)
                    LOG.info('found z-wave controller at %s', device)
                    break
                except Exception as e:
                    LOG.info('error attempting to open z-wave controller: %s', e)
        if self.driver is None:
            LOG.error('Could not find ZWave controller!')
            return

        self.controller = Controller(self.driver,
                pairing_timeout_secs=PAIRING_TIMEOUT)
        self.controller.Initialize()
        self.controller.WaitUntilInitialized()

        self.translator = CommandTranslator(self.driver)
        self.nodeset = pyzwaver.node.Nodeset(self.translator, self.controller.GetNodeId())
        # Add our listener after creating the node set. This is just to ensure
        # that nodes get commands first, and can update their values before
        # our listener sees them. Kinda annoying but oh well
        self.translator.AddListener(ZWaveListener())

        # Load node info from the database
        load_db_info()

        # Keep track of nodes that have been added but not initialized with the lifeline group
        self.pending_nodes = set()

        self.refresh_nodes()

    def pair_nodes(self):
        def handler(action, event, node_id):
            LOG.info('GOT PAIR CALLBACK: %s %s %s', action, event, node_id)
            if node_id is not None and event == 'Success':
                self.pending_nodes.add(node_id)
                self.refresh_nodes()
        LOG.info('begin pair mode')
        self.controller.StopAddNodeToNetwork(cb_generic)
        self.controller.AddNodeToNetwork(handler)
        self.controller.StopAddNodeToNetwork(cb_generic)

    def unpair_nodes(self):
        def handler(action, event, node_id):
            LOG.info('GOT UNPAIR CALLBACK: %s %s %s', action, event, node_id)
            if node_id is not None and event == 'Success':
                self.refresh_nodes()
        LOG.info('begin unpair mode')
        self.controller.StopRemoveNodeFromNetwork(cb_generic)
        self.controller.RemoveNodeFromNetwork(handler)
        self.controller.StopRemoveNodeFromNetwork(cb_generic)
        LOG.info('end unpair mode')

    def ping_nodes(self):
        with ZWAVE_LOCK:
            for node_id in self.controller.nodes.copy():
                if node_id == self.controller.props.node_id:
                    continue
                node = self.nodeset.GetNode(node_id)
                #if node.state == pyzwaver.node.NODE_STATE_NONE:
#                if node.state != pyzwaver.node.NODE_STATE_DISCOVERED:
#                    self.translator.Ping(node_id, 3, False, 'undiscovered')
#                else:
#                    node.RefreshStaticValues()

                #set_node_group(node, 1, [1])

                # Try to get current level/color
                cmds = [(zwave.SwitchMultilevel_Get, {}),
                        (zwave.ColorSwitch_Get, {'group': 0})]
                node.BatchCommandSubmitFilteredFast(cmds)

                get_node_group(node, 1)

        update_all_node_info()

        # Notify the dumb DB that maybe we have node updates... maybe
        dali.DUMB_DB.scan_zwave_nodes()

    def refresh_nodes(self, done_cb=None):
        def handler(*args):
            global PYZWAVER_NODES
            refresh_pyzwaver_nodes()

            # If any nodes were just added, set them up like we need
            if self.pending_nodes:
                for node_id in self.pending_nodes:
                    node = PYZWAVER_NODES[node_id]

                    # On pair, set the hub as the entire lifeline group. This is rather weird...
                    set_node_group(node, 1, [1])
                    get_node_group(node, 1)

                self.pending_nodes = set()

                LOG.info('end pair mode')

            # Request node info from all the nodes
            for node in self.controller.nodes.copy():
                self.controller.RequestNodeInfo(node, cb=make_cb('req', node))

            if done_cb:
                done_cb()

        self.controller.Update(handler)

class ZWaveThread(threading.Thread):
    def run(self):
        global ZWAVE_HANDLER
        ZWAVE_HANDLER = ZWaveHandler()
        ZWAVE_HANDLER.init()

        #time.sleep(1)
        #while True:
        #    if ZWAVE_HANDLER.driver:
        #        ZWAVE_HANDLER.ping_nodes()
        #        time.sleep(20*60)

def init():
    ZWaveThread(daemon=True).start()
