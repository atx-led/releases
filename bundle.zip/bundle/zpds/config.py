import sqlalchemy.orm

import db
import util

CONFIG = {}

SITE_SETTINGS = None

def update_site_settings(**update_args):
    global SITE_SETTINGS, CONFIG

    with db.db_session() as session:
        # Retrieve the SiteSettings row (there should be at most one row)
        # and perform any updates, so we make sure the row exists and has its
        # default values (inserting a row if necessary).
        row = session.upsert(db.SiteSettings, {}, **update_args)

        # Commit any changes to the database, and refresh attribute values
        # (required for weird SQLAlchemy reasons with make_transient below)
        session.commit()
        session.refresh(row)

        # Copy the SiteSettings row (there should be at most one row) after
        # making it transient. session.make_transient() makes SQLAlchemy ORM
        # objects usable as normal objects outside a session.
        sqlalchemy.orm.session.make_transient(row)

    # Set dynamic defaults (just site name now)
    if row.site_name is None:
        if 'site-name' in CONFIG:
            row.site_name = CONFIG['site-name']
        else:
            row.site_name = util.get_mac_address()[-4:].upper()
    if 'backup-notification-seen' in CONFIG:
        row.backup_notification_seen = CONFIG['backup-notification-seen']

    # Copy the setting to a nice global place
    SITE_SETTINGS = row
