import contextlib
import datetime
import functools
import re
import subprocess
import time
import urllib.parse

import flask

# Import some common API helpers into this namespace
from common_api import (init_logging, get_logger, schema_obj, JSONSCHEMA_STR_OR_NULL,
        APIError, validate_json, json_route, json_stream_route, EventStream,
        queue_to_list, ws_stream_queue, contexts)

LOG = get_logger('util')

# HACKish: put this here because it's a central module with no dependencies
ALL_WEEKDAYS = ['M', 'Tu', 'W', 'Th', 'F', 'Sa', 'Su']

def chunked(l, n):
    for i in range(0, len(l), n):
        yield l[i:i+n]

# Time utilities. Partially here for easy mocking

def now():
    return datetime.datetime.now()

def utcnow():
    #tz = datetime.timezone(datetime.timedelta(minutes=0))
    #return datetime.datetime.utcnow().astimezone(tz)
    return datetime.datetime.utcnow()

def today():
    return datetime.date.today()

def get_time():
    return time.time()

def get_timezone():
    with open('/etc/timezone') as f:
        return f.read().strip()

# Get the ip address
def get_ip_address():
    try:
        output = subprocess.check_output(['ip', 'route', 'get', '1.1.1.1'])
        return output.decode('ascii').split()[6]
    except Exception:
        return '???'

# Get the mac of the wifi adapter. RPi specific-ish
def get_mac_address():
    try:
        with open('/sys/class/net/wlan0/address') as f:
            return f.read().strip().replace(':', '')
    except Exception:
        return '???'

def get_zpds_version():
    # ugh fucking circular dependency
    import serve
    return serve.ZPDS_VERSION

def get_uptime():
    with open('/proc/uptime', 'r') as f:
        return int(float(f.read().split()[0]) / 60)

def get_temp():
    temp = 0
    cmd = ['vcgencmd', 'measure_temp']
    output = subprocess.check_output(cmd).decode('utf-8')
    match = re.search('temp=(.*)\'C', output)
    if match:
        temp = match.group(1)
    return temp

def clip(value, minimum, maximum):
    if minimum > maximum:
        minimum, maximum = maximum, minimum
    return max(minimum, min(value, maximum))

# Scale x from range [a1, b1] to [a2, b2]
def scale(x, a1, b1, a2, b2):
    denom = a1 - b1
    if denom == 0:
        denom = 1
    return (x - a1) * (a2 - b2) / denom + a2

def retry_fn(msg, fn, retries=3):
    for i in range(retries):
        try:
            return fn()
        except Exception as e:
            if i < retries - 1:
                LOG.warning('got exception during %s: %s', msg, e)
                continue
            raise

def with_lock(lock):
    def wrap(fn):
        @functools.wraps(fn)
        def inner(*args, **kwargs):
            with lock:
                return fn(*args, **kwargs)
        return inner
    return wrap

# Dummy object that we can set arbitrary attributes in
class Object:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

@contextlib.contextmanager
def time_execution(label=None, print=print):
    obj = Object()
    start = get_time()
    yield obj
    end = get_time()
    obj.time = end - start
    if label:
        print('%s: %.3fs' % (label, end - start))

# Get query string as a dict. Ignores duplicate keys!!
def get_query_string():
    query = urllib.parse.parse_qs(flask.request.query_string.decode('ascii'))
    return {k: v[0] for k, v in query.items()}

# A small wrapper of flask.redirect to not rewrite the Location header to be
# absolute. This goes against the spec apparently but current Firefox, Safari,
# and Chrome accept it. This is done so redirects work in my frickin ssh tunnels
# See: https://stackoverflow.com/questions/22669447/how-to-return-a-relative-uri-location-header-with-flask
def redirect(url):
    resp = flask.redirect(url)
    resp.autocorrect_location_header = False
    return resp
