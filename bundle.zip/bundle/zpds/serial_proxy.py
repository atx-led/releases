import json
import sys
import threading

import requests

import util

# This file is for an NREL debug interface. They apparently prefer to use
# a serial port than a web connection, so we have this functionality to
# proxy web requests over the serial port. This isn't very robust or
# secure, but it's hacky one-off stuff that can hopefully be deleted soon...

LOG = util.get_logger('serial-proxy')

def run():
    import serial

    conn = serial.Serial(port='/dev/ttyUSB0', baudrate=19200,
            parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS, timeout=1)

    while True:
        line = b''
        # Read the next request(s)
        ct = 0
        while True:
            r = conn.read(1024)
            ct += 1
            # Quick timeout if we've gotten data, slow timeout if not
            if not r and (line or ct > 120):
                break
            ct = 0
            line += r

        if line:
            # Process each request
            for req in line.split(b'\n'):
                try:
                    if req and req[0] == '/':
                        req = req[1:]
                    req = req.strip()
                    if not req:
                        continue
                    LOG.info('got request over serial proxy: %r', req)
                    chunks = req.split(b' ', 1)
                    url = chunks.pop(0)
                    url = 'http://%s' % (url.decode('ascii'))
                    body = b' '.join(chunks)
                    if body:
                        data = json.loads(body)
                        resp = requests.post(url, json=data)
                    else:
                        resp = requests.get(url)
                    conn.write(resp.content + b'\n\n')
                except Exception:
                    try:
                        conn.write(b'ERROR\n\n')
                    except Exception:
                        time.sleep(1)
                        pass

def init_serial_proxy():
    threading.Thread(target=run, daemon=True, name='Serial Proxy').start()
