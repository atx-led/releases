const STATUS_BITS = [
  [0, 'Status of ballast', ['OK', 'Bad']],
  [1, 'Lamp failure', ['OK', 'Bad']],
  [2, 'Lamp arc power on', ['Off', 'On']],
  [3, 'Limit Error', ['No', 'Yes']],
  [4, 'Fade ready', ['Yes', 'No']],
  [5, 'Reset State', ['No', 'Yes']],
  [6, 'Missing short address', ['No', 'Yes']],
  [7, 'Power failure', ['No', 'Yes']],
];
// As usual, ATX-LED has some weird non-standard behavior
const DR2_STATUS_BITS = [
  [1, 'Left', ['Not Found', 'OK']],
  [0, 'Right', ['Not Found', 'OK']],
].concat(STATUS_BITS.slice(2));

const CMDS = [
  [0x100, 'Off'],
  [0x101, 'Up'],
  [0x102, 'Down'],
  [0x106, 'Min'],
  [0x105, 'Max'],
  [0x108, 'On and Step Up'],
  [0x107, 'Step Down and Off'],
];
const LEVEL_CMDS = [
  [0xFE,  '100%'],
  [0xBF,  '75%'],
  [0x7F,  '50%'],
  [0x3F,  '25%'],
  [0x00,  '0%'],
];
function Advanced(props) {
  let [state, setState] = useState({addrType: 'single', channel: -1,
    shortAddr: 0, groupAddr: 0, sceneID: 0, level: 0, CCT: 0,
    driverModesFixed: false, status: [], response: '', powerStatus: [],
    CCTFade: 0, fadeTime: 0, failLevel: 0});
  let [reassign, setReassignState] = useState({channel: 0,
    old_addr: '', new_addr: ''});
  let [powerState, setPowerState] = useState({current: current, locked: locked});

  let [nChannels, updateNChannels] = useState({channels: 4});
  useEffect(() => fetchJSONState(updateNChannels, '/dali/api/get-n-channels'), []);

  console.log('chan', nChannels);
  let CHANNEL_OPTS = null;
  if (nChannels.channels === 1) {
    if (state.channel !== 0)
      setState({ ...state, channel: 0 });
    CHANNEL_OPTS = [[0, 1]];
  } else
    CHANNEL_OPTS = [[-1, 'Select...']].concat(
      range(nChannels.channels).map((x) => [x, x + 1]));


  // Create radio boxes for the short address display
  let addrOpts = range(64).map((addr) => {
    let a = `${state.channel}_s_${addr}`;
    let active = (initialDevices[a] !== undefined);
    let missing = (missingDevices[a] !== undefined);
    let conflict = (conflictAddresses[a] !== undefined);
    let cls = 'addr-box';
    if (active)
      cls += ' addr-box-active';
    else if (missing)
      cls += ' addr-box-missing';
    else if (conflict)
      cls += ' addr-box-conflict';
    let dev = initialDevices[a];
    let mdevname = missingDevices[a];
    let name = dev ? dev.dev_name : (mdevname || '');
    let label = <span title={ name } className={ cls }>{ addr }</span>;
    let br = addr % 8 === 7 ? <br/> : null;
    return [addr, label, br];
  });

  // Helpers

  const fixCmd = (cmd, fixAddr, sendTwice) => {
    if (typeof cmd === 'string')
      return cmd;

    // Add the currently selected address if requested
    if (fixAddr) {
      let hi = null;
      switch (state.addrType) {
        case 'all': hi = 0xFE; break;
        case 'group': hi = 0x80 | state.groupAddr << 1; break;
        case 'single': hi = state.shortAddr << 1; break;
      }
      cmd = cmd | hi << 8;
    }

    let prefix = sendTwice ? 't' : 'h';
    return prefix + ('0000' + cmd.toString(16)).substr(-4);
  };

  const fixAddr = (cmd) => fixCmd(cmd, true);

  const sendRaw = (cmds) => {
    if (state.channel === -1) {
      alert('Please select a channel.');
      return;
    }
    cmds = cmds.map((cmd) => fixCmd(cmd, false, false));
    postJSON('/dali/api/send-raw', {channel: state.channel, commands: cmds},
      (resp, error) => setState({ ...state, response: error ? error : resp.responses.join(' ') }));
  };

  const send = (cmds) => {
    cmds = cmds.map((cmd) => fixCmd(cmd, true));
    sendRaw(cmds);
  };

  // Action functions (for button onclick handlers)

  let queryStatus = () => {
    let addr = `${state.channel}_s_${state.shortAddr}`;
    let dev = initialDevices[addr];
    let mdevname = missingDevices[addr];
    let upc = null;
    if (dev !== undefined && UPC_TABLE[dev['upc_code']] !== undefined)
      upc = dev['upc_code'];

    if (state.addrType != 'single') {
      setState({ ...state, status: [['Error', 'Must use address type "single" to query status']] });
      return;
    }
    // Send the commands to get current level, device type, and status.
    // And if this is a DR1-PIR, read ambient light levels
    let cmds = [fixAddr(0x1A0), fixAddr(0x199), fixAddr(0x190)];
    if (upc === DR1_PIR_UPC)
      // Set DTR/DTR1 to 04:20 (blaze it), then read two bytes
      cmds = cmds.concat([0xA314, 0xC304, fixAddr(0x1C5), fixAddr(0x1C5)]);

    if (state.channel === -1) {
      alert('Please select a channel.');
      return;
    }
    cmds = cmds.map((cmd) => fixCmd(cmd));
    postJSON('/dali/api/send-raw', {channel: state.channel, commands: cmds},
      (resp, error) => {
        let status = [];
        let name;
        if (dev !== undefined)
          name = `${dev.dev_name} (short address ${state.shortAddr})`;
        else
          name = mdevname || `Light ${state.shortAddr}`;
        status.push(['Device', name]);

        if (error)
          status.push(['Error', error]);
        else if (resp.responses.length > 0 && resp.responses[0][0] === 'X')
          status.push(['Error', 'conflict - multiple devices at address']);
        else if (resp.responses.length < 3 || resp.responses[0][0] !== 'J')
          status.push(['Error', 'no device found']);
        else {
          let level = resp.responses[0];
          level = parseInt(level.substr(1, 3), 16);
          status.push(['Level', level]);

          let devType = resp.responses[1];
          devType = (devType[0] === 'N') ? '-' : parseInt(devType.substr(1, 3), 16);
          status.push(['Device Type', devType]);

          let bits = parseInt(resp.responses[2].substr(1, 3), 16);
          let status_bits = STATUS_BITS;
          // ATX-LED devices besides the DR1-PIR have special meaning to status bits
          if (upc !== null && upc !== DR1_PIR_UPC)
            status_bits = DR2_STATUS_BITS;
          for (let [bit, desc, values] of status_bits) {
            let value = values[(bits >> bit) & 1];
            status.push([desc, value]);
          }

          // For DR1-PIR, try reading the response to the ambient light queries
          if (upc === DR1_PIR_UPC && resp.responses.length == 7 &&
            resp.responses[5][0] === 'J' && resp.responses[6][0] === 'J') {
            status.push(['Ambient light (now)',
              parseInt(resp.responses[5].substr(1, 3), 16)]);
            status.push(['Ambient light (dark)',
              parseInt(resp.responses[6].substr(1, 3), 16)]);
          }
        }

        setState({ ...state, status: status })
      });
  };

  let queryPowerStatus = (force) => postJSON(
      '/dali/api/power-status' + (force ? '-force' : ''), {},
      (resp, error) => {
        let status = (error) ? ['Error', error] : resp.data;
        setState({ ...state, powerStatus: status })
      });

  let fixDriverModes = () => {
    setState({ ...state, driverModesFixed: true });
    postStatus('fix-driver-modes-status', '/dali/api/fix-unknown-driver-modes', {});
  };

  const reassignAddress = () => {
    postStatus('reassign-status', '/dali/api/reassign-address', reassign);
  };

  let rescanAddr = () => {
    if (state.addrType != 'single') {
      setState({ ...state, status: [['Error', 'Must use address type "single" to rescan']] });
      return;
    }
    postJSON(`/dali/api/rescan-address/${state.channel}/${state.shortAddr}`, {},
      (resp, error) => {
        let status = [];
        if (error)
          status.push(['Error', error]);
        else
          status.push(['Status', resp.message]);
        setState({ ...state, status: status });
      });
  };

  let resetAddr = () => {
    if (state.addrType != 'single') {
      setState({ ...state, status: [['Error', 'Must use address type "single" to reset']] });
      return;
    }
    sendRaw([fixCmd(0x120, true, true)]);
  };

  const setPowerOptions = () => {
    postStatus('set-power-opts-status', '/dali/api/set-power-options', powerState);
  };

  return <div>
      <BasicState setState={ setState }>
        <div className="columns info-block">
          <div>
            <h3>Basic DALI commands</h3>
            { /* Address selector */ }
            <div className='spacey'>
              <b>Channel:</b>
              <Dropdown name='channel' options={ CHANNEL_OPTS } cast={ (v) => v|0 } value={ state.channel } />
            </div>

            <div className='spacey'>
              <b>Address Type:</b>
              <Radio name='addrType' options={ [
                  ['all', 'Broadcast'],
                  ['group', 'Group', <Dropdown name='groupAddr'
                    options={ range(16) } cast={ (v) => v|0 } />],
                  ['single', 'Single (select below):']] }
                 value={ state.addrType } />
            </div>

            <div style={{ marginLeft: 10 }}>
              <Radio name='shortAddr' horizontal={ true } options={ addrOpts }
                disabled={ state.addrType !== 'single' } value={ state.shortAddr } cast={ (v) => v|0 } />
            </div>

            { /* Basic DALI commands */ }
            <div className='spacey aside'>
              <div>
                { CMDS.map(([cmd, desc]) => <span>
                    <Button onClick={ (e) => send([cmd]) } value={ desc } /></span>) }

                <div>
                  <Button onClick={ (e) => send([0x110 | state.sceneID]) } value='Go to scene: ' />
                  <Dropdown name='sceneID' options={ range(16) } cast={ (v) => v|0 } value={ state.sceneID } />
                </div>
              </div>

              <div>
                { LEVEL_CMDS.map(([cmd, desc]) => <span>
                    <Button onClick={ (e) => send([cmd]) } value={ desc } /></span>) }

                <div>
                  <Button onClick={ (e) => send([state.level]) } value='Manual level: ' />
                  { /* Annoying: we can't use the Slider since that relies on debounceDelay from
                  NestedState, and we're just using BasicState, so duplicate functionality */ }
                  <Input type='range' name='level' min={ 0 } max={ 254 }
                      value={ state.level } cast={ (v) => v|0 } />
                  <Input type='number' name='level' min={ 0 } max={ 254 }
                      value={ state.level } cast={ (v) => v|0 } 
                      style={{width: '40px', fontSize: '8pt', marginLeft: 5}} />
                </div>

                <div>
                  <span>DT8 Color (0-511):</span>
                  <Input type='number' name='CCT' min={ 0 } max={ 511 }
                      value={ state.CCT } cast={ (v) => v|0 } 
                      style={{width: '60px', fontSize: '8pt', marginLeft: 5}} />
                  <Button onClick={ (e) => sendRaw([
                      0xC300 | (state.CCT >> 8),
                      0xA300 | (state.CCT & 0xFF),
                      0xC108,
                      fixCmd(0x1E7, true),
                      0xC108,
                      fixCmd(0x1E2, true),
                    ]) } value='Send' />
                  <Button onClick={ (e) => sendRaw([
                      fixCmd(0x103, true),
                      0xC300 | (state.CCT >> 8),
                      0xA300 | (state.CCT & 0xFF),
                      0xC108,
                      fixCmd(0x1E7, true),
                      0xC108,
                      fixCmd(0x1E2, true),
                    ]) } value='Send (no fade)' />
                </div>

                <div>
                  <span>CCT fade time:</span>
                  <Input type='number' name='CCTFade' min={ 0 } max={ 2550 } step={ 10 }
                      value={ state.CCTFade * 10 } cast={ (v) => ~~(~~v/10) }
                      style={{width: '60px', fontSize: '8pt', marginLeft: 5}} />
                  seconds
                  <Button onClick={ (e) => sendRaw([
                      0xC305,
                      0xA34C,
                      fixCmd(0x181, true, true),
                      0xC700 | (state.CCTFade & 0xFF),
                    ]) } value='Send' />
                </div>

                <div>
                  <Dropdown name='fadeTime' enumerate={ true }
                      options={ FADE_TIMES } value={ state.fadeTime } />
                  seconds
                  <Button onClick={ (e) => sendRaw([
                      0xA300 | (state.fadeTime & 0xF),
                      fixAddr(0x12E, true),
                    ]) } value='Set fade up' />
                  <Button onClick={ (e) => sendRaw([
                      0xA300 | (state.fadeTime & 0xF),
                      fixAddr(0x12F, true),
                    ]) } value='Set fade down' />
                </div>

                <div>
                  <Input type='number' name='failLevel' min={ 0 } max={ 255 }
                      value={ state.failLevel } cast={ (v) => v|0 }
                      style={{width: '60px', fontSize: '8pt', marginLeft: 5}} />
                  <Button onClick={ (e) => sendRaw([
                      0xA300 | (state.failLevel & 0xFF),
                      fixAddr(0x12C, true),
                    ]) } value='Set fail level' />
                  (255 to ignore DALI bus fail)
                </div>
              </div>

              <div id='response'>
                Response: { state.response }
              </div>
            </div>

            <div class="vert-spacer"></div>

            { /* Advanced DALI commands */ }
            <div className='aside'>
              <div className='spacey'>
                <Button onClick={ (e) => queryStatus() } value='Query Status' />
                <Button onClick={ (e) => rescanAddr() } value='Rescan Device' />
                <Button onClick={ (e) => resetAddr() } value='Reset Device' />
              </div>

              <table className='fixed-width'>
                { state.status.map(([desc, value]) =>
                    <tr><td>{ desc }:</td> <td>{ value }</td></tr>) }
              </table>
            </div>
          </div>

          <div className='spacey'>
            <h3>Tools</h3>
            { /* Query DALI power */ }
            <div className='aside'>
              <b>DALI power status</b><br/>
              <Button onClick={ (e) => queryPowerStatus(false) } value='Query DALI Power Status' />
              <Button onClick={ (e) => queryPowerStatus(true) } value='Query DALI Power Status (force retest)' />
              <pre className='fixed-width'>
                { state.powerStatus.map(([k, v]) => '\n' + (k + ':').padEnd(25, ' ') + v) }
              </pre>
            </div>

            { /* CCT mode fixing */ }
            { (nbAutoDevices || nbFixedDevices) ?
              <div className='aside'>
                <b>Fix CCT modes</b><br/>
                There are <span>{ nbAutoDevices }</span> device(s) in autodetect
                CCT mode, and <span>{ nbFixedDevices }</span> device(s) possibly
                in fixed mode. Fixing this will change the driver modes on
                these devices from 'autodetect' to 'CCT' and 'possibly fixed' to
                'fixed'.

                <div>
                  <Button onClick={ (e) => fixDriverModes() }
                    className={ state.driverModesFixed ? 'disabled' : '' }
                    disabled={ state.driverModesFixed } value='Fix driver modes' />
                  <span id='fix-driver-modes-status' />
                </div>
              </div> : null }

            { /* Address reassignment */ }
            <div className='aside' style={{ fontSize: '12px' }}>
              <p>
                <BasicState setState={ setReassignState }>
                  <b>Manual address reassignment</b><br/>
                  WARNING: only use this if you know what you're doing!
                  <label for="channel">DALI Channel</label>
                  <Dropdown name='channel' options={ CHANNEL_OPTS }
                    cast={ (v) => v|0 } value={ reassign.channel } />
                  <label for="old_addr">Old Address</label>
                  <Input type='number' name='old_addr' value={ reassign.old_addr }
                    cast={ (v) => v|0 } maxlength="2" style={{ width: '40px' }} />
                  <label for="new-addr">New Address</label>
                  <Input type='number' name='new_addr' value={ reassign.new_addr }
                    cast={ (v) => v|0 } maxlength="3" style={{ width: '40px' }} />
                  <Button onClick={ (e) => reassignAddress() }
                    value='Re-assign Address' />
                  <span class="spacer"></span>
                  <span id="reassign-status"></span>
                </BasicState>
              </p>
            </div>

            { /* DALI power options */ }
            <div class="aside">
              <b>Internal DALI Supply options</b>
              <BasicState setState={ setPowerState }>
                <Dropdown name='locked' options={ lockedOpts }
                  cast={ (v) => v|0 } value={ powerState.locked } />
                <Dropdown name='current' options={ currentOpts }
                  cast={ (v) => v|0 } value={ powerState.current } />
                <Button onClick={ (e) => setPowerOptions() }
                  value='Save' />
                <span id='set-power-opts-status' />
              </BasicState>
            </div>
          </div>
        </div>
      </BasicState>
    </div>;
}
