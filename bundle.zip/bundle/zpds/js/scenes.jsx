function Scene(props) {
  let scene = props.scene;
  let id = 'scene-' + scene.id;
  let lights = [];

  const get = (value) => value === undefined ? true : value;

  for (let addr in scene.state) {
    let state = scene.state[addr];
    let device = initialDevices[addr] || {};
    // Add a color slider if applicable. This duplicates a bit from devices.jsx...
    let colorSliderRow = null;
    if (device.has_color_temp) {
      let [min, max] = [device['color_k_min'], device['color_k_max']];
      colorSliderRow = <tr>
          <td></td>
          <td><span>Color:</span></td>
          <td><Checkbox name='send_color' value={ get(state['send_color']) }/></td>
          <td className='color-temp-slider'>
            <Slider name='color_temp_k' disabled={ !get(state['send_color']) }
                value={ state['color_temp_k'] } min={min} max={max}/>
          </td>
        </tr>;
    }

    lights.push(
        <NestedState indices={ ['state', addr] }>
          <tr>
            <td>{ device.dev_name || addr }</td>
            <td><Toggle name='dev_on' value={ state['dev_on'] } /></td>
            <td><Checkbox name='send_level' value={ get(state['send_level']) }/></td>
            <td><Slider name='level' disabled={ !get(state['send_level']) }
                min={0} max={255} value={ state['level'] } /></td>
            <td><Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='small-button delete' value='Remove'/></td>
          </tr>
          { colorSliderRow }
        </NestedState>);
  }

  return <NestedState baseIndices={ [scene.id] }>
      <div className='device' id={ id }>
        <Expander />

        <span style={{ width: '200px' }}>
          <label name='name'> { `${scene.id}: ${scene.name}` } </label>
        </span>

        <span style={{ width: '200px' }}>
          <Button onClick={ (e) => postJSON(`/dali/api/scenes/${scene.id}/trigger`) }
            className='small-button' value='Trigger'/>
        </span>

        <div className='detail'>
          <Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='small-button delete right' value='Delete Scene'/>

          <table>
            <tr>
              <td><span>Edit name:</span></td>
              <td>
                <Text name='name' value={ scene['name'] } />
              </td>
              <td>
                <label>Visible:</label>
                <Checkbox name='visible' value={ scene.visible }/>
              </td>
            </tr>
          </table>
          <table>
          { lights }
          </table>
        </div>
      </div>
    </NestedState>;
}

function CaptureScene(form, updateScenes) {
  let sceneID = form.querySelector(`select[name=scene]`).selectedOptions[0].value;
  let scenePath = sceneID === '' ? '' : sceneID + '/';
  postJSON(`/dali/api/scenes/${scenePath}capture`, {}, (data, err) => {
    if (err)
      flashError(err);
    else
      updateScenes((scenes) => ({...scenes, [data['scene']['id']]: data['scene']}));
  });
}

function Scenes(props) {
  let [scenes, updateScenes] = useObjState([]);

  useEffect(() => fetchJSONState(updateScenes, '/dali/api/scenes'), []);

  let sceneElems = [];
  for (let id in scenes)
    sceneElems.push(<Scene scene={ scenes[id] } />);

  let sceneIDs = range(16);

  return <div>
      <form className='aside'>
        <b>Capture Scene</b>
        <br/>
        <label for='scene'>Scene ID:</label>
        <select name='scene'>
          <option value=''>First available</option>
          { sceneIDs.map((i) => <option>{i}</option>) }
        </select>
        <input type='button' className='button small-button' value='Capture'
          onClick={ (e) => CaptureScene(e.target.form, updateScenes) } />
      </form>

      <NestedState setState={ updateScenes } url='/dali/api/scenes'>
        { sceneElems }
      </NestedState>
    </div>;
}
