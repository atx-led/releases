function ZWaveNode(props) {
  if (props.info.hidden)
    return null;

  return <div>
      <NestedState baseIndices={ [props.node_id] }>
        <Expander checked={ true }/>
        <span>{ props.info.name }</span>

        <div className='detail'>
          <div className='right'>
              <Button bind={{ onClick: (ctx) => (e) => ctx.update('hidden', true) }}
                  className='delete' value='Hide Node'/>
          </div>

          <div>
            <span>Edit name:</span>
            <Text name='name' value={ props.info.name } />
          </div>

          <div>
            Node ID: { props.node_id }
          </div>

          <div>
          {
            mapObj(props.info, (key, data) =>
            key === 'name' || key === 'hidden' ?
              null
            : [<b>{ key }:</b>,
              data.length === 0 ?
                <div>None.</div>
              : <table className='pre'>
                  { mapObj(data, (desc, subdata) =>
                    <tr><td>{ desc }:</td><td>{ JSON.stringify(subdata, null, 2) }</td></tr>) }
                </table>])
            }
          </div>
        </div>
      </NestedState>
    </div>;
}

function ZWaveNodes(props) {
  const baseURL = '/dali/zwave/api/nodes';
  let [zwaveNodes, updateZwaveNodes] = useObjState([]);

  useEffect(() => fetchJSONState(updateZwaveNodes, baseURL), []);

  return <div>
      <div className='header'>Known ZWave Nodes</div>
        <NestedState setState={ updateZwaveNodes } url={ baseURL }>
          { mapObj(zwaveNodes, (node_id, info) =>
            <ZWaveNode node_id={ node_id } info={ info } />) }
        </NestedState>
    </div>;
}
