const DEFAULT_ACTION = {
  'type': 'level_set',
  'address': 'all',
  'source_address': '0_s_0',
  'level': 0,
  'color_temp_k': 1700,
  'scene_id': 0,
  'delay_minutes': 1,
  'unix_message': '',
};

const AM_PM = [['am', 'AM'], ['pm', 'PM']];
const BEFORE_AFTER = ['before', 'after'];
const ALL_WEEKDAYS = ['M', 'Tu', 'W', 'Th', 'F', 'Sa', 'Su'];

const ACTION_TYPES = [
  ['level_set', 'Set light to level'],
  ['level_inc', 'Brighten light by 10%'],
  ['level_dec', 'Dim light by 10%'],
  ['level_min', 'Set light to minimum level'],
  ['level_max', 'Set light to maximum level'],
  ['level_off', 'Turn light off'],
  ['level_step_up', 'Step light level up and end fade'],
  ['level_step_down', 'Step light level down and end fade'],
  ['color_set', 'Set light color temperature'],
  ['check_level_gte', 'Check light is at least level'],
  ['check_level_lte', 'Check light is at most level'],
  ['copy_level', 'Copy level from a light'],
  ['min_level_set', 'Set minimum limit for light range'],
  ['max_level_set', 'Set maximum limit for light range'],
  ['fade_up_set', 'Set light fade up value'],
  ['fade_down_set', 'Set light fade down value'],
  ['trigger_scene', 'Trigger Scene'],
  ['delay', 'Wait'],
  ['unix_socket_msg', 'Send a message to a script'],
];

const ADDRESS_TYPES = {
  's': 'light',
  'p': 'passive light',
  'g': 'group',
  'v': 'virtual group',
  'd': 'virtual device',
}

function addrDesc(address, addrMap) {
  let addr = addrMap[address];
  if (!addr) {
    if (!address)
      return 'all lights';
    let [ch, type, id] = address.split('_');
    ch = ch > 0 ? ` (channel ${ch|0+1})` : '';
    return `${ADDRESS_TYPES[type]} ${id}${ch}`;
  }
  return addr.toLowerCase();
}

function actionDesc(action, addrMap) {
  let action_type = action.type || 'level_set';

  if (action_type === 'level_set' || action_type === 'color_set' ||
      action_type === 'level_min' || action_type === 'level_max' ||
      action_type === 'min_level_set' || action_type === 'max_level_set' ||
      action_type === 'fade_up_set' || action_type === 'fade_down_set' ||
      action_type === 'level_inc' || action_type === 'level_dec' ||
      action_type === 'check_level_gte' || action_type === 'check_level_lte' ||
      action_type === 'copy_level' || action_type == 'level_off') {
    let addr = addrDesc(action.address, addrMap);
    if (action_type === 'level_set')
      return `set ${addr} to level ${action.level}`;
    else if (action_type === 'level_inc')
      return `brighten ${addr} by 10%`;
    else if (action_type === 'level_dec')
      return `dim ${addr} by 10%`;
    else if (action_type === 'level_min')
      return `set ${addr} to minimum level`;
    else if (action_type === 'level_max')
      return `set ${addr} to maximum level`;
    else if (action_type === 'level_off')
      return `turn ${addr} off`;
    else if (action_type === 'min_level_set')
      return `set level range minimum of ${addr} to ${action.level}`;
    else if (action_type === 'max_level_set')
      return `set level range maximum of ${addr} to ${action.level}`;
    else if (action_type === 'fade_up_set')
      return `set fade up level of ${addr} to ${action.level}`;
    else if (action_type === 'fade_down_set')
      return `set fade down level of ${addr} to ${action.level}`;
    else if (action_type === 'color_set')
      return `set color of ${addr} to ${action.color_temp_k}K`;
    else if (action_type === 'copy_level') {
      let source = addrDesc(action.source_address, addrMap);
      return `set ${addr} to the same level as ${source}`;
    } else if (action_type === 'check_level_gte')
      return `check that ${addr} is at least level ${action.level}`;
    else if (action_type === 'check_level_lte')
      return `check that ${addr} is at most level ${action.level}`;
  } else if (action_type === 'trigger_scene')
    return `trigger scene ${action.scene_id}`;
  else if (action_type === 'unix_socket_msg')
    return `send a message to a script`;
  else if (action_type === 'delay')
    return `wait for ${action.delay_minutes} minute(s)`;
  return '';
}

// Produce a pretty sentence description of a schedule entry, to show when
// the entry is collapsed
function scheduleEntryDesc(entry, addrMap) {
  let condition = entry.condition;
  let condStr = '';
  if (condition.type === 'specific') {
    let t = condition.time;
    condStr = `At ${t.hour}:${t.minute} ${t.ampm}`;
  } else if (condition.type === 'sunrise' || condition.type === 'sunset') {
    if (condition.offset.minutes)
      condStr = `${condition.offset.minutes} minutes ${condition.offset.direction} ${condition.type}`;
    else
      condStr = `At ${condition.type}`;
  } else if (condition.type === 'level_on' || condition.type === 'level_off') {
    let addr = addrDesc(condition.address, addrMap);
    let on_off = condition.type === 'level_on' ? 'on' : 'off';
    condStr = `When ${addr} turns ${on_off}`;
  } else if (condition.type === 'zwave_generic') {
    // Ugh just punt on this for now
    //let key = condition.zwave_key;
    //let eventType = ZWAVE_EVENT_TYPES[key[0]];
    //condStr = `When a ZWave event occurs (${eventType} ${key})`;
    condStr = `When a ZWave event occurs`;
  }

  let actions = entry.actions.map((a) => actionDesc(a, addrMap)).join('; ');
  return `${condStr}: ${actions}`;
}

function ActionList(entry, props) {
  let addresses = props.addresses;
  let singleAddresses = props.addresses.Lights || [];
  let scenes = mapObj(props.scenes, (id, scene) => [id, scene.name]);
  let actions = entry.actions.map((action, actionID) => {
    let action_type = action.type || 'level_set';
    return <div className='action spaces'>
        <NestedState indices={ [actionID] }>
          <Dropdown name='type' options={ ACTION_TYPES }
              value={ action_type } />

          <Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='small-button delete right' value='-'/>

          <div style={{ marginLeft: 20 }}>
            { action_type === 'level_set' ? [
              <span>Set</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
              <span>to</span>,
              <Slider name='level' min={ 0 } max={ 254 } value={ action.level } />,
            ] : (action_type === 'level_inc' || action_type === 'level_dec' ||
                  action_type === 'level_min' || action_type === 'level_max' ||
                  action_type === 'level_off' || action_type === 'level_step_up' ||
                  action_type === 'level_step_down') ? [
              <span>Light:</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
            ] : (action_type === 'check_level_gte' || action_type === 'check_level_lte') ? [
              <span>Check</span>,
              <Dropdown name='address' sort={ true }
                  options={ singleAddresses } value={ action.address } />,
              <span>is at { action_type.indexOf('gte') !== -1 ? 'least ' : 'most ' } level</span>,
              <Slider name='level' min={ 0 } max={ 254 } value={ action.level } />,
              <div className='info'>(otherwise, the rest of the actions are ignored)</div>,
            ] : action_type === 'min_level_set' || action_type === 'max_level_set' ? [
              <span>Set</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
              <span>{ action_type == 'min_level_set' ? 'minimum ' : 'maximum ' }
                  level to</span>,
              <Slider name='level' min={ 0 } max={ 254 } value={ action.level } />,
            ] : action_type === 'fade_up_set' || action_type === 'fade_down_set' ? [
              <span>Set</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
              <span>fade { action_type == 'fade_up_set' ? 'up ' : 'down ' }
                  level to</span>,
              <Slider name='level' min={ 0 } max={ 15 } value={ action.level } />,
            ] : action_type === 'color_set' ? [
              <span>Set</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
              <span>to</span>,
              <span className='color-temp-slider'>
                <Slider name='color_temp_k' min={ 1700 } max={ 6500 }
                    value={ action.color_temp_k } />
              </span>,
            ] : action_type === 'copy_level' ? [
              <span>Set</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
              <span>to be the same level as</span>,
              <Dropdown name='source_address' options={ singleAddresses }
                  sort={ true } value={ action.source_address } />,
            ] : action_type === 'trigger_scene' ? [
              <span>Trigger scene</span>,
              <Dropdown name='scene_id' options={ scenes } cast={ (v) => v|0 }
                  value={ action.scene_id } />,
              <span>on</span>,
              <Dropdown name='address' group={ true } sort={ true }
                  options={ addresses } value={ action.address } />,
            ] : action_type === 'unix_socket_msg' ? [
              <div className='info'>For advanced users! This event will send the
              following message on a UNIX-domain socket to the file 
              <b>/home/pi/atxled/api-events</b>, which can be listened to by a
              script.</div>,
              <div>Send message: <Text name='unix_message' length={ 64 }
                  value={ action.unix_message } /></div>,
            ] : action_type === 'delay' ? [
              <span>Wait for</span>,
              <TextNumber name='delay_minutes' min={0} max={24*60}
                  style={{width: 50}} value={ action.delay_minutes } />,
              <span>minute(s)</span>,
            ] : null }
          </div>
        </NestedState>
      </div>;
    });

  return <NestedState indices={ ['actions'] }>
      <span>
        <b>Actions:</b>
        <span style={{ width: '20px' }} />
        <Button bind={{ onClick: (ctx) => (e) => ctx.update(null, {...DEFAULT_ACTION}) }}
          className='small-button' value='+'/>
      </span>
      { actions }
    </NestedState>;
}

function ScheduleEntry(props) {
  let entry = props.entry;

  const CONDITION_TYPES = [
    ['specific', 'At a specific time'],
    ['sunrise', 'Sunrise'],
    ['sunset', 'Sunset']
  ];
  let condition = entry.condition;

  const HOURS = range(1, 13).map((x) => '' + x);
  // Zero-pad minutes array, ugh
  let MINUTES = range(60);
  for (let m in MINUTES)
    if (MINUTES[m] < 10)
      MINUTES[m] = '0' + MINUTES[m];
  MINUTES = MINUTES.map((x) => '' + x);

  return <div className='schedule-entry' id={ props.id }>
      <Expander checked={ false }/>

      <span>
        <label name='name'> { entry['name'] } </label>
      </span>

      <div className='right'>
        <Button onClick={ (e) => postJSON(`/dali/schedule/api/entries/${entry.id}/trigger`) }
            className='button' value='Trigger Now'/>
      </div>

      <div className='collapsed small-text'>
        <span> { scheduleEntryDesc(entry, props.addrMap) } </span>
      </div>

      <div className='detail'>
        <div className='right'>
          <Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='delete' value='Delete Entry'/>
        </div>

        <div>
          <span style={{ width: '100px' }}>Edit name:</span>
          <span style={{ width: '200px' }}>
            <Text name='name' value={ entry['name'] } />
          </span>
        </div>

        <div>
          <span style={{ width: '100px' }}><b>When?</b></span>
          <NestedState indices={ ['condition'] }>
            <Dropdown name='type' options={ CONDITION_TYPES }
                value={ condition.type } />
            <div className='spaces'>
              { condition.type === 'specific' ?
                <NestedState indices={ ['time'] }>
                  <Dropdown name='hour' options={ HOURS }
                      value={ condition.time.hour } />
                  <Dropdown name='minute' options={ MINUTES }
                      value={ condition.time.minute } />
                  <Dropdown name='ampm' options={ AM_PM }
                      value={ condition.time.ampm } />
                </NestedState>
                :
                <NestedState indices={ ['offset'] }>
                  <span>Offset:</span>
                  <TextNumber name='minutes' min={0} max={24*60}
                      style={{width: 50}} value={ condition.offset.minutes } />
                  <span>minutes</span>
                  <Dropdown name='direction' options={ BEFORE_AFTER }
                      value={ condition.offset.direction } />
                </NestedState>
              }
            </div>
            <span style={{ width: '100px' }}><b>On weekdays:</b></span>
            <CheckboxSet name='weekdays' names={ ALL_WEEKDAYS }
                values={ condition.weekdays || ALL_WEEKDAYS } />
          </NestedState>
        </div>

        <div>
          { ActionList(entry, props) }
        </div>
      </div>
    </div>;
}

// This function is a tad awkward, but it's logic we don't want duplicated that
// needs to work with the slightly weird React hooks API
function loadAddrsAndMap(updateAddresses, updateAddrMap) {
  useEffect(() => fetchJSONState((addrFn) => {
      updateAddresses(addrFn);
      let addrs = addrFn();
      let merged = {};
      for (let addrType in addrs)
        for (let addr of addrs[addrType])
          merged[addr.key] = addr.value;
      updateAddrMap(() => merged);
    }, '/dali/api/addresses'), []);
}

function Schedule(props) {
  let [entries, updateEntries] = useObjState({});
  let [addresses, updateAddresses] = useObjState({});
  let [addrMap, updateAddrMap] = useObjState({});
  let [scenes, updateScenes] = useObjState({});

  useEffect(() => fetchJSONState(updateEntries, '/dali/schedule/api/entries'), []);
  useEffect(() => fetchJSONState(updateScenes, '/dali/api/scenes'), []);
  loadAddrsAndMap(updateAddresses, updateAddrMap);

  let ents = mapObj(entries, (id, entry) =>
    <NestedState baseIndices={ [id] }>
      <ScheduleEntry entry={ entry } addresses={ addresses } addrMap={ addrMap } scenes={ scenes }/>
    </NestedState>
  );

  return <div className='schedule'>
      <NestedState setState={ updateEntries } url='/dali/schedule/api/entries'>
        <h4>
          Schedule
          <form action='/dali/schedule/import' className='import-export'
              method='POST' enctype='multipart/form-data'>
            <LinkButton className='button' url='/dali/schedule/export' value='Export' />
            <input type='file' name='file' required={ true } />
            <input type='submit' className='button' value='Import' />
          </form>
        </h4>

        <Button value='New Entry'
            bind={{onClick: (ctx) => (e) => ctx.create({'name': 'New Entry'}) }} />

        { ents }
      </NestedState>
    </div>;
}
