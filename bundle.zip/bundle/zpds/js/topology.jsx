function TopoDevice(device, runID, devID, totalWatts) {
  let label = (runID + 1) + String.fromCharCode(97+devID);
  let minVolts = device.led_count * 9 + 4;
  let cls = device.voltage < minVolts ? 'undervolt' : '';
  return <tr className={ cls }>
      <td>{ totalWatts && totalWatts.toPrecision(3) }</td>
      <td>{ label }</td>
      <td>{ device.watts.toPrecision(3) }</td>
      <td>{ device.voltage.toPrecision(3) }</td>
      <td>{ device.dev_name }</td>
      <td>{ device.distance.toPrecision(3) }</td>
      <td>{ device.led_counts_lr && device.led_counts_lr[0] }</td>
      <td>{ device.led_counts_lr && device.led_counts_lr[1] }</td>
      <td>{ device.led_count_cct }</td>
    </tr>;
}

function TopoRun(run, runID) {
  let totalWatts = run.map((d) => d.watts).reduce((a, b) => a + b);
  let idx = 0;
  let children = run.map((d) => TopoDevice(d, runID, idx++,
    idx == 1 ? totalWatts : null));
  return [...children, <tr><td><div className='vert-spacer'/></td></tr>];
}

function LoadTopoDevice(device) {
  const light = device.light;
  return <tr>
      <td>{ device.channel }</td>
      <td>{ device.short_addr }</td>
      <td>{ light.dev_name }</td>
      <td>{ light.level }</td>
      <td>{ UPC_TABLE[light.upc_code] || light.upc_code }</td>
      <td>{ device.led_counts_lr && device.led_counts_lr[0] }</td>
      <td>{ device.led_counts_lr && device.led_counts_lr[1] }</td>
      <td>{ device.led_count_cct }</td>
      <td>{ device.peak_watts }</td>
      <td>{ device.has_fan ? 'yes' : 'no' }</td>
    </tr>;
}

function PSETopoDevice(device) {
  const name = `pse-status-${device.channel}-${device.pse_addr}`;
  const rescan = (e) => {
    let cmd = (device.pse_addr << 9) | 0x120;
    cmd = 't' + cmd.toString(16).padStart(4, '0');
    postStatus(name, '/dali/api/send-raw', {channel: device.channel, commands: [cmd]});
  };

  return <div>
    <h5>{ `PSE device (channel ${device.channel}, address ${device.pse_addr})` }</h5>
    <Button value='Rescan devices' onClick={ rescan } />
    <span id={ name } />
    <table className='topo-dev' style={{ fontSize: 14, marginLeft: 50 }}>
      <tr>
        <td>Short Address</td>
        <td>Watts</td>
        <td>PSE Channel</td>
      </tr>
      { device.devices.map((dev) => 
        <tr>
          <td>{ dev.addr }</td>
          <td>{ dev.watts }</td>
          <td>{ dev.channel }</td>
        </tr>
      )}
    </table>
  </div>;
}

function Topology() {
  let [topo, updateTopo] = useState(initialTopology);
  let [loadTopo, updateLoadTopo] = useState(initialLoadTopology);
  let [PSETopo, updatePSETopo] = useState(initialPSETopology);

  let progressRef = useRef();
  let loadProgressRef = useRef();
  let PSEProgressRef = useRef();

  let rescan = () => postProgress(progressRef.current.id,
    '/dali/api/scan-topology', (data) => updateTopo(data.topology));
  let rescanLoad = () => postProgress(loadProgressRef.current.id,
    '/dali/api/scan-load-topology', (data) => updateLoadTopo(data.topology));
  let rescanPSE = () => postProgress(PSEProgressRef.current.id,
    '/dali/api/scan-pse-topology', (data) => updatePSETopo(data.topology));

  return <div>
    <h3>DR2G Topology</h3>
    <div>
      <Button value='Rescan Topology' onClick={ rescan } />
      <span className='spacer' />
      <span id='progress' ref={ progressRef } />
    </div>
    { mapObj(topo, (c, runs) =>
      <div>
        <h4>Channel { (c|0) + 1 }</h4>

        <table className='topo-dev'>
          <tr>
            <td>Total Watts</td>
            <td>Home Run</td>
            <td>Watts</td>
            <td>Voltage</td>
            <td>Device</td>
            <td>Distance</td>
            <td>LEDs</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td colspan='6'></td>
            <td>Left</td>
            <td>Right</td>
            <td>CCT</td>
          </tr>
          { runs.map((run, i) => TopoRun(run, i)) }
        </table>
      </div>) }
    <h3>Load Topology</h3>
    <div>
      <Button value='Rescan Load Topology' onClick={ rescanLoad } />
      <span className='spacer' />
      <span id='load-progress' ref={ loadProgressRef } />
    </div>
    <table className='topo-dev'>
      <tr>
        <td>Channel</td>
        <td>Short Address</td>
        <td>Name</td>
        <td>Level</td>
        <td>Model</td>
        <td>LEDs</td>
        <td></td>
        <td></td>
        <td>Peak Watts</td>
        <td>Has Fan</td>
      </tr>
      <tr>
        <td colspan='5'></td>
        <td>Left</td>
        <td>Right</td>
        <td>CCT</td>
        <td></td>
      </tr>
      { loadTopo.map((dev) => LoadTopoDevice(dev)) }
    </table>

    <h3>PSE-4D Topology</h3>
    <div>
      <Button value='Rescan PSE-4D Topology' onClick={ rescanPSE } />
      <span className='spacer' />
      <span id='PSE-progress' ref={ PSEProgressRef } />
    </div>
    <div>
      { PSETopo.map((dev) => PSETopoDevice(dev)) }
    </div>

    </div>;
}
