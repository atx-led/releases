const GREY = [100, 100, 100];
const YELLOW = [255, 255, 80];
const RED = [255, 240, 140];
const BLUE = [220, 240, 255];

const LIGHT_ICON = '/dali/static/icon/light.svg';
const LIGHT_ICON_ON = '/dali/static/icon/switchon.png';
const LIGHT_ICON_OFF = '/dali/static/icon/switchoff.png';

function blendColors([r1, g1, b1], [r2, g2, b2], x) {
  let r = lerp(r1, r2, x);
  let g = lerp(g1, g2, x);
  let b = lerp(b1, b2, x);
  return [r, g, b];
}

function rgbStr([r, g, b]) {
  return `rgb(${r}, ${g}, ${b})`;
}

function BasicDevice(props) {
  let device = props.device;
  let ctx = React.useContext(StateContext);
  const onClick = (e) => ctx.update('dev_on', !device.dev_on)

  let rgb = device.dev_on ? YELLOW : GREY;
  if (device.has_color_temp) {
    let x = scale(device.color_temp_k, device.color_k_min, device.color_k_max, 0, 1);
    let s = device.dev_on ? (device.level + 256) / 512 : 0;
    rgb = blendColors(RED, BLUE, x);
    rgb = blendColors(GREY, rgb, s);
  }

  //const icon = group.dev_on ? LIGHT_ICON_ON : LIGHT_ICON_OFF;
  const icon = LIGHT_ICON;

  /*
        <BasicSlider name='color_temp_k' value={ device.color_temp_k }
            style={{ width: '80px' }} min={ device.color_k_min }
            max={ device.color_k_max } />
  */

  return <div className='basic-device-wrapper'>
      <div className='basic-device-icon' onClick={ onClick }>
        <svg width='90' height='90' viewBox='-50 -50 100 100'>
          <circle cx='0' cy='0' r='40'
                fill={ rgbStr(rgb) } stroke='#666' stroke-width='2'  />
          <image x='-20' y='-20' width='40'
              href={ icon }/>
        </svg>
      </div>
      <BasicSlider name='level' value={ device.level }
          style={{ width: '80px' }} min='0' max='254' />
      <div className='basic-device-name'>
        { device.hue_name || device.dev_name }
      </div>
    </div>;
}

function BasicGroup(props) {
  let group = props.group;
  let ctx = React.useContext(StateContext);
  const onClick = (e) => ctx.update('dev_on', !group.dev_on);

  let rgb = group.dev_on ? YELLOW : GREY;
  //let icon = group.dev_on ? LIGHT_ICON_ON : LIGHT_ICON_OFF;
  const icon = LIGHT_ICON;

  return <div className='basic-device-wrapper' onClick={ onClick }>
      <div className='basic-device-icon'>
        <svg width='90' height='90' viewBox='-50 -50 100 100'>
          <circle cx='0' cy='0' r='40'
                fill={ rgbStr(rgb) } stroke='#666' stroke-width='2'  />
          <image x='-10' y='-30' width='20'
              href={ icon }/>
          <image x='-10' y='10' width='20'
              href={ icon }/>
          <image x='-30' y='-10' width='20'
              href={ icon }/>
          <image x='10' y='-10' width='20'
              href={ icon }/>
        </svg>
      </div>
      <div className='basic-device-name'>
        { group.hue_name || group.dev_name }
      </div>
    </div>;
}

function BasicScene(props) {
  let scene = props.scene;
  const onClick = (e) => postJSON(`/dali/api/scenes/${scene.id}/trigger`);

  const icon = LIGHT_ICON;

  return <div className='basic-device-wrapper' onClick={ onClick }>
      <div className='basic-device-icon'>
        <svg width='90' height='90' viewBox='-50 -50 100 100'>
          <clipPath id='circle' clipPathUnits='userSpaceOnUse'>
            <circle cx='0' cy='0' r='40' clipRule='evenodd'/>
          </clipPath>
          <circle cx='0' cy='0' r='40'
                fill='#888' stroke='#666' stroke-width='2'  />
          <path d='M-40 -40 L-40 40 L40 40 z'
                fill={ rgbStr(RED) } clipPath='url(#circle)'/>
          <path d='M-40 -40 L40 -40 L40 40 z'
                fill={ rgbStr(BLUE) } clipPath='url(#circle)'/>
          <line x1='-28.284' y1='-28.284' x2='28.284' y2='28.284'
                stroke='#333' stroke-width='1'  />
          <image x='-10' y='-30' width='20'
              href={ icon }/>
          <image x='-10' y='10' width='20'
              href={ icon }/>
          <image x='-30' y='-10' width='20'
              href={ icon }/>
          <image x='10' y='-10' width='20'
              href={ icon }/>
        </svg>
      </div>
      <div className='basic-device-name'>
        { scene.name }
      </div>
    </div>;
}

function getPowerUsage(devices) {
  let nLEDs = {};
  for (let dev of initialLoadTopology) {
    let addr = `${dev.channel}_s_${dev.short_addr}`;
    if (dev.led_counts_lr !== null)
      nLEDs[addr] = dev.led_counts_lr[0] + dev.led_counts_lr[1];
    else if (dev.led_count_cct !== null)
      nLEDs[addr] = dev.led_count_cct;
  }

  let psePower = 0, power = 0;
  let found = false;
  for (let addr in devices) {
    let dev = devices[addr];
    if (isPSE4D(dev)) {
      found = true;
      if (dev.dev_on)
        psePower += dev.level > 200 ? (dev.level - 200) * 10 : dev.level;
    } else if (dev.dev_on) {
      let n = nLEDs[addr] !== undefined ? nLEDs[addr] : 4;
      // Convert level to approximate power with the curve from DALI spec,
      // and the current/power from our LEDs (660 mA, 9V)
      let scale = Math.pow(10, 3 * dev.level / 254) / 1000.;
      console.log(n, scale, dev.level);
      power += .660 * 9 * scale * n;
    }
  }
  power = found ? psePower : power;
  return <div>{ power.toFixed(0) }W</div>;
}

function BasicDevices(props) {
  let [devices, updateDevices] = useObjState(initialDevices);
  let [groups, updateGroups] = useObjState(initialGroups);
  let [scenes, updateScenes] = useObjState([]);

  updateDevsFromWS('/ws/dali/devices', updateDevices, true);
  updateDevsFromWS('/ws/dali/groups', updateGroups, true);

  useEffect(() => fetchJSONState(updateScenes, '/dali/api/scenes'), []);

  let devs = [];
  let otherDevs = [];
  for (let addr in devices) {
    let device = <NestedState setState={ updateDevices }
              url={ '/dali/api/devices' } baseIndices={ [addr] }>
            <BasicDevice device={ devices[addr] }/>
          </NestedState>;

    if (devices[addr].hue_hidden)
      otherDevs.push(device);
    else
      devs.push(device);
  }

  for (let addr in groups) {
    let group = groups[addr];
    if (group.device_ids.length === 0)
      continue;
    let device = <NestedState setState={ updateGroups } url={ '/dali/api/devices' }
              baseIndices={ [addr] }>
            <BasicGroup group={ group }/>
          </NestedState>;

    if (group.hue_hidden)
      otherDevs.push(device);
    else
      devs.push(device);
  }

  for (let addr in scenes)
    if (scenes[addr].visible)
      devs.push(<BasicScene scene={ scenes[addr] }/>);

  return <div>
      <div className='top-bar'>
        <div className='top-bar-items'>
          <div className='top-bar-box'>
            <a href='https://atxled.com'>
              <img width='60' src='/dali/static/icon/atxled.png'/>
            </a>
          </div>
          <div className='top-bar-box'>
            <a href='/dali/schedule'>
              <img width='60' src='/dali/static/icon/schedule.svg'/>
            </a>
          </div>
          <div className='top-bar-box flex-grow'>
            <div className='top-bar-title'>{ siteName }</div>
          </div>
          <div className='top-bar-box'>
            <a href='/dali/devices'>
              <img width='60' src='/dali/static/icon/config.svg'/>
            </a>
          </div>
          <div className='top-bar-box'>
            { getPowerUsage(devices) }
          </div>
        </div>
      </div>

      <div className='page-container'>
        <div className='basic-device-container'>
          { devs }
        </div>
      </div>
      { devs.length && otherDevs.length ?
        <h4 className='device-header'>Hidden devices</h4> : null }
      <div className='page-container'>
        <div className='basic-device-container'>
          { otherDevs }
        </div>
      </div>
    </div>;
}
