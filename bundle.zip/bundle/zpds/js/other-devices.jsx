function VirtualDevice(device) {
  let id = `virtual_device_${device.channel}_${device.short_addr}`;

  if (device['address'][1] != 'virtual-device')
    return null;

  // Set up status info
  let statusAttrs = [
    ['Channel', (dev) => dev['channel'] + 1, false],
    ['Short address', 'short_addr', false],
  ];
  let statusTable = getStatusTable(device, statusAttrs);

  let detail = <div className='detail'>
      <div className='columns'>
        <div>
          <h4>Config</h4> 
          <table>
            <tr>
              <td><span>Edit name:</span></td>
              <td>
                <Text name='dev_name' value={ device['dev_name'] } />
              </td>
            </tr>

            <tr>
              <td><span>Number of sequential devices:</span></td>
              <td>
                <TextNumber name='fail_level' min={1} max={63}
                    value={ device['fail_level'] } />
              </td>
            </tr>
          </table>
        </div>

        <div>
          <Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='delete right' value='Delete'/>

          <h4>Status</h4>
          { statusTable }
        </div>
      </div>

      <h4>Groups</h4>
      <div>
        <CheckboxSet name='groups' count={16} values={ device['groups'] || [] } />
      </div>
    </div>;

  return BaseDevice(id, device, detail, null);
}

function PassiveDevice(device) {
  let id = `passive_device_${device.channel}_${device.short_addr}`;

  let addr = `${device.channel}_s_${device.short_addr}`;
  let mainDev = initialDevices[addr];

  return <tr className='passive-device'>
      <td>{ device.channel + 1 }</td>
      <td>{ device.short_addr }</td>
      <td>

      <div>
        <label name='dev_name'> { device['dev_name'] } </label>
      </div>

      <div className='detail expanded'>
        <table>
          { mainDev ? 
            <tr>
              <td>Main device:</td>
              <td>{ mainDev['dev_name'] }</td>
            </tr> : null }

          <tr>
            <td><span>Edit name:</span></td>
            <td>
              <Text name='dev_name' value={ device['dev_name'] } />
            </td>
          </tr>
        </table>
      </div>

      </td>
    </tr>;
}

const BUTTON_SEND_MODES = [
  'single',
  'group',
  'scene',
  'all',
];

const RELAY_LED_MODES = [
  ['off', 'Off'],
  ['on_off', 'On/Off'],
];

const BUTTON_LED_MODES = RELAY_LED_MODES.concat([
  ['master', 'Dimmable, remote'],
  ['dest', 'Dimmable, local'],
]);

function ButtonDevice(device) {
  let id = `button_device_${device.channel}_${device.short_addr}`;

  let addr = `${device.channel}_s_${device.short_addr}`;

  let label = device.is_io_device ? 'I/O ' :
      device.is_relay_device ? 'Output ' 
      : 'Button ';

  let led_modes = device.is_relay_device ? RELAY_LED_MODES : BUTTON_LED_MODES;

  return <div className='button-device'>
      <Expander />

        <label name='dev_name'> { device['dev_name'] } </label>

      <div className='detail'>
        <tr>
          <td><span>Edit name:</span></td>
          <td>
            <Text name='dev_name' value={ device['dev_name'] } />
          </td>
        </tr>

        <table>
          { device.buttons.map((button) =>
            <NestedState indices={ ['buttons', button.id] }>
            <tr>
              <td><b>{ label } { button.id + 1 }</b></td>
              <td colspan='2'>Send to:
                <Dropdown name='send_mode' options={ BUTTON_SEND_MODES }
                    value={ button.send_mode } />
                { ' address ' }
                <TextNumber name='address'
                    disabled={ button.send_mode === 'all' }
                    min={0} max={ button.send_mode === 'single' ? 63 : 15 }
                    value={ button.address } style={{ width: 50 }} />
              </td>
            </tr>
            <tr>
              <td></td>
              <td>LED: <Dropdown name='led_mode' options={ led_modes }
                    value={ button.led_mode } /> </td>
              <td>Momentary: <Checkbox name='momentary'
                  value={ button.momentary } /> </td>

              <td>
              { button.send_mode === 'scene' ?
                [<label for='undo'>Allow scene undo (press again within 5s):</label>,
                  <Checkbox name='undo' value={ button.undo } />]
                : [<label for='pairwise'>Paired:</label>,
                  <Checkbox name='pairwise' value={ button.pairwise }
                    disabled={ !button.momentary } />] }
              </td>

            </tr>
            </NestedState>) }
        </table>
      </div>
    </div>;
}

function getUsedAddresses() {
  let usedAddrs = [[], [], [], []];
  for (let addr in initialVirtualDevices) {
    let dev = initialVirtualDevices[addr];
    usedAddrs[dev.address[0]].push(dev.address[2]);
  }
  for (let addr in initialDevices) {
    let dev = initialDevices[addr];
    usedAddrs[dev.address[0]].push(dev.address[2]);
  }
  return usedAddrs;
}

function OtherDevices(props) {
  let opts = {
    baseURL: '/dali/api/virtual-devices',
    socketURL: '/ws/dali/devices',
    emptyMessage: 'No receive-only devices found.',
    showFilter: true,
    addNew: true,
  };
  let devices = DeviceSet(opts, initialVirtualDevices, VirtualDevice);

  // Calculate which short addresses are already used
  let addresses = [[], [], [], []];
  let usedAddrs = getUsedAddresses();
  for (let ch of activeChannels) {
    for (let addr of range(64))
      if (usedAddrs[ch].indexOf(addr) === -1)
        addresses[ch].push(addr);
  }

  let [selection, updateSelection] = useState({channel: 0,
    short_addr: addresses[0][0]});

  function NewVirtualDevice() {
    postJSON(`/dali/api/virtual-devices/${selection.channel}_d_${selection.short_addr}`, {});
  }

  // Create passive device table
  let passiveOpts = {
    baseURL: '/dali/api/passive-devices',
    socketURL: '/ws/dali/devices',
    emptyMessage: 'No transmit-only devices found.',
    showFilter: true,
  };
  let wrapper = (ps) => <table className='passive-devices'>
      <tr>
        <td>Ch</td>
        <td>Addr</td>
        <td>Device</td>
      </tr>
      { ps }
    </table>;

  let passiveDevices = DeviceSet(passiveOpts, initialPassiveDevices, PassiveDevice,
      wrapper);

  // Create button device table
  let buttonOpts = {
    baseURL: '/dali/api/button-devices',
    socketURL: '/ws/dali/devices',
    emptyMessage: 'No multi-address devices found.',
    showFilter: true,
  };

  let buttonDevices = DeviceSet(buttonOpts, initialButtonDevices, ButtonDevice);

  return <div>
      <h3>Receive-Only Devices</h3>
      <p className='info'>
        Use this section to configure to DALI address that do not respond to
        normal DALI commands, and to reserve those addresses from address assignment.
        See AL-DALI-DMX for an example of this kind of device
      </p>
      <div className='aside'>
        <BasicState setState={ updateSelection }>
          <b>Add New DMX Device</b>
          <br/>
          <label for='channel'>Channel:</label>
          <Dropdown name='channel' value={ selection.channel }
              options={ activeChannels.map((i) => [i, i + 1]) } />
          <label for='short_addr'>Short Address:</label>
          <Dropdown name='short_addr' value={ selection.short_addr }
              options={ addresses[selection.channel] } sort={ true } />
          <input type='button' className='button small-button' value='Add'
            onClick={ (e) => NewVirtualDevice() } />
        </BasicState>
      </div>
      { devices }

      <h3>ATX-LED Transceiver</h3>
      <p className='info'>
        Use this section to configure AL-WS-010v and AL-WS-DALI-8B devices that
        transmit only on defined addresses
      </p>
      { passiveDevices }

      <h3>Multi-Address Devices</h3>
      <p className='info'>
        Use this section to assign passive addresses to buttons and inputs in
        the AL-WS-DALI8B or AL-DALI-IO16
      </p>
      { buttonDevices }
    </div>;
}
