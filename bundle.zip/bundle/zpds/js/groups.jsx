function Group(group) {
  if (group.device_ids.length === 0)
    return null;

  let id = `group_${group['channel']}_${group['group_id']}`;

  let child = <div style={{fontSize: 12, marginLeft: 30}}>
      Lights: { group['device_names'].join(', ') }
    </div>;

  // Helper to make a simple two-column row
  let row = (desc, value) => <tr>
        <td>{ desc }</td>
        <td>{ value }</td>
      </tr>;

  let detail = <div className='detail' style={{fontSize: 12}}>
      <table>
        { row('Hue name:',
            <Text name='hue_name' value={ group['hue_name'] } />) }
        { row('Hide from Hue:',
            <Checkbox name='hue_hidden' value={ group['hue_hidden'] } />) }
      </table>
    </div>;

  return BaseDevice(id, group, detail, child);
}

function VirtualNway(props) {
  let [state, setState] = useObjState(props.group);

  let names = props.devices[state.channel].map((d) =>
    [d.short_addr, `[${d.short_addr}] ${d.dev_name}`]);

  let sendUpdate = () => postJSON('/dali/api/update-virtual-n-way', state,
      (resp, error) => {
        if (error)
          flashError(error)
        else
          location.reload();
      });

  return <div className='device'>
      <Expander checked={ true } />

      <span>{ state['name'] }</span>
      <div style={{fontSize: 12, marginLeft: 30}}>
        { state['device_names'].join(', ') }
      </div>

      <div className='detail'>
        <b>Devices</b>
        <BasicState setState={ setState }>
          <div style={{ minWidth: 200 }}>
            <CheckboxSet name='device_ids' names={ names }
                values={ state.device_ids } groupBy={1} className=' ' />
          </div>
        </BasicState>

        <Button onClick={ (e) => sendUpdate() } value='Save' />
      </div>
    </div>;
}

function VirtualNwayGroups(initialGroups, initialDevices) {
  let [groups, updateGroups] = useState(initialGroups);
  let [state, updateState] = useState({channel: 0});

  // Collect candidates
  let devices = {};
  for (let id in initialDevices) {
    let d = initialDevices[id];
    if (!isATXLED(d))
      continue;
    if (devices[d.channel] === undefined)
      devices[d.channel] = [];
    devices[d.channel].push(d);
  }

  // New group stuff
  let channels = range(4);
  let createNew = (channel) => {
    let id = `n_${groups.length}`;
    let group = {
      id: id,
      channel: state.channel,
      name: 'New Virtual Combo',
      device_ids: [],
      device_names: [],
    };
    updateGroups((groups) => ({...groups, id: group}));
  };

  // Render virtual n-way groups
  let gs = [];
  for (let addr in groups) {
    let g = groups[addr];
    gs.push(<VirtualNway group={g} devices={devices} />);
  }

  return <div>
      <h3>Virtual 3-Way</h3>

      { gs }

      <div className='aside'>
        <BasicState setState={ updateState }>
          <b>Add New Virtual N-Way Group</b>
          <br/>
          <label for='channel'>Channel:</label>
          <Dropdown name='channel' value={ state.channel }
              options={ channels.map((i) => [i, i + 1]) } />
          <input type='button' className='button small-button' value='Create New Virtual 3-Way Combo'
            onClick={ (e) => createNew(state.channel) } />
        </BasicState>
      </div>
    </div>;
}

function Groups(props) {
  let gOpts = {
    socketURL: '/ws/dali/groups',
    emptyMessage: 'No groups currently assigned.',
  };
  let groups = DeviceSet(gOpts, initialGroups, Group);

  let virtual_n_way = VirtualNwayGroups(initialVirtualNway, initialDevices);

  return <div>
      { groups }
      { virtual_n_way }
    </div>;
}
