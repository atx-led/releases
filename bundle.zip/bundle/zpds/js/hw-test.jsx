const INIT_HW_STATE = {
  running: false,
  complete: false,
  status: '',
  messages: [],
  results: [],
  alert: null,
  upc_code: null,
  hw_version: null,
  fw_version: null,
  serial_nb: null,
  wattage: null,
  passes: 0,
  fails: 0,
};

const INIT_STRESS_STATE = {
  running: false,
  status: '',
  messages: [],
  n_packets: null,
};

var beep = new Audio('/dali/static/sound/beep.mp3');

// Connect a websocket to get a stream of events, updating the state with setState
function connectSocket(setState) {
  const socketURL = '/ws/hw-test/events';
  useEffect(() => {
    var socket = getWebSocket(socketURL);
    socket.onmessage = (message) => {
      setState((state) => {
        let events = JSON.parse(message.data);
        for (let event of events) {
          if (event.running) {
            // Copy INIT_HW_STATE and reset messages so they don't share state
            state = { ...INIT_HW_STATE, running: true, messages: [], results: []};
          }
          if (event.msg) {
            state.messages.push([event.msg, event.bold]);
            delete event.msg;
            delete event.bold;
          }
          if (event.source)
            state.messages.push(['    ' + event.source, true]);
          if (event.result) {
            state.results.push(event.result);
            if (event.result[2])
              state.passes++;
            else {
              state.fails++;
            }
            delete event.result;
          }
          state = { ...state, ...event };
        }
        return state;
      });
    };
  }, [socketURL]);
}

function HWTest(props) {
  let [state, setState] = useObjState({ ...INIT_HW_STATE,
      running: props.alreadyRunning, });

  connectSocket(setState);

  let sendRequest = (endpoint, data) => {
    postJSON('/dali/hw-test/' + endpoint, data,
      (resp, error) => {
        let status = (error) ? error : resp.data;
        setState((state) => ({ ...state, status: status }));
      });
  };

  let runTest = (endpoint, data) => {
      // Copy INIT_HW_STATE and reset messages so they don't share state
      setState(() => ({ ...INIT_HW_STATE, running: true, messages: [], results: [] }));
      sendRequest(endpoint, data);
    };

  let runHWTest = () => runTest('run-test');
  let runFWTest = () => runTest('run-fw-test');

  let turnPower = (on) => sendRequest('turn-power-' + (on ? 'on' : 'off'), {});

  let sendReset = () => sendRequest('send-reset', {});

  let format = (v, unit) => v !== null ? v.toPrecision(3) + unit : '-';

  // Play a beep sound whenever an alert shows up
  useEffect(() => {
    if (state.alert)
      beep.play();
  }, [state.alert]);

  return <div>
      <BasicState setState={ setState }>
        <div className='columns'>
          <div>
            <Button className={ state.running ? 'disabled' : '' }
                value='Run test'
                onClick={ (e) => runHWTest() } />

            { state.running ?
              [<span className='spacer' />,
              <Button className='delete' value='Cancel'
                  onClick={ (e) => postJSON('/dali/hw-test/cancel-test', {}) } />]
              : null }

            <div className='vert-spacer' />
            <Button className={ state.running ? 'disabled' : '' } value='Run FW test'
                onClick={ (e) => runFWTest() } />

            <div className='vert-spacer' />
          </div>
          <div>
            <div><b>Tools</b></div>
            <Button value='Turn power on' onClick={ (e) => turnPower(true) } />
            <div className='vert-spacer' />
            <Button value='Turn power off' onClick={ (e) => turnPower(false) } />
            <div className='vert-spacer' />
            <Button value='Reset and unassign address' onClick={ (e) => sendReset() } />
          </div>
        </div>

        <div className='fixed-width'>
          <div>Status: { state.status } </div>
          <div>UPC Code: { state.upc_code } </div>
          <div>HW Version: { state.hw_version } </div>
          <div>FW Version: { state.fw_version } </div>
          <div>Serial Nb.: { state.serial_nb && state.serial_nb.toString(16) } </div>
          <div>Current Wattage: { format(state.wattage, 'W') }</div>
        </div>

        <div className='vert-spacer' />

        <div className='columns'>

          <div>
            <div className='header'>Test results</div>
            <table border='1'>
              <thead><tr>
                <td>#</td>
                <td>Test</td>
                <td>Measurement</td>
                <td>Result</td>
              </tr></thead>
              <tbody>
                <tr>
                  <td colspan='4'>
                    <div className={ 'test-results ' + (state.fails ? 'test-results-bad' : '') }>
                  { `${state.passes} / ${state.passes + state.fails} tests passed` }</div>
                  </td>
                </tr>

                { state.complete ?
                  <tr>
                    <td colspan='4'>
                      <div className={ 'test-results ' + (state.fails ? 'test-results-bad' : '') }>
                    { state.fails ? 'FAIL' : 'PASS' }</div>
                    </td>
                  </tr> : null }

                { state.alert ?
                  <tr>
                    <td colspan='4'>
                      <div className='test-alert'>{ state.alert }</div>
                    </td>
                  </tr> : null }

                { state.results.map(([test_name, watts, pass, msg], i) =>
                  <tr>
                    <td>{ i + 1 }</td>
                    <td>{ test_name }</td>
                    <td>{ watts }</td>
                    <td><div className={ 'test-result-' + (pass ? 'pass' : 'fail') } >
                      { msg }
                    </div></td>
                  </tr>) }
              </tbody>
            </table>
          </div>

          <div>
            <div className='header'>Messages</div>
            <pre className='fixed-width'>
              { state.messages.map(([msg, bold]) =>
                  <div style={{ fontWeight: bold ? 'bold': '' }}>{ msg }</div>) }
            </pre>
          </div>

        </div>
      </BasicState>
    </div>;
}

function DALIStressTest(props) {
  let [state, setState] = useObjState({ ...INIT_STRESS_STATE,
      running: props.alreadyRunning });

  connectSocket(setState);

  let runTest = (endpoint) => {
      // Copy INIT_STRESS_STATE and reset messages so they don't share state
      setState(() => ({ ...INIT_STRESS_STATE, running: true, messages: [] }));
      postJSON('/dali/hw-test/' + endpoint, {},
        (resp, error) => {
          let status = (error) ? error : resp.data;
          setState((state) => ({ ...state, status: status }));
        });
    };

  return <div>
      <BasicState setState={ setState }>
        <Button className={ state.running ? 'disabled' : '' } value='Receive stress test'
            onClick={ (e) => runTest('run-stress-test') } />

        <Button className={ state.running ? 'disabled' : '' } value='Send stress test'
            onClick={ (e) => runTest('send-stress-test') } />

        { state.running ?
          [<span className='spacer' />,
          <Button className='delete' value='Cancel'
              onClick={ (e) => postJSON('/dali/hw-test/cancel-test', {}) } />]
          : null }

        <div className='vert-spacer' />

        <div className='fixed-width'>
          <div>Packets received: { state.n_packets } </div>
        </div>

        <div className='vert-spacer' />

        <div className='header'>Messages</div>
        <div className='fixed-width'>
          { state.messages.map(([msg, bold]) =>
              <div style={{ fontWeight: bold ? 'bold': '' }}>{ msg }</div>) }
        </div>
      </BasicState>
    </div>;
}
