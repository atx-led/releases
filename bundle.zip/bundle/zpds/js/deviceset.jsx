function getStatusTable(device, attrs) {
  let statusLines = [];
  for (let [desc, name, hex] of attrs) {
    let value = typeof name === 'function' ? name(device) : device[name];
    if (hex)
      value = (value || 0).toString(16);
    statusLines.push(<tr>
        <td>{ desc }:</td>
        <td>{ value }</td>
      </tr>);
  }
  return <table className='pre'>{ statusLines }</table>;
}

function updateDevsFromWS(socketURL, updateDevices, addNew) {
  useEffect(() => {
    var socket = getWebSocket(socketURL);
    socket.onmessage = (event) =>
      updateDevices((devs) => {
        let msgs = JSON.parse(event.data);
        for (let msg of msgs) {
          if (devs[msg.addr] === undefined) {
            if (addNew)
              devs[msg.addr] = {};
            else
              continue;
          }
          for (let key in msg.data)
            devs[msg.addr][key] = msg.data[key];
        }
        return devs;
      });
  }, [socketURL]);
}

function DeviceSet(opts, initialDevices, devFn, wrapperFn) {
  let [devices, updateDevices] = useObjState(initialDevices);
  let [filter, updateFilter] = useState('');
  let baseURL = opts.baseURL || '/dali/api/devices';
  let wrapperFn = wrapperFn || ((ds) => ds);

  updateDevsFromWS(opts.socketURL, updateDevices, opts.addNew);

  let devs = [];
  for (let addr in devices) {
    let device = devices[addr];
    let elem = devFn(device);
    if (filter && device['dev_name'].toLowerCase().indexOf(filter) === -1)
      continue;
    // Normalize the address for sorting
    // Ugh I really should've made the nice address string zero-padded in the first
    // place. I don't think it's safe to change at this point...
    let sortKey = addr;
    if (addr.indexOf('_') != -1) {
      let [ch, type, id] = addr.split('_');
      sortKey = `${ch}_${type}_${id.padStart(2, '0')}`;
    }
    if (elem !== null)
      devs.push(
        [sortKey,
          <NestedState setState={ updateDevices } url={ baseURL }
              baseIndices={ [addr] }>
            { elem }
          </NestedState>]);
  }

  let filterDiv = null;
  if (opts.showFilter)
    filterDiv = <div className='filter'>
        <input type='text' value={ filter } placeholder='Filter...'
            onChange={ (e) => updateFilter(e.target.value.toLowerCase()) } />
      </div>;

  // Sort devices
  devs.sort((a, b) => a[0] > b[0]);
  devs = devs.map((d) => d[1]);

  return <div>
      { filterDiv }
      { (devs.length === 0) ? 
          <h4>{ opts.emptyMessage }</h4>
          : wrapperFn(devs) }
    </div>;
}

function BaseDevice(id, device, detail, children) {
  return <div className='device' id={ id }>
      { detail ?
        <Expander />
        : <span className='spacer' /> }

      <span style={{ width: '200px' }}>
        <label name='dev_name'> { device['dev_name'] } </label>
      </span>

      <span style={{ width: '50px' }}>
        <Toggle name='dev_on' value={ device['dev_on'] } />
      </span>

      <span style={{ width: '300px' }}>
        <Slider name='level' value={ device['level'] }
            min={ device['min_level'] || 0 }
            max={ device['max_level'] || 254 } />
      </span>

      { children }

      { detail }
    </div>;
}
