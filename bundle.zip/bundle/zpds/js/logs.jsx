const LINE_LIMIT = 5000;
const CHUNK_SIZE = 50;

let ROW_HEIGHT = 25;
let ROW_HEIGHT_SET = false;

function Log(props) {
  let [_, _setRows] = useState(null);
  let [filter, _setFilter] = useState('');
  let [offsetMin, setOffsetMin] = useState(0);
  let [offsetMax, setOffsetMax] = useState(10);

  let rowsRef = useRef();
  let filteredRowsRef = useRef();
  let filterRef = useRef();
  let scrollAreaRef = useRef();
  let rowsDivRef = useRef(null);

  let userScrolling = useRef(false);
  let autoScroll = useRef(true);
  let atBottom = useRef(true);
  let scrollTimer = useRef(debounce(500, () => {
    userScrolling.current = false;
  }));

  let getRows = () => rowsRef.current || [];
  let getFilteredRows = () => filteredRowsRef.current || [];
  function setRows(rows, f) {
    rowsRef.current = rows;
    // Update filter
    if (f === null)
      f = filterRef.current;
    else
      filter = f;
    let filtered = rows;
    if (f)
      filtered = rows.filter((r) => props.filterFn(r, f));
    filteredRowsRef.current = filtered;

    // Assign a new single-element array to the rows state, so that React knows
    // we need to re-render but we don't need to copy the actual rows array
    _setRows([rows]);
    _setFilter(f);
    filterRef.current = f;
  }
  function setFilter(f) {
    setRows(rowsRef.current, f);
    scrollToEnd(false);
  }

  useEffect(() => {
    var socket = getWebSocket(props.route);
    socket.onmessage = (event) => {
      var data = JSON.parse(event.data);
      var rows = getRows();

      var shouldScroll = false;
      var scrollArea = scrollAreaRef.current;
      if (scrollAreaRef.current !== undefined) {
        shouldScroll = atBottom.current;
        if (!shouldScroll && !userScrolling.current) {
          var scrollMax = scrollArea.scrollHeight - scrollArea.offsetHeight; 
          shouldScroll = (scrollArea.scrollTop >= scrollMax - 50);
        }
      }

      for (var row of data) {
        // If this is an amended event, update the old one
        let amended = false;
        if (row.seq !== undefined && rows.length > 0 &&
            row.seq <= rows[rows.length - 1].seq) {
          // Look in the last few slots for this sequence ID
          for (let x = 1; x < 10 && x <= rows.length; x++) {
            if (row.seq === rows[rows.length - x].seq) {
              rows[rows.length - x] = row;
              amended = true;
              break;
            }
          }
        }

        if (!amended)
          rows.push(row);
      }

      let deleteCount = rows.length - LINE_LIMIT;
      if (deleteCount > 0)
        rows.splice(0, deleteCount);

      setRows(rows, null);

      if (shouldScroll) {
        autoScroll.current = true;
        scrollArea.scrollTop = scrollArea.scrollHeight;
      }
    };
  }, [props.route, scrollAreaRef]);

  // Use an effect to scroll to the bottom if the user is there already.
  // The effect allows us to use the final calculated scroll area size before
  // scrolling, which isn't available during rendering, only after.
  useEffect(() => {
    if (atBottom.current) {
      var scrollArea = scrollAreaRef.current;
      scrollArea.scrollTop = scrollArea.scrollHeight;
    }
  }, []);

  function clearLog() {
    setRows([], null);
  }
  function scrollToEnd(bottom) {
    var scrollArea = scrollAreaRef.current;
    autoScroll.current = true;
    atBottom.current = bottom;
    userScrolling.current = false;
    scrollArea.scrollTop = bottom ? scrollArea.scrollHeight : 0;
  }

  // Determine the height of a row in this table. This is pretty icky code,
  // and is mostly the result of not being able to use max-height within
  // table rows without wrapping every single cell in a div. It's not perfect
  // even if it works anyways, since we assume all rows are the same height
  if (!ROW_HEIGHT_SET && rowsDivRef.current !== null) {
    // Get the second child if there is one. The first child is a spacer
    // taking up an arbitrary amount of blank space out of view.
    let rows = rowsDivRef.current.childNodes;
    if (rows.length > 2) {
      ROW_HEIGHT = rows[1].getBoundingClientRect().height;
      // Clip to [15, 40] for sanity
      ROW_HEIGHT = Math.max(15, Math.min(ROW_HEIGHT, 40));
      ROW_HEIGHT_SET = true;
    }
  }

  // Only render the rows that are close to the currently viewed area

  useEffect(() => {
    scrollAreaRef.current.addEventListener('wheel', () => {
      atBottom.current = false;
      userScrolling.current = true;
      scrollTimer.current();
      return true;
    })
  }, [scrollAreaRef]);

  // Handle scrolling. We update the window of visible rows, as well as set
  // a flag indicating the user is scrolling (so we shouldn't try and auto-scroll)
  let onscroll = () => {
    if (autoScroll.current)
      autoScroll.current = false;
    else {
      userScrolling.current = true;
      //atBottom.current = false;
      scrollTimer.current();
    }

    var scrollArea = scrollAreaRef.current;
    var scrollMax = scrollArea.scrollHeight - scrollArea.offsetHeight; 
    var first = scrollArea.scrollTop / ROW_HEIGHT;
    var last = (scrollArea.scrollTop + scrollArea.offsetHeight) / ROW_HEIGHT;
    // Round up/down to the nearest multiple of the chunk size, and add an
    // extra chunk margin
    first -= first % CHUNK_SIZE;
    first = Math.max(0, (first|0) - CHUNK_SIZE);
    last -= last % CHUNK_SIZE;
    last = (last|0) + 2*CHUNK_SIZE;
    setOffsetMin(first);
    setOffsetMax(last);
  }

  // Render only the rows that are in a window near the current scroll position.
  // This makes rendering massively faster with high row counts, which would
  // previously cause quite a bit of GC action. We also calculate the size of
  // blank buffer areas to put above and below the rows to keep the total size
  // constant (more or less, assuming a constant row size)
  let rows = getFilteredRows();
  let spaceAbove = ROW_HEIGHT * offsetMin;
  let spaceBelow = ROW_HEIGHT * Math.max(0, rows.length - offsetMax);
  rows = rows.slice(offsetMin, offsetMax+1);

  return <div>
      <div className="header">
        <span>{ props.title }</span>
        <span className="spacer"></span>
        <input type="button" value="Clear" onClick={ clearLog }/>
        <span className="spacer"></span>
        <input type="button" value="Scroll To Bottom" onClick={ (e) =>
          scrollToEnd(true) }/>

        <div className='filter'>
          <input type='text' value={ filter } placeholder='Filter...'
              onChange={ (e) => setFilter(e.target.value.toLowerCase()) } />
        </div>
      </div>
      <div className='log-wrapper' onScroll={ onscroll } ref={ scrollAreaRef }>
        <table className='log-table'>
          <thead>
            <tr>{ props.header }</tr>
          </thead>
          <tbody className='log-rows' ref={ rowsDivRef }>
            <tr className='log-spacer' style={{ minHeight: spaceAbove }} />

            { rows.map((row) => props.rowFn(row, filter)) }

            <tr className='log-spacer' style={{ minHeight: spaceBelow }} />
          </tbody>
        </table>
        <div className='log-scroll-anchor' />
      </div>
    </div>;
}

function DALILog(props) {
  let header = [
    <th>Time</th>,
    <th>Dir</th>,
    <th>Raw</th>,
    <th>Bus</th>,
    <th>Addr</th>,
    <th>Description</th>,
    <th colspan="2">Response</th>,
  ];

  function filterFn(data, filter) {
    let key = [data.address, data.raw, data.send_desc, data.recv_raw, data.recv_desc].join(' ');
    return (key.toLowerCase().indexOf(filter) !== -1);
  }

  function row(data, filter) {
    let id = 'log-' + data.seq;
    return <tr id={ id } key={ data.seq }>
        <td>{ data.ts }</td>
        <td>{ data.dir }</td>
        <td>{ data.raw }</td>
        <td>{ data.channel + 1 }</td>
        <td>{ data.address }</td>
        <td>{ data.send_desc }</td>
        <td>{ data.recv_raw }</td>
        <td>{ data.recv_desc }</td>
      </tr>;
  }

  return Log({...props, title: 'DALI Log', route: '/ws/dali/log',
    rowFn: row, filterFn: filterFn, header: header });
}

function ZWaveLog(props) {
  let header = [
    <th>Time</th>,
    <th>Level</th>,
    <th>Message</th>,
  ];

  function filterFn(data, filter) {
    return (data.message.toLowerCase().indexOf(filter) !== -1);
  }

  function row(data, filter) {
    return <tr>
        <td>{ data.ts }</td>
        <td>{ data.level }</td>
        <td>{ data.message }</td>
      </tr>;
  }

  return Log({...props, title: 'ZWave Log', route: '/ws/zwave/log',
    rowFn: row, filterFn: filterFn, header: header });
}
