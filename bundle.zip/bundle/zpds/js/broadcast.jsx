function BroadcastDevice(device) {
  return BaseDevice('broadcast', device);
}

function Broadcast(props) {
  let opts = {
    socketURL: '/ws/dali/broadcast',
    emptyMessage: null,
  };
  return DeviceSet(opts, initialBroadcast, BroadcastDevice);
}
