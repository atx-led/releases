const CONDITION_TYPES = [
  ['level_on', 'When a DALI light turns on'],
  ['level_off', 'When a DALI light turns off'],
  ['bcast_level_on', 'When an "on" command is broadcast on the DALI bus'],
  ['bcast_level_off', 'When an "off" command is broadcast on the DALI bus'],
  ['level_change', 'When a DALI light changes its level'],
  ['dali_scene', 'When a DALI scene is triggered'],
  ['startup', 'At system startup'],
  ['zwave_generic', 'When a ZWave event occurs'],
];

const COMPARISON_OPTIONS = [
  ['cmp_gt', 'greater than'],
  ['cmp_lt', 'less than'],
];

const DALI_SCENE_OPTS = range(0, 16);

const ZWAVE_EVENT_TYPES = [
  ['scene', 'Button Press (scene)'],
  ['switch-binary', 'Switch (binary)'],
  ['sensor-binary', 'Sensor (binary)'],
  ['sensor-multilevel', 'Sensor (multilevel)'],
  ['basic-set', 'Basic Set'],
  ['alarm', 'Alarm'],
];
const ZWAVE_EVENT_DEFAULT_ARGS = {
  'scene': [1, 0],
  'switch-binary': [1],
  'sensor-binary': [1],
  'sensor-multilevel': ['cmp_gt', 1],
  'basic-set': [0],
  'alarm': [0, 0],
};
const ZWAVE_SCENE_OPTS = range(1, 16);
const ZWAVE_ON_OFF_OPTS = [[1, 'On'], [0, 'Off']];

function Trigger(props) {
  let entry = props.entry;
  let condition = entry.condition;
  let zwave_key = condition.zwave_key;
  let addresses = {};
  for (let type of ['Lights', 'Buttons', 'Virtual Devices']) {
    let list = props.addresses[type];
    if (list !== undefined && list.length > 0)
      addresses[type] = list;
  }

  return <div className='schedule-entry' id={ entry.id }>
      <Expander checked={ false }/>

      <span>
        <label name='name'> { entry['name'] || `Macro ${entry.id}`} </label>
      </span>

      <div className='right'>
        <Button onClick={ (e) => postJSON(`/dali/schedule/api/entries/${entry.id}/trigger`) }
            className='button' value='Trigger Now'/>
      </div>

      <div className='collapsed small-text'>
        <span> { scheduleEntryDesc(entry, props.addrMap) } </span>
      </div>

      <div className='detail'>
        <div className='right'>
          <Button bind={{ onClick: (ctx) => (e) => ctx.remove() }}
              className='delete' value='Delete Macro'/>
        </div>

        <div>
          <span style={{ width: '100px' }}>Edit name:</span>
          <span style={{ width: '200px' }}>
            <Text name='name' value={ entry['name'] } />
          </span>
        </div>

        <div>
          <span style={{ width: '100px' }}><b>When?</b></span>
          <NestedState indices={ ['condition'] }>
            <div className='spaces'>
              <Dropdown name='type' options={ CONDITION_TYPES }
                  value={ condition.type } />

              { condition.type === 'level_on' || condition.type === 'level_off' ||
                condition.type === 'level_change' ?
                  <table>
                    <tr>
                      <td>Light/Button:</td>
                      <td><Dropdown name='address' group={ true } sort={ true }
                          options={ addresses } value={ condition.address } /></td>
                    </tr>
                  </table>
                : condition.type === 'dali_scene' ?
                  <table>
                    <tr>
                      <td>Scene:</td>
                      <td><Dropdown name='dali_scene' options={ DALI_SCENE_OPTS }
                          cast={ (x) => x|0 } value={ condition.dali_scene } /></td>
                    </tr>
                  </table>
                /* ZWave cases */
                : condition.type === 'zwave_generic' ?
                  [
                  /* Add a shortcut to listen to recent zwave events. This is kinda annoying,
                   * since we have manual inputs, context updating, etc. */
                  (props.zwaveRecentEvents.length > 0 ?
                    <div className='aside'>
                      <b>Set to recent event:</b>
                      <Input elem='select' bind={{ onChange: (ctx) => (e) => {
                          let idx = e.target.value | 0;
                          if (idx < 0) return;
                          let [desc, node, key] = props.zwaveRecentEvents[idx];
                          ctx.update('zwave_node_id', node);
                          ctx.update('zwave_key', key);
                        } }} >
                        <option value={ -1 }>Select...</option>
                        { props.zwaveRecentEvents.map(([desc, node, key], id) =>
                          <option value={ id }>{ desc }</option>) }
                      </Input>
                    </div> : null),

                  <table>
                    <tr>
                      <td>Device:</td>
                      <td><Dropdown name='zwave_node_id' options={ props.zwaveNodes }
                          cast={ (x) => x|0 } value={ condition.zwave_node_id } /></td>
                    </tr>
                    <tr>
                      <td>Event type:</td>
                      <td><Dropdown name='zwave_key' options={ ZWAVE_EVENT_TYPES }
                          cast={ (x) => [x, ...ZWAVE_EVENT_DEFAULT_ARGS[x]] }
                          value={ condition.zwave_key[0] } /></td>
                    </tr>
                    <NestedState indices={ ['zwave_key'] }>
                      {
                      /* Event-specific values */
                        zwave_key[0] === 'scene' ?
                          <tr>
                            <td>Button:</td>
                            <td><Dropdown jsonName={ 1 } options={ ZWAVE_SCENE_OPTS }
                                cast={ (x) => x|0 } value={ zwave_key[1] } /></td>
                          </tr>
                        : (zwave_key[0] === 'switch-binary' || zwave_key[0] === 'sensor-binary') ?
                          <tr>
                            <td>Value:</td>
                            <td><Dropdown jsonName={ 1 } options={ ZWAVE_ON_OFF_OPTS }
                                cast={ (x) => x|0 } value={ zwave_key[1] } /></td>
                          </tr>
                        : zwave_key[0] === 'sensor-multilevel' ?
                          <tr>
                            <td colspan='2'>Trigger when sensor level is 
                            <Dropdown jsonName={ 1 } options={ COMPARISON_OPTIONS }
                                value={ zwave_key[1] } />
                            the value:
                            <TextNumber jsonName={ 2 }
                                cast={ parseFloat } value={ zwave_key[2] } />
                            </td>
                          </tr>
                        : zwave_key[0] === 'alarm' ?
                          [<tr>
                            <td>Type:</td>
                            <td><TextNumber jsonName={ 1 } minimum={ 0 } maximum={ 255 }
                                cast={ (x) => x|0 } value={ zwave_key[1] } /></td>
                          </tr>,
                          <tr>
                            <td>Level:</td>
                            <td><TextNumber jsonName={ 2 } minimum={ 0 } maximum={ 255 }
                                cast={ (x) => x|0 } value={ zwave_key[2] } /></td>
                          </tr>]
                        : zwave_key[0] === 'basic-set' ?
                          <tr>
                            <td>Value:</td>
                            <td><TextNumber jsonName={ 1 } minimum={ 0 } maximum={ 255 }
                                cast={ (x) => x|0 } value={ zwave_key[1] } /></td>
                          </tr>
                        : null }
                    </NestedState>
                  </table>]
                : null }

            </div>
          </NestedState>
        </div>

        <div>
          { ActionList(entry, props) }
        </div>
      </div>
    </div>;
}

function Triggers(props) {
  let [triggers, updateTriggers] = useObjState({});
  let [addresses, updateAddresses] = useObjState({});
  let [addrMap, updateAddrMap] = useObjState({});
  let [zwaveNodes, updateZwaveNodes] = useObjState([]);
  let [scenes, updateScenes] = useObjState({});
  let [zwaveRecentEvents, updateZwaveRecentEvents] = useObjState([]);

  useEffect(() => fetchJSONState(updateTriggers, '/dali/schedule/api/triggers'), []);
  useEffect(() => fetchJSONState(updateScenes, '/dali/api/scenes'), []);
  useEffect(() => fetchJSONState(updateZwaveNodes, '/dali/zwave/api/node-addresses'), []);
  useEffect(() => fetchJSONState(updateZwaveRecentEvents, '/dali/zwave/api/recent-events'), []);

  loadAddrsAndMap(updateAddresses, updateAddrMap);

  let triggerDivs = mapObj(triggers, (id, trigger) =>
      <NestedState baseIndices={ [trigger.id] }>
        <Trigger entry={ trigger } addresses={ addresses } addrMap={ addrMap } scenes={ scenes }
            zwaveNodes={ zwaveNodes } zwaveRecentEvents={ zwaveRecentEvents } />
      </NestedState>
  );

  let firstAddress = firstValue(addresses.Lights, {key: null}).key;

  return <div>
      <NestedState setState={ updateTriggers } url='/dali/schedule/api/entries'>
        <Button value='New Macro'
            bind={{onClick: (ctx) => (e) => ctx.create({
              'condition': {'type': 'level_on', 'address': firstAddress,
                'zwave_key': ['scene', 2, 0]},
              'actions': [DEFAULT_ACTION]}) }} />

        { triggerDivs }
      </NestedState>
    </div>;
}
