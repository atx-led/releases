const DR2F16_UPC = 784099948268;
const DR2F32_UPC = 784099948190;
const DR2G32_UPC = 784099947797;
const DR1_PIR_UPC = 784099947780;
const PSE_4D_UPC = 722512407350;
const UPC_TABLE = {
  722512406476: 'AL-WS-DALI-8B',
  722512406087: 'AL-DALI-IO16',
  722512407367: 'AL-DALI-Relay8',
  722512407176: 'AL-WS-DR2',
  722512407183: 'AL-DALI-DR2-mx',
  722512407282: 'AL-WS-010v',
  784099948466: 'AL-WS-DR1G',
  [DR2G32_UPC]: 'AL-WS-DR2G32',
  [DR2F32_UPC]: 'AL-WS-DR2F32',
  [DR2F16_UPC]: 'AL-WS-DR2F16',
  [DR1_PIR_UPC]:'AL-WS-DR1-PIR',
  [PSE_4D_UPC]:  'AL-PSE-4D',
  784099948350: 'PWS-POE-DALI',
  784099948404: 'AL-DR-TW2',
};

const N_WAY = {
  'AL-WS-010v': true,
  'AL-DALI-DR2-mx': true,
  'AL-WS-DR2F16': true,
  'AL-WS-DR2F32': true,
  'AL-WS-DR2G32': true,
  'PWS-POE-DALI': true,
  'AL-WS-DR1-PIR': true,
};

const N_WAY_OPTIONS = ['Three Way', 'Push Button', 'Dual Switch',
  'Dimming PIR Mode','Full On PIR Mode', 'PIR Detect Mode',
  'Fan Mode', 'Hotel Mode', 'Night Mode'];

const N_WAY_OPTIONS_DR2F16 = ['Three Way', 'Split'];
const N_WAY_OPTIONS_DR2F32 = ['Three Way', 'Split', 'Fan Mode', 'Night Mode', 'PIR Mode', 'Vacancy', 'Auto Off Mode'];
const N_WAY_OPTIONS_DR1_PIR = ['Three Way', 'Split'];

const FADE_TIMES = ['0', '0.7', '1.0', '1.4', '2.0', '2.8', '4.0', '5.7',
  '8.0', '11.3', '16.0', '22.6', '32.0', '45.3', '64.0', '90.5'];

const BUTTON_ON_TIME_ITEMS = ['0', '0.7', '1.0', '1.4', '2.0', '2.8', '4.0',
  '5.7', '8.0', '11.3', '16.0', '22.6', '32.0', '45.3', '64.0', 'Forever'];

const FADE_RATES = ['-', '357.8', '253.0', '178.9', '126.5', '89.4', '63.3', '44.7',
  '31.6', '22.4', '15.8', '11.2', '7.9', '5.6', '4.9', '2.8'];

const COLOR_RANGE_ATTRS = {
    'color_k_min':   [1800, 6500],
    'color_k_max':   [1800, 6500],
    'color_cct_min': [0, 511],
    'color_cct_max': [0, 511],
};

const SLIDER_POS_OPTS = [[false, 'Right'], [true, 'Left']];

const DR2F16_DRIVER_OPTIONS = [[0, 'Autodetect'], [1, 'Split Left + Right'],
  [3, 'ALL CCT'], [4, 'ALL Fixed']];

const DR2F32_DRIVER_OPTIONS = DR2F16_DRIVER_OPTIONS.concat([[2, 'Fan plus Light'],
  [5, 'Special PIR'], [6, 'Split Left + Right 12v'], [7, 'Bad Fan Load'],
  [8, 'CCT not found']]);

const DR1PIR_DRIVER_OPTIONS = [[0, 'Autodetect'], [2, 'Fan'], [4, 'CC LED'],
  [6, '12v CV LED']];

const NIGHTLIGHT_MODE_OPTIONS = [[0, 'Off'], [1, 'Internal'],
  [2, 'Overhead'], [3, 'Both']];

const VACANCY_MODE_OPTIONS = [[0, 'Occupancy'], [1, 'Vacancy'], [2, 'Manual'],
  [3, 'Occupancy Harvest'], [4, 'Vacancy Harvest'], [5, 'Manual Harvest']];

const isDR2F16 = (d) => (d['upc_code'] === DR2F16_UPC);
const isDR2F32 = (d) => (d['upc_code'] === DR2F32_UPC || d['upc_code'] === DR2G32_UPC);
const isDR2F   = (d) => (isDR2F16(d) || isDR2F32(d));
const isDR1PIR = (d) => (d['upc_code'] === DR1_PIR_UPC);
const isPSE4D  = (d) => (d['upc_code'] === PSE_4D_UPC);
const isATXLED = (d) => (UPC_TABLE[d['upc_code']] !== undefined);

function isInFanMode(device) {
  if (isDR2F(device))
    return (device['driver_mode'] === 2);
  return false;
}

function Device(device) {
  let sliders = [];
  let statusTable = null;
  // State for voltage offset inputs for devices with fw >= 54
  let [offsetState, setOffsetState] = useObjState(null);

  // Helper to make a simple two-column row
  let row = (desc, value) => <tr>
        <td>{ desc }</td>
        <td>{ value }</td>
      </tr>;

  // ...and a helper to make a slider
  let slider = (desc, name, min, max) => {
    // Annoying: set a class on the <td> since CSS doesn't allow an "AND" combinator,
    // so we use a descendant combinator instead
    let cls = (name === 'color_temp_k' ? 'color-temp-slider' : '');
    sliders.push(<tr>
      <td><span>{ desc }:</span></td>
      <td className={ cls }>
        <Slider name={ name } value={ device[name] } min={ min } max={ max }
            style={{ width: 160 }} />
      </td></tr>);
  }

  if (device['address'][1] === 'single' || device['address'][1] === 'zwave') {
    let ATXLEDModel = UPC_TABLE[device['upc_code']];
    device['model_id'] = ATXLEDModel || device['model'];

    // Handle fade rates, which are handled differently for ATX-LED lights
    let fadeAttrs = null;
    if (ATXLEDModel) {
      if (device.is_button)
        fadeAttrs = [['On Time', 'fade_up', BUTTON_ON_TIME_ITEMS, 'seconds'],
          ['Keep Alive Time', 'fade_down', FADE_TIMES, 'seconds']];
      else
        fadeAttrs = [['Fade Up', 'fade_up', FADE_TIMES, 'seconds'],
          ['Fade Down', 'fade_down', FADE_TIMES, 'seconds']];
    } else
      fadeAttrs = [['Fade Time', 'fade_up', FADE_TIMES, 'seconds'],
        ['Fade Rate', 'fade_down', FADE_RATES, 'steps / second']];
    for (let [desc, name, opts, unit] of fadeAttrs)
      sliders.push(row(desc + ':', <span>
          <Dropdown name={ name } enumerate={ true }
              options={ opts } value={ device[name] } />
          &nbsp; { unit }</span>));

    // Set up sliders for configuration
    slider('Min Level', 'min_level', 0, 254);
    slider('Max Level', 'max_level', 0, 254);
    if (!ATXLEDModel) {
      slider('Power On Level', 'power_on_level', 0, 254);
      slider('Fail Level', 'fail_level', 0, 254);
    } else if (isDR2F32(device))
      slider('Fail Level', 'fail_level', 0, 254);
    else if (isDR1PIR(device)) {
      sliders.push(row('On timeout (seconds):',
        <AutoNumber name='on_timeout' label='Always On' autoValue={ 255*30 }
          defaultValue={ 2 } value={ device.on_timeout * 30 } cast={ (v) => v / 30 }
          min={ 0 } max={ 7200 } step={ 30 } style={{ width: 60 }}/>));

      slider('Vacancy sensitivity', 'vac_sens', 0, 255);
      slider('Occupancy sensitivity', 'occ_sens', 0, 255);
      slider('Daylight Harvesting', 'ambient_sens', 0, 255);
      slider('Vacancy fade out (seconds)', 'vac_fade_out', 0, 255);
      slider('Nightlight level', 'night_bright', 0, 255);
      slider('Nightlight threshold', 'night_thresh', 0, 255);

      sliders.push(row('Nightlight Mode:',
          <Dropdown name='night_mode' options={ NIGHTLIGHT_MODE_OPTIONS }
            value={ device.night_mode } />));

      sliders.push(row('Vacancy Mode:',
          <Dropdown name='vac_mode' options={ VACANCY_MODE_OPTIONS }
            value={ device.vac_mode } />));

      sliders.push(row('Driver Mode:',
          <Dropdown name='driver_mode' options={ DR1PIR_DRIVER_OPTIONS }
            value={ device.driver_mode } />));
    }

    // Add color temperature slider
    if (device['has_color_temp']) {
      let [colorMin, colorMax] = [device['color_k_min'] || 2700,
        device['color_k_max'] || 5000].sort();
      slider('Color Temp', 'color_temp_k', colorMin, colorMax);
    }

    // Add color temperature range values
    if (device['has_color_temp']) {
      for (let [desc, value] of [['Temp', 'k'], ['DALI', 'cct']]) {
        let rangeSliders = [];
        for (let side of ['min', 'max']) {
          let attr = `color_${value}_${side}`;
          let [min, max] = COLOR_RANGE_ATTRS[attr];
          rangeSliders.push(<TextNumber name={attr} value={ device[attr] }
            min={ min } max={ max } style={{ width: 70 }}/>);
        }
        sliders.push(row(`${desc} range:`, rangeSliders));
      }
      sliders.push(row('CCT fade time (seconds)', 
          <TextNumber name='cct_fade_time' value={ device.cct_fade_time * 10 }
            cast={ (v) => (v / 10) } min={ 0 } max={ 2550 } step={ 10 }/>));
    }

    // Add RGB color values
    let colorRGB = null;
    if (device.has_color_rgb) {
      const COLOR_CHANNELS = 'RGBWAF';
      colorRGB = row('Color (0-254):', <div className='flex-row flex-wrap'>
          <NestedState indices={ ['color_rgbw'] }>
            { range(device.rgb_n_channels).map((n) =>
              <div>
                { COLOR_CHANNELS[n] }
                <br/>
                <TextNumber name={ n } value={ device.color_rgbw[n] }
                  min={ 0 } max={ 254 } style={{ width: 50 }} />
              </div>) }
          </NestedState>
          <div>
            Gamma
            <br/>
            <TextFloat name='rgb_power_scale' value={ device.rgb_power_scale }
              min={ 0 } max={ 3 } style={{ width: 50 }} />
          </div>
        </div>);
    }

    // ATX-LED lights have special meaning for power_on_level
    if (ATXLEDModel) {
      let manual = Math.max(3, device.power_on_level);
      let manualLevel = <TextNumber name='power_on_level' value={ manual }
            min={ 3 } max={ 254 } style={{ width: 40 }}/>;
      let opts = [
        [1, 'Off'],
        [2, 'Last'],
        [manual, 'Manual:', manualLevel]
      ];
      sliders.push(row('Power On Level:',
        <Radio name='power_on_level' horizontal={ true } options={ opts }
              value={ device.power_on_level } />));
    }

    // For DR2F32 and DR1PIR, show the split 2nd address
    if (isDR2F32(device) || isDR1PIR(device)) {
      sliders.push(row('Split 2nd address:',
          <TextNumber name='split_addr' value={ device.split_addr }
              min={ 0 } max={ 255 } style={{ width: 60 }}/>));
    }

    // Add DR2F-specific values
    if (isDR2F(device)) {
      let driverOpts = isDR2F16(device) ? DR2F16_DRIVER_OPTIONS : DR2F32_DRIVER_OPTIONS;
      sliders.push(row('Driver Mode:',
          <Dropdown name='driver_mode' options={ driverOpts } value={ device.driver_mode } />));
    }

    // Add n-way directly after driver mode
    if (N_WAY[device['model_id']]) {
      sliders.push(row('N-Way Setting:',
          <Dropdown name='n_way' enumerate={ true }
              options={ isDR2F32(device) ? N_WAY_OPTIONS_DR2F32
                : isDR2F16(device) ? N_WAY_OPTIONS_DR2F16
                : isDR1PIR(device) ? N_WAY_OPTIONS_DR1_PIR
                : N_WAY_OPTIONS }
              value={ device['n_way'] } />));
    }

    // Add more DR2F-specific values after n-way
    if (isDR2F(device)) {
      sliders.push(row('Slider Position:',
          <Dropdown name='slider_pos' options={ SLIDER_POS_OPTS }
              value={ device.slider_pos } cast={ (v) => v === 'true' } />));

      let sides = ['left', 'right']
      if (device.driver_mode === 2 || device.driver_mode === 6)
        sides = ['left'];
      for (let side of sides) {
        let attr = `voltage_${side}`;
        sliders.push(row(`Voltage (${side}):`, <span>
              <AutoNumber name={ attr } autoValue={ 56 } defaultValue={ 48 }
                  value={ device[attr] } min={ 8 } max={ 55 } style={{ width: 60 }} />
              V</span>));
      }

      if (isDR2F32(device)) {
        sliders.push(row('Dim to warm:', <span>
              <TextFloat name='dim_to_warm' defaultValue={ 1.5 }
                  value={ device.dim_to_warm } min={ 0 } max={ 4.5 }
                  style={{ width: 60 }} />%</span>));

        let color_raw = [];
        for (let [side, def] of [['left', 5000], ['right', 2700]]) {
          let attr = `color_k_${side}`;
          color_raw.push(<span>{ `${side}: ` }
                <TextNumber name={ attr } defaultValue={ def } value={ device[attr] }
                    min={ 2300 } max={ 5615 } style={{ width: 60 }} /></span>);
        }

        // Add l/r swap button
        color_raw.push(<div><Button value='Swap left/right' 
            bind={{ onClick: (ctx) => (e) => {
              let [left, right] = [device.color_k_left, device.color_k_right];
              ctx.update({color_k_left: right, color_k_right: left}, null);
          }}} /></div>);
        sliders.push(row('Color (raw):', color_raw));
      }

      /*
       * XXX disabled for now
      for (let side of ['left', 'right']) {
        let attr = `current_${side}`;
        sliders.push(<tr>
            <td>{`Max Current (${side}):`}</td>
            <td>
              <AutoNumber name={ attr } autoValue={ 0 } defaultValue={ 200 }
                  value={ device[attr] } min={ 20 } max={ 660 } style={{ width: 60 }} />
              mA
            </td>
          </tr>);
      }
      */

      if (isDR2F32(device) && device.fw_version && device.fw_version >= 54) {
        if (offsetState === null) {
          offsetState = {height_left: device.height_left,
            height_right: device.height_right};
          setOffsetState((s) => offsetState);
        }
        sliders.push(<BasicState setState={ setOffsetState }>
          { row('# LEDs (left):', <Input type='number' cast={ (v) => v|0 }
            name='height_left' value={ offsetState.height_left } />) }
          { row('# LEDs (right):', <Input type='number' cast={ (v) => v|0 }
            name='height_right' value={ offsetState.height_right } />) }
        </BasicState>);
        // Have to put the submit outside the BasicState so it can update the
        // parent context
        sliders.push(row('', <Button value='Save and recal' 
            bind={{ onClick: (ctx) => (e) => {
              let idealLeft = device.thresh_v_left / (offsetState.height_left ? offsetState.height_left : -1);
              let idealRight = device.thresh_v_right / (offsetState.height_right ? offsetState.height_right : -1);
              let ol = (idealLeft - 2500) / 10;
              let or = (idealRight - 2500) / 10;
              if (ol < 0)
                ol += 256;
              if (or < 0)
                or += 256;

              postJSON(`/dali/api/set-dali-voltage-offsets/${device.channel}_s_${device.short_addr}`,
                {offset_left: ol | 0, offset_right: or | 0});
            }}}/>));
      }
    }

    // Set up status info
    let statusAttrs = [
      ['Channel', (dev) => dev['channel'] + 1, false],
      ['Short address', 'short_addr', false],
      ['Model ID', 'model_id', false],
      ['UPC', 'upc_code', false],
      ['Serial #', 'serial_nb', true],
      ['FW Version', 'fw_version', false],
      ['HW Version', 'hw_version', false],
      ['Phy Min Level', 'phy_min_level', false],
    ];
    statusTable = getStatusTable(device, statusAttrs);
  }

  let id = 'device_' + device.short_addr;
  let detail = <div className='detail'>
      <div className='columns'>
        <div style={{ width: '360px' }}>
          <h4>Config</h4> 
          <table className='small-spacey'>
            { row('Edit name:',
                <Text name='dev_name' value={ device['dev_name'] } />) }

            { row('Public name:',
                <Text name='hue_name' value={ device['hue_name'] } />) }
            { row('Visible to cloud:',
                <Checkbox name='hue_hidden' value={ !device['hue_hidden'] }
                    cast={ (v) => !v }/>) }

            { row('Groups:',
                <CheckboxSet name='groups' className='checkbox' count={16} groupBy={8}
                    values={ device['groups'] || [] } />) }

            { sliders }

            { colorRGB }

            { isDR2F32(device) && device.n_way === 6 ? row( 'Light On Time',
                <span><Slider name='fan_run_time'
                  value={ device['fan_run_time'] } min={0} max={254}/>
                minutes</span>)
              : null }

            { isInFanMode(device) ? [
                row('Fan Speed:', <Slider name='fan_speed'
                    value={ device['fan_speed'] } min={50} max={254}/>),
                row('Fan Idle Speed:', <Slider name='fan_idle_speed'
                    value={ device['fan_idle_speed'] } min={0} max={254}/>),
                // Delay time is seconds * 4
                row('Fan Delay Time:', <span><Slider name='fan_delay_time'
                    value={ device['fan_delay_time'] * 4 } cast={ (v) => v / 4 }
                    min={0} max={1020} step={4}/> seconds</span>),
                row('Fan Run Time:', <span><Slider name='fan_run_time'
                    value={ device['fan_run_time'] } min={0} max={254}/>
                  minutes</span>),
              ] : null }

          </table>
        </div>

        <div>
          <h4>Status</h4>
          { statusTable }
        </div>
      </div>
    </div>;

  return BaseDevice(id, device, detail, null);
}

function Devices(props) {
  let opts = {
    socketURL: '/ws/dali/devices',
    emptyMessage: 'No DALI devices found.',
    showFilter: true,
  };
  return DeviceSet(opts, initialDevices, Device);
}
