import os
import subprocess
import sys

import jinja2

def read_file(use_head, path):
    if use_head:
        # Resolve symlinks, then make path relative to the repo root again
        path = os.path.relpath(os.path.realpath(path), start='.')
        return subprocess.run(['git', 'show', 'HEAD:' + path], check=True, stdout=subprocess.PIPE).stdout
    else:
        with open(path, 'rb') as in_f:
            return in_f.read()

def build(files=None, output_dir=None, use_head=False):
    base = '%s/..' % sys.path[0]
    input_dir = '%s/zpds/js' % base
    if not output_dir:
        output_dir = '%s/zpds/static/js' % base

    # Input files. Order sort of matters, in that dependencies come first
    if not files:
        files = ['common', 'deviceset', 'devices', 'other-devices', 'broadcast',
                'schedule', 'scenes', 'triggers', 'groups', 'logs', 'advanced',
                'hw-test', 'zwave', 'topology', 'basic']
    merged_file = '%s/.merged.js' % input_dir

    extra_files = ['react/%s.production.min.js' % f for f in ['react', 'react-dom']]

    if use_head:
        print('Compiling from HEAD...')
    else:
        print('Compiling from working copy...')

    # Merge input files
    with open(merged_file, 'wb') as out_f:
        for f in files:
            out_f.write(read_file(use_head, '%s/%s.jsx' % (input_dir, f)))

    # Compile merged code, and prepend react code
    with open('%s/.mini.js' % output_dir, 'wb') as out_f:
        for f in extra_files:
            out_f.write(read_file(use_head, '%s/%s' % (input_dir, f)))
        compiled = subprocess.check_output(['%s/zpds/swc-cli' % base, merged_file])
        out_f.write(compiled)

    # Compile CSS
    css = read_file(use_head, '%s/common/css/base.jinja.css' % base)
    template = jinja2.Template(css.decode('utf-8'))
    with open('%s/common/css/.base.css' % base, 'wt') as out_f:
        out_f.write(template.render())

if __name__ == '__main__':
    build(use_head='-g' in sys.argv)
