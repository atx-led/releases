#!/usr/bin/env python3
import argparse
import collections
import io
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

import flask
import jinja2
from wss import websocket_server

import cloud
import config
import dali
import dali_cmds
import db
import hw_test
import schedule
import util
import wifi
from util import json_route, json_stream_route
from dali import ensure_scanned

# fake_dali isn't included in the deployment
try:
    import fake_dali
except Exception:
    pass

util.init_logging()
LOG = util.get_logger('serve')

wsr = websocket_server.WebSocketRouter('/dali')
app = flask.Blueprint('serve', __name__, static_folder=None)
MAIN_APP = None
STATIC_URL = '/dali/static'

# Set up options based on dev/prod
if os.path.exists('ramdisk'):
    RAMDISK = True
    STATIC_DIR = './ramdisk/static'
    TEMPLATE_DIR = './ramdisk/templates'
    FW_TEST_DIR = './ramdisk/fw_tests'
    USER_DATA_PATH = './user-data'
    CONFIG_PATH = '%s/zpds-config.json' % USER_DATA_PATH
    DATABASE_URL = 'sqlite:///user-data/zpds.db'
    with open('./releases/tag', 'r') as f:
        ZPDS_VERSION = f.read()
    # cut off some hash characters
    ZPDS_VERSION = ZPDS_VERSION.strip()[:12]
else:
    RAMDISK = False
    STATIC_DIR = './static'
    TEMPLATE_DIR = './templates'
    FW_TEST_DIR = './fw_tests'
    DATABASE_URL = 'sqlite:///zpds.db'
    USER_DATA_PATH = '/home/pi/atxled/user-data'
    CONFIG_PATH = './zpds-config.json'
    ZPDS_VERSION = subprocess.check_output(['git', 'describe', '--always'])
    ZPDS_VERSION = 'dev-' + ZPDS_VERSION.decode('ascii').strip()

    # Set GPS cache info so we don't spam Murray's server during dev
    schedule.GPS_CACHE_INFO = {"latlng": [30.2623, -97.7465], "accuracy": "5000",
            "address": "208 Barton Springs Rd, Austin, TX 78704, USA",
            "sunrise": "12:29,-300", "sunset": "00:43"}
    schedule.GPS_CACHE_TIME = util.utcnow()

# Read user config, creating it if necessary
LOG.info('Trying to load config from %s...', CONFIG_PATH)
CONFIG = {}
if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, 'r') as f:
        CONFIG = json.load(f)
# Set the user config in the config module so the site-settings stuff can
# use it for defaults
config.CONFIG = CONFIG

# Read registration data
REGISTRATION_PATH = '%s/registration.json' % USER_DATA_PATH
if os.path.exists(REGISTRATION_PATH):
    with open(REGISTRATION_PATH, 'r') as f:
        REGISTRATION_DATA = json.load(f)
else:
    REGISTRATION_DATA = {}

# Load zwave module if enabled
USE_ZWAVE = CONFIG.get('enable-zwave', True)
if USE_ZWAVE:
    import zwave

def read_dir(dir, mode='rt'):
    result = {}
    for path in os.listdir(dir):
        full_path = '%s/%s' % (dir, path)
        if os.path.isdir(full_path):
            result[path] = read_dir(full_path, mode=mode)
        else:
            with open(full_path, mode) as f:
                result[path] = f.read()
    return result

# Read all of the HTML templates, and create a DictLoader with their
# contents. That way we can be sure to not access any source code after
# startup. We don't have many templates so this should be fine.
def read_templates():
    MAIN_APP.jinja_loader = jinja2.DictLoader(read_dir(TEMPLATE_DIR))
    MAIN_APP.jinja_options = {'cache_size': 0}

# Also read all the static files and serve them manually, because Flask is
# acting really dumb and not serving them properly
def read_static_files():
    global STATIC_FILES
    STATIC_FILES = read_dir(STATIC_DIR, mode='rb')

def reload_static_data():
    read_templates()
    read_static_files()

def reload_db_info():
    dali.DUMB_DB.reset_all_info()
    dali.DUMB_DB.init_from_db()
    schedule.reset_all_info()
    config.update_site_settings()

PAGES = [
    ['basic', '/dali/basic', 'Basic View'],
    ['devices', '/dali/devices', 'DALI Devices'],
    ['cloud', '/dali/cloud/', 'Cloud'],
    ['other-devices', '/dali/other-devices', 'Other DALI'],
    ['groups', '/dali/groups', 'Groups'],
    ['scenes', '/dali/scenes', 'Scenes'],
    ['schedule', '/dali/schedule/', 'Schedule'],
    ['triggers', '/dali/triggers', 'Macros'],
    ['virtual-groups', '/dali/virtual-groups', 'DMX Groups'],
    ['hue', '/dali/hue', 'Hue'],
    ['admin', '/dali/admin', 'Admin'],
    ['power', '/dali/power', 'Power Management'],
    ['support', '/dali/support', 'Support'],
    ['wifi', '/dali/wifi/', 'WiFi Setup'],
    ['dali-log', '/dali/dali-log', 'DALI Log'],
    ['advanced', '/dali/advanced', 'Advanced'],
]
if USE_ZWAVE:
    PAGES.extend([
        ['zwave', '/dali/zwave/', 'ZWave'],
        ['zwave-log', '/dali/zwave/log', 'ZWave Logs'],
    ])
PAGE_URLS = {name: url for [name, url, _] in PAGES}

@app.app_context_processor
def add_template_globals():
    builtins = __builtins__
    # XXX why is this sometimes not true? It happens during tests...
    if not isinstance(builtins, dict):
        builtins = __builtins__.__dict__
    builtins = {k: v for k, v in builtins.items() if callable(v)}
    return {'pages': PAGES, 'get_device_name': dali.get_device_name,
            'static_url': STATIC_URL, 'site_settings': config.SITE_SETTINGS,
            'get_device_nice_addr': dali.get_device_nice_addr, **builtins}

# Special method for logging requests, mainly to downgrade spammy paths that
# the Hue app requests all the time to debug level logging
def log_request(response):
    SPAM_PATHS = [
        ('GET', '/state'),
        ('GET', '/dali/api/server-status'),
    ]
    level = logging.INFO
    for method, path in SPAM_PATHS:
        if flask.request.method == method and flask.request.path == path:
            level = logging.DEBUG

    query = flask.request.query_string
    query = '?%s' % query.decode('utf-8') if query else ''
    LOG.log(level, '"%s %s%s" %s', flask.request.method, flask.request.path,
            query, response.status_code)
    return response

################################################################################
## Hue protocol emulation ######################################################
################################################################################

def convert_state_to_hue_protocol(state):
    return {
        'name': dali.get_device_hue_name(state),
        'light_nr': dali.get_device_nice_addr(state),
        'on': state.get('dev_on', (state['level'] > 0)),
        'ct': int(1000000 / max(1, state.get('color_temp_k', 4000))),
        'bri': state['level'],
    }

def get_group_hue_state(channel, group_id):
    group = dali.DUMB_DB.get_group_state(channel, group_id)
    return convert_state_to_hue_protocol(group)

@json_route(app, '/state', methods=['PUT'])
def hue_set_state():
    ensure_scanned()
    query = flask.request.get_json()

    with dali.get_dali_lock(None):
        for address, data in query.items():
            LOG.debug('set hue state(%s): %s', address, data)

            new_state = {}

            # Name
            if 'name' in data:
                new_state['hue_name'] = data['name']
            # On/off
            if 'on' in data:
                new_state['dev_on'] = data['on']
            # Brightness
            if 'bri' in data:
                new_state['level'] = int(data['bri'])
            # Color temp
            if 'ct' in data:
                color_temp_mired = data['ct']
                color_temp_k = 1000000 / max(1, color_temp_mired)
                new_state['color_temp_k'] = color_temp_k

            # Update state. Always send a bus update if we're only updating the
            # level, even if there's not a device at that address (and we'll
            # rescan it below)
            force_send = all(k in {'name', 'bri'} for k in new_state.keys())
            light_data = dali.DUMB_DB.set_dali_light_state(address,
                    new_state, force_send=force_send)
            # If there was no device at this address, flag the address to rescan it
            if light_data is None:
                [channel, addr_type, addr_id] = dali.parse_device_nice_addr(address)
                if addr_type == 'single':
                    dali.DUMB_DB.blacklist_address(channel, addr_id)

    return {'ok': True}

@json_route(app, '/state', methods=['GET'])
def hue_get_state():
    ensure_scanned()

    qs = util.get_query_string()
    if 'light' in qs:
        address = qs['light']
        [channel, addr_type, addr_id] = dali.parse_device_nice_addr(address)
        # Check for group address
        if addr_type == 'group':
            return get_group_hue_state(channel, addr_id)

        for light in dali.DUMB_DB.get_matching_lights(address):
            if not light.get('hue_hidden'):
                state = convert_state_to_hue_protocol(light)
                LOG.debug('get hue state: %s %s', address, state)
                return state
        raise util.APIError('Unknown light %s' % address, code=404)
    else:
        state = {}
        # Add normal lights
        for light in dali.DUMB_DB.get_all_lights_state():
            if not light.get('hue_hidden'):
                light = convert_state_to_hue_protocol(light)
                state[light['light_nr']] = light
        # Add named groups
        for [[channel, group_id], [name, hidden]] in dali.DUMB_DB.group_info.items():
            if name and not hidden:
                group = get_group_hue_state(channel, group_id)
                state[group['light_nr']] = group

        return state

@json_route(app, '/detect', methods=['GET'])
def hue_discover():
    ensure_scanned()

    # Add normal lights
    lights = []
    for light in dali.DUMB_DB.get_all_lights_state():
        if light.get('hue_hidden'):
            continue
        lights.append({
            'light_nr': dali.get_device_nice_addr(light),
            "name": dali.get_device_hue_name(light),
        })

    # Add named groups
    for [[channel, group_id], [name, hidden]] in dali.DUMB_DB.group_info.items():
        if name and not hidden:
            group = dali.DUMB_DB.get_group_state(channel, group_id)
            lights.append({
                'light_nr': dali.get_device_nice_addr(group),
                "name": dali.get_device_hue_name(group),
            })

    resp = {
        "protocol": "native_multi",
        "light_ids": lights,
        "modelid": "ATX-LED",
        "type": "ATX-LED",
        "mac": util.get_mac_address(),
        "version": "0.02",
    }
    LOG.info('DISCOVER: %s', resp)
    return resp

################################################################################
## DALI API Stuff ##############################################################
################################################################################

def dali_get_state():
    ensure_scanned()
    data = {dali.get_device_nice_addr(dev): dev
            for dev in dali.DUMB_DB.get_devices_state()}
    return data
json_route(app, '/dali/api/devices', methods=['GET'])(dali_get_state)

@json_route(app, '/dali/api/devices/<string:address>', methods=['GET'])
def dali_get_device_state(address):
    ensure_scanned()
    device = dali.DUMB_DB.get_device_state(address)
    return {'ok': True, 'data': device}

def dali_get_group_state():
    ensure_scanned()
    data = {dali.get_device_nice_addr(group): group
            for group in dali.DUMB_DB.get_all_groups_state(discard_empty=False)}
    return data
json_route(app, '/dali/api/groups', methods=['GET'])(dali_get_group_state)

def dali_get_passive_device_state():
    data = {dali.get_device_nice_addr(pd): pd
            for pd in dali.DUMB_DB.get_passive_devices_state()}
    return data
json_route(app, '/dali/api/passive-devices', methods=['GET'])(
    dali_get_passive_device_state)

def dali_get_button_device_state():
    data = {dali.get_device_nice_addr(pd): pd
            for pd in dali.DUMB_DB.get_button_devices_state()}
    return data
json_route(app, '/dali/api/button-devices', methods=['GET'])(
    dali_get_button_device_state)

def dali_get_virtual_device_state():
    data = {dali.get_device_nice_addr(vd): vd
            for vd in dali.DUMB_DB.get_virtual_devices_state()}
    return data
json_route(app, '/dali/api/virtual-devices', methods=['GET'])(
    dali_get_virtual_device_state)

def dali_get_virtual_n_way_state():
    ensure_scanned()
    data = {group['id']: group
            for group in dali.DUMB_DB.get_virtual_n_way_groups()}
    return data
json_route(app, '/dali/api/virtual-n-way', methods=['GET'])(dali_get_virtual_n_way_state)

def dali_get_broadcast_state():
    ensure_scanned()
    return {'all': dali.DUMB_DB.get_broadcast_state()}
json_route(app, '/dali/api/broadcast', methods=['GET'])(dali_get_broadcast_state)

@json_route(app, '/dali/api/addresses', methods=['GET'])
def dali_get_addresses():
    ensure_scanned()
    return dali.DUMB_DB.get_all_addresses()

@json_route(app, '/dali/api/devices/<string:address>', methods=['POST'])
def dali_set_state_nice(address):
    ensure_scanned()
    data = flask.request.get_json()
    light_data = dali.DUMB_DB.set_dali_light_state(address, data)
    if light_data is None:
        return {'ok': False}
    return {'ok': True, 'data': light_data}

PASSIVE_DEVICE_SCHEMA = util.schema_obj({
    'dev_name': util.JSONSCHEMA_STR_OR_NULL,
})

@json_route(app, '/dali/api/passive-devices/<string:address>', methods=['POST'],
        input_schema=PASSIVE_DEVICE_SCHEMA)
def dali_set_passive_device(data, address):
    (channel, addr_type, addr_id) = dali.parse_device_nice_addr(address)
    assert addr_type == 'passive'
    device = dali.DUMB_DB.set_dali_light_state(address, data)
    return {'ok': True, 'device': device}

# Schema validation handled in set_dali_light_state
@json_route(app, '/dali/api/button-devices/<string:address>', methods=['POST'])
def dali_set_button_device(address):
    (channel, addr_type, addr_id) = dali.parse_device_nice_addr(address)
    assert addr_type == 'single'
    data = flask.request.get_json()
    device = dali.DUMB_DB.set_dali_light_state(address, data)
    return {'ok': True, 'device': device}

VIRTUAL_DEVICE_SCHEMA = util.schema_obj({
    'dev_name': util.JSONSCHEMA_STR_OR_NULL,
    'groups': {
        'type': 'array',
        'items': {'type': 'integer', 'minimum': 0, 'maximum': 15},
    },
    'dev_on': {'type': 'boolean'},
    'level': {'type': 'integer', 'minimum': 0, 'maximum': 255},
    'fail_level': {'type': 'integer', 'minimum': 1, 'maximum': 63},
})

@json_route(app, '/dali/api/virtual-devices/<string:address>', methods=['POST'],
        input_schema=VIRTUAL_DEVICE_SCHEMA)
def dali_set_virtual_device(data, address):
    (channel, addr_type, addr_id) = dali.parse_device_nice_addr(address)
    assert addr_type == 'virtual-device'
    device = dali.DUMB_DB.set_virtual_device(channel, addr_id, data)
    return {'ok': True, 'device': device}

@json_route(app, '/dali/api/virtual-devices/<string:address>', methods=['DELETE'])
def dali_delete_virtual_device(address):
    (channel, addr_type, addr_id) = dali.parse_device_nice_addr(address)
    assert addr_type == 'virtual-device'
    dali.DUMB_DB.delete_virtual_device(channel, addr_id)
    return {'ok': True}

@json_route(app, '/dali/api/virtual-groups/<int:channel>/<int:group_id>', methods=['POST'])
def dali_set_virtual_group(channel, group_id):
    data = flask.request.get_json()
    assert 0 <= channel < dali.MAX_CHANNELS
    assert 0 <= group_id < 16
    name = data.get('name')
    devices = data['devices']
    dali.DUMB_DB.set_virtual_group(channel, group_id, name, devices)
    return {'ok': True, 'group': devices}

VIRTUAL_N_WAY_SCHEMA = util.schema_obj({
    'id': util.JSONSCHEMA_STR_OR_NULL,
    'channel': {'type': 'integer', 'minimum': 0, 'maximum': dali.MAX_CHANNELS},
    'name': util.JSONSCHEMA_STR_OR_NULL,
    'device_ids': {
        'type': 'array',
        'items': {'type': 'integer', 'minimum': 0, 'maximum': 63},
    },
    'device_names': {
        'type': 'array',
        'items': {'type': 'string'},
    },
})

@json_route(app, '/dali/api/update-virtual-n-way', methods=['POST'],
        input_schema=VIRTUAL_N_WAY_SCHEMA)
def dali_update_virtual_n_way(data):
    dali.DUMB_DB.update_virtual_n_way(data['channel'], data['device_ids'])
    return {'ok': True}

# Scenes

@json_route(app, '/dali/api/scenes', methods=['GET'])
def dali_get_scenes():
    return dali.DUMB_DB.get_scenes()

@json_route(app, '/dali/api/scenes/<int:scene_id>', methods=['POST'])
def dali_set_scene(scene_id):
    assert 0 <= scene_id < dali.MAX_SCENES
    data = flask.request.get_json()
    name = data.pop('name', None)
    state = data.pop('state', None)
    set_visible = False
    visible = False
    if 'visible' in data:
        set_visible = True
        visible = data.pop('visible')
    scene = dali.DUMB_DB.set_scene(scene_id, name, state, set_visible=set_visible,
            visible=visible)
    return {'ok': True, 'scene': scene}

@json_route(app, '/dali/api/scenes/<int:scene_id>/capture', methods=['POST'])
def dali_capture_scene(scene_id):
    assert 0 <= scene_id < dali.MAX_SCENES
    scene = dali.DUMB_DB.capture_scene(scene_id)
    return {'ok': True, 'scene': scene}

@json_route(app, '/dali/api/scenes/capture', methods=['POST'])
def dali_capture_next_scene():
    scenes = set(dali.DUMB_DB.get_scenes().keys())
    for scene_id in range(dali.MAX_SCENES):
        if scene_id not in scenes:
            scene = dali.DUMB_DB.capture_scene(scene_id)
            return {'ok': True, 'scene': scene}
    raise util.APIError('No available scenes')

@json_stream_route(app, '/dali/api/scenes/rescan', methods=['POST'])
def dali_rescan_scenes():
    for [i, n] in dali.DUMB_DB.read_scenes():
        yield {'done': False, 'progress': i / (n or 1),
                'message': '%s/%s devices scanned' % (i, n)}
    yield {'done': True, 'message': 'Scenes rescanned.'}

@json_route(app, '/dali/api/scenes/<int:scene_id>/trigger', methods=['POST'])
def dali_trigger_scene(scene_id):
    assert 0 <= scene_id < dali.MAX_SCENES
    dali.DUMB_DB.trigger_scene(scene_id)
    return {'ok': True}

@json_route(app, '/dali/api/scenes/<int:scene_id>', methods=['DELETE'])
def dali_delete_scene(scene_id):
    assert 0 <= scene_id < dali.MAX_SCENES
    dali.DUMB_DB.delete_scene(scene_id)
    return {'ok': True}

# Triggers

@app.route('/dali/triggers')
def get_triggers_page():
    return flask.render_template('schedule.html', page='triggers')

# Provisioning

@json_route(app, '/dali/api/assign-addresses', methods=['POST'])
def assign_dali_addresses():
    quick = 'quick' in util.get_query_string()
    (new, total) = dali.DUMB_DB.assign_addresses(quick=quick)
    message = '%s addresses assigned, %s total.' % (new, total)
    return {'ok': True, 'message': message}

@json_stream_route(app, '/dali/api/assign-addresses-stream', methods=['POST'])
def assign_dali_addresses_stream():
    quick = 'quick' in util.get_query_string()
    randomize = 'nonrandom' not in util.get_query_string()
    new = total = 0
    addrs = None
    for item in dali.DUMB_DB.assign_addresses_gen(quick=quick, randomize=randomize):
        if isinstance(item, str):
            yield {'error': item}
        else:
            [progress, new, total, addrs] = item
            latest = ' (latest: %s)' % ', '.join(map(str, addrs[-4:])) if addrs else ''
            message = '%s assigned, %s total%s' % (new, total, latest)
            yield {'done': False, 'progress': progress, 'message': message}
    latest = ' Last addresses: %s' % ', '.join(map(str, addrs[-4:])) if addrs else ''
    message = '%s addresses assigned, %s total.%s' % (new, total, latest)
    yield {'done': True, 'message': message}

REASSIGN_SCHEMA = util.schema_obj({
    'channel': {'type': 'integer', 'minimum': 0, 'maximum': dali.MAX_CHANNELS},
    'old_addr': {'type': 'integer', 'minimum': 0, 'maximum': 63},
    'new_addr': {'oneOf': [
        {'type': 'integer', 'minimum': 0, 'maximum': 63},
        {'type': 'integer', 'minimum': 255, 'maximum': 255},
    ]},
})

@json_route(app, '/dali/api/reassign-address', methods=['POST'],
    input_schema=REASSIGN_SCHEMA)
def reassign_dali_address(data):
    dali.DUMB_DB.reassign_address(data['channel'], data['old_addr'],
            data['new_addr'])

    message = 'Address reassigned.'
    return {'ok': True, 'message': message}

@json_route(app, '/dali/api/rescan-addresses', methods=['POST'])
def rescan_addresses():
    quick = 'quick' in util.get_query_string()
    n_devices = ensure_scanned(rescan=True, quick=quick)
    if n_devices == -1:
        message = 'DALI bus fault'
    else:
        message = '%s devices found.' % n_devices
    return {'ok': True, 'message': message}

@json_route(app, '/dali/api/rescan-address/<int:channel>/<int:addr>',
        methods=['POST'])
def rescan_address(channel, addr):
    assert 0 <= channel < dali.MAX_CHANNELS
    assert 0 <= addr < 64
    dali.DUMB_DB.blacklist_address(channel, addr)
    return {'ok': True, 'message': 'Rescan in progress.'}

# Topology

@json_stream_route(app, '/dali/api/scan-topology', methods=['POST'])
def dali_scan_topology():
    for [complete, total] in dali.DUMB_DB.read_dr2g_topology_gen():
        message = '%s/%s lights scanned' % (complete, total)
        progress = 100 * complete / (total or 1)
        yield {'done': False, 'progress': progress, 'message': message}
    message = 'Done.'
    yield {'done': True, 'message': message, 'topology': dali.DUMB_DB.dr2g_topology}

@json_stream_route(app, '/dali/api/scan-load-topology', methods=['POST'])
def dali_scan_load_topology():
    for [complete, total] in dali.DUMB_DB.read_load_topology_gen():
        message = '%s/%s lights scanned' % (complete, total)
        progress = 100 * complete / (total or 1)
        yield {'done': False, 'progress': progress, 'message': message}
    message = 'Done.'
    yield {'done': True, 'message': message, 'topology': dali.DUMB_DB.load_topology}

@json_stream_route(app, '/dali/api/scan-pse-topology', methods=['POST'])
def dali_scan_pse_topology():
    for [complete, total] in dali.DUMB_DB.read_pse_topology_gen():
        message = '%s/%s lights scanned' % (complete, total)
        progress = 100 * complete / (total or 1)
        yield {'done': False, 'progress': progress, 'message': message}
    message = 'Done.'
    yield {'done': True, 'message': message, 'topology': dali.DUMB_DB.pse_topology}

# Utilities

VOLTAGE_OFFSETS_SCHEMA = util.schema_obj({
    'offset_left': {'type': 'number', 'minimum': 0, 'maximum': 255},
    'offset_right': {'type': 'number', 'minimum': 0, 'maximum': 255},
}, required=['offset_left', 'offset_right'])
@json_route(app, '/dali/api/set-dali-voltage-offsets/<string:address>',
        methods=['POST'], input_schema=VOLTAGE_OFFSETS_SCHEMA)
def set_dali_voltage_offsets(data, address):
    [channel, addr_type, addr_id] = dali.parse_device_nice_addr(address)
    assert addr_type == 'single'
    old_level = 0
    for light in dali.DUMB_DB.get_matching_lights(address):
        old_level = light.get('level', 0)
        break
    dali.DUMB_DB.set_dali_light_state(address, {'level': 0}, force_send=True)
    dali.DUMB_DB.set_dali_light_state(address, data)
    time.sleep(1)
    dali.DUMB_DB.set_dali_light_state(address, {'level': 128}, force_send=True)
    dali.DUMB_DB.delay_blacklist(channel, addr_id, True, set_level=old_level)
    return {'ok': True}

@json_route(app, '/dali/api/reset-light-levels', methods=['POST'])
def reset_light_levels():
    dali.DUMB_DB.reset_light_levels()
    return {'ok': True, 'message': 'Light levels reset.'}

@app.route('/dali/api/start-pulse-lights', methods=['POST'])
def start_pulse_lights():
    dali.PULSE_LIGHTS = True
    return flask.render_template('pulse.html')

@app.route('/dali/api/stop-pulse-lights', methods=['POST'])
def stop_pulse_lights():
    dali.PULSE_LIGHTS = False
    return util.redirect(flask.url_for('.get_admin_page'))

@json_route(app, '/dali/api/fix-unknown-driver-modes', methods=['POST'])
def fix_unknown_driver_modes():
    dali.DUMB_DB.fix_unknown_driver_modes()
    return {'ok': True, 'message': 'Driver modes fixed.'}

SEND_RAW_SCHEMA = util.schema_obj({
    'channel': {'type': 'integer', 'minimum': 0, 'maximum': dali.MAX_CHANNELS - 1},
    'commands': {
        'type': 'array',
        'items': {'type': 'string', 'pattern': r'^[0-9a-zA-Z]{1,6}$'},
    },
}, required=['commands'])
@json_route(app, '/dali/api/send-raw', methods=['POST'],
        input_schema=SEND_RAW_SCHEMA)
def send_raw(data):
    channel = data.get('channel')
    with dali.get_dali_lock(channel):
        responses = []
        for cmd in data['commands']:
            # Be sure there's a newline, but only one
            cmd = cmd.strip() + '\n'
            assert 2 <= len(cmd) <= 7
            send_twice = cmd[0] == 't' or cmd[1] == 't'
            responses.append(dali.DUMB_DB.send_cmd_raw(cmd, channel=channel))
            if send_twice:
                responses.append(dali.DUMB_DB.read_line_raw(channel=channel,
                        allow_blank=True))
    return {'ok': True, 'responses': responses}

@json_route(app, '/dali/api/power-status', methods=['POST'])
def get_power_status():
    dali.DUMB_DB.read_dali_power_status()
    return {'ok': True, 'data': dali.DUMB_DB.dali_power_status}

@json_route(app, '/dali/api/power-status-force', methods=['POST'])
def get_power_status_force():
    dali.DUMB_DB.read_dali_power_status(force=True)
    return {'ok': True, 'data': dali.DUMB_DB.dali_power_status}

@json_route(app, '/dali/api/get-n-channels', methods=['GET'])
def get_n_channels():
    dali.DUMB_DB.read_version(log=False)
    return {'ok': True, 'channels': dali.DUMB_DB.channels}

@json_route(app, '/dali/api/update-server', methods=['POST'])
def update_server():
    subprocess.check_call('sudo systemctl restart --no-block '
            'atx-led-updater.service', shell=True)
    return {'ok': True,
        'message': 'Server will now shutdown and update.'}

# This route shouldn't exists because dataplicity sucks
SETUP_DATAPLICITY_SCHEMA = util.schema_obj({
    'key': {'type': 'string', 'pattern': r'^[a-z0-9]+\.py$'},
}, required=['key'])
@json_route(app, '/dali/api/setup-dataplicity', methods=['POST'],
        input_schema=SETUP_DATAPLICITY_SCHEMA)
def setup_dataplicity(data):
    key = data.get('key').strip()
    assert re.match(r'^[a-z0-9]+\.py$', key)

    subprocess.check_call('sudo mkdir /var/log/supervisor', shell=True)

    # In theory this is pretty dumb (sticking user input into a shell command),
    # but [a-z0-9]+ isn't much attack surface
    cmd = 'curl -s https://www.dataplicity.com/%s | sudo python' % key
    LOG.info('Setting up dataplicity with command: %s', cmd)
    subprocess.check_call(cmd, shell=True)

    # Keep the dataplicity ID in the database so backups can see it
    with db.db_session() as session:
        session.upsert(db.SiteSettings, {}, dataplicity_key=key)

    return {'ok': True, 'message': 'Dataplicity enabled.'}

# This route also shouldn't exist, but it's better because it uninstalls
@json_route(app, '/dali/api/uninstall-dataplicity', methods=['POST'])
def uninstall_dataplicity():
    cmds = [
        'service supervisor stop',
        'apt-get purge supervisor',
        'rm -r /opt/dataplicity',
        'rm -r /etc/supervisor',
    ]
    for cmd in cmds:
        subprocess.check_call('sudo ' + cmd, shell=True)
    return {'ok': True, 'message': 'Dataplicity uninstalled.'}

# Just return something saying the server is up. This is for cron-boom to check
# that the server is possibly running and can restart everything as a fail-safe
# in case something weird happens. Maybe we'll want to return more info someday...
@json_route(app, '/dali/api/server-status')
def get_server_status():
    return {'ok': True}

################################################################################
## DALI web interface ##########################################################
################################################################################

@app.route('/')
@app.route('/dali/basic')
def get_basic_page():
    return flask.render_template('basic.html', page='basic',
            initial_devices=dali_get_state(),
            initial_groups=dali_get_group_state(),
            initial_load_topology=dali.DUMB_DB.load_topology)

@app.route('/dali/')
@app.route('/dali')
@app.route('/dali/devices')
def get_devices_page():
    return flask.render_template('devices.html', page='devices',
            initial_devices=dali_get_state(),
            initial_broadcast=dali_get_broadcast_state())

@app.route('/dali/other-devices')
def get_other_devices_page():
    return flask.render_template('virtual-devices.html', page='other-devices',
            active_channels=dali.DUMB_DB.get_active_channels(),
            initial_devices=dali_get_state(),
            initial_pdevices=dali_get_passive_device_state(),
            initial_bdevices=dali_get_button_device_state(),
            initial_vdevices=dali_get_virtual_device_state())

@app.route('/dali/groups')
def get_groups_page():
    # HACK: run a full scan. This is so we register any address reassignments
    # from a virtual n-way update (which reloads this page when done)
    dali.DUMB_DB.full_scan()

    return flask.render_template('groups.html', page='groups',
            initial_devices=dali_get_state(),
            initial_groups=dali_get_group_state(),
            initial_virtual_n_way=dali_get_virtual_n_way_state())

@app.route('/dali/virtual-groups')
def get_virtual_groups_page():
    used_devices = collections.defaultdict(list)
    for d in dali.DUMB_DB.get_devices_state():
        used_devices[d['channel']].append(d['short_addr'])
    return flask.render_template('virtual-groups.html', page='virtual-groups',
            channel_groups=dali.DUMB_DB.get_virtual_groups(),
            used_devices=used_devices)

@app.route('/dali/scenes')
def get_scenes_page():
    return flask.render_template('scenes.html', page='scenes',
            initial_devices=dali_get_state())

@app.route('/dali/hue')
def get_hue_page():
    # Count visible lights
    total = visible = 0
    for light in dali.DUMB_DB.get_all_lights_state():
        total += 1
        if not light.get('hue_hidden'):
            visible += 1
    # Now kick off a scan
    try:
        url = 'http://localhost/scan'
        with urllib.request.urlopen(url) as f:
            data = f.read()
    except Exception:
        pass
    return flask.render_template('hue.html', page='hue',
            visible=visible, total=total)

@app.route('/dali/dali-log')
def get_dali_log_page():
    return flask.render_template('dali-log.html', page='dali-log')

SET_POWER_OPTS_SCHEMA = util.schema_obj({
    'current': {'type': 'integer'},
    'locked': {'type': 'integer'},
}, required=['current', 'locked'])
@json_route(app, '/dali/api/set-power-options', methods=['POST'],
        input_schema=SET_POWER_OPTS_SCHEMA)
def set_power_options(data):
    dali.DUMB_DB.set_dali_power_mode(data['current'], data['locked'])
    return {'ok': True}

@app.route('/dali/api/restore-ups-defaults', methods=['POST'])
def restore_ups_defaults():
    dali.DUMB_DB.restore_ups_defaults()
    return util.redirect(flask.url_for('.get_power_page'))

@app.route('/dali/topology')
def get_topology_page():
    return flask.render_template('topology.html', page='topology',
            initial_topology=dali.DUMB_DB.dr2g_topology,
            initial_load_topology=dali.DUMB_DB.load_topology,
            initial_pse_topology=dali.DUMB_DB.pse_topology)

@json_route(app, '/dali/api/get-backup-info', methods=['GET'])
def get_backup_info():
    mac = util.get_mac_address()
    url = 'https://atxled.com/me/up/retrieve-date.php?mac=%s' % mac
    with urllib.request.urlopen(url) as f:
        data = f.read()
    return {'ok': True, 'date': data.decode('ascii')}

@app.route('/dali/api/restore-backup', methods=['POST'])
def restore_backup():
    # List of allowed paths in backups
    # XXX keep this in sync with cron-boom... annoying!
    USER_DATA_PATH = '/home/pi/atxled/user-data'
    paths = ['%s/%s' % (USER_DATA_PATH, path)
            for path in ['config.json', 'zpds-config.json', 'zpds.db']]
    paths += ['/etc/wpa_supplicant/wpa_supplicant.conf']

    try:
        # First, do another (local) backup just in case
        date = str(util.now())
        date = re.sub('[^0-9]', '', date)[:14]
        backup_path = '/home/pi/atxled/old-backup-%s.zip' % date
        with zipfile.ZipFile(backup_path, mode='w',
                compression=zipfile.ZIP_DEFLATED) as backup_zip:
            for path in paths:
                status = "doesn't exist"
                if os.path.exists(path):
                    backup_zip.write(path)
                    with open(path, 'rb') as f:
                        status = '%s bytes' % len(f.read())
                logging.info('file %s: %s', path, status)

        # Retrieve backup from atxled server
        mac = util.get_mac_address()
        url = 'https://atxled.com/me/up/retrieve.php?mac=%s' % mac
        with urllib.request.urlopen(url) as f:
            data = f.read()

        # HACK: work around weird response from Murray's server
        data = re.sub(b'hello[.0-9a-f]*<br>\r\n', b'', data)

        new_path = '/home/pi/atxled/new-backup-%s.zip' % date
        with open(new_path, 'wb') as f:
            f.write(data)

        # Now actually restore the backup
        ps_out = subprocess.check_output(['sudo', 'unzip', '-o',
            '-d', '/', new_path])

        # ...and chown the user data part, since sudo unzip makes root
        # the owner
        ps_out = subprocess.check_output(['sudo', 'chown', '-R',
            'pi', '/home/pi/atxled/user-data'])

        # Restart so we can run any needed migrations and reload
        # all the DB info
        subprocess.check_call('sudo systemctl restart --no-block '
                'zpds.service', shell=True)
    except Exception as e:
        LOG.exception('error restoring backup')
        return flask.render_template('restore-backup.html', failed=True)

    return flask.render_template('restore-backup.html', failed=False)

@app.route('/dali/admin')
def get_admin_page():
    # This is dumb, dataplicity sucks
    dataplicity_installed = False
    try:
        ps_out = subprocess.check_output(['ps', '-ef'])
        dataplicity_installed = (b'dataplicity' in ps_out)
    except Exception:
        LOG.exception('error getting dataplicity status')

    status = dali.DUMB_DB.get_status()
    status['zpds_version'] = ZPDS_VERSION
    status['ip_address'] = util.get_ip_address()
    status['mac_address'] = util.get_mac_address()
    return flask.render_template('admin.html', page='admin', status=status,
            dataplicity_installed=dataplicity_installed,
            registration_data=REGISTRATION_DATA)

@app.route('/dali/power')
def get_power_page():
    status = dali.DUMB_DB.get_status()
    pse_status = dali.DUMB_DB.read_pse_status()
    return flask.render_template('power.html', page='power', status=status,
            pse_status=pse_status, failover_status=dali.FAILOVER_STATUS)

@app.route('/dali/support')
def get_support_page():
    return flask.render_template('support.html')

@app.route('/dali/power-status')
def get_power_status_page():
    status = dali.DUMB_DB.read_device_power_status()
    return flask.render_template('power-status.html', status=status)

@app.route('/dali/api/set-site-option', methods=['POST'])
def set_site_option():
    update_args = {}
    BOOL_ATTRS = ['send_power_on_level', 'manage_failover', 'enable_backups',
           'backup_notification_seen']

    redirect = flask.url_for('.get_admin_page')

    for k, v in flask.request.form.items():
        if k == 'redirect':
            if v in PAGE_URLS:
                redirect = PAGE_URLS[v]
        elif k in BOOL_ATTRS:
            v = (v == 'on')
            update_args[k] = v
        elif k == 'name':
            update_args['site_name'] = v
        elif k == 'failover_level':
            v = int(v)
            assert 0 <= int(v) < 255
            dali.FAILOVER_LEVEL = v
            update_args['failover_level'] = v
        elif k == 'heartbeat_interval':
            send = (flask.request.form.get('send_heartbeat') == 'on')
            v = int(v) if send else 0
            assert v == 0 or v >= 5
            update_args['heartbeat_interval'] = v
        elif k == 'send_heartbeat':
            pass
        else:
            assert False
    if update_args:
        logging.info('set_site_option: %s', update_args)
        config.update_site_settings(**update_args)
    return util.redirect(redirect)

@json_route(app, '/dali/api/clear-gps-cache', methods=['POST'])
def clear_gps_cache():
    schedule.get_gps_info(use_cache=False)
    return {'ok': True, 'message': 'GPS/timezone info updated.'}

@app.route('/dali/api/set-registration-info', methods=['POST'])
def set_registration_info():
    global REGISTRATION_DATA
    email = flask.request.form['email']
    email = email.strip()
    if not re.match(r'^[-\d\w+.!@$]{1,128}$', email):
        return 'Invalid email', 400
    REGISTRATION_DATA['email'] = email
    with open(REGISTRATION_PATH, 'w') as f:
        json.dump(REGISTRATION_DATA, f, indent=4)
    return util.redirect(flask.url_for('.get_admin_page'))

@app.route('/dali/advanced')
def get_advanced_page():
    missing_devices = {'%s_s_%s' % (c, a): v for [[c, a], v] in dali.DUMB_DB.missing_devices.items()}
    conflict_addresses = {'%s_s_%s' % (c, a): True for [c, a] in dali.DUMB_DB.conflict_addresses}
    [n_auto, n_fixed] = dali.DUMB_DB.query_unknown_driver_modes()
    return flask.render_template('advanced.html',
            initial_devices=dali_get_state(), missing_devices=missing_devices,
            conflict_addresses=conflict_addresses, n_auto=n_auto, n_fixed=n_fixed,
            current=dali.DUMB_DB.power_mode_current or 0,
            locked=dali.DUMB_DB.power_mode_locked or 0,
            current_opts=dali.POWER_MODE_CURRENT_DICT,
            locked_opts=dali.POWER_MODE_LOCKED_DICT,
            show_power_opts=dali.DUMB_DB.has_power_opts)

# THIS FUNCTION SHOULDN'T EXIST!
# But Flask was acting weird in the ramdisk mode, and not returning files
# that really looked like they were there... so here we are.
@app.route('%s/<path:path>' % STATIC_URL)
def get_static_file(path):
    base = STATIC_FILES
    for component in path.split('/'):
        if isinstance(base, dict) and component in base:
            base = base[component]
        else:
            flask.abort(404)
    if not isinstance(base, bytes):
        flask.abort(404)
    headers = {}
    if path.endswith('.css'):
        headers['Content-Type'] = 'text/css'
    elif path.endswith('.js'):
        headers['Content-Type'] = 'application/javascript'
    elif path.endswith('.svg'):
        headers['Content-Type'] = 'image/svg+xml'
    elif path.endswith('.png'):
        headers['Content-Type'] = 'image/png'
    return (base, headers)

################################################################################
## Websocket interface #########################################################
################################################################################

@wsr.route('/log')
def ws_dali_log(handler):
    with dali.DUMB_DB.listen_all_busses() as dali_msgs:
        for data in util.ws_stream_queue(dali_msgs, handler):
            handler.send_message(json.dumps(data))

@wsr.route('/devices', defaults={'type': 'device'})
@wsr.route('/groups', defaults={'type': 'group'})
@wsr.route('/broadcast', defaults={'type': 'all'})
def ws_dali_state_changes(handler, type=None):
    stream = {
        'device': dali.DUMB_DB.state_changes,
        'group':  dali.DUMB_DB.group_state_changes,
        'all':    dali.DUMB_DB.broadcast_state_changes,
    }[type]
    with stream.listen() as dali_msgs:
        for messages in util.ws_stream_queue(dali_msgs, handler):
            messages = [{'addr': addr, 'data': data} for addr, data in messages]
            handler.send_message(json.dumps(messages))

# Disabled for now
#@wsr.route('/api/events')
#def ws_trigger_events(handler):
#    with schedule.TRIGGER_LISTENER.listen() as events:
#        for data in util.ws_stream_queue(events, handler):
#            handler.send_message(json.dumps(data))

# This is just a centralized place to get the full Flask app with
# blueprints added. All the secondary setup for background threads/db/etc.
# is in create_app().
def get_full_app():
    main_app = flask.Flask(__name__, static_folder=None)
    main_app.register_blueprint(app, url_prefix='/')
    main_app.register_blueprint(hw_test.app, url_prefix='/dali/hw-test')
    main_app.register_blueprint(schedule.app, url_prefix='/dali/schedule')
    main_app.register_blueprint(wifi.app, url_prefix='/dali/wifi')
    main_app.register_blueprint(cloud.app, url_prefix='/dali/cloud')
    if USE_ZWAVE:
        main_app.register_blueprint(zwave.app, url_prefix='/dali/zwave')
    main_app.after_request(log_request)

    main_app.secret_key = 'lYJZqA4qJy4JF22JZLrnsLoj5' + util.get_mac_address()

    return main_app

def initialize(args=None):
    LOG.info('===== starting zpds version %s =====' % ZPDS_VERSION)

    # No args passed: get the defaults (this is used by the gunicorn path)
    if args is None:
        args = get_cli_args()

    # Turn the werkzeug logging down to warnings or worse, mainly to stop the
    # request logging (that we handle ourselves in log_request() above)
    logging.getLogger('werkzeug').setLevel(logging.WARNING)

    reload_static_data()

    if args.sim or args.fw_sim:
        dali.DUMB_DB.serial_device.conn = fake_dali.FakeSerialBus(
                channels=args.channels, n_devices=args.devices, upcs=args.upcs,
                fake_upcs=True, fw_sim=args.fw_sim, hat_hw_type=args.hat_type)
    dali.DUMB_DB.init_busses()

    if args.mac:
        util.get_mac_address = lambda: args.mac

    if args.mem:
        db.init_mem_db()
    elif args.db_url:
        db_url = 'sqlite:///%s' % args.db_url
        db.init_db(db_url)
    else:
        db.init_db(DATABASE_URL)

    if USE_ZWAVE:
        zwave.init()

    # Start a cloud listener thread if cloud integration is enabled
    cloud.init_cloud()

    # Initialize site options
    config.update_site_settings()

    # Read the power status etc. so we can check the hat HW type, and also so
    # that the LED status thread has some info to go on initially
    # Note: must be done after config.update_site_settings()
    dali.DUMB_DB.get_status()

    use_led_thread = True
    use_fan_control = True
    # For the HW tester, add a link to the test page in the sidebar
    if dali.DUMB_DB.hw_type == 5:
        use_led_thread = False
        PAGES.append(['hw_test', '/dali/hw-test/', 'HW Testing'])
        PAGE_URLS['hw_test'] = '/dali/hw-test/'
    # Old hats don't have LEDs or fans, neither do simulators
    elif not dali.DUMB_DB.hw_type or dali.DUMB_DB.hw_type <= 2 or args.sim:
        use_led_thread = False
        use_fan_control = False

    if args.monitor:
        dali.start_monitor_threads(use_led_thread=use_led_thread)
        schedule.start_schedule_thread(use_fan_control=use_fan_control)

    # Initialize serial proxy if enabled
    if CONFIG.get('enable-serial-proxy', False):
        import serial_proxy
        serial_proxy.init_serial_proxy()

    # Initialize FW test sources, reading the whole directory from the ramdisk
    fw_test_srcs = None
    if RAMDISK:
        fw_test_srcs = read_dir(FW_TEST_DIR)
    hw_test.init_fw_tests(fw_test_srcs)

    wss = websocket_server.WebSocketServer('127.0.0.1', args.ws_port,
            root_path='/ws', name='WS Server')
    wss.add_router(wsr)
    wss.add_router(hw_test.wsr)
    if USE_ZWAVE:
        wss.add_router(zwave.wsr)
    wss.start()

    if RAMDISK:
        subprocess.run('sudo umount ./ramdisk', shell=True,
                check=1, stdout=sys.stdout, stderr=sys.stderr)

def create_app(args=None):
    global MAIN_APP
    try:
        MAIN_APP = get_full_app()
        initialize(args=args)
    except Exception as e:
        LOG.exception(e)
        raise
    return MAIN_APP

def reload_thread():
    while True:
        input()
        import build_js
        build_js.build()
        reload_static_data()
        print('Reloaded.')

def signal_handler(signal, frame):
    import pdb
    pdb.Pdb().set_trace(frame)    

def default_signal(signal, frame):
    LOG.info('GOT SIGNAL! signal: %s', signal)
    LOG.info('frame: %s', frame)
    sys.exit(1)

# Command line parsing
def get_cli_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('-m', '--mem', action='store_true',
            help='use a temporary in-memory database')
    parser.add_argument('-s', '--sim', action='store_true',
            help='run with a simulated DALI bus')
    parser.add_argument('-f', '--fw-sim', action='store_true')
    parser.add_argument('-c', '--channels', type=int, default=1,
            help='number of channels to run under simulation (with --sim)')
    parser.add_argument('-d', '--devices', type=int, default=3,
            help='number of devices to run under simulation (with --sim)')
    parser.add_argument('-u', '--upcs', help='comma separated list of UPCs or '
            'product names to use for simulated devices (with --sim)')
    parser.add_argument('-H', '--hat-type', type=int, default=None,
            help='use a specific hat HW type for the simulator')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--no-monitor', action='store_false', dest='monitor')
    parser.add_argument('-z', '--no-zwave', action='store_false', dest='zwave')
    parser.add_argument('--db', dest='db_url', help='filename of SQLite database')

    parser.add_argument('--mac', dest='mac', help='fake mac address')
    parser.add_argument('--port', dest='port', help='server port', type=int,
            default=5000)
    parser.add_argument('--ws-port', dest='ws_port', help='websocket server port',
            type=int, default=5001)

    args = sys.argv[1:]
    if '--' in args:
        args = args[args.index('--')+1:]

    return parser.parse_args(args)

if __name__ == '__main__':
    args = get_cli_args()

    if not args.zwave:
        USE_ZWAVE = False

    if args.debug:
        import signal
        signal.signal(signal.SIGUSR1, signal_handler)
    elif not RAMDISK:
        threading.Thread(target=reload_thread, daemon=True, name='Reloader').start()
    else:
        import signal
        signal.signal(signal.SIGABRT, default_signal)
        signal.signal(signal.SIGTERM, default_signal)
        signal.signal(signal.SIGINT, default_signal)
        signal.signal(signal.SIGILL, default_signal)
        signal.signal(signal.SIGFPE, default_signal)
        signal.signal(signal.SIGSEGV, default_signal)
    create_app(args=args).run(host='0.0.0.0', port=args.port)#, debug=args.debug)
