import json
import logging
import re
import socket
import subprocess
import threading
import time

import flask
import jsonschema

import config
import util

LOG = util.get_logger('wifi')

app = flask.Blueprint('wifi', __name__, static_folder=None)

CRON_BOOM_PATH = '/home/pi/atxled/hue/cron-boom/cron_boom.py'

STATIC_IP_SCHEMA = util.schema_obj({
    'ip': {'type': 'string', 'pattern': r'^[0-9a-f.:]*$'},
    'mask': {'type': 'string', 'pattern': r'^[0-9]*$'},
    'router': {'type': 'string', 'pattern': r'^[0-9a-f.:,]*$'},
    'dns': {'type': 'string', 'pattern': r'^[0-9a-f.:,]*$'},
})

def run_wpa_cli(*args):
    cmd = ['wpa_cli', '-iwlan0', *args]
    return subprocess.check_output(cmd).decode('utf-8')

# Get ip/mac addresses
def get_internet_status():
    try:
        # Get the mac of the wifi adapter. RPi specific-ish
        with open('/sys/class/net/wlan0/address') as f:
            mac = f.read().strip().replace(':', '')

        # https://stackoverflow.com/questions/166506
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("1.1.1.1", 80))
            ip = sock.getsockname()[0]

        return {'mac': mac, 'ip': ip}
    except Exception as e:
        LOG.error('error getting LAN info: %s', e)
        return None

# Run wpa_cli status and parse the output into a dict
def get_wpa_status():
    result = {}
    try:
        for line in run_wpa_cli('status').splitlines():
            k, _, v = line.partition('=')
            result[k] = v

        # Ugh, also run iwconfig and parse the output to get signal level
        output = subprocess.check_output('iwconfig', stderr=subprocess.DEVNULL).decode('utf-8')
        match = re.search('Signal level=(.*) dBm', output)
        if match:
            result['signal_level'] = match.group(1)
    except Exception as e:
        LOG.error('error getting wpa status: %s', e)
    return result

# Parse escape bytes: convert \xFF sequences to raw byte values. These are used
# in the output of both wpa_cli and iwlist, apparently
def unescape(value):
    if isinstance(value, str):
        value = value.encode('ascii')
    b = bytearray(value)
    while b'\\x' in b:
        index = b.index(b'\\x')
        b[index:index+4] = [int(b[index+2:index+4], 16)]
    return bytes(b)

# HTML escape an SSID value to display it properly (maybe). We try unicode first
# and default to raw bytes, which will show some garbage values but it's better
# than nothing. That is, it will use the raw byte value as the unicode code point,
# e.g. b'\xFF' -> '&#255;', which displays as ÿ
def html_ssid_display(value):
    try:
        value = [ord(c) for c in value.decode('utf-8')]
    except Exception as e:
        LOG.error('error encoding ssid name: %s (name=%r)', e, value)
    return ''.join('&#%d;' % b for b in value)

# Return a basic round-trippable value for bytes: just a string of hex values
# separated by spaces. We don't want any HTML/form encoding crap to mess with it
def html_ssid_key(value):
    return ' '.join('%02x' % b for b in value)

# ...and a parser for the same format
def parse_html_ssid_key(value):
    return bytes(int(b, 16) for b in value.split(' '))

def iwlist_scan():
    cmd = ['sudo', 'iwlist', 'wlan0', 'scan']
    scan = subprocess.check_output(cmd)
    current = None
    networks = []
    for line in scan.splitlines():
        # This is a big hack! It relies on kinda sketchy parsing
        # across multiple lines, assuming the Address line always
        # starts a new entry. Entries can have multiple ESSIDs,
        # apparently, so we just ignore that and keep the last
        regexes = [
            [0, b' - Address: ([0-9A-F:]+)$'],
            [2, b'Signal level=([-0-9]+) dBm'],
            [1, b'ESSID:"(.*)"$'],
        ]
        for [i, regex] in regexes:
            match = re.search(regex, line)
            if match:
                if i == 0:
                    current = [None] * 3
                    networks.append(current)
                value = match.group(1)
                if i == 0:
                    current[i] = value.decode('utf-8')
                elif i == 1:
                    b = unescape(value)
                    # Only accept the SSID if there are non-zero bytes
                    if any(b):
                        current[i] = b
                elif i == 2:
                    current[i] = int(value)
    return networks

def wpa_cli_scan():
    scan = run_wpa_cli('scan_results')
    run_wpa_cli('scan')
    networks = []
    for line in scan.splitlines():
        try:
            bssid, _, signal, _, ssid = line.split('\t')
            ssid = unescape(ssid)
            if any(ssid):
                networks.append((bssid, ssid, int(signal)))
        except Exception:
            pass
    return networks

# Get wifi SSIDs currently being broadcasted. We use two different methods here,
# as a weird way to handle concurrency. iwlist_scan() forces an immediate scan,
# but this takes a few seconds, and if another process tries to run the same
# scan concurrently, the second will fail. This can easily happen if somebody
# reloads the wifi page while it's still scanning. The second method, wpa_cli_scan(),
# is fast but uses possibly stale results from the last scan. So we use a lock
# to make sure only one scan happens at once, and if a scan was already happening
# when we wanted to scan, we can use the quick method after.
SCAN_LOCK = threading.Lock()
def scan_wifi():
    # Check if the lock is already held. If it is, another thread is running a full
    # scan, so we still wait for it
    quick = SCAN_LOCK.locked()
    try:
        with SCAN_LOCK:
            if quick:
                networks = wpa_cli_scan()
            else:
                networks = iwlist_scan()
        # Filter out networks with incomplete information
        networks = [n for n in networks if all(v is not None for v in n)]
        return networks
    except Exception as e:
        logging.error('error getting scanned networks: %s', e)
        return []

def get_conf_networks():
    try:
        network_lines = run_wpa_cli('list_networks').splitlines()
        conf_networks = {}
        for line in network_lines[1:]:
            net_id, ssid, _, _ = line.split('\t')
            ssid = unescape(ssid)
            conf_networks[ssid] = net_id
        return conf_networks
    except Exception as e:
        LOG.error('error getting configured networks: %s', e)
        return {}

def configure_ssid(ssid, password):
    # Remove this network from the configuration if it already exists
    conf_networks = get_conf_networks()
    if ssid in conf_networks:
        net_id = conf_networks[ssid]
        run_wpa_cli('remove_network', net_id)

    # Set the network up and 
    net_id = run_wpa_cli('add_network')
    ssid = b'"%s"' % ssid
    run_wpa_cli('set_network', net_id, 'ssid', ssid)
    run_wpa_cli('set_network', net_id, 'priority', str(int(time.time())))
    if password:
        run_wpa_cli('set_network', net_id, 'psk', '"%s"' % password)
        run_wpa_cli('set_network', net_id, 'key_mgmt', 'WPA-PSK')
    else:
        run_wpa_cli('set_network', net_id, 'key_mgmt', 'NONE')
    run_wpa_cli('set_network', net_id, 'scan_ssid', '1')
    run_wpa_cli('enable_network', net_id)
    run_wpa_cli('save_config')

@app.route('/')
def get_wifi_setup():
    seen = set()
    networks = []
    for [bssid, ssid, signal] in sorted(scan_wifi(), key=lambda bss: -bss[2]):
        if ssid and ssid not in seen:
            # Weird escaping
            networks.append((html_ssid_key(ssid), html_ssid_display(ssid)))
            seen.add(ssid)
    conf_networks = []
    for [ssid, net_id] in get_conf_networks().items():
        conf_networks.append((net_id, html_ssid_display(ssid)))
    status = get_wpa_status()

    # Get static IP
    static_ip = None
    try:
        proc = subprocess.run([CRON_BOOM_PATH, 'get-static-ip'],
                stdout=subprocess.PIPE)
        info = json.loads(proc.stdout.decode('ascii'))
        util.validate_json(info, STATIC_IP_SCHEMA)
        static_ip = info
    except Exception:
        pass

    return flask.render_template('wifi.html', scan_networks=networks,
            conf_networks=conf_networks, status=status,
            static_ip=static_ip, page='wifi')

@app.route('/setup', methods=['POST'])
def post_wifi_setup():
    ssid = flask.request.form['ssid']
    if ssid:
        # Decode our dumb bytes encoding
        ssid = parse_html_ssid_key(ssid)
    else:
        ssid = flask.request.form['ssid-manual'].encode('utf-8')
    assert ssid
    # From what I can gather, wpa_supplicant.conf doesn't allow any
    # escaping, but takes every byte between the first and last quotes on
    # a line, so we basically just have to filter newlines
    ssid = ssid.replace(b'\n', b'')
    password = flask.request.form['password'].replace('\n', '')

    configure_ssid(ssid, password)

    # HACKish: unset the backup notification seen status, assuming the
    # wifi setup means the pi is now with a customer
    config.update_site_settings(backup_notification_seen=False)

    # Remove any static IP that might be set
    proc = subprocess.run([CRON_BOOM_PATH, 'set-static-ip', ''])
    if proc.returncode != 0:
        flask.abort(500)

    return flask.render_template('wifi-done.html')

@app.route('/remove-network', methods=['POST'])
def remove_network():
    net_id = str(int(flask.request.form['net_id'][:10]))
    run_wpa_cli('remove_network', net_id)
    run_wpa_cli('save_config')

    return util.redirect(flask.url_for('.get_wifi_setup'))

@app.route('/status')
def get_status():
    data = get_internet_status()
    status = get_wpa_status()
    scan = run_wpa_cli('scan_results')

    return '<html><pre>%s\n%s\n%s</pre></html>' % (data, status, scan)

@app.route('/set-static-ip', methods=['POST'])
def set_static_ip():
    info = dict(flask.request.form)
    try:
        util.validate_json(info, STATIC_IP_SCHEMA)
    except jsonschema.ValidationError as e:
        flask.flash(e.message)
        return util.redirect(flask.url_for('.get_wifi_setup'))

    if not info['ip']:
        info = ''
    else:
        info = json.dumps(info)

    # Set the static IP
    proc = subprocess.run([CRON_BOOM_PATH, 'set-static-ip', info])
    if proc.returncode != 0:
        flask.abort(500)

    flask.flash('Static IP set.')

    return util.redirect(flask.url_for('.get_wifi_setup'))
