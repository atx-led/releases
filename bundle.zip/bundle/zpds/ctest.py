import subprocess
import requests

import time

def register(email, password, name):
    url = '%s/devices/register' % SERVER_URL
    mac = 'asdf'
    resp = requests.post(url, json={'email': email,
        'password': password, 'name': name, 'mac_address': mac})

    data = resp.json()
    print(data)

    return {'api-token': data['token']}

SERVER_URL = 'http://localhost:7000'
headers = register('asdf@a', 'asdf', 'asdf')

procs = []
for i in range(2, 5):
    procs.append(subprocess.Popen(['python', 'cloud.py', 't%s@c' % i]))

time.sleep(1)
url = '%s/api/messages/push' % SERVER_URL
msg = 'asdf' * 5
for i in range(2, 5):
    resp = requests.post(url, json={'id': i, 'message': {'msg': 'asdf%s' % i}},
            headers=headers)
    print('POST', resp, resp.text)
for p in procs:
    p.wait()
