import collections
import util

# Just a basic container class for keeping some attrs together
class AttrData:
    def __init__(self, **kwargs):
        self.__dict__.update(**kwargs)

# Type check an RGBW tuple in the form of a list (from JSON or something).
# Make sure it's a 3-to-6-element list with each element an int in 0..255 
def RGBW(args):
    assert isinstance(args, list) and 3 <= len(args) <= 6, args
    for a in args:
        if not isinstance(a, int) or not (0 <= a <= 254):
            raise util.APIError('invalid RGBW value: %s' % a)
    return args

# Table of all ATX-LED device UPCs. This should match the table in devices.jsx
DR2MX_UPC = 722512407183
DR2F16_UPC = 784099948268
DR2F32_UPC = 784099948190
DR2G32_UPC = 784099947797
DR1G_UPC = 784099948466
DR1_PIR_UPC = 784099947780
DALI_8B_UPC = 722512406476
DALI_IO16_UPC = 722512406087
DALI_RELAY8_UPC = 722512407367
WS_010v_UPC = 722512407282
PSE_4D_UPC = 722512407350
# A fake UPC just used for creating simulated RGB lights during testing
FAKE_RGB_DEVICE_UPC = 784099777777
FAKE_RGBWAF_DEVICE_UPC = 784099777778
ATX_UPC_TABLE = {
    DALI_8B_UPC:    'AL-WS-DALI-8B',
    DALI_IO16_UPC:  'AL-DALI-IO16',
    DALI_RELAY8_UPC:'AL-DALI-Relay8',
    722512407176:   'AL-WS-DR2',
    DR2MX_UPC:      'AL-DALI-DR2-mx',
    WS_010v_UPC:    'AL-WS-010v',
    DR2G32_UPC:     'AL-WS-DR2G32',
    DR1G_UPC:       'AL-WS-DR1G',
    DR2F32_UPC:     'AL-WS-DR2F32',
    DR2F16_UPC:     'AL-WS-DR2F16',
    DR1_PIR_UPC:    'AL-WS-DR1-PIR',
    PSE_4D_UPC:     'AL-PSE-4D',
    784099948350:   'PWS-POE-DALI',
    784099948404:   'AL-DR-TW2',
}
NON_ATX_UPC_TABLE = {
    FAKE_RGB_DEVICE_UPC: 'FAKE-RGB',
    FAKE_RGBWAF_DEVICE_UPC: 'FAKE-RGBWAF',
}
UPC_TABLE = {**ATX_UPC_TABLE, **NON_ATX_UPC_TABLE}

DALI_ATTRS = [
    # Attr name         type  get    set    mem range  (extra attrs)
    ['dev_name',       [str,  None,  None,  None]],
    ['hue_name',       [str,  None,  None,  None]],
    ['hue_hidden',     [bool, None,  None,  None]],
    ['dev_status',     [int,  0x90,  None,  None]],
    # XXX remove the 'get' command here. We really don't need to read it ever,
    # since 'dev_on' is just an artificial attribute that we use to save levels
    # when turning lights on/off. We had always read it (as the "ballast powered
    # on" value from DALI), up until Feb 2022, which is a lot of useless reads,
    # but it had never been noticed really, until the PSE-4D started returning
    # weird values for it (other lights seemingly always ignored the query),
    # and was thus interfering with the power readings
    #['dev_on',         [bool, 0x93,  None,  None]],
    ['dev_on',         [bool, None,  None,  None]],
    ['dali_version',   [int,  0x97,  None,  None]],
    ['dev_type',       [int,  0x99,  None,  None]],
    ['phy_min_level',  [int,  0x9A,  None,  None]],
    ['level',          [int,  0xA0,  None,  None]],
    ['level_inc',      [int,  None,  None,  None]],
    ['level_inc_on',   [int,  None,  None,  None]],
    ['max_level',      [int,  0xA1,  0x2A,  None]],
    ['min_level',      [int,  0xA2,  0x2B,  None]],
    # Order of power on/fail is backwards between get/set. WHAT A SILLY PROTOCOL
    ['power_on_level', [int,  0xA3,  0x2D,  None]],
    ['fail_level',     [int,  0xA4,  0x2C,  None]],
    # DALI spec uses fade time/rate, but we use separate up/down times instead.
    # This is handled in the frontend, displaying separate values for ATX-LED lights.
    ['fade_up',        [int,  None,  0x2E,  None]],
    ['fade_down',      [int,  None,  0x2F,  None]],
    ['group_0_7',      [int,  0xC0,  None,  None]],
    ['group_8_15',     [int,  0xC1,  None,  None]],
    ['color_temp_k',   [int,  None,  None,  None]],
    ['has_color_temp', [bool, None,  None,  None]],
    ['color_k_min',    [int,  None,  None,  None]],
    ['color_k_max',    [int,  None,  None,  None]],
    ['color_cct_min',  [int,  None,  None,  None]],
    ['color_cct_max',  [int,  None,  None,  None]],
    ['has_color_rgb',  [bool, None,  None,  None]],
    ['color_rgbw',     [RGBW, None,  None,  None]],
    ['rgb_n_channels', [int,  None,  None,  None]],
    ['rgb_power_scale',[float,None,  None,  None]],

    # Nonstandard ATX-LED extensions
    #['model',          [int, 'A6',   None,  None]],
    ['upc_code',       [int,  None,  None,  [3, 9]]],
    ['serial_nb',      [int,  None,  None,  [11, 15]]],
    ['fw_version',     [int,  None,  None,  9]],
    ['hw_version',     [int,  None,  None,  10]],
    ['n_way',          [int,  None,  None,  15]],

    # DR2F-specific values
    ['voltage_right',  [int,  None,  None,  6,  {'dr2f_only': True, 'mem_bank': 5}]],
    ['voltage_left',   [int,  None,  None,  7,  {'dr2f_only': True, 'mem_bank': 5}]],
    ['driver_mode',    [int,  None,  None,  9,  {'dr2f_only': True, 'mem_bank': 5}]],
    ['slider_pos',     [bool, None,  None,  30, {'dr2f_only': True, 'mem_bank': 5}]],

    ['fan_run_time',   [int,  None,  None,  20, {'dr2f_only': True, 'mem_bank': 5}]],
    ['fan_delay_time', [int,  None,  None,  21, {'dr2f_only': True, 'mem_bank': 5}]],
    ['fan_idle_speed', [int,  None,  None,  22, {'dr2f_only': True, 'mem_bank': 5}]],
    ['fan_speed',      [int,  None,  None,  23, {'dr2f_only': True, 'mem_bank': 5}]],

    ['cct_fade_time',  [int,  None,  None,  76, {'dr2f_only': True, 'mem_bank': 5}]],

    # DR2F32-specific values
    ['dim_to_warm',    [float,None,  None,  28, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['split_addr',     [int,  None,  None,  29, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['color_k_left',   [int,  None,  None,  10, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['color_k_right',  [int,  None,  None,  11, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],

    ['thresh_v_right', [int,  None,  None,  [36, 38], {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5, 'big_endian': False}]],
    ['thresh_v_left',  [int,  None,  None,  [38, 40], {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5, 'big_endian': False}]],
    ['height_right',   [int,  None,  None,  44, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['height_left',    [int,  None,  None,  45, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['offset_right',   [int,  None,  None,  78, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],
    ['offset_left',    [int,  None,  None,  79, {'dr2f_only': True,
        'dr2f32_only': True, 'mem_bank': 5}]],

    # DR1-PIR-specific values
    ['on_timeout',     [int,  None,  None,  16, {'dr1pir_only': True}]],
    ['vac_sens',       [int,  None,  None,  17, {'dr1pir_only': True}]],
    ['occ_sens',       [int,  None,  None,  18, {'dr1pir_only': True}]],
    ['night_bright',   [int,  None,  None,  19, {'dr1pir_only': True}]],
    ['ambient_sens',   [int,  None,  None,  20, {'dr1pir_only': True}]],
    ['vac_fade_out',   [int,  None,  None,  21, {'dr1pir_only': True}]],
    ['night_thresh',   [int,  None,  None,  22, {'dr1pir_only': True}]],
    ['night_mode',     [int,  None,  None,  23, {'dr1pir_only': True}]],
    ['vac_mode',       [int,  None,  None,  24, {'dr1pir_only': True}]],
]

# Min/max values for Kelvin temperature and CCT value, as attr: (default, min, max)
# This should match table in devices.jsx
COLOR_RANGE_ATTRS = {
    'color_k_min':   (2700, 1700, 6500),
    'color_k_max':   (5000, 1700, 6500),
    'color_cct_min': (353, 0, 511),
    'color_cct_max': (0,   0, 511),
}

# Some DALI attributes that require special handling
SPECIAL_ATTRS = {
    'groups',
    'buttons',
    'level_min',
    'level_max',
    'level_off',
    'level_step_up',
    'level_step_down',
} | set(COLOR_RANGE_ATTRS)

# Make convenient tables for get/set command lookup, and transform DALI_ATTRS to objects
DALI_GET_CMDS = {}
DALI_SET_CMDS = {}
new_dali_attrs = collections.OrderedDict()
for [attr, [attr_type, get_cmd, set_cmd, mem_range, *extra_attrs]] in DALI_ATTRS:
    if get_cmd:
        DALI_GET_CMDS[get_cmd] = attr
    if set_cmd:
        DALI_SET_CMDS[set_cmd] = attr

    # Create a dummy object for easy access
    kwargs = {'dr2f_only': False, 'dr2f32_only': False, 'dr1pir_only': False,
            'mem_bank': 0, 'big_endian': True, 'write_only': False}
    if extra_attrs:
        kwargs.update(extra_attrs[0])
    if isinstance(mem_range, int):
        mem_range = (mem_range, mem_range + 1)
    new_dali_attrs[attr] = AttrData(type=attr_type, get_cmd=get_cmd,
            set_cmd=set_cmd, mem_range=mem_range, **kwargs)
DALI_ATTRS = new_dali_attrs

# Low byte commands, addressed to specific devices
DALI_LO_CMDS = {
    0x00: 'turn-off',
    0x03: 'step-up',
    0x04: 'step-down',
    0x05: 'set-to-max-level',
    0x06: 'set-to-min-level',
    0x20: 'reset-light-settings',
    0x21: 'capture-level-to-dtr',
    0x26: 'reset-light-levels',
    0x31: ('set-failover-status', {'dtr': None}),
    0x98: 'query-dtr',
    0xA5: 'get-fade-rates',
    # XXX ATX-LED Extensions
    0x80: ('set-short-addr', {'dtr': None}),
    0x81: 'write-enable',
    0x9C: 'query-dtr1',
    0xAB: 'get-passive-level',
    0xC5: ('read-memory', {'dtr': None, 'dtr1': None}),
    0xE2: ('save-cct', {'color_temp_cct': None}),
    0xE7: ('set-cct', {'color_temp_cct': None}),
    0xEB: ('set-color-rgb', {'color_rgb': None}),
    0xEC: ('set-color-w', {'color_waf': None}),
    0xED: ('set-color-unknown-attr', {'dtr': None}),
    0xF9: 'query-color-capability',
    0xFA: 'query-cct',
}
for group in range(16):
    DALI_LO_CMDS[0x60 | group] = ('add-to-group', {'group': group})
    DALI_LO_CMDS[0x70 | group] = ('remove-from-group', {'group': group})

for scene in range(16):
    DALI_LO_CMDS[0x10 | scene] = ('trigger-scene', {'scene': scene})
    DALI_LO_CMDS[0x40 | scene] = ('set-scene-level', {'scene': scene})
    DALI_LO_CMDS[0x50 | scene] = ('remove-scene', {'scene': scene})

DALI_HI_CMDS = {
    0xA1: 'terminate',
    0xA3: ('set-dtr', {'arg': 'dtr'}),
    0xA5: ('enable-search-mode', {'twice': True}),
    0xA7: ('randomize-address', {'twice': True}),
    0xA9: ('compare-address', {'comp_addr': None}),
    0xAB: ('withdraw', {'comp_addr': None}),
    0xB1: ('set-comp-addr-high', {'arg': 'comp_addr_hi'}),
    0xB3: ('set-comp-addr-mid', {'arg': 'comp_addr_mid'}),
    0xB5: ('set-comp-addr-low', {'arg': 'comp_addr_lo'}),
    0xB7: 'assign-short-addr',
    0xBB: 'query-short-addr',
    # XXX ATX-LED Extensions
    0xC1: ('enable-cct-mode'),
    0xC3: ('set-dtr1', {'arg': 'dtr1'}),
    0xC5: ('set-dtr2', {'arg': 'dtr2'}),
    0xC7: ('write-memory', {'dtr': None, 'dtr1': None}),
}

# Set empty attribute dict on lo/hi commands here, to keep definitions above clean
for table in [DALI_LO_CMDS, DALI_HI_CMDS]:
    for k, v in table.items():
        if isinstance(v, str):
            table[k] = (v, {})

# Data for dealing with commands 0-8: off/min/max/step etc
LEVEL_CMDS = {
    0: 0,
    5: 254,
    6: 1
}
LEVEL_INC_CMDS = {
    1: 7,
    2: -7,
    3: 1,
    4: -1,
    7: -1,
    8: 1
}

# Number of bits in a DALI packet based on the Hat command prefix
DALI_PACKET_SIZE = {'J': 8, 'H': 16, 'L': 24, 'M': 25}
# ...and the inverse
DALI_PACKET_PREFIX = {v: k.lower() for [k, v] in DALI_PACKET_SIZE.items()}

# Parse the first byte of a DALI command into an (address type, address id) tuple
def parse_dali_addr(cmd):
    addr_type = addr_id = None
    # 0AAAAAAS: Target device 0 <= A < 64.
    if not cmd & 0x80:
        addr_type, addr_id = ('single', cmd >> 1)
    # 100AAAAS: Target group 0 <= A < 16. Each device may be a member of any or all groups.
    elif cmd & 0xE0 == 0x80:
        addr_type, addr_id = ('group', (cmd >> 1) & 15)
    # 101CCCC1: Special commands 256–271
    # 110CCCC1: Special commands 272–287
    elif cmd & 0xE0 == 0xA0 or cmd & 0xE0 == 0xC0:
        pass
    # 1111111S: Broadcast to all devices.
    elif cmd & 0xFE == 0xFE:
        addr_type, addr_id = ('all', None)
    # 111xxxx1: Reserved (x != 15)
    else:
        pass
    return addr_type, addr_id

# Memory conversion functions. ATX-LED convention uses big-endian
def int_from_mem(mem, big_endian=True):
    if big_endian:
        mem = reversed(mem)
    return sum(byte << (i*8) for i, byte in enumerate(mem))

def int_from_attrs(attrs, *args):
    if not all(arg in attrs for arg in args):
        return None
    int_bytes = [attrs.pop(arg) for arg in args]
    return int_from_mem(int_bytes)

def mem_from_int(x, n_bytes, big_endian=True):
    assert 0 <= x < (1 << (8 * n_bytes))
    indices = range(n_bytes)
    if big_endian:
        indices = reversed(indices)
    return [(x >> (8 * i)) & 0xFF for i in indices]

def titleize(s):
    s = clean_str(s)
    return s[0].upper() + s[1:]

def clean_str(s):
    return s.replace('_', ' ').replace('-', ' ')

def pretty_cmd(name_attrs, arg, state=None):
    (name, attrs) = name_attrs
    attrs = attrs.copy()
    cmd_str = titleize(name)
    if attrs:
        if 'arg' in attrs:
            attr = attrs.pop('arg')
            state[attr] = attrs[attr] = arg
        for attr in ['dtr', 'dtr1', 'dtr2']:
            if attr in attrs:
                attrs[attr] = state[attr]
        if 'comp_addr' in attrs:
            comp_addr = (state['comp_addr_hi'] << 16 |
                    state['comp_addr_mid'] << 8 | state['comp_addr_lo'])
            attrs['comp_addr'] = hex(comp_addr)[2:].upper()
        if 'color_temp_cct' in attrs:
            attrs['color_temp_cct'] = state['dtr1'] << 8 | state['dtr']
        if 'color_rgb' in attrs:
            attrs['color_rgb'] = [state['dtr'], state['dtr1'], state['dtr2']]
        if 'color_waf' in attrs:
            attrs['color_waf'] = [state['dtr'], state['dtr1'], state['dtr2']]

        cmd_str = '%s (%s)' % (cmd_str, ', '.join('%s=%s' % (k, v) for k, v in attrs.items()))
        if name == 'read-memory' or name == 'write-memory':
            state['dtr'] += 1
    return cmd_str

def pretty_dali_cmd_str(cmd, state=None):
    cmd_hi = (cmd >> 8) & 0xFF
    cmd_lo = cmd & 0xFF
    addr_type, addr_id = parse_dali_addr(cmd_hi)
    pretty_addr = ''
    if addr_type is not None:
        if addr_type == 'single':
            pretty_addr = 'A%s' % addr_id
        elif addr_type == 'all':
            pretty_addr = 'all'
        else:
            pretty_addr = '%s%s' % (addr_type[0].upper(), addr_id)

        if (cmd_hi & 1) == 0:
            cmd_str = 'Set level (level=%s)' % cmd_lo
        elif cmd_lo in DALI_GET_CMDS:
            cmd_str = 'Get %s' % clean_str(DALI_GET_CMDS[cmd_lo])
        elif cmd_lo in DALI_SET_CMDS:
            cmd_str = 'Set %s to %s' % (clean_str(DALI_SET_CMDS[cmd_lo]),
                    state['dtr'])
        elif cmd_lo in DALI_LO_CMDS:
            cmd_str = pretty_cmd(DALI_LO_CMDS[cmd_lo], None, state=state)
        else:
            cmd_str = '<unknown>'
    elif cmd_hi in DALI_HI_CMDS:
        cmd_str = pretty_cmd(DALI_HI_CMDS[cmd_hi], cmd_lo, state=state)
    else:
        cmd_str = '<unknown>'

    return (pretty_addr, cmd_str)
