#!/usr/bin/env python3
import contextlib
import datetime
import itertools
import json
import logging
import random
import queue
import subprocess
import sys
import threading
import time

import requests

import config
import dali
import dali_cmds
import db
import fake_dali
import hue
import schedule
import serve
import util
import wifi
import zwave
# Import some handy nuggets of code from common/test_utils.py, which is symlinked
# into this directory so we can pretend Python packaging isn't terrible
from test_utils import (test, run_tests, filter_logs, monkeypatch_client,
        mock_attr)

TRACE_DIR = 'test/dali-traces'


def get_client():
    client = serve.get_full_app().test_client()
    return monkeypatch_client(client)

# Select your dumb joke:
# * this wiretap authorized by FISA court order #[redacted]
# * let's hope they don't know about *67
# * the call was coming from... INSIDE THE HOUSE!!!
@contextlib.contextmanager
def trace_calls(obj, attr, fn, expected):
    actual = []
    def capture(*args, **kwargs):
        actual.append([args, kwargs])
        return fn(*args, **kwargs)
    with mock_attr(obj, attr, capture):
        yield
    check_trace(actual, expected)

# Big hack! Keep the original Popen value here so we can still use it
ORIG_POPEN = subprocess.Popen

# Context manager to trace all subprocess executions
@contextlib.contextmanager
def trace_procs(fn, procs):
    with trace_calls(subprocess, 'Popen', fn, procs):
        yield

# Another hack: keep the real sleep function around, so we can use it where we
# actually want to sleep. Normal sleeps, along with all other time functions,
# are mocked out
SLEEP = time.sleep

# Mock out time-related functions. This is not perfect, and it only mocks the
# util date functions plus time.sleep(), but freezegun was weirdly buggy
# with timezones and didn't support time.sleep().
@contextlib.contextmanager
def mock_time(dt, tz_offset=0):
    raw_time = 0
    if isinstance(dt, str):
        dt = datetime.datetime.fromisoformat(dt)
    def fake_sleep(seconds):
        nonlocal dt, raw_time
        dt = dt + datetime.timedelta(seconds=seconds)
        raw_time += seconds
    tz = datetime.timezone(datetime.timedelta(minutes=tz_offset))
    with util.contexts(
            mock_attr(util, 'utcnow', lambda: dt),
            mock_attr(util, 'now', lambda: dt.astimezone(tz)),
            mock_attr(util, 'today', lambda: dt.astimezone(tz).date()),
            mock_attr(util, 'get_time', lambda: raw_time),
            mock_attr(time, 'sleep', fake_sleep)):
        yield

FAKE_MAC = 0xFFFFFFCB347A
def get_fake_mac():
    return '%012X' % FAKE_MAC

# Context manager for running some code under a simulated DALI bus
@contextlib.contextmanager
def setup_sim(**kwargs):
    fake_serial = fake_dali.FakeSerialBus(**kwargs)
    with util.contexts(mock_attr(dali.DUMB_DB.serial_device, 'conn', fake_serial),
            mock_attr(util, 'get_mac_address', get_fake_mac)):
        dali.DUMB_DB.init_busses()
        yield fake_serial

def columnize(rows):
    rows = [[str(c) for c in row] for row in rows]
    try:
        widths = [max(len(row[col]) for row in rows) for col in range(len(rows[0]))]
    except:
        return [repr(r) for r in rows]
    return [' '.join('%-*s' % (width, cell) for [width, cell] in zip(widths, row))
            for row in rows]

def check_trace(actual, expected, msg=None):
    if actual != expected:
        comp = [[act or '', exp or '', '***' if act != exp else '']
                for [act, exp] in itertools.zip_longest(actual, expected)]
        for row in columnize([['Actual', 'Expected', '']] + comp):
            print(row)
        assert False, msg

def check_sim_trace(sim, expected):
    if sim.trace_log != expected:
        [act, exp] = [columnize([['%s,' % packet for packet in send_recv]
                for send_recv in util.chunked(log, 2)])
            for log in [sim.trace_log, expected]]
        check_trace(act, exp)
        assert False

def check_lists_eq(msg, actual, expected):
    if actual != expected:
        print('Test "%s" failed:' % msg)
        sentinel = object()
        for [i, [a, b]] in enumerate(itertools.zip_longest(
                actual, expected, fillvalue=sentinel)):
            if a != b:
                if a is sentinel:
                    a = '*** nonexistent ***'
                if b is sentinel:
                    b = '*** nonexistent ***'
                print('    actual[%2d]: %s' % (i, a))
                print('  expected[%2d]: %s' % (i, b))
        assert False

# Fake serial device for zwave, that reads a trace from a JSON file.
# This is mostly resurrected from the DALI FakeSerialTrace, which was
# deleted in commit 446a1e68425e6de68df0796664ab99a09242cb28. This was
# pretty similar at first, since they both wrapped a pyserial device,
# but has since diverged due to the weird multi-threaded architecture
# of PyZwaver, requiring a synchronization mechanism across reading/writing
# threads.

class FakeZWaveSerialDevice:
    def __init__(self, path):
        with open(path) as f:
            self.data = json.load(f)
        self._byte_stream = iter(self._handle_pushback())
        self.condition = threading.Condition()
        self.lock = threading.Lock()
        self.pushed_item = None

    def _iter_bytes(self):
        for i, (direction, line) in enumerate(self.data):
            self.line_number = i
            line = bytes(line)
            for j, char in enumerate(line):
                self.byte_number = j
                yield (direction, char)
        yield ('done', None)

    def _handle_pushback(self):
        self.pushes = 0
        for item in self._iter_bytes():
            yield item
            while self.pushed_item:
                self.pushes += 1
                i = self.pushed_item
                self.pushed_item = None
                yield i

    def _check_finished(self):
        if next(self._byte_stream) is not None:
            self._raise_error('Did not finish trace')

    def _raise_error(self, msg, cmp_line=None):
        # Print the line number for debugging. +2 because we're using 0-based
        # indexing, and the json file has a '[' on the first line, so the data
        # starts at line 2 there.
        print('%s on line %s, byte %s:' % (msg, self.line_number + 2,
                self.byte_number))
        direction, line = self.data[self.line_number]
        print('  expected: [%s] %s' % (direction, repr(line)))
        if cmp_line is not None:
            print('       got: [w] %s' % list(cmp_line))
        assert False

    def _check(self, flag, msg=None, cmp_line=None):
        if not flag:
            self._raise_error(msg or 'Byte mismatch', cmp_line=cmp_line)

    def read(self, n_bytes):
        with self.wait_for_state('r') as done:
            if done:
                return b''
            buf = []
            for i in range(n_bytes):
                direction, byte = next(self._byte_stream)
                self._check(direction == 'r', msg='Wrong direction')
                buf.append(byte)
            return bytes(buf)

    def write(self, buf):
        with self.wait_for_state('w') as done:
            if done:
                return None
            for char in buf:
                expected = next(self._byte_stream)
                if not expected:
                    self._raise_error('unexpected EOF')
                direction, test_char = expected
                self._check(direction == 'w', msg='Wrong direction')
                self._check(test_char == char, cmp_line=buf)

    def flush(self): pass
    def flushInput(self): pass
    def flushOutput(self): pass

    # This is a fancy lock that does a regular lock, peeks at the next value
    # in the stream, and only lets the user through if the value is the expected
    # state. Otherwise, it releases the lock and tries again. Since PyZwaver
    # has different threads for reading/writing, we only let them through in
    # the expected order.
    @contextlib.contextmanager
    def wait_for_state(self, state):
        while True:
            with self.lock:
                item = next(self._byte_stream)
                self.pushed_item = item
                if item[0] == 'done':
                    yield True
                    break
                if item[0] == state:
                    yield False
                    break
            # Unsuccessful lock: we got some other state instead. Use a tiny
            # non-zero sleep to yield our time slice before trying again
            SLEEP(0.00001)

@test
def test_zwave_trace():
    logging.getLogger().setLevel(logging.ERROR)
    device = FakeZWaveSerialDevice('zwave-trace.json')
    zwave.ZWAVE_HANDLER = zwave.ZWaveHandler()
    zwave.ZWAVE_HANDLER.init(device=device)

    with device.wait_for_state('done') as done:
        pass
    zwave.ZWAVE_HANDLER.driver.Terminate()

# Test the DALI code with a bus simulator and simulated devices
@test
def test_dali_sim():
    with setup_sim():
        dali.DUMB_DB.full_scan()

    with setup_sim() as sim, mock_time('2020-06-23 00:00:00+00:00'):
        (new, total) = dali.DUMB_DB.assign_addresses(assign_random=True)
        assert new == 10 and total == 10, (new, total)
        short_addrs = {d.short_addr for d in sim.devices[0]}
        assert len(short_addrs) == 5, short_addrs

        (new, total) = dali.DUMB_DB.assign_addresses(quick=True)
        assert new == 6 and total == 6
        assert len({d.short_addr for d in sim.devices[0]}) == 10

        # Check that serial numbers make sense. We can't rely on a clean
        # mapping from short address to serial, so check the range
        for d in sim.devices[0]:
            assert d.mem[0][11:14] == [0xCB, 0x34, 0x7A]
            assert 64 <= d.mem[0][14] < 64 + len(sim.devices[0])
        # Make sure serials are unique
        assert len(set(d.mem[0][14] for d in sim.devices[0])) == len(sim.devices[0])

        # Verify that the serial number sequence table makes sense
        with db.db_session() as session:
            [serial_nb_seq] = [sn.serial_number_seq
                for sn in session.query_all(db.SerialNumberSeq)]
            assert serial_nb_seq == (FAKE_MAC & 0xFFFFFF) << 8 | 74

        (new, total) = dali.DUMB_DB.assign_addresses()
        assert new == 0 and total == 10
        assert len({d.short_addr for d in sim.devices[0]}) == 10

        # Collide some addresses
        for d in sim.devices[0][2:5]:
            d.short_addr = sim.devices[0][0].short_addr

        dali.DUMB_DB.full_scan()
        assert len(dali.DUMB_DB.address_blacklist[0]) == 0

        # Change an address, make sure both the old address and the new get
        # blacklisted, as well as the conflicting address
        sim.devices[0][6].short_addr = 43
        (new, total) = dali.DUMB_DB.assign_addresses(quick=True)
        assert new == 4 and total == 4, (new, total)

        assert dali.DUMB_DB.address_blacklist[0] == [(23, False),
                (18, False), (19, False), (24, False), (43, False)]

# Make sure re-scanning takes place when something unexpected occurs
@test
def test_rescan():
    # These commands are sent on every rescan
    prelude = [['send', 'v\n'], ['send', 'd\n']]

    with setup_sim(n_devices=4, fake_upcs=True) as sim:
        # Scan the bus
        dali.DUMB_DB.full_scan()

        # Send a level set command for a nonexistent device
        #dali.DUMB_DB.send_cmd_raw('h38FF\n')
        #sim.reset_trace()
        ## Rescan and make sure we just scan for the single address
        #dali.DUMB_DB.full_scan()
        #check_sim_trace(sim, prelude + [
        #    ['send', 'h39A0\n'], ['recv', 'N\n'],
        #])

        # Send a hue light update for a nonexistent device
        client = get_client()
        client.check_put('/state', json={'0_s_24': {'bri': 128}})
        sim.reset_trace()
        # Rescan and make sure we just scan for the single address
        dali.DUMB_DB.full_scan()
        check_sim_trace(sim, prelude + [
            ['send', 'h31A0\n'], ['recv', 'N\n'],
        ])

# Test color temperature/RGB settings. Make sure we can approximately round
# trip between CCT and K values, and that we're updating properly from the bus
@test
def test_dali_colors():
    with setup_sim(n_devices=5, fake_upcs=True) as sim:
        addresses = list(dali.DUMB_DB.full_scan())

        # Set various interpolation values
        for device in dali.DUMB_DB.get_devices_state():
            i = device['short_addr']
            data = {
                'color_k_min':   2700 + i * 61,
                'color_k_max':   5000 - i * 11,
                'color_cct_min': 353 - i * 3,
                'color_cct_max': 0 + i * 17,
            }
            dali.DUMB_DB.set_dali_light_state(device['address'], data)

        sim.reset_trace()

        dali.DUMB_DB.set_color_temp('all', 3000)
        trace_1 = sim.reset_trace()

        dali.DUMB_DB.set_color_temp('all', 4000)
        trace_2 = sim.reset_trace()

        for [trace, color_temp_k] in [[trace_1, 3000], [trace_2, 4000]]:
            for [[_, cmd], _] in util.chunked(trace, 2):
                dali.DUMB_DB.send_cmd_raw(cmd)
            for device in dali.DUMB_DB.get_devices_state():
                # Might be rounding errors, so just check that it's close
                assert abs(device['color_temp_k'] - color_temp_k) <= 6

            # Trace should match exactly
            check_sim_trace(sim, trace)
            sim.reset_trace()

        # Test RGBW colors. Each test case is 0-100 values from the UI,
        # with expected interpolated 0-254 values sent over the wire.
        # It should only get sent out to one device (short address 4)
        rgb_tests = [
            [[10, 10, 10, 10], '0A 0A 0A 0A 00 00'],
            [[100, 10, 10, 10, 10], '64 0A 0A 0A 0A 00'],
        ]
        for [send_rgbw, exp_rgbw] in rgb_tests:
            sim.reset_trace()
            dali.DUMB_DB.set_color_rgbw('all', send_rgbw)
            [r, g, b, w, a, f] = exp_rgbw.split()
            check_sim_trace(sim, [
                ['send', 'hA3%s\n' % r], ['recv', 'N\n'],
                ['send', 'hC3%s\n' % g], ['recv', 'N\n'],
                ['send', 'hC5%s\n' % b], ['recv', 'N\n'],
                ['send', 'hC108\n'], ['recv', 'N\n'],
                ['send', 'h09EB\n'], ['recv', 'N\n'],
                ['send', 'hA3%s\n' % w], ['recv', 'N\n'],
                ['send', 'hC3%s\n' % a], ['recv', 'N\n'],
                ['send', 'hC5%s\n' % f], ['recv', 'N\n'],
                ['send', 'hC108\n'], ['recv', 'N\n'],
                ['send', 'h09EC\n'], ['recv', 'N\n'],
                ['send', 'hA380\n'], ['recv', 'N\n'],
                ['send', 'hC108\n'], ['recv', 'N\n'],
                ['send', 'h09ED\n'], ['recv', 'N\n'],
                ['send', 'hC108\n'], ['recv', 'N\n'],
                ['send', 'h09E2\n'], ['recv', 'N\n'],
            ])

        # Test raw left/right color values
        address = '0_s_3'
        for attr in ['left', 'right']:
            attr = 'color_k_%s' % attr
            mem_addr = dali_cmds.DALI_ATTRS[attr].mem_range[0]
            for [temp, value] in [[0, 0xB1], [6000, 0x00], [4000, 0x4D]]:
                sim.reset_trace()
                dali.DUMB_DB.set_dali_light_state(address, {attr: temp})
                check_sim_trace(sim, [
                    ['send', 'hA3%02X\n' % mem_addr], ['recv', 'N\n'],
                    ['send', 'hC305\n'], ['recv', 'N\n'],
                    ['send', 't0781\n'], ['recv', 'N\n'],
                    ['send', 'hC7%02X\n' % value], ['recv', 'J%02X\n' % value],
                ])

        # Test dim to warm
        attr = 'dim_to_warm'
        mem_addr = dali_cmds.DALI_ATTRS[attr].mem_range[0]
        for [dim, value] in [[0, 0xF0], [5, 0xFF], [1.5, 0xF5]]:
            sim.reset_trace()
            dali.DUMB_DB.set_dali_light_state(address, {attr: dim})
            check_sim_trace(sim, [
                ['send', 'hA3%02X\n' % mem_addr], ['recv', 'N\n'],
                ['send', 'hC305\n'], ['recv', 'N\n'],
                ['send', 't0781\n'], ['recv', 'N\n'],
                ['send', 'hC7%02X\n' % value], ['recv', 'J%02X\n' % value],
            ])

# Test address scanning error detection: this should be handled somewhat gracefully
@test
def test_scan_errors():
    with setup_sim(n_devices=8) as sim:
        # Set up a mock traffic handler to fuck with the traffic
        counter = 0
        counter_blacklist = None
        old_interpret = None
        def interpret(self, hi, lo, count=1):
            nonlocal counter, counter_blacklist, old_interpret
            # Trigger on one address for one command (group read 0-7, doesn't really matter tho)
            if lo == 0xC0 and self.short_addr == 0:
                counter += 1
                if counter in counter_blacklist:
                    assert False
            return old_interpret(self, hi, lo, count=count)

        with mock_attr(fake_dali.FakeDevice, 'interpret_command', interpret) as old_interpret:
            with filter_logs('bogus'):
                # Make sure two failures still works
                counter_blacklist = (2, 3)
                addresses = list(dali.DUMB_DB.full_scan())
                assert len(addresses) == 8, addresses
                assert counter > 0

                # Ten failures in a row: should throw
                counter = 0
                counter_blacklist = range(2, 12)
                dali.DUMB_DB.blacklist_all_addresses()
                try:
                    addresses = list(dali.DUMB_DB.full_scan())
                except Exception:
                    pass
                else:
                    assert False, "should've thrown"

                # Now try ten failures in a row again, but restart the scan afterwards.
                # We should pick up where we left off, and we detect this by removing
                # some of the devices between
                counter = 0
                counter_blacklist = range(2, 12)
                dali.DUMB_DB.blacklist_all_addresses()
                try:
                    addresses = list(dali.DUMB_DB.full_scan())
                except Exception:
                    del sim.devices[0][:3]
                    addresses = list(dali.DUMB_DB.full_scan())
                    assert len(addresses) == 8

                    dali.DUMB_DB.blacklist_all_addresses()
                    addresses = list(dali.DUMB_DB.full_scan())
                    assert len(addresses) == 5
                else:
                    assert False, "should've thrown"

# Test support for connecting to multiple DALI busses through one hat
@test
def test_multi_bus():
    with setup_sim(channels=4), mock_time('2020-06-23 00:00:00+00:00'):
        devices = list(dali.DUMB_DB.full_scan())
        assert len(devices) == 40

        (new, total) = dali.DUMB_DB.assign_addresses()
        assert total == 40

    with setup_sim(channels=4, active_channels={0,3}) as sim, mock_time('2020-06-23 00:00:00+00:00'):
        dali.DUMB_DB.reset_all_info()
        # This is kinda gross, and a bad separation of concerns. Ideally we'd
        # do this at the beginning of full_scan(), but that screws up other
        # things: we call full_scan() all the time in the monitor thread, and
        # we don't want a ton of extra hat traffic, which also interferes with
        # reading other traffic off the bus
        dali.DUMB_DB.init_busses()

        devices = list(dali.DUMB_DB.full_scan().values())
        assert len(devices) == 20, len(devices)
        assert all(d['channel'] in {0, 3} for d in devices)

        (new, total) = dali.DUMB_DB.assign_addresses()
        assert total == 20

        # Update some virtual groups, make sure inactive busses work
        sim.reset_trace()
        client = get_client()
        for channel in range(4):
            update_virtual_group(client, channel, 0, None, [40, 41])
        check_sim_trace(sim, [
            ['send', 't5160\n'], ['recv', 'N\n'],
            ['send', 't5360\n'], ['recv', 'N\n'],
            ['send', '3t5160\n'], ['recv', '3N\n'],
            ['send', '3t5360\n'], ['recv', '3N\n'],
        ])

    with setup_sim(channels=4, active_channels={}) as sim:
        n_devices = dali.DUMB_DB.scan()
        assert n_devices == -1, n_devices

# Test topology detection using DR2G's power reading features
@test
def test_dr2g_topology():
    n_devices = 10
    with setup_sim(n_devices=n_devices, upcs=[dali_cmds.DR2G32_UPC]) as sim:
        # Build up a tree structure of all devices
        trees = [[0, 1, 2], [3, 4, [5, 6], 7], [8, 9]]

        def walk(node, distance, parents):
            parents = parents.copy()
            for light in node:
                distance += random.randrange(1, 20)
                if isinstance(light, int):
                    dev = sim.devices[0][light]
                    dev.dr2g_distance = distance

                    for p in parents:
                        parent = sim.devices[0][p]
                        parent.dr2g_related_devs.append(dev)
                        dev.dr2g_related_devs.append(parent)
                    parents.append(light)
                else:
                    walk(light, distance, parents)

        for tree in trees:
            walk(tree, 0, [])

        dali.DUMB_DB.full_scan()

        list(dali.DUMB_DB.read_dr2g_topology_gen())

# Test the firmware simulation code. This runs the actual firmware through
# a shim that interprets GPIO pin flips as DALI
# Disabled for now because it's slow
#@test
def test_fw_sim():
    with setup_sim(n_devices=1, fw_sim=True, assign_addresses=False) as sim:
        n_devices = len(dali.DUMB_DB.full_scan())
        assert n_devices == 0, n_devices

        (new, total) = dali.DUMB_DB.assign_addresses()

        assert new == total == 1, (new, total)

        n_devices = len(dali.DUMB_DB.full_scan())
        assert n_devices == 1
        state = dali.DUMB_DB.get_device_state('0_s_16')

        assert state['serial_nb'] == (FAKE_MAC & 0xFFFFFF) << 8 | 64

    with setup_sim(n_devices=3, fw_sim=True, assign_addresses=False) as sim:
        n_devices = len(dali.DUMB_DB.full_scan())
        assert n_devices == 0, n_devices
    
        (new, total) = dali.DUMB_DB.assign_addresses()
    
        assert new == total == 3, (new, total)
    
        n_devices = len(dali.DUMB_DB.full_scan())
        assert n_devices == 3
    
        for n in range(3):
            state = dali.DUMB_DB.get_device_state('0_s_%s' % (n + 16))
            assert state['serial_nb'] == (FAKE_MAC & 0xFFFFFF) << 8 | (64 + n), state

# Test the DALI stress-test code
#@test
def test_fw_bus():
    # Whitelist of subprocess.Popen calls
    procs = [
        [(['/home/pi/hue/fw/dr2f32/run.sh', 'deb', 'run'],),
            {'stdin': subprocess.PIPE, 'stdout': subprocess.PIPE, 'bufsize': 0}],
    ]
    with trace_procs(ORIG_POPEN, procs):
        with setup_sim(n_devices=1, fw_sim=True, assign_addresses=False) as sim:
            # Start the stress test
            n_packets = 40
            packets = sim.run_stress_test(n_packets)

            # Run the receiver for the stress test, collecting only error statuses.
            # We can only use a timeout of zero here because blank reads from the
            # serial bus also trigger the FakeSerialBus to call into the firmware
            # idle loop to possibly send more commands (which it will since
            # it's in stress mode). So there will be a steady stream of more packets
            # after this, but with single blank reads in between; if the timeout is
            # >0, there will never be a quiet enough period on the bus to stop.
            statuses = list(dali.DUMB_DB.busses[0].recv_stress_test_gen(timeout=0))
            errors = [msg for [error, msg] in statuses if error]

            check_lists_eq('stress test errors', errors, [])
            assert len(statuses) == 2 * n_packets

# Test the on/off/level code
@test
def test_on_off():
    with setup_sim() as sim:
        client = get_client()

        dali.DUMB_DB.scan()
        state = dali.DUMB_DB.get_device_state('0_s_0')
        assert state['level'] == 0

        # A sequence of on/off or level set commands, and the corresponding
        # on/off/level state we should see afterwards.
        TEST_CASES = [
            # Normal level set, as a switch would send
            [[None,    20], [True,  20]],
            # Normal level set to 0, keep the old level and just turn it off
            [[None,     0], [False, 20]],
            # Set the level back to 20, should turn it on
            [[None,    20], [True,  20]],
            # Turn back on and then off, stay at 20
            [[True,  None], [True,  20]],
            [[False, None], [False, 20]],
            # Turn up to 40, turn off and on
            [[None,    40], [True,  40]],
            [[False, None], [False, 40]],
            [[True,  None], [True,  40]],
            # Make sure sending both level and on/off works
            [[True,    50], [True,  50]],
            [[False,    0], [False, 50]],
            # Weird edge cases, inconsistent on/level commands. Not
            # really necessary to test but oh well.
            # XXX Level takes precedence over on/off because of alphabetical order
            #[[True,     0], [False,  0]],
            #[[True,  None], [True, 254]],
            #[[False,   30], [True,  30]],
        ]
        # Do the full test run on both the normal and hue APIs
        for (api, on_attr, level_attr) in [
                ['api', 'dev_on', 'level'], 
                ['hue', 'on', 'bri']]:
            for test_case in TEST_CASES:
                ((set_on, set_level), (test_on, test_level)) = test_case
                # Set up the JSON post data
                data = {}
                if set_on is not None:
                    data[on_attr] = set_on
                if set_level is not None:
                    data[level_attr] = set_level

                if api == 'hue':
                    response = client.check_put('/state', json={'0_s_0': data})
                else:
                    response = client.check_post('/dali/api/devices/0_s_0', json=data)

                # Check the data we get from the database
                state = dali.DUMB_DB.get_device_state('0_s_0')
                #print(state['dev_on'], state['level'])
                assert state['dev_on'] == test_on
                assert state['level'] == test_level

                # Check the data we get from the fake device
                #print(sim.devices[0][0].level)
                assert sim.devices[0][0].level == (test_level if test_on else 0)

@test
def test_set_dali_light_state():
    with setup_sim() as sim:
        dali.DUMB_DB.scan()

        lights = [1, 2, 3]
        for light in lights:
            data = {'level': 52, 'groups': [4]}
            address = (0, 'single', light)
            result = dali.DUMB_DB.set_dali_light_state(address, data)
            assert isinstance(result, dict), result
            assert result['address'] == address
            assert result['level'] == 52
            assert result['groups'] == [4]

        result = dali.DUMB_DB.set_dali_light_state((0, 'group', 4), {'level': 50})
        assert isinstance(result, list)
        assert len(result) == 3
        assert all(r['level'] == 50 and r['short_addr'] == light
                for light, r in zip(lights, result)), result

# Test the send-power-on-level option
@test
def test_power_on_level():
    with setup_sim(fake_upcs=True, n_devices=8) as sim:
        client = get_client()

        response = client.check_post('/dali/api/set-site-option',
                data={'send_power_on_level': 'on'}, status=302)
        assert config.SITE_SETTINGS.send_power_on_level == True

        # Meh
        dali.DUMB_DB.ensure_scanned()
        addresses = list(dali.DUMB_DB.full_scan())
        assert len(addresses) == 8
        sim.reset_trace()

        # Send out one level broadcast. We should be updating two lights'
        # power on levels, since fake_upcs sets up an ATX-LED UPC for lights
        # that are != 0 or 4 mod 5
        response = client.check_post('/dali/api/devices/all', json={'level': 43})
        # XXX It's weird to depend on the order of attributes for this. Oh well
        #   (fail_level < level < power_on_level)
        check_sim_trace(sim, [
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't012C\n'], ['recv', 'N\n'],
            ['send', 'hFE2B\n'], ['recv', 'N\n'],
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't012D\n'], ['recv', 'N\n'],
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't092C\n'], ['recv', 'N\n'],
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't092D\n'], ['recv', 'N\n'],
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't0B2C\n'], ['recv', 'N\n'],
            ['send', 'hA32B\n'], ['recv', 'N\n'],
            ['send', 't0B2D\n'], ['recv', 'N\n'],
        ])

        power_on_levels = [dev.power_on_level for dev in sim.devices[0]]
        assert power_on_levels == [43, 0, 0, 0, 43, 43, 0, 0]

        response = client.check_post('/dali/api/set-site-option',
                data={'send_power_on_level': 'off'}, status=302)
        assert config.SITE_SETTINGS.send_power_on_level == False

@test
def test_failover():
    with setup_sim(channels=1, n_devices=5) as sim:
        dali.DUMB_DB.ensure_scanned(rescan=1)
        client = get_client()

        dali.DUMB_DB.set_dali_light_state('all', {'level': 254})

        # Enable failover
        response = client.check_post('/dali/api/set-site-option',
                data={'manage_failover': 'on', 'failover_level': 128}, status=302)

        sim.reset_trace()

        # Fake a P output from the hat to indicate failure on one channel
        dali.DUMB_DB.update_from_dali_cmd('P4764150\n')
        for d in sim.devices[0]:
            assert d.level == 128, d.level
        assert dali.FAILOVER_STATUS == 128

        # Now fake an power-ok update from another device
        response = client.check_post('/dali/api/send-raw', json={'commands': ['hA3FF', 'hFF31']})
        assert dali.FAILOVER_STATUS == 255

        check_sim_trace(sim, [
            ['send', 'hA380\n'], ['recv', 'N\n'],
            ['send', 'hFF31\n'], ['recv', 'N\n'],
            ['send', 'hA3FF\n'], ['recv', 'N\n'],
            ['send', 'hFF31\n'], ['recv', 'N\n'],
        ])

        # Re-disable failover
        response = client.check_post('/dali/api/set-site-option',
                data={'manage_failover': 'off'}, status=302)

# Test passive DALI devices
@test
def test_passive_devices():
    # Set up a bus with one fake passive device
    devices = [fake_dali.FakeDevice(short_addr=5, is_passive=True)]
    with setup_sim(devices=devices) as sim:
        dali.DUMB_DB.full_scan()
        client = get_client()

        client.check_put('/state', json={'0_s_5': {'bri': 111}})

        client.check_post('/dali/api/devices/0_p_5', json={'level': 111})

        response = client.check_get('/dali/api/devices/0_p_5')
        data = response.get_json()['data']
        assert data['dev_name'] == 'Passive Switch or Button 5', data

        client.check_post('/dali/api/devices/0_p_5',
                json={'dev_name': 'cool light'})

        # Helper to check the database entries
        def check_db_entries(expected):
            with db.db_session() as session:
                entries = [(d.dali_addr_short, d.name)
                        for d in session.query_all(db.PassiveDevice)]
            assert entries == expected, entries

        check_db_entries([(5, 'cool light')])

        dali.DUMB_DB.reassign_address(0, 5, 17)

        check_db_entries([(17, 'cool light')])

        dali.DUMB_DB.reassign_address(0, 17, 255)

        check_db_entries([])

# Test DALI button devices
@test
def test_button_devices():
    # Set up a bus with one fake passive device
    devices = [fake_dali.FakeDevice(upc=dali_cmds.DALI_8B_UPC)]
    with setup_sim(devices=devices) as sim:
        [new, total] = dali.DUMB_DB.assign_addresses()
        assert new == 1
        assert sim.devices[0][0].short_addr == 16

        dali.DUMB_DB.full_scan()

        buttons = list(dali.DUMB_DB.get_button_devices_state())
        assert len(buttons) == 1, buttons

        sim.reset_trace()

        btn_cfg = buttons[0]['buttons'].copy()
        btn_cfg[3] = {
            'id': 3,
            'address': 44,
            'send_mode': 'all',
            'pairwise': True,
            'led_mode': 'on_off',
        }
        dali.DUMB_DB.set_dali_light_state('0_s_16', {'buttons': btn_cfg})

        check_sim_trace(sim, [
            ['send', 'hA31B\n'], ['recv', 'N\n'],
            ['send', 'hC300\n'], ['recv', 'N\n'],
            ['send', 't2181\n'], ['recv', 'N\n'],
            ['send', 'hC7F8\n'], ['recv', 'JF8\n'],
            ['send', 'hA31C\n'], ['recv', 'N\n'],
            ['send', 'hC300\n'], ['recv', 'N\n'],
            ['send', 't2181\n'], ['recv', 'N\n'],
            ['send', 'hC72C\n'], ['recv', 'J2C\n'],
        ])

        assert sim.devices[0][0].mem[0][27:29] == [0xF8, 0x2C]

# Test address reassigning, making sure serial numbers and device names
# stay the same
@test
def test_reassignment():
    with setup_sim() as sim:
        dali.DUMB_DB.scan()

        serial_nb = 0xabcdef00
        dali.DUMB_DB.set_dali_light_state('0_s_0',
               {'serial_nb': serial_nb, 'dev_name': 'abc'})

        light = dali.DUMB_DB.get_device_state('0_s_0')
        assert light['dev_name'] == 'abc'

        dali.DUMB_DB.reassign_address(0, 0, 44)
        dali.DUMB_DB.full_scan()

        light = dali.DUMB_DB.get_device_state('0_s_44')
        assert light['dev_name'] == 'abc'

# Test device database handling: dealing with missing devices, setting info in the
# db given possibly incomplete device information, etc
@test
def test_device_db():
    def check_db_devs(expected, missing_devices={}):
        with db.db_session() as session:
            entries = [(d.channel_id, d.dali_addr_short, d.serial_number, d.name)
                    for d in session.query_all(db.Device)]
        assert entries == expected, entries
        assert dali.DUMB_DB.missing_devices == missing_devices

    # Test 1: set name with/without serial number
    serial_nb = 0xabcdef00
    devices = [fake_dali.FakeDevice(short_addr=0, serial_nb=serial_nb)]
    with setup_sim(devices=devices) as sim:
        dali.DUMB_DB.scan()

        # Set a name before the full scan, so we get a db entry with no serial
        dali.DUMB_DB.set_dali_light_state('0_s_0', {'dev_name': 'abc'})
        check_db_devs([(0, 0, None, 'abc')])

        dali.DUMB_DB.full_scan()
        assert dali.DUMB_DB.get_device_state('0_s_0')['serial_nb'] == serial_nb

        # Set a name again: this should update the db entry with the new name
        # and the serial number too
        dali.DUMB_DB.set_dali_light_state('0_s_0', {'dev_name': 'abcd'})
        check_db_devs([(0, 0, serial_nb, 'abcd')])

        # Start over and insert some crap into the db, to simulate the weird old
        # db update behavior
        reset_db()
        with db.db_session() as session:
            session.add(db.Device(channel_id=0, dali_addr_short=0,
                        name='abc'))
            session.add(db.Device(channel_id=0, dali_addr_short=0,
                        serial_number=serial_nb, name='abcd'))
        check_db_devs([(0, 0, None, 'abc'), (0, 0, serial_nb, 'abcd')])

        # Set a name again, along with a new serial: this should update the db entry
        # and delete the old crap
        dali.DUMB_DB.set_dali_light_state('0_s_0', {'serial_nb': serial_nb+1, 'dev_name': 'abcde'})
        check_db_devs([(0, 0, serial_nb+1, 'abcde')])

    # Test 2: set info on a device that later collides with a different device in the db
    devices = [fake_dali.FakeDevice(short_addr=1, serial_nb=serial_nb+1)]
    with setup_sim(devices=devices) as sim:
        dali.DUMB_DB.reset_all_info()
        dali.DUMB_DB.scan()

        dali.DUMB_DB.set_dali_light_state('0_s_1', {'dev_name': 'abc'})
        check_db_devs([(0, 0, serial_nb+1, 'abcde'), (0, 1, None, 'abc')])

        # Now do a full scan, where we come to the shocking realization that we have two
        # db entries for the same device with conflicting info
        dali.DUMB_DB.full_scan()

        # Should get new address and new name
        check_db_devs([(0, 1, serial_nb+1, 'abc')])

        # Reassign to another address
        dali.DUMB_DB.reassign_address(0, 1, 17)
        check_db_devs([(0, 17, serial_nb+1, 'abc')])

        # Remove the device, make sure it's shown as missing
        sim.devices[0] = []
        dali.DUMB_DB.full_scan()
        check_db_devs([(0, 17, serial_nb+1, 'abc')], missing_devices={(0, 17): 'abc'})

        # Unassign the address (should remove from the db)
        dali.DUMB_DB.reassign_address(0, 17, 255)
        check_db_devs([], missing_devices={(0, 17): 'abc'})
        # ...and after a scan, should not be missing anymore
        dali.DUMB_DB.full_scan()
        check_db_devs([])

    # Test 3: more colliding
    devices = [fake_dali.FakeDevice(short_addr=1, serial_nb=serial_nb)]
    with setup_sim(devices=devices) as sim:
        # Start with one entry in the db
        reset_db()
        with db.db_session() as session:
            session.add(db.Device(channel_id=0, dali_addr_short=0,
                        serial_number=serial_nb+1, name='abcde'))
        dali.DUMB_DB.reset_all_info()
        dali.DUMB_DB.scan()

        # Set a device name
        dali.DUMB_DB.set_dali_light_state('0_s_1', {'dev_name': 'abc'})
        check_db_devs([(0, 0, serial_nb+1, 'abcde'), (0, 1, None, 'abc')])

        # Do a full scan, should update the second entry and recognize one missing device
        dali.DUMB_DB.full_scan()
        check_db_devs([(0, 0, serial_nb+1, 'abcde'), (0, 1, serial_nb, 'abc')],
                missing_devices={(0, 0): 'abcde'})

        # Update the serial number manually and scan--should merge the entries
        sim.devices[0][0].mem[0][11:15] = dali_cmds.mem_from_int(serial_nb+1, 4)
        dali.DUMB_DB.blacklist_all_addresses()
        dali.DUMB_DB.full_scan()
        assert dali.DUMB_DB.get_device_state('0_s_1')['serial_nb'] == serial_nb+1
        check_db_devs([(0, 1, serial_nb+1, 'abc')])

        # Set the device name again, should update the entry
        dali.DUMB_DB.set_dali_light_state('0_s_1', {'dev_name': 'abcdef'})
        check_db_devs([(0, 1, serial_nb+1, 'abcdef')])

# Test the serial number assignment. We shouldn't get duplicate serials ever,
# even when several devices start out with the same short address... whoops.
# And if we do accidentally assign colliding serials, address assignment should
# handle that by reassigning a new serial
@test
def test_serial_numbers():
    with setup_sim() as sim:
        # Hackily make a bunch of devices collide on one address
        for d in sim.devices[0]:
            d.short_addr = 33

        # Assign addresses
        with filter_logs('bogus'):
            (new, total) = dali.DUMB_DB.assign_addresses()
        assert total == 10
        assert len({d.short_addr for d in sim.devices[0]}) == 10

        serials = {dali_cmds.int_from_mem(d.mem[0][11:15]) for d in sim.devices[0]}
        assert len(serials) == 10
        assert 0 not in serials

    with setup_sim() as sim:
        # Hackily make a bunch of devices collide on one serial number
        for d in sim.devices[0]:
            d.mem[0][11:15] = [0,0,0,1]
        # Assign addresses
        (new, total) = dali.DUMB_DB.assign_addresses()
        assert total == 10
        assert len({d.short_addr for d in sim.devices[0]}) == 10

        serials = {dali_cmds.int_from_mem(d.mem[0][11:15]) for d in sim.devices[0]}
        assert len(serials) == 10
        assert 0 not in serials
        assert 1 in serials

@test
def test_locks():
    # Test the fancy double-reentrant-locking mechanism for the DALI bus. We
    # had deadlocks happening in real life so we gotta test now.
    def run(thread_id, low_priority):
        dali._DALI_THREAD_LOCALS.is_low_priority = low_priority
        sleep = lambda: SLEEP(.0001 if low_priority else .0002)
        for i in range(50):
            #print('try lock %s %s %s' % (thread_id, low_priority, i))
            with dali.get_dali_lock(0):
                sleep()
                with dali.get_dali_lock(0):
                    sleep()
                    with dali.get_dali_lock(0):
                        #print('got lock %s %s %s' % (thread_id, low_priority, i))
                        sleep()
            sleep()

    threads = [threading.Thread(target=run, args=(i, bool(i&3))) for i in range(4)]
    [t.start() for t in threads]
    [t.join() for t in threads]

    # Also test the db/DALI lock ordering mechanism. We have checks to make sure
    # that the DALI lock must be acquired before the db lock if both are held
    # in order to prevent deadlocks
    for low_pri in [True, False]:
        dali._DALI_THREAD_LOCALS.is_low_priority = low_pri
        try:
            with db.db_session():
                with dali.get_dali_lock(0):
                    pass
        except AssertionError:
            pass
        else:
            assert False, "didn't throw"

# Basic test of Hue API endpoints
@test
def test_hue_api():
    with setup_sim() as sim:
        client = get_client()

        # First, test the initial/default state of the 'hidden' feature.
        # Old devices that were already in the database before the hide
        # feature was introduced default to not hidden, new devices not
        # in the db default to hidden. So create a database device and
        # make sure only that device shows up (others are new)
        with db.db_session() as session:
            session.upsert(db.Device, {}, channel_id=0, dali_addr_short=2)
        response = client.check_get('/detect')
        assert len(response.get_json()['light_ids']) == 1

        # Now unhide everything so the normal test code below works
        response = client.check_post('/dali/api/devices/all',
                json={'hue_hidden': False})

        # Test get of /state
        response = client.check_get('/state')
        assert len(response.get_json()) == 10

        # Test /detect
        response = client.check_get('/detect')
        assert len(response.get_json()['light_ids']) == 10

        # Test put to /state
        sim.reset_trace()
        response = client.check_put('/state', json={'0_s_1': {'bri': 37}})
        check_sim_trace(sim, [['send', 'h0225\n'], ['recv', 'N\n']])

        # Check that device 2 got updated
        response = client.check_get('/state')
        data = response.get_json()
        assert len(data) == 10
        assert data['0_s_1']['bri'] == 37
        response = client.check_get('/state?light=0_s_1')
        assert response.get_json()['bri'] == 37

        # Set a device as hidden, make sure it doesn't show up in a scan
        response = client.check_post('/dali/api/devices/0_s_2',
                json={'hue_hidden': True})
        response = client.check_get('/detect')
        assert len(response.get_json()['light_ids']) == 9
        response = client.check_get('/state')
        assert len(response.get_json()) == 9

        # Set a hue name for a device
        response = client.check_post('/dali/api/devices/0_s_3',
                json={'hue_name': 'cool light bro'})
        lights = client.check_get('/state').get_json()
        device = lights['0_s_3']
        assert device['name'] == 'cool light bro'

        # Set a name through hue, should override both names
        response = client.check_put('/state', json={'0_s_3': {'name': 'whoa dude'}})
        response = client.check_get('/dali/api/devices/0_s_3')
        device = response.get_json()['data']
        assert device['dev_name'] == 'Switch 3'
        assert device['hue_name'] == 'whoa dude'

        # Set up a named group, should not show up in hue just yet (hidden)
        client.check_post('/dali/api/devices/0_s_0', json={'groups': [3]})
        client.check_post('/dali/api/devices/0_s_1', json={'groups': [3]})
        client.check_post('/dali/api/devices/0_g_3', json={'dev_name': 'g3'})

        lights = client.check_get('/detect').get_json()['light_ids']
        assert len(lights) == 9

        # Now unhide the group, and then it should show up
        client.check_post('/dali/api/devices/0_g_3', json={'hue_hidden': False})

        response = client.check_get('/detect')
        lights = response.get_json()['light_ids']
        assert len(lights) == 10
        assert lights[-1]['name'] == 'g3'

        response = client.check_get('/state')
        lights = response.get_json()
        assert len(lights) == 10
        group = lights['0_g_3']
        assert group['bri'] == 37

        response = client.check_get('/state?light=0_g_3')
        assert response.get_json()['name'] == 'g3'

        # Make sure setting state to a group works too
        client.check_put('/state', json={'0_g_3': {'name': 'g3!'}})
        response = client.check_get('/state?light=0_g_3')
        assert response.get_json()['name'] == 'g3!'
        response = client.check_get('/state?light=0_s_1')
        assert response.get_json()['name'] == 'Switch 1'
        client.check_put('/state', json={'0_g_3': {'bri': 129}})
        response = client.check_get('/state')
        lights = response.get_json()
        assert all(lights[l]['bri'] == 129 for l in ['0_g_3', '0_s_0', '0_s_1'])

# Test Hue protocol emulation
#@test
def test_hue_emu():
    with setup_sim(n_devices=1) as sim:
        client = get_client()

        # Un-hide lights, ugh
        dali.ensure_scanned()
        dali.DUMB_DB.set_dali_light_state('all', {'hue_hidden': False})

        hue.push_link_button()
        key = hue.create_new_user('Jim')

        # Run a list of test cases. Each test case is a list of this data:
        # [http method, http endpoint, json data, expected response json]
        def run_tests(cases):
            for [method, path, send, recv] in cases:
                path = path.format(key=key)
                resp = client.check_req(path, method=method, json=send)
                assert resp.status_code == 200, resp
                import pprint
                left = pprint.pformat(resp.get_json(), width=40).splitlines()
                right = pprint.pformat(recv, width=40).splitlines()
                check_trace(left, right, msg='Error in %s %s' % (method, path))
                assert resp.get_json() == recv, (resp.get_json(), recv)

        # Test groups
        run_tests([
            ['GET', '/api/{key}/groups',
                None,
                {}],
            ['POST', '/api/{key}/groups',
                {'name': 'Living room', 'lights': ['1'], 'type': 'Room',
                    'class': 'Living room'},
                [{'success': {'id': '1'}}]],
            ['GET', '/api/{key}/groups',
                None,
                {'1': {'name': 'Living room', 'lights': ['1'],
                    'type': 'Room', 'class': 'Living room',
                    'state': {'any_on': False, 'all_on': False}}}],
        ])

        # Test scenes
        run_tests([
            ['POST', '/api/{key}/scenes',
                {'type': 'GroupScene', 'group': '1', 'lightstates':
                    {'1': {'on': True, 'bri': 144, 'ct': 447}},
                    'name': 'Relax', 'recycle': False,
                    'appdata': {'version': 1, 'data': 'sdfHs_r01_d01'}},
                [{'success': {'id': '1'}}]],
            ['GET', '/api/{key}/scenes',
                None,
                {'1': {'group': '1', 'name': 'Relax', 'type': 'GroupScene',
                    'lightstates': {'1': {'bri': 144, 'ct': 447, 'on': True}}}}],
        ])

        # Test lights
        run_tests([
            ['GET', '/api/{key}/lights',
                None,
                {'1': {'manufacturername': 'Philips', 'modelid': 'ATX-LED',
                    'name': 'Switch 0', 'state': {'bri': 0, 'colormode': 'ct',
                        'ct': 1000.0, 'on': False, 'reachable': True},
                    'swversion': '1.46.13_r26312', 'type': 'ATX LED Light',
                    'uniqueid': '00:17:88:01:00:00:00:00-0b'}}]
        ])

        bridge_id = hue.get_bridge_id()
        ip_addr = util.get_ip_address()
        mac_addr = ':'.join(util.chunked(util.get_mac_address(), 2))

        # Test basic config
        run_tests([
            ['GET',  '/api/{key}/config', 
                None, 
                {'UTC': '2020-08-18T00:00:00', 'apiversion': '1.65.0',
                    'backup': {'errorcode': 0, 'status': 'idle'},
                    'bridgeid': bridge_id, 'datastoreversion': '87', 'dhcp': True,
                    'factorynew': False, 'gateway': '192.168.0.1',
                    'internetservices': {'internet': 'connected',
                        'remoteaccess': 'connected', 'swupdate': 'connected',
                        'time': 'connected'}, 'ipaddress': ip_addr,
                    'linkbutton': False, 'localtime': '2020-08-18T00:00:00',
                    'mac': mac_addr, 'modelid': 'BSB002', 'name': 'Philips hue',
                    'netmask': '255.255.255.0', 'portalconnection': 'connected',
                    'portalservices': True,
                    'portalstate': {'communication': 'disconnected',
                        'incoming': False, 'outgoing': True, 'signedon': True},
                    'proxyaddress': 'none', 'proxyport': 0,
                    'replacesbridgeid': None, 'starterkitid': '',
                    'swupdate': {'checkforupdate': False,
                        'devicetypes': {'bridge': False, 'lights': [],
                            'sensors': []}, 'notify': True, 'text': '',
                        'updatestate': 0, 'url': ''}, 
                    'swupdate2': {'autoinstall': {'on': True}},
                    'swversion': '1967113020', 'timezone': 'America/Chicago',
                    'zigbeechannel': 25}], 
            ['GET',  '/api/{key}', 
                None, 
                {'config': {'UTC': '2020-08-18T00:00:00', 'apiversion': '1.65.0',
                    'backup': {'errorcode': 0, 'status': 'idle'},
                    'bridgeid': bridge_id, 'datastoreversion': '87', 'dhcp': True,
                    'factorynew': False, 'gateway': '192.168.0.1',
                    'internetservices': {'internet': 'connected',
                        'remoteaccess': 'connected', 'swupdate': 'connected',
                        'time': 'connected'}, 'ipaddress': ip_addr,
                    'linkbutton': False, 'localtime': '2020-08-18T00:00:00',
                    'mac': mac_addr, 'modelid': 'BSB002', 'name': 'Philips hue',
                    'netmask': '255.255.255.0', 'portalconnection': 'connected',
                    'portalservices': True,
                    'portalstate': {'communication': 'disconnected',
                        'incoming': False, 'outgoing': True, 'signedon': True},
                    'proxyaddress': 'none', 'proxyport': 0,
                    'replacesbridgeid': None, 'starterkitid': '',
                    'swupdate': {'checkforupdate': False,
                        'devicetypes': {'bridge': False, 'lights': [],
                            'sensors': []}, 'notify': True, 'text': '',
                        'updatestate': 0, 'url': ''},
                    'swupdate2': {'autoinstall': {'on': True}},
                    'swversion': '1967113020', 'timezone': 'America/Chicago',
                    'zigbeechannel': 25}}],
        ])
# Basic test of JSON API endpoints
@test
def test_basic_api():
    with setup_sim(assign_addresses=False) as sim:
        client = get_client()

        # Get all device states
        response = client.check_post('/dali/api/assign-addresses')
        assert response.get_json()['ok']

        # Get all addresses
        response = client.check_get('/dali/api/addresses')

        # Get all device states
        response = client.check_get('/dali/api/devices')
        assert len(response.get_json()) == 10

        # Turn a light to half dim, check DALI trace
        sim.reset_trace()
        response = client.check_post('/dali/api/devices/0_s_17', json={'level': 37})
        check_sim_trace(sim, [['send', 'h2225\n'], ['recv', 'N\n']])

        # Check that device 17 got updated
        response = client.check_get('/dali/api/devices')
        data = response.get_json()
        assert len(data) == 10
        assert data['0_s_17']['level'] == 37

        # Turn a light to on, check DALI trace
        sim.reset_trace()
        response = client.check_post('/dali/api/devices/0_s_17', json={'dev_on': False})
        response = client.check_post('/dali/api/devices/0_s_17', json={'dev_on': True})
        response = client.check_post('/dali/api/devices/0_s_17', json={'dev_on': False})
        check_sim_trace(sim, [
            ['send', 'h2200\n'], ['recv', 'N\n'],
            ['send', 'h2225\n'], ['recv', 'N\n'],
            ['send', 'h2200\n'], ['recv', 'N\n'],
        ])

# Test groups
@test
def test_groups():
    with setup_sim() as sim:
        client = get_client()
        dali.DUMB_DB.full_scan()

        # Get all device states (mostly so we can separate the DALI traffic for
        # the bus scan and for the group update)
        response = client.check_get('/dali/api/devices')
        response = client.check_post('/dali/api/devices/0_s_1', json={'groups': []})

        # Make sure group numbering is right
        sim.reset_trace()
        response = client.check_post('/dali/api/devices/0_s_1', json={'groups': [1, 11]})
        check_sim_trace(sim, [
            ['send', 't0361\n'], ['recv', 'N\n'],
            ['send', 't036B\n'], ['recv', 'N\n'],
        ])

        # Make sure the groups get updated from groups on the bus
        def check(groups):
            assert sim.devices[0][1].groups == set(groups)
            assert dali.DUMB_DB.lights[(0, 1)]['groups'] == groups

        dali.DUMB_DB.send_cmd_raw('t0362\n')
        check([1, 11, 2])
        dali.DUMB_DB.send_cmd_raw('tFF62\n')
        check([1, 11, 2])
        dali.DUMB_DB.send_cmd_raw('t0363\n')
        check([1, 11, 2, 3])
        dali.DUMB_DB.send_cmd_raw('tFF72\n')
        check([1, 11, 3])
        dali.DUMB_DB.send_cmd_raw('tFF71\n')
        check([11, 3])

        # Test group naming
        response = client.check_post('/dali/api/devices/0_g_3', json={'hue_name': 'g3'})
        response = client.check_get('/dali/api/devices/0_s_1')
        device = response.get_json()['data']
        assert device['dev_name'] == 'Switch 1'
        response = client.check_get('/dali/api/groups')
        group = response.get_json()['0_g_3']
        assert group['hue_name'] == 'g3'
        assert group['device_ids'] == [1]

        with db.db_session() as session:
            [group] = session.query_all(db.Group)
            assert group.name == 'g3'

# Test scenes
@test
def test_scenes():
    with setup_sim(channels=2, n_devices=4) as sim:
        client = get_client()

        # Set all lights to one level
        response = client.check_post('/dali/api/devices/all', json={
                'level': 127, 'color_temp_k': 4000})

        # Capture a scene
        response = client.check_post('/dali/api/scenes/0/capture')
        scene_0 = response.get_json()['scene']

        # Change some light levels
        for light in range(3):
            response = client.check_post('/dali/api/devices/0_s_%s' % light,
                    json={'dev_on': False})

        # Capture another scene, using ID assignment
        response = client.check_post('/dali/api/scenes/capture')
        scene_1 = response.get_json()['scene']
        assert scene_1['id'] == 1

        # Remove some lights from both scenes and save as new scenes
        scene_2 = {addr: state for addr, state in scene_0['state'].items()
                if '_1' in addr}
        scene_3 = {addr: state for addr, state in scene_1['state'].items()
                if '_1' in addr}
        response = client.check_post('/dali/api/scenes/2', json={'state': scene_2})
        response = client.check_post('/dali/api/scenes/3', json={'state': scene_3})

        # Trigger the scenes and verify the levels match
        scene_levels = [
            [0, [127, 127, 127]],
            [1, [  0,   0,   0]],
            [2, [  0, 127,   0]],
            [3, [  0,   0,   0]],
        ]
        for scene, levels in scene_levels:
            response = client.check_post('/dali/api/scenes/%s/trigger' % scene)
            # Check internal sim levels
            assert all(sim.devices[0][i].level == level
                    for i, level in enumerate(levels))
            # Check database levels
            for i, level in enumerate(levels):
                [light] = dali.DUMB_DB.get_matching_lights('0_s_%s' % i)
                l = light['level'] if light['dev_on'] else 0
                assert l == level

        # Read back all scenes and verify the levels match
        scene_levels = dict(scene_levels)
        list(dali.DUMB_DB.read_scenes())

        for [scene, state] in dali.DUMB_DB.get_scenes().items():
            for i in range(4):
                s = state['state']['0_s_%s' % i]

                if scene in scene_levels and i < len(scene_levels[scene]):
                    level = scene_levels[scene][i]
                    assert s['level'] == level, (i, s)
                else:
                    assert not s['send_level'] or s['level'] == 127, (i, s)
                # Kind of a quick dumb test: rather than messing with a bunch
                # of code to change the color temperatures, just see that the
                # value is slightly different than the one we sent before due
                # to rounding, indicating it was read from the device and converted
                assert not s['send_color'] or s['color_temp_k'] == 4003, (i, s)

        # Create some mappings to trigger scenes
        mappings = [
            [0, 0, False, 0],
            [0, 0, True,  1],
            [0, 1, True,  1],
            [0, 3, False, 0],
            [1, 0, False, 2],
            [1, 0, True,  3],
        ]
        trigger_ids = []
        for [channel, addr, level_on, scene] in mappings:
            # Set address type to either single light/virtual device.
            # Either way should behave the same
            addr_type = 's' if level_on else 'd'
            address = '%s_%s_%s' % (channel, addr_type, addr)
            condition = 'level_%s' % ('on' if level_on else 'off')
            data = {'condition': {'address': address, 'type': condition},
                'actions': [{'scene_id': scene, 'type': 'trigger_scene'}]}
            response = client.check_put('/dali/schedule/api/entries', json=data)
            trigger_ids.append(response.get_json()['id'])

        # Flip some switches through raw commands, as if it
        # happened on the bus
        sim.reset_trace()
        commands = [
            'h0001',  # 0:0 set 1
            'h0300',  # 0:1 off
            'h0305',  # 0:1 max
            'h0700',  # 0:3 set 0
            'h0000',  # 0:0 set 0
            '1h0000', # 1:0 set 0
            '1h0106', # 1:0 min
            #'1h0102', # 1:0 dec
            #'1h0101', # 1:0 inc
        ]
        response = client.check_post('/dali/api/send-raw', json={'commands': commands})

        check_sim_trace(sim, [
            ['send', 'h0001\n'],  ['recv', 'N\n'],
            ['send', 'hFF11\n'],  ['recv', 'N\n'],
            ['send', '1hFF11\n'], ['recv', '1N\n'],

            ['send', 'h0300\n'],  ['recv', 'N\n'],
            ['send', 'h0305\n'],  ['recv', 'N\n'],
            ['send', 'hFF11\n'],  ['recv', 'N\n'],
            ['send', '1hFF11\n'], ['recv', '1N\n'],

            ['send', 'h0700\n'],  ['recv', 'N\n'],
            ['send', 'hFF10\n'],  ['recv', 'N\n'],
            ['send', '1hFF10\n'], ['recv', '1N\n'],

            ['send', 'h0000\n'],  ['recv', 'N\n'],
            ['send', 'hFF10\n'],  ['recv', 'N\n'],
            ['send', '1hFF10\n'], ['recv', '1N\n'],

            ['send', '1h0000\n'], ['recv', '1N\n'],
            ['send', 'hFF12\n'],  ['recv', 'N\n'],
            ['send', '1hFF12\n'], ['recv', '1N\n'],

            ['send', '1h0106\n'], ['recv', '1N\n'],
            ['send', 'hFF13\n'],  ['recv', 'N\n'],
            ['send', '1hFF13\n'], ['recv', '1N\n'],
        ])

        # Delete the mappings
        for trigger_id in trigger_ids:
            response = client.check_delete('/dali/schedule/api/entries/%s' % trigger_id)

# Test triggers
@test
def test_triggers():
    with setup_sim(n_devices=4) as sim:
        client = get_client()

        dali.DUMB_DB.scan()
        sim.reset_trace()

        trigger_ids = []
        def create_trigger(condition, delay, level, type='level_set'):
            actions = [{'type': type, 'address': 'all', 'level': level}]
            if delay:
                actions = [{'type': 'delay', 'delay_minutes': delay}] + actions

            data = {'condition': condition, 'actions': actions}
            response = client.check_put('/dali/schedule/api/entries', json=data)
            trigger_ids.append(response.get_json()['id'])

        def create_zwave_trigger(key, node_id, delay, level, type='level_set'):
            condition = {'type': 'zwave_generic', 'zwave_node_id': node_id,
                    'zwave_key': key}
            create_trigger(condition, delay, level, type=type)

        # Create some triggers from zwave actions
        key = ('scene', 0, 0)
        create_zwave_trigger(key, 2, 5, 254)
        create_zwave_trigger(key, 3, 10, 0)

        # Fake-trigger the zwave event a few times
        for node_id in [3, 2, 2, 3, 3, 2]:
            schedule.zwave_listener(node_id, key, None)

        # Create some more triggers with the fancy new cmp_gt/lt functionality
        node_id = 4
        key = ('sensor-multilevel',)
        create_zwave_trigger(key + ('cmp_gt', 4.5), node_id, 0, 80)
        create_zwave_trigger(key + ('cmp_lt', 2), node_id, 1, 40)
        # Trigger several sensor readings: should get two triggers of each.
        # The cmp_lt is delayed, so it should only be triggered once.
        for value in range(7):
            schedule.zwave_listener(node_id, key, None, fn_value=value)

        # Check the events from the non-delays trigger events
        check_sim_trace(sim, [
            ['send', 'hFE50\n'], ['recv', 'N\n'],
            ['send', 'hFE50\n'], ['recv', 'N\n'],
        ])
        sim.reset_trace()

        # Check that three events are queued. More reaching into schedule's
        # internals...
        assert len(schedule.SCHEDULE_QUEUE) == 3

        GPS_DATA = {'sunrise': '12:31,-300', 'sunset': '00:05'}
        with util.contexts(mock_time('2020-05-07 00:00:00+00:00', tz_offset=-300),
                mock_attr(schedule, 'get_gps_info', lambda: GPS_DATA)):
            for i in range(15):
                schedule.run_schedule_step()

        check_sim_trace(sim, [
            ['send', 'hFE28\n'], ['recv', 'N\n'],
            ['send', 'hFEFE\n'], ['recv', 'N\n'],
            ['send', 'hFE00\n'], ['recv', 'N\n'],
        ])

        # Test the dim up/down functionality, make sure it only affects
        # lights that are already on

        # Turn only light 3 on
        dali.DUMB_DB.set_level('all', 0)
        dali.DUMB_DB.set_level('0_s_3', 40)
        sim.reset_trace()

        # Trigger a dim up and down
        key = ('scene', 0, 0)
        create_zwave_trigger(key, 4, 0, 0, type='level_inc')
        create_zwave_trigger(key, 4, 0, 0, type='level_dec')
        schedule.zwave_listener(4, key, None)

        check_sim_trace(sim, [
            ['send', 'h0641\n'], ['recv', 'N\n'],
            ['send', 'h0628\n'], ['recv', 'N\n'],
        ])

        # Create some DALI level triggers
        cond = {'type': 'level_change', 'address': '0_s_0'}
        create_trigger(cond, 0, 254)

        # Send some level/status commands. Make sure the status command causes
        # triggers to be ignored for 90s
        sim.reset_trace()

        commands = ['h0001', 'h0190', 'h0001']
        response = client.check_post('/dali/api/send-raw', json={'commands': commands})
        time.sleep(89)
        commands = ['h0001']
        response = client.check_post('/dali/api/send-raw', json={'commands': commands})
        time.sleep(2)
        commands = ['h0001']
        response = client.check_post('/dali/api/send-raw', json={'commands': commands})

        check_sim_trace(sim, [
            ['send', 'h0001\n'], ['recv', 'N\n'],
            ['send', 'hFEFE\n'], ['recv', 'N\n'],
            ['send', 'h0190\n'], ['recv', 'J00\n'],
            ['send', 'h0001\n'], ['recv', 'N\n'],
            ['send', 'h0001\n'], ['recv', 'N\n'],
            ['send', 'h0001\n'], ['recv', 'N\n'],
            ['send', 'hFEFE\n'], ['recv', 'N\n'],
        ])

        # Delete the mappings
        for trigger_id in trigger_ids:
            response = client.check_delete('/dali/schedule/api/entries/%s' % trigger_id)

# Test that updating all/group state translates to DALI broadcast/group commands
@test
def test_command_grouping():
    with setup_sim(n_devices=3, channels=2) as sim:
        client = get_client()

        for dev in ['0_s_1', '0_s_2', '1_s_1']:
            response = client.check_post('/dali/api/devices/%s' % dev,
                    json={'groups': [1]})

        # Make sure group commands are sent for levels and for device off commands.
        # We can't easily and reliably send broadcast commands for device on
        # commands, since that might be setting each device to a different level.
        sim.reset_trace()
        for addr in ['0_g_1', '1_g_1', 'all']:
            for cmd in [{'level': 254}, {'dev_on': False}, {'dev_on': True}]:
                response = client.check_post('/dali/api/devices/%s' % addr, json=cmd)
        check_sim_trace(sim, [
            ['send', 'h82FE\n'],  ['recv', 'N\n'],
            ['send', 'h8200\n'],  ['recv', 'N\n'],
            ['send', 'h02FE\n'],  ['recv', 'N\n'],
            ['send', 'h04FE\n'],  ['recv', 'N\n'],
            ['send', '1h82FE\n'], ['recv', '1N\n'],
            ['send', '1h8200\n'], ['recv', '1N\n'],
            ['send', '1h02FE\n'], ['recv', '1N\n'],
            ['send', 'hFEFE\n'],  ['recv', 'N\n'],
            ['send', '1hFEFE\n'], ['recv', '1N\n'],
            ['send', 'hFE00\n'],  ['recv', 'N\n'],
            ['send', '1hFE00\n'], ['recv', '1N\n'],
            ['send', 'h00FE\n'],  ['recv', 'N\n'],
            ['send', 'h02FE\n'],  ['recv', 'N\n'],
            ['send', 'h04FE\n'],  ['recv', 'N\n'],
            ['send', '1h00FE\n'], ['recv', '1N\n'],
            ['send', '1h02FE\n'], ['recv', '1N\n'],
            ['send', '1h04FE\n'], ['recv', '1N\n'],
        ])

# Test all of our web interface. Just check for 200s now.
@test
def test_web_interface():
    # Whitelist of subprocess.Popen calls
    kwargs = {'stdout': subprocess.PIPE}
    procs = [
        [(['ps', '-ef'],), kwargs],
        [(['ip', 'route', 'get', '1.1.1.1'],), kwargs],
        [(['sudo', 'iwlist', 'wlan0', 'scan'],), kwargs],
        [(['wpa_cli', '-iwlan0', 'list_networks'],), kwargs],
        [(['/home/pi/atxled/hue/cron-boom/cron_boom.py', 'get-static-ip'],), kwargs],
    ]
    # Make all traced processes return no output and exit successfully
    fake_popen = lambda *a,**k: ORIG_POPEN(['true'], stdout=subprocess.PIPE)
    with setup_sim() as sim, trace_procs(fake_popen, procs):
        client = get_client()

        for [page, url, name] in serve.PAGES:
            response = client.check_get(url)

def update_virtual_device(client, channel, short_addr, name, groups):
    data = {}
    if name:   data['dev_name'] = name
    if groups: data['groups'] = groups

    response = client.check_post('/dali/api/virtual-devices/%d_d_%d' % (channel, short_addr),
            json=data)
    resp = response.get_json()
    assert resp['ok']
    assert resp['device']['groups'] == groups

# Test virtual devices
@test
def test_virtual_devices():
    with setup_sim(n_devices=4) as sim:
        client = get_client()

        def post_vd(name, devices):
            sim.reset_trace()
            update_virtual_device(client, 0, 7, name, devices)
        def get_vd():
            response = client.check_get('/dali/api/devices/0_d_7')
            data = response.get_json()
            assert data['ok']
            return data['data']

        # Add virtual device to groups 12 and 13
        post_vd(None, [12, 13])
        check_sim_trace(sim, [
            ['send', 't0F6C\n'], ['recv', 'N\n'],
            ['send', 't0F6D\n'], ['recv', 'N\n'],
        ])

        # Remove from group 13 and add to 14
        post_vd(None, [12, 14])
        check_sim_trace(sim, [
            ['send', 't0F7D\n'], ['recv', 'N\n'],
            ['send', 't0F6E\n'], ['recv', 'N\n'],
        ])

        # Check that the hue /state endpoint now returns 11 devices
        response = client.check_post('/dali/api/devices/all',
                json={'hue_hidden': False})
        response = client.check_get('/state')
        assert len(response.get_json()) == 5

        # Test put to /state
        sim.reset_trace()
        response = client.check_put('/state', json={'0_d_7': {'bri': 37}})
        check_sim_trace(sim, [['send', 'h0E25\n'], ['recv', 'N\n']])

        # Verify the information stored
        data = get_vd()
        assert data['address'] == [0, 'virtual-device', 7]
        assert data['dev_name'] == 'DMX Device 7'
        assert data['groups'] == [12, 14]
        assert data['level'] == 37

        # Test updating name
        post_vd('new vd name', [12, 14])
        dali.DUMB_DB.init_from_db()
        data = get_vd()
        assert data['dev_name'] == 'new vd name'
        assert data['groups'] == [12, 14]

        # Test a query of the fail level. We should respond after the N
        sim.reset_trace()
        client.check_post('/dali/api/send-raw',
                json={'commands': ['h0FA4']})

        check_sim_trace(sim, [
            ['send', 'h0FA4\n'],  ['recv', 'N\n'],
            ['send', 'hA301\n'],  ['recv', 'N\n'],
            ['send', 't0F2C\n'],  ['recv', 'N\n'],
        ])


def update_virtual_group(client, channel, group, name, devices):
    data = {'name': name, 'devices': devices}
    response = client.check_post('/dali/api/virtual-groups/%d/%d' % (channel, group),
            json=data)
    resp = response.get_json()
    assert resp['ok']
    assert resp['group'] == devices

# Test virtual groups
@test
def test_virtual_groups():
    with setup_sim() as sim:
        client = get_client()

        def post_vg(name, devices):
            sim.reset_trace()
            update_virtual_group(client, 0, 0, name, devices)
        def get_vg():
            response = client.check_get('/dali/api/devices/0_v_0')
            data = response.get_json()
            assert data['ok']
            return data['data']

        # Add 16 and 17 to a virtual group
        post_vg(None, [16, 17])
        check_sim_trace(sim, [
            ['send', 't2160\n'], ['recv', 'N\n'],
            ['send', 't2360\n'], ['recv', 'N\n']
        ])

        # Remove 17 and add 18 to the virtual group
        post_vg(None, [16, 18])
        check_sim_trace(sim, [
            ['send', 't2370\n'], ['recv', 'N\n'],
            ['send', 't2560\n'], ['recv', 'N\n']
        ])

        # Check that the hue /state endpoint now returns 11 devices
        response = client.check_post('/dali/api/devices/all',
                json={'hue_hidden': False})
        response = client.check_get('/state')
        assert len(response.get_json()) == 11

        # Test put to /state
        sim.reset_trace()
        response = client.check_put('/state', json={'0_v_0': {'bri': 37}})
        check_sim_trace(sim, [['send', 'h8025\n'], ['recv', 'N\n']])

        # Verify the information stored
        data = get_vg()
        assert data['address'] == [0, 'virtual-group', 0]
        assert data['dev_name'] == 'Virtual Group 0'
        assert data['devices'] == [16, 18]
        assert data['level'] == 37

        # Test updating name
        post_vg('new vg name', [16, 18])
        dali.DUMB_DB.init_from_db()
        data = get_vg()
        assert data['dev_name'] == 'new vg name'
        assert data['devices'] == [16, 18]

# Test virtual n-way
@test
def test_virtual_n_way():
    GROUPS = {
        # Bad 1: only one device
        0: [0],

        # Good 1: 3 devices
        1: [1, 2, 3],
        2: [1, 2, 3],
        3: [1, 2, 3],

        # Good 2: 4 devices
        4: [4, 5, 6, 7],
        5: [4, 5, 6, 7],
        6: [4, 5, 6, 7],
        7: [4, 5, 6, 7],

        # Bad 2: one missing group
        8: [8, 9, 10],
        9: [8, 9, 10],
        10: [8, 10],

        # Bad 3: one missing device
        11: [11, 12, 13],
        12: [11, 12, 13],

        # Bad 4: extra device >= 16
        14: [14, 15],
        15: [14, 15],
        18: [14, 15],
    }

    with setup_sim(channels=2, n_devices=20, upcs=[dali_cmds.DR2F32_UPC]) as sim:
        dali.DUMB_DB.full_scan()

        for channel in range(2):
            for [light, groups] in GROUPS.items():
                # Flip addresses 0-15 for channel 1
                if channel == 1:
                    light = 15 ^ light
                    groups = [15 ^ d for d in groups]
                address = (channel, 'single', light)
                data = {'groups': groups}
                result = dali.DUMB_DB.set_dali_light_state(address, data)

        vnw = dali.DUMB_DB.get_virtual_n_way_groups()
        vnw = [(v['channel'], v['device_ids']) for v in vnw]
        assert vnw == [
                (0, [1, 2, 3]),
                (0, [4, 5, 6, 7]),
                # I guess this just appears because device -3 (15-18) isn't checked
                (1, [0, 1]),
                (1, [8, 9, 10, 11]),
                (1, [12, 13, 14]),
        ], vnw

    # Make a virtual n-way group, make sure the right address/group updates happen
    with setup_sim(n_devices=5, upcs=[dali_cmds.DR2F32_UPC]) as sim:
        dali.DUMB_DB.blacklist_all_addresses()
        dali.DUMB_DB.full_scan()

        sim.reset_trace()
        # Create a new virtual n-way group
        dali.DUMB_DB.update_virtual_n_way(0, [1, 2])
        check_sim_trace(sim, [
            # First, addresses 0, 3, and 4 get reassigned since they're not
            # in groups
            ['send', 'hA321\n'], ['recv', 'N\n'],
            ['send', 't0180\n'], ['recv', 'N\n'],
            ['send', 'hA323\n'], ['recv', 'N\n'],
            ['send', 't0780\n'], ['recv', 'N\n'],
            ['send', 'hA325\n'], ['recv', 'N\n'],
            ['send', 't0980\n'], ['recv', 'N\n'],
            # ...then the groups for 1 and 2 get updated
            ['send', 't0361\n'], ['recv', 'N\n'],
            ['send', 't0362\n'], ['recv', 'N\n'],
            ['send', 't0561\n'], ['recv', 'N\n'],
            ['send', 't0562\n'], ['recv', 'N\n'],
        ])

    # Make sure the reassignment handles groups properly
    with setup_sim(n_devices=7, upcs=[dali_cmds.DR2F32_UPC]) as sim:
        dali.DUMB_DB.blacklist_all_addresses()
        dali.DUMB_DB.full_scan()

        dali.DUMB_DB.set_dali_light_state('0_s_0', {'groups': [0]})
        dali.DUMB_DB.set_dali_light_state('0_s_1', {'groups': [1, 2]})
        dali.DUMB_DB.set_dali_light_state('0_s_2', {'groups': [3]})

        # Set up group 6 with lights 6 + 16, to make sure we don't
        # reassign 6
        dali.DUMB_DB.set_dali_light_state('0_s_5', {'groups': [6]})
        dali.DUMB_DB.set_dali_light_state('0_s_6', {'groups': [6]})
        dali.DUMB_DB.reassign_address(0, 5, 16)
        dali.DUMB_DB.full_scan()

        sim.reset_trace()
        dali.DUMB_DB.update_virtual_n_way(0, [3, 4])

        check_sim_trace(sim, [
            # Remove group 0 from 0 and reassign to 17
            ['send', 't0170\n'], ['recv', 'N\n'],
            ['send', 'hA323\n'], ['recv', 'N\n'],
            ['send', 't0180\n'], ['recv', 'N\n'],
            # Set 3 and 4 in the same groups
            ['send', 't0763\n'], ['recv', 'N\n'],
            ['send', 't0764\n'], ['recv', 'N\n'],
            ['send', 't0963\n'], ['recv', 'N\n'],
            ['send', 't0964\n'], ['recv', 'N\n'],
            # Remove group 3 from 2
            ['send', 't0573\n'], ['recv', 'N\n'],
        ])

@test
def test_schedule():
    client = get_client()

    # Add some schedule entries
    entries = [
        ['specific', [8, 0],  '0_s_0', 0],
        ['specific', [16, 0], '0_s_1', 1],
        ['sunrise', [0, 20],  '0_s_2', 2],
        ['sunset', [0, -20],  '0_s_3', 3],
        ['specific', [0, 0],  '0_s_4', 4],
        ['specific', [12, 0], '0_s_5', 5],
        # An entry for a non-existent device to make sure they still get sent
        ['specific', [11, 0], '0_s_17', 6],
    ]
    for [type, [h, m], address, level] in entries:
        entry = {
            'condition': {
                'time': {'ampm': 'pm' if h >= 12 else 'am',
                    'hour': str((h-1) % 12 + 1), 'minute': '%02d' % abs(m)},
                'offset': {'minutes': abs(m),
                    'direction': 'before' if m < 0 else 'after'},
                'weekdays': ['Tu', 'Th'],
                'type': type,
            },
            'actions': [{'address': address, 'level': level}],
        }
        response = client.check_put('/dali/schedule/api/entries', json=entry)

    # An expected list of changes, each one a time, address, and level
    changes = iter([
        ['2019-10-08 00:00', '0_s_4', 4],
        ['2019-10-08 07:51', '0_s_2', 2],
        ['2019-10-08 08:00', '0_s_0', 0],
        ['2019-10-08 11:00', '0_s_17', 6],
        ['2019-10-08 12:00', '0_s_5', 5],
        ['2019-10-08 16:00', '0_s_1', 1],
        ['2019-10-08 18:45', '0_s_3', 3],
        ['2019-10-10 00:00', '0_s_4', 4],
        ['2019-10-10 07:51', '0_s_2', 2],
        ['2019-10-10 08:00', '0_s_0', 0],
        ['2019-10-10 11:00', '0_s_17', 6],
        ['2019-10-10 12:00', '0_s_5', 5],
        ['2019-10-10 16:00', '0_s_1', 1],
        ['2019-10-10 18:45', '0_s_3', 3],
    ])

    def fake_set_level(address, level):
        [test_dt, test_address, test_level] = next(changes)
        address = dali.get_nice_addr(*address)

        # Only test up until minutes
        dt = str(util.now())[:16]
        assert dt == test_dt, (dt, test_dt)
        assert address == test_address, (address, test_address)
        assert level == test_level, (level, test_level)

    GPS_DATA = {'sunrise': '12:31,-300', 'sunset': '00:05'}
    with util.contexts(setup_sim(),
            mock_time('2019-10-08 00:00:00+00:00', tz_offset=-300),
            mock_attr(schedule, 'get_gps_info', lambda: GPS_DATA)):
        # Scan the bus and replace the bus-specific set_level() function
        dali.DUMB_DB.scan()
        with mock_attr(dali.DUMB_DB.busses[0], 'set_level', fake_set_level):
            # Test three days worth of minutes
            for i in range(1440*3):
                schedule.run_schedule_step()
            try:
                last = next(changes)
            except StopIteration:
                pass
            else:
                assert False, 'did not hit all expected schedule entries: %s' % last

    with setup_sim(upcs=[dali_cmds.DR2F32_UPC]) as sim:
        # Test rolling scan
        with util.contexts(
                mock_time('2020-06-25 05:00:00+00:00', tz_offset=-300),
                mock_attr(schedule, 'get_gps_info', lambda: GPS_DATA)):
            # Do a full scan, to clear the blacklist
            dali.DUMB_DB.full_scan()

            # Run 5 minutes of schedule from 12am UTC
            for i in range(5):
                schedule.run_schedule_step()

            # Make sure a full scan only does a level check for the first
            # 5 addresses
            sim.reset_trace()
            dali.DUMB_DB.full_scan()
            check_sim_trace(sim, [
                ['send', 'v\n'],     ['send', 'd\n'],
                ['send', 'h01A0\n'], ['recv', 'J00\n'],
                ['send', 'h03A0\n'], ['recv', 'J00\n'],
                ['send', 'h05A0\n'], ['recv', 'J00\n'],
                ['send', 'h07A0\n'], ['recv', 'J00\n'],
                ['send', 'h09A0\n'], ['recv', 'J04\n'],
            ])

        # Test UPC check: remove a UPC code, make sure that device gets a full scan
        with util.contexts(
                mock_time('2020-06-25 05:00:00+00:00', tz_offset=-300),
                mock_attr(schedule, 'get_gps_info', lambda: GPS_DATA)):

            dali.DUMB_DB.set_dali_light_state('0_s_0', {'upc_code': 0})

            # Run 5 minutes of schedule from 12am UTC
            for i in range(5):
                schedule.run_schedule_step()

            # HACK: peek into DUMB_DB internals, easier than matching the trace
            blacklist = dali.DUMB_DB.address_blacklist[0]
            assert blacklist == [(0, False), (1, True), (2, True),
                    (3, True), (4, True)], blacklist

@test
def test_heartbeat():
    urls = []
    def fake_get(url):
        urls.append(url)
        return util.Object(status_code=200)
    base = 'http://sens.wifi-soft.com/sensors/services/datalogger'
    expected = [
        base + '?t=30&h=50&r=0&l=200&s=2841&w=dev&mac=FF%3AFF%3AFF%3ACB%3A34%3A7A&'
            'lat=30.2623&long=-97.7465&rssi=-72&F=1&up=1&n=0%2C91%2C0%2C0%2C9%2C11&'
            'v=02.21&db=47.5&f=1844&m=2000&e=1.7.0.0',
        base + '?t=61.8&h=47.6&r=1&l=-1&s=2841&w=dev&mac=FF%3AFF%3AFF%3ACB%3A34%3A7A&'
            'lat=30.2623&long=-97.7465&rssi=-72&F=2&up=1&n=0%2C91%2C0%2C0%2C9%2C11&'
            'v=02.21&db=47.5&f=15.703&m=0.084&p=0'
    ]

    # Set up a nonexistant device in the db so as to test the device counts
    with db.db_session() as session:
        session.add(db.Device(channel_id=1, dali_addr_short=17))

    with util.contexts(setup_sim(),
            mock_attr(config.SITE_SETTINGS, 'heartbeat_interval', 3),
            mock_attr(schedule, 'estimate_power_usage', lambda: -1),
            mock_time('2020-05-12 00:00:00', tz_offset=-300),
            mock_attr(requests, 'get', fake_get),
            mock_attr(util, 'get_zpds_version', lambda: 'dev'),
            mock_attr(util, 'get_uptime', lambda: 1),
            mock_attr(util, 'get_temp', lambda: '61.8'),
            mock_attr(wifi, 'get_wpa_status', lambda: {'signal_level': -72})):
        dali.DUMB_DB.full_scan()
        # Meh, send a color temperature so the last color part is deterministic
        dali.DUMB_DB.set_dali_light_state('all', {'color_temp_k': 2841})
        schedule.heartbeat()
        check_lists_eq('heartbeat URLs match', urls, expected)

@test
def test_event_streams():
    # Set up multiple busses with no devices (just to save the setup
    # time). We don't directly use the devices or anything, but manually
    # call the DALIBus.push_event() interface to test events/amending.
    with setup_sim(channels=4, n_devices=0) as sim:
        dali.DUMB_DB.ensure_scanned()

        # Helper function to send a couple fake messages on each bus, then a
        # response
        def push_events():
            for bus in dali.DUMB_DB.iter_busses():
                bus.push_event('send', 'hFE00')
                bus.push_event('send', 'hFEFE')
            for bus in dali.DUMB_DB.iter_busses():
                bus.push_event('recv', 'J00')

        # Get the relevant data in a simple format
        def get_events():
            attrs = ['seq', 'channel', 'raw', 'recv_raw']
            return [[event[attr] for attr in attrs]
                    for event in util.queue_to_list(q)]

        # Perform some events while listening. We should see both the
        # original send events as well as the amended ones
        dali.DUMB_DB.dali_events.clear_history()
        with dali.DUMB_DB.listen_all_busses() as q:
            push_events()

            check_trace(get_events(), [
                [1, 0, 'hFE00', ''],
                [2, 0, 'hFEFE', 'J00'],
                [3, 1, 'hFE00', ''],
                [4, 1, 'hFEFE', 'J00'],
                [5, 2, 'hFE00', ''],
                [6, 2, 'hFEFE', 'J00'],
                [7, 3, 'hFE00', ''],
                [8, 3, 'hFEFE', 'J00'],
                [2, 0, 'hFEFE', 'J00'],
                [4, 1, 'hFEFE', 'J00'],
                [6, 2, 'hFEFE', 'J00'],
                [8, 3, 'hFEFE', 'J00'],
            ])

        # Perform the same events while not listening. We should only
        # see the final amended events
        dali.DUMB_DB.dali_events.clear_history()
        push_events()
        with dali.DUMB_DB.listen_all_busses() as q:
            check_trace(get_events(), [
                [1, 0, 'hFE00', ''],
                [2, 0, 'hFEFE', 'J00'],
                [3, 1, 'hFE00', ''],
                [4, 1, 'hFEFE', 'J00'],
                [5, 2, 'hFE00', ''],
                [6, 2, 'hFEFE', 'J00'],
                [7, 3, 'hFE00', ''],
                [8, 3, 'hFEFE', 'J00'],
            ])

def reset_db():
    db.init_db('sqlite:///:memory:')

def reset_state():
    reset_db()

    # Initialize any state
    random.seed(0)
    serve.reload_db_info()

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.WARNING)
    #logging.getLogger().setLevel(logging.INFO)

    matches = sys.argv[1:]

    # Blacklist a bunch of methods to make sure testing is deterministic
    # and doesn't have any external side effects
    with util.contexts(
            # No web requests
            mock_attr(requests, 'request', None),
            mock_attr(requests, 'get', None),
            mock_attr(requests, 'post', None),
            # Fake time
            mock_time('2020-08-18 00:00:00+00:00'),
            # No subprocesses
            mock_attr(subprocess, 'Popen', None),
            # No serial bus
            mock_attr(dali.DUMB_DB.serial_device, 'conn', None),
            # No misc crap
            mock_attr(util, 'get_uptime', None),
            mock_attr(util, 'get_temp', None),
            mock_attr(wifi, 'get_wpa_status', lambda: {}),
            ):
        # Now run the tests
        failed = run_tests(matches=matches, setup=reset_state)

    sys.exit(1 if failed else 0)
