import sys

import requests

data = {'channel': 0, 'commands': sys.argv[1:]}
r = requests.post('http://localhost/dali/api/send-raw', json=data)
print(r.text)
