import contextlib
import importlib
import inspect
import json
from operator import invert
import os
import sys
import threading
import time
import traceback

import flask
from wss import websocket_server

import dali
import dali_cmds
import db
import util
from util import json_route

app = flask.Blueprint('hw_test', __name__, static_folder=None)
wsr = websocket_server.WebSocketRouter('/hw-test')
LOG = util.get_logger('hw-test')

TEST_EVENTS = util.EventStream()

TEST_LOCK = threading.RLock()
TEST_RUNNING = False
CANCEL_TEST = False

# For running tests from the fw_tests directory out of the ramdisk, we
# read the files first on bootup and save the contents as strings
FW_TEST_SRCS = None

ALL = 'all'

class TestCancellation(Exception):
    pass

def initialize_gpio():
    # Initialize GPIO
    import RPi.GPIO as GPIO
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    for port in [31, 33, 29, 37]:
        GPIO.setup(port, GPIO.OUT)
        GPIO.output(port, 0)

def turn_power_off():
    import RPi.GPIO as GPIO
    GPIO.setmode(GPIO.BOARD)
    GPIO.output(37, 0)
    time.sleep(.25)
    GPIO.output(29, 0)

    # Wait to get a low voltage message, voltage should be <9V before device
    # can be removed
    with get_dali_lock(None):
        for i in range(150):
            resp = self.read_line_raw(channel=0, allow_blank=True, log=True)
            if resp and len(resp) >= 4 and resp[0] == 'P':
                voltage = int(resp[1:4]) / 10
                if voltage < 9:
                    return True
    error('Could not turn power off!')
    return False

# If no test is running, make extra sure the power is off. This is called
# when the test page loads so plugging in a DR2 doesn't spark
def check_power_off():
    if not TEST_LOCK.acquire(blocking=False):
        return
    try:
        initialize_gpio()
    finally:
        TEST_LOCK.release()

################################################################################
## Helper functions ############################################################
################################################################################

def check_cancel():
    if CANCEL_TEST:
        LOG.info('cancelling test...')
        TEST_EVENTS.push({'msg': 'Test cancelled.', 'running': False})
        raise TestCancellation()

def status(data):
    check_cancel()
    LOG.info('test status: %s', data)
    TEST_EVENTS.push(data)

def message(msg, **kwargs):
    status({'msg': msg, **kwargs})

def error(test, msg):
    status({'result': [test, '', False, msg]})

def prompt(msg):
    status({'alert': msg})

def end_prompt():
    status({'alert': None})

def broadcast(cmd_lo, **kwargs):
    bus = dali.DUMB_DB.busses[0]
    resp = bus.send_normal_cmd(0xFE00 | cmd_lo, **kwargs)
    if resp and resp[0] == 'J':
        return int(resp[1:3], 16)
    return None

def read_watts(type):
    assert type in {0, 1, 3}
    resp = dali.DUMB_DB.send_conf_command('w%s\n' % type, 'W', log=True)
    if resp:
        resp = int(resp[1:])
        if type == 3:
            status({'wattage': resp / 1000})
    return resp

def read_voltage():
    p = dali.DUMB_DB.send_conf_command('p\n', 'P', log=True)
    return int(p[1:4]) / 10

def format(value, units, divide=1000):
    if value is None:
        return '-'
    return '%.2f%s' % (value / divide, units)

def check_equal(test_name, value, expected):
    good = (value == expected)
    msg = 'expected %s' % expected
    status({'result': [test_name, value, good, msg]})

def wait_for_wattage(test_name, label, value, margin=None, max_wait=5,
        fail_on_over=False, wait_cb=None, source=None):
    # Get high/low values. If a range is passed explicitly, use those.
    # Otherwise, use the value +/- a margin.
    if isinstance(value, tuple):
        [low, high] = value
    else:
        # Use a separate high/low voltage margin if not explicitly provided
        if margin is None:
            margin = 1000 if value > 5000 else 300
        low = value - margin
        high = value + margin

    if test_name:
        message('Running test "%s"' % test_name.lower(), source=source)
    start = time.time()
    while True:
        sleep(.1)
        check_cancel()
        watts = read_watts(3)
        if watts and low <= watts <= high:
            break
        # Check for going over the margin when fail_on_over is true
        if fail_on_over and watts and watts > high:
            break
        # Call a callback if given
        if wait_cb:
            wait_cb()
        # Check for timeout
        if time.time() - start > max_wait:
            break

    good = False
    if watts and watts > high:
        msg = '%s too high' % label
    elif watts and watts < low:
        msg = '%s too low' % label
    elif not watts:
        msg = 'Failure reading wattage'
    else:
        good = True
        msg = '%s good' % label

    if test_name:
        status({'result': [test_name, watts and format(watts, 'W'), good, msg]})
    return good

def sleep(t=.5):
    time.sleep(t)
    pass

def set_driver_mode(mode):
    broadcast(0)
    print(' set drive mode %d'%mode)
    mode_attrs = dali_cmds.DALI_ATTRS['driver_mode']
    bus = dali.DUMB_DB.busses[0]
    bus.write_dev_mem_range(ALL, mode_attrs.mem_bank, mode_attrs.mem_range,
            mode, big_endian=mode_attrs.big_endian)

    # Turn power to half and keep doing so until light is ready
    for i in range(100):
        check_cancel()
        broadcast(127+mode)
        resp = broadcast(0x190)
        if resp is not None and resp & 0x7:
            break
        sleep(.5)

    wait_for_status(cmd=None, mask=0x10)

def set_n_way(n_way, momentary=0):
    assert n_way in (0, 1)
    dali.DUMB_DB.send_conf_command('w4%d%04d\n' % (n_way, momentary), 'W', log=True)

def turn_power_on():
    initialize_gpio()

    # Turn power on
    import RPi.GPIO as GPIO
    GPIO.output(29, 1)
    with util.time_execution(label='voltage startup delay',
            print=lambda s: message(s)):
        for i in range(10):
            sleep(.5)
            voltage = read_voltage()
            if voltage >= 35:
                break
        else:
            message('DR2 power overload, cannot test')
            return
    GPIO.output(37, 1)

@util.with_lock(dali.GLOBAL_LOCK)
@dali.get_dali_lock(None)
def reset_devices(send_reset=False):
    bus = dali.DUMB_DB.busses[0]

    # Reset
    if send_reset:
        broadcast(0x120, send_twice=True)
        sleep(.5)
        wait_for_status(cmd=None, mask=0x20)

    # Unassign short address
    bus.send_normal_cmd(0xA3, 0xFF)
    bus.send_normal_cmd(0xFF, 0x80, send_twice=True)

    message('Waiting for EEPROM writes to flush...')
    wait_for_status(cmd=None, mask=0x20)

def wait_for_response(cmd):
    sleep(3)
    while True:
        check_cancel()
        if broadcast(cmd) is not None:
            break
        sleep(.25)

def wait_for_status(cmd=0x105, mask=0x30, wait_for_low_bits=False, timeout=100):
    if cmd is not None:
        broadcast(cmd)
    # Wait up to X seconds for fade to end
    for i in range(timeout):
        check_cancel()
        resp = broadcast(0x190)
        if resp is not None and (resp & mask == 0) ^ invert:
            break
        # If the light is powered up, turn it on to trigger calibration
        elif cmd is not None:
            if resp is None or (wait_for_low_bits and resp & 0x03 == 0):
                broadcast(cmd)
        sleep(.5)

# Some helper functions from Murray

def set_nway_mode(mode):
    bus = dali.DUMB_DB.busses[0]
    bus.write_dev_mem('all', 0x00F, [mode])

def check_status_on(bits):
    resp = broadcast(0x190)
    loops = 20
    while resp is None or ((resp & bits) != bits and loops > 0):
        check_cancel()
        resp = broadcast(0x190)
        sleep(1)
        loops = loops -1

def read_led_voltages(Bottom, Top, LB, LT):
    bus = dali.DUMB_DB.busses[0]
    data = bus.read_dev_mem('all', 0x0538, 4)
    if len(data) != 4:
        error('Read right/left voltages', 'Could not read device memory: %r' % data)
    else:
        right = dali_cmds.int_from_mem(data[0:2], big_endian=False)
        left = dali_cmds.int_from_mem(data[2:4], big_endian=False)
        good_r = (Bottom <= right <= Top)
        good_l = (LB <= left <= LT )
        status({'result': ['Right LED at voltage between %d and %d mV'%(Bottom,Top),
            format(right, 'V'), good_r, 'Good' if good_r else 'Bad']})
        status({'result': ['Left voltage between %d and %d mV'%(LB,LT),
            format(left, 'V'), good_l, 'Good' if good_l else 'Bad']})

################################################################################
## Main DR2 test ###############################################################
################################################################################

@util.with_lock(dali.GLOBAL_LOCK)
@dali.get_dali_lock(None)
def run_dr2_hw_test():
    bus = dali.DUMB_DB.busses[0]
    message('new test')

    message('power DALI bus')
    message('Setting 180mA bus current, locked')
    dali.DUMB_DB.set_dali_power_mode(3, 4)
    sleep(.5)

    # Wait for power up
    message('Waiting for power up')
    broadcast(0)

    turn_power_on()

    check_status_on(0x80)
    message('device has power')
    broadcast(0)

#    # Disable slow calibration mode at power up
#    set_nway_mode(0x10)

    wait_for_status(cmd=None, mask=0x10)
    message('device running')
    message('Test to see if update from repo is happening')

    wait_for_wattage('Startup Power', 'Startup', 27000, margin=27000)

    # Disable slow calibration mode at power up - insurance
    set_nway_mode(0x10)
    sleep(1)

    # Reset
    broadcast(0x120, send_twice=True)
    sleep(.5)

    # Put in fixed x8 mode at level = 128
    wait_for_status(cmd=None, mask=0x30)
    set_driver_mode(4)
    message('set driver mode 4')
    

    # wait end of power up sequence
    message('waiting for end of power up sequence')
    wait_for_status(cmd=None, mask=0x10)

    # leds on off
    message('leds on and off')
    broadcast(0x103)
    broadcast(0)
    wait_for_status(cmd=None, mask=0x14)
    wait_for_wattage('Idle power', 'Idle', 500, margin=500)

    # lets go
    message('Waiting for power up and calibration')
    wait_for_status(cmd=None, mask=0x10)

    # Check both left/right LEDs
    resp = None
    for i in range(40):
        resp = broadcast(0x190)
        if resp is not None:
            break
        sleep(.25)
    if resp is None:
        message('ERROR: could not read left/right LED status', bold=True)
        return
    if not resp & 0x1:
        error('Check right LED', 'Right LED not found' )
        return
    if not resp & 0x2:
        error('Check left LED', 'Left LED not found' )
        return

    # PNP ok, not MP
    broadcast(0x103)
    broadcast(100)
    wait_for_status(cmd=None, mask=0x10)

    read_led_voltages(28000,32000,28000,32000)

    # no need for max brightness in this test, just enough for the MP
    broadcast(0x103)
    broadcast(200)
    wait_for_status(cmd=None, mask=0x10)

    # ignore any P status updates before reading result

    message('Setting fade rate and fixed mode')
    # XXX also reset fade up/down to level 2 (1 second)
    bus.send_normal_cmd(0xA3, 0x02)
    bus.send_normal_cmd(0xFF, 0x2E, send_twice=True)
    bus.send_normal_cmd(0xFF, 0x2F, send_twice=True)

    # Send level 0 and wait for light to turn off
    message('Turning LEDs off')

    wait_for_status(cmd=0, mask=0x4)

    message('Measure LED at full')

#   ignore P commands

    # Test max power
    broadcast(0x103)
    broadcast(0x105)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Max power', 'Max', 52000, margin=2000)

# first PNP test not needed

    # Test PNP LED off power
    broadcast(0x103)
    broadcast(1)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Min power', 'Min', 500, margin=500)

    broadcast(0)

    # Set CCT mode, broadcast 2700K
    set_driver_mode(3)

    bus.set_save_cct(ALL, 511)
    broadcast(0x103)
    broadcast(128)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Warm white - low', 'Right PNP', 2700, margin=800)

# goto full
    broadcast(0x103)
    broadcast(0x105)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Warm white - max', 'Right MP', 26000, margin=2000)

# Broadcast 5000K
    bus.set_save_cct(ALL, 0)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Cool white - max', 'Left MP', 26000, margin=2000)

    broadcast(128)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Cool white - low', 'Left PNP', 2700, margin= 800)

    n_way_status = None

    # Read bank 0 memory for version info
    message('Reading device info...')
    mem = bus.read_dev_mem(ALL, 0x0003, 13)
    if len(mem) != 13:
        message('Failed to read 16-byte device info, only got %r' % mem, bold=True)
        message('Skipping serial number assignment/bank 5 data dump', bold=True)
    else:
        mem = [0] * 3 + mem
        data = {}
        for attr in ['upc_code', 'serial_nb', 'fw_version', 'hw_version']:
            [lo, hi] = dali_cmds.DALI_ATTRS[attr].mem_range
            mem_bytes = mem[lo:hi]
            if len(mem_bytes) == (hi - lo):
                data[attr] = dali_cmds.int_from_mem(mem_bytes)
        status(data)

        if data.get('fw_version') == 255:
            error('Check FW version', 'Bad version: 255')
            return

        with db.db_session() as session:
            serial_nb = data.get('serial_nb')
            if not serial_nb:
                # Write a serial number. This loop is to consume the generator and
                # assign the serial_nb variable (a slightly weird abstraction to
                # match usage elsewhere)
                for [serial_nb, _, _] in bus.assign_serials_gen([ALL]):
                    pass

                message('Assigned serial number %08x' % serial_nb)
                data['serial_nb'] = serial_nb

            # Read all of bank 5
            bank_5_data = bytes(bus.read_dev_mem(ALL, 0x0500, 72))
            data['bank_5_data'] = bank_5_data
            entry = db.DeviceBank5Data(**data)
            session.add(entry)
            message('Read bank 5 data: %r' % bank_5_data)
            if len(bank_5_data) > 16:
                n_way_status = bank_5_data[16] & 1

    # Read DR2 DALI voltage
    message('Reading DR2 DALI logic low voltage')
    u = dali.DUMB_DB.send_conf_command('u\n', 'U', log=True)
    dr2_voltage = int(u[6:10])
    good = dr2_voltage < 3000
    msg = 'DALI xmit ' + ('good' if good else 'bad')
    status({'result': ['DALI zero voltage', format(dr2_voltage, 'V'), good, msg]})

    # Test N-way
    message('Testing N-Way')
    broadcast(0x103)
    broadcast(217)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage("Medium Bright", "Mid", 10500, margin=1000)
    # Rocker mode: press n-way until end of test
    if not n_way_status:
        set_n_way(1)
        wait_for_status(cmd=None, mask=0x10)
        wait_for_wattage('N-Way Rocker', 'N-Way', 500, margin=500)
        set_n_way(0)
    # Momentary mode: hold for 300ms
    else:
        set_n_way(1, momentary=500)
        wait_for_status(cmd=None, mask=0x10)
        wait_for_wattage('N-Way Momentary', 'N-Way', 500, margin=500)

    # Test slider. Put in color mode for the max just to save a bit of power
    broadcast(0x103)
    bus.set_save_cct(ALL, 0)
    broadcast(120)

    prompt('Please move slider to max position')
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage('Slider - max', 'Slider', 26000, margin=2000, max_wait=60,
            fail_on_over=True)

    prompt('Please move slider to min position')
    wait_for_wattage('Slider - min', 'Slider', 1000, margin=1000, max_wait=60)
    end_prompt()

    # Test main switch
    broadcast(0x103)
    broadcast(217)
    wait_for_status(cmd=None, mask=0x10)
    wait_for_wattage("Medium Bright", "Mid", 10500, margin=1000)
    prompt('Please press main switch')

    wait_for_wattage('Main switch', 'Main switch', 500, margin=500)
    end_prompt()

    # back to zero then change modes
    broadcast(0x103)
    broadcast(0)
    wait_for_status(cmd=None, mask=0x10)

    # Test diode on 12v output, set 12v mode
    set_driver_mode(6)

    # Read left/right voltages
    read_led_voltages(11750,13200,30000,33000)

    # verify that Right can turn off - left is in PNP cal
    broadcast(0)
    wait_for_status(cmd=None, mask=0x10)
    sleep(2)
    read_led_voltages(0,1000,0,19000)

    # restore to Auto detect mode - end 12v mode
    set_driver_mode(0)

    # set customer power up state == off, write to EEprom
    broadcast(0)

    # remove any short address, wait for eeprom done
    reset_devices(send_reset=True)

    message('All tests complete.', bold=True, complete=True)

################################################################################
## Firmware regression testing #################################################
################################################################################

CURRENT_TEST_FILE = None
CURRENT_TEST_SRC = None

# Kinda hacky: get the line number of the call site two functions up. This
# function is called from the helpers below, which should be called directly
# from the test function. So the line number is where we are in the test...
def get_source_line():
    traceback = inspect.stack()
    caller = traceback[2]
    [_, filename, line, _, ctx, index] = caller
    filename = filename.split('/')[-1]
    if ctx:
        src = ctx[index].strip()
    else:
        # Gross: pull the source line out of the global variable of the
        # currently exec()ing code
        assert CURRENT_TEST_SRC
        src = CURRENT_TEST_SRC.splitlines()[line-1].strip()
        filename = CURRENT_TEST_FILE
    line = '%s:%s' % (filename, line)
    return (line, src)

def send_cmds(cmds, delay_ms=None, responses=None):
    [name, source] = get_source_line()
    bus = dali.DUMB_DB.busses[0]
    if isinstance(cmds, str):
        cmds = cmds.split()
    cmds = [int(c, 16) for c in cmds]
    result = [bus.send_normal_cmd(c) for c in cmds]
    if responses:
        if isinstance(responses, str):
            responses = responses.split()
        if responses == result:
            message('%s: OK' % name, source=source)
        else:
            message('%s: bad response, got %s, expected %s' % (name,
                ' '.join(result), ' '.join(responses)), source=source)

    return result

def send_level(level, expect_mw=None, max_wait=5, margin=None):
    broadcast(level)
    if expect_mw is not None:
        [name, source] = get_source_line()
        wait_for_wattage(name, '', value=expect_mw, max_wait=max_wait, margin=margin,
                source=source)

# Some helper functions to make available to tests in fw_tests/
TEST_GLOBALS = '''message prompt end_prompt turn_power_on turn_power_off
        check_equal send_cmds send_level broadcast sleep read_watts
        read_voltage set_driver_mode wait_for_wattage set_n_way
        error status format wait_for_status wait_for_response
        check_cancel set_nway_mode check_status_on read_led_voltages ALL'''.split()

def init_fw_tests(fw_test_srcs):
    global FW_TEST_SRCS
    FW_TEST_SRCS = fw_test_srcs

def get_fw_test_fns():
    global CURRENT_TEST_FILE, CURRENT_TEST_SRC

    test_globals = {name: globals()[name] for name in TEST_GLOBALS}
    test_dirs = ['/home/pi/hue/zpds/fw_tests', '/home/pi/atxled/fw_tests']

    srcs = {}

    # Read all python files in the test directories
    for test_dir in test_dirs:
        if not os.path.isdir(test_dir):
            continue
        for file in os.listdir(test_dir):
            if not file.endswith('.py'):
                continue

            with open(os.path.join(test_dir, file)) as f:
                srcs[file] = f.read()

    # Also add any firmware tests out of the cached ramdisk data
    # XXX disabled for now
#    if FW_TEST_SRCS:
#        srcs.update(FW_TEST_SRCS)
#        for [file, src] in FW_TEST_SRCS.items():
#            if not file.endswith('.py'):
#                continue

    if not srcs:
        prompt('No test files found (looking in %s).' % ', '.join(test_dirs))
        return []

    # Now, for every source file, execute it to get the functions defined, and
    # yield each test function
    for [file, src] in sorted(srcs.items()):
        if not file.endswith('.py'):
            continue

        exec_ctx = {}
        exec(src, exec_ctx)

        # Hackily stick the helper functions into the module's globals
        exec_ctx.update(test_globals)

        # Collect all functions in the module
        fns = []
        for fn in exec_ctx.values():
            if callable(fn) and fn.__name__.startswith('test'):
                fns.append(fn)

        yield (file, src, fns)

# Firmware tests. For ease of use, we just run all Python scripts in the
# fw_tests/ directory.
@util.with_lock(dali.GLOBAL_LOCK)
@dali.get_dali_lock(None)
def run_dr2_fw_test():
    global CURRENT_TEST_FILE, CURRENT_TEST_SRC

    for [file, src, fns] in get_fw_test_fns():
        try:
            # Ugly: update the line number globals so get_source_line()
            # works
            CURRENT_TEST_FILE = file
            CURRENT_TEST_SRC = src

            # Run each test
            for fn in fns:
                message('Running test %s' % fn.__name__, bold=True)
                try:
                    fn()
                except:
                    message('Got exception:\n%s' % traceback.format_exc())
        finally:
            CURRENT_TEST_SRC = None
            CURRENT_TEST_FILE = None

################################################################################
## Stress testing stuff ########################################################
################################################################################

# Weird hack for testing: if we're running with firmware simulation, send a
# command to set stress mode. Otherwise we depend on the user hitting a
# switch (or whatever physical mechanism is used) to start/stop
def set_stress_mode(mode):
    bus = dali.DUMB_DB.serial_device.conn
    if getattr(bus, 'fw_sim', False):
        bus.run_fw_cmd(b'-write-global stress_mode %d\n' % mode)

def run_stress_test():
    set_stress_mode(1)
    with test_lock():
        # Just keep running continuously
        # XXX only bus one
        for [error, msg] in dali.DUMB_DB.busses[0].recv_stress_test_gen():
            timestamp = time.strftime('%Y%m%d %H:%M:%S')

            # Push errors
            if error:
                TEST_EVENTS.push({'msg': '%s: %s' % (timestamp, msg)})
            # Otherwise, send an update every 5 packets
            elif msg % 5 == 0:
                TEST_EVENTS.push({'n_packets': msg})

            # Check for cancellation
            if CANCEL_TEST:
                set_stress_mode(0)
                break

    TEST_EVENTS.push({'msg': 'Done.'})
    set_stress_mode(0)

def send_stress_test():
    with test_lock():
        # Just keep running continuously
        # XXX only bus one
        for [error, msg] in dali.DUMB_DB.busses[0].send_stress_test_gen():
            timestamp = time.strftime('%Y%m%d %H:%M:%S')

            # Push errors
            if error:
                TEST_EVENTS.push({'msg': '%s: %s' % (timestamp, msg)})
            # Otherwise, send an update every 5 packets
            elif msg % 5 == 0:
                TEST_EVENTS.push({'n_packets': msg})

            # Check for cancellation
            if CANCEL_TEST:
                break

    TEST_EVENTS.push({'msg': 'Done.'})

# Context manager to make sure only one thread runs a test a once, and clean
# up related state
@contextlib.contextmanager
def test_lock():
    global TEST_RUNNING, CANCEL_TEST
    # Atomically make sure the test isn't already running. If it is, this
    # context manager will fail with a 'generator didn't yield' error, which
    # is kinda weird but better than making consumers deal with failure manually
    if not TEST_LOCK.acquire(blocking=False):
        return
    try:
        TEST_RUNNING = True
        CANCEL_TEST = False
        TEST_EVENTS.push({'running': True})
        yield
    except TestCancellation:
        pass
    finally:
        TEST_EVENTS.push({'running': False})
        TEST_RUNNING = False
        TEST_LOCK.release()

def run_wrapper(fn, *args):
    with test_lock():
        fn(*args)
    return turn_power_off()

################################################################################
## Web routes ##################################################################
################################################################################

@app.route('/')
def main_page():
    check_power_off()
    return flask.render_template('hw-test.html', page='Hardware Test',
            already_running=TEST_RUNNING, test_type='HWTest')

@app.route('/stress')
def stress_test_page():
    return flask.render_template('hw-test.html', page='DALI Stress Test',
            already_running=TEST_RUNNING, test_type='DALIStressTest')

@json_route(app, '/run-test', methods=['POST'])
def run_test_json():
    # XXX need to properly reclaim this thread when it finishes
    threading.Thread(target=run_wrapper, args=(run_dr2_hw_test,)).start()
    return {'ok': True}

@json_route(app, '/run-fw-test', methods=['POST'])
def run_fw_test_json():
    # XXX need to properly reclaim this thread when it finishes
    threading.Thread(target=run_wrapper, args=(run_dr2_fw_test,)).start()
    return {'ok': True}

@json_route(app, '/cancel-test', methods=['POST'])
def cancel_test():
    global CANCEL_TEST
    CANCEL_TEST = True
    return {'ok': True}

@json_route(app, '/run-stress-test', methods=['POST'])
def run_stress_test_json():
    # XXX need to properly reclaim this thread when it finishes
    threading.Thread(target=run_stress_test).start()
    return {'ok': True}

@json_route(app, '/send-stress-test', methods=['POST'])
def send_stress_test_json():
    # XXX need to properly reclaim this thread when it finishes
    threading.Thread(target=send_stress_test).start()
    return {'ok': True}

@json_route(app, '/turn-power-on', methods=['POST'])
def turn_power_on_json():
    # Gotta pretend we're in a test to check for cancellation
    with test_lock():
        turn_power_on()
    return {'ok': True}

@json_route(app, '/turn-power-off', methods=['POST'])
def turn_power_off_json():
    if turn_power_off():
        message('Power turned off.')
    return {'ok': True}

@json_route(app, '/send-reset', methods=['POST'])
def send_reset_json():
    with test_lock():
        turn_power_on()
        reset_devices()
        if turn_power_off():
            message('Device(s) reset.')
    return {'ok': True}

@wsr.route('/events')
def ws_events(handler):
    with TEST_EVENTS.listen() as test_log:
        for data in util.ws_stream_queue(test_log, handler):
            handler.send_message(json.dumps(data))
