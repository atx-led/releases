# Example DR2 tests

# Available helper functions:
#
# message(msg):
#   Display a message to the user of the test (shown on the side during testing)
#   Example: message('Starting test...')
#
# prompt(msg):
#   Display a large prompt to indicate an action is required from the user.
#   Example: prompt('Please move slider to max position')
#
# end_prompt():
#   Take away the current prompt. This should be called after each prompt is
#   shown and the user has responded with the prompted action.
#
# sleep(t):
#   Sleep for a given number of seconds
#   Example: sleep(1.0)
#
# send_level(level, expect_mw=None, max_wait=5, margin=None):
#   Send a normal DALI level command. There are a few keyword arguments supported
#   for convenience in writing tests:
#     expect_mw: a milliwatt value to expect from the device. This is either
#       a pair of values indicating a range of good values (like (500, 1500) for
#       a power that must be between .5 and 1.5 W), or a single value along with
#       the 'margin' keyword to specify a +/- margin of error
#     margin: if expect_mw is a single value, this is added/subtracted to get
#       the acceptable range of power readings
#     max_wait: the maximum number of seconds to wait for an acceptable
#       power reading before the test is considered failed
#   If expect_mw is not passed, the level is sent without checking the response.
#   Examples:
#       send_level(254) # Turn on to max power, ignore power readings
#       send_level(25, expect_mw=5000, margin=1000) # Turn to 10% power, expect 4-6 W
#       send_level(0, expect_mw=(0, 1500)) # Turn off power, expect 0-1.5 W
#
# send_cmds(commands, responses=None):
#   Send a series of two-byte DALI commands to all devices on the DALI bus.
#   The commands are provided as a string of hexadecimal values separated by
#   spaces, encoding the DALI commands (see the DALI spec for command values).
#   If the 'responses' keyword argument is given, it should be a space-separated
#   string containing the expected responses from each command. These responses
#   are checked against the actual responses given, and an error shown on mismatch.
#   This function returns the responses, as a list of strings, one for each
#   command. Each string is in the format provided by the AL-DALI-HAT, such
#   as "N" or "JFF"
#   Examples:
#       send_cmds('FE00', responses='n') # Broadcast all lights off,
#                                        # expect no response
#
#       resp = send_cmds('FFA0') # Get the current light level
#       level = int(resp[0][1:], 16) # Parse the level from a 'JXX' response
#
# turn_power_on():
#   Turn on the power relays of the test harness to power up the tested device
#
# turn_power_off():
#   Turn off the power relays of the test harness to shut down the tested device
#
# read_watts(type):
#   Read the wattage of the DR2F, with a given type of reading. There are
#   three types of readings available:
#     0: initial calibration
#       response is the error offset voltage - not interesting normally
#     1: calibrate with load including the Pi
#       response is the effective resistance of the power supply, should
#       be between 400 and 1000 milliohms
#     3: read milliwatts
#   Example: mwatts = read_watts(3)
#
# read_voltage():
#   Read the voltage of the LEDs under test
#
# wait_for_wattage(test_name, label, expect_mw, margin=None, max_wait=5,
#        fail_on_over=False):
#   A test helper to wait for a given power reading.
#   Arguments:
#     test_name: a name for this test. Displayed in the first column of the
#       results table.
#     label: a label for the unit under test (like 'MP' or 'PNP'). Displayed
#       in the second column of the results table.
#     expect_mw: a milliwatt value to expect from the device. This is either
#       a pair of values indicating a range of good values (like (500, 1500) for
#       a power that must be between .5 and 1.5 W), or a single value along with
#       the 'margin' keyword to specify a +/- margin of error
#     margin: if expect_mw is a single value, this is added/subtracted to get
#       the acceptable range of power readings
#     max_wait: the maximum number of seconds to wait for an acceptable
#       power reading before the test is considered failed
#     fail_on_over: if the power is ever above this value, the test is
#       immediately considered failed and any waiting stops.
#   Examples:
#       wait_for_wattage('Test max power', 'MP', 55000, margin=6000)
#
# set_driver_mode(mode):
#   Set the DR2F to a given driver mode.
#   These driver modes are available on the DR2F32:
#      0: Autodetect
#      1: Split Left + Right
#      2: Fan plus Light
#      3: ALL CCT
#      4: ALL Fixed
#      5: Special PIR
#      6: Split Left + Right 12v
#      7: Bad Fan Load
#      8: CCT not found
#   On the DR2F16, only modes 0, 1, 3, and 4 are available
#
# set_n_way(n):
#   Set the value of the DR2F hardware's N-way pin (0 to turn off, 1 to turn on).
#   Example: set_n_way(1)

# Test that fade rates work properly
def test_dr2_fades():
    # Turn the DR2 on
    turn_power_on()

    # Set fade rates to 0
    send_cmds('A300 FE46 FE47', responses='N N N')

    # Turn to max power, expect 24-60W within .1 seconds
    send_level(254, expect_mw=(24000, 60000), max_wait=.1)

    # Turn fade up/down rates to 4 (2 seconds)
    send_cmds('A344 FE46 FE47', responses='N N N')

    # Turn to low power, expect .6-4W in 5 seconds
    send_level(10,  expect_mw=(  600,  4000), max_wait=5)
    # Turn to max power, expect 24-60W in 5 seconds
    send_level(254, expect_mw=(24000, 60000), max_wait=5)

    # Turn fade rate back to 0
    send_cmds('A300 FE46 FE47', responses='N N N')

    # Turn off, expect 0-.6W within .1 seconds
    send_level(0,   expect_mw=(    0,   600), max_wait=.1)

# Test that various values are kept in memory over a power cycle
def test_dr2_persistence():
    # Send a sepcific level
    send_level(137)

    # Wait a bit to try and make sure to flush memory writes
    sleep(15)

    # Power cycle
    turn_power_off()
    sleep(1)
    turn_power_on()
    sleep(5)

    # Read the device's level
    level = broadcast(0x1A0)
    check_equal('got the same level', level, 137)
