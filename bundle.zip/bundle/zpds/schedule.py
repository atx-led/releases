import collections
import contextlib
import datetime
import io
import json
import socket
import subprocess
import threading
import time
import urllib.parse

import flask
import requests

import config
import dali
import db
import util
import wifi
import zwave
from util import json_route, schema_obj

LOG = util.get_logger('schedule')
app = flask.Blueprint('schedule', __name__, static_folder=None)

SCHEDULE_CACHE = None
# HACK: have an empty set of mappings, mostly for tests where the
# initialization doesn't get called
TRIGGER_MAPPINGS = {}

# An event stream of all triggerable events
TRIGGER_LISTENER = util.EventStream()

SCHEDULE_QUEUE = []

# A map of devices currently known on the bus, and whether they have
# a UPC code. Used for rescanning devices which mysteriously lose it
DEVICE_UPC_MAP = {}

# Last color temperature sent to any light. We just overwrite this whenver we
# send a command, and we don't care about this for any functional purpose, it's
# just some info to put in the heartbeat
LAST_COLOR_SENT = 3500

# A lock to make sure only one trigger runs at once, including a potential recursive trigger
TRIGGER_LOCK = threading.RLock()
INSIDE_TRIGGER = False

# Path to a UNIX-domain socket for sending API events
API_EVENTS_SOCKET_PATH = '/home/pi/atxled/api-events'

# Heartbeat info
HEARTBEAT_PING_TIME = None
HEARTBEAT_MINUTES = 0

# Dumb helper to add back in colons to MAC address
def get_mac_address():
    return ':'.join(util.chunked(util.get_mac_address(), 2))

GPS_CACHE_TTL = datetime.timedelta(days=4)
GPS_CACHE_TIME = None
GPS_CACHE_INFO = None
def get_gps_info(use_cache=True):
    global GPS_CACHE_TIME, GPS_CACHE_INFO
    # Check the cache for a recent entry
    now = util.utcnow()
    if use_cache and GPS_CACHE_TIME and now - GPS_CACHE_TIME < GPS_CACHE_TTL:
        return GPS_CACHE_INFO
    ip_address = util.get_ip_address()
    if use_cache:
        with db.db_session() as session:
            for entry in session.query_all(db.GPSCache):
                cache_ip = entry.gps_info.get('ip_address')
                LOG.info('gps db cache time=%s age=%s ip=%s' % (entry.updated_at,
                    now - entry.updated_at, cache_ip))
                if now - entry.updated_at < GPS_CACHE_TTL and ip_address == cache_ip:
                    LOG.info('cache hit!')
                    GPS_CACHE_TIME = entry.updated_at
                    GPS_CACHE_INFO = entry.gps_info
                    return entry.gps_info

    networks = wifi.scan_wifi()
    # Deduplicate networks after ignoring the first and last bytes
    networks = {bssid[2:-2]: [signal, bssid] for [bssid, ssid, signal] in networks}
    networks = list(sorted(networks.values(), key=lambda bs: -bs[0]))
    networks = networks[:5]

    auth = ('cn3kf', 'mariec')
    query = ['mac%d=%s&r%d=%s' % (i, bssid, i, signal)
            for [i, [signal, bssid]] in enumerate(networks)]
    mac = get_mac_address()
    query += ['mac=%s' % mac]
    query = '&'.join(query)
    resp = requests.get('https://atxled.com/gps/proxy.php?%s' % query, auth=auth)
    if resp.status_code == 200:
        data = dict(line.split(': ', 1) for line in 
                resp.text.strip().splitlines())
        data['latlng'] = [float(x) for x in data['latlng'].split(',')]
        data['ip_address'] = ip_address
        with db.db_session() as session:
            session.upsert(db.GPSCache, {}, gps_info=data)
        GPS_CACHE_TIME = now
        GPS_CACHE_INFO = data
        return data

    return None

def get_tz():
    # First try using the GPS timezone, which doesn't require any settings change
    gps_info = get_gps_info()
    if gps_info and ',' in gps_info.get('sunrise', ''):
        offset = int(gps_info['sunrise'].partition(',')[2])
    # Otherwise, use the system time
    else:
        # Get the UTC offset in a dumb way--comparing now/utcnow stripped of timezones
        offset = (util.now().replace(tzinfo=None) -
                util.utcnow().replace(tzinfo=None)).total_seconds()
        offset = round(offset / 60)
    # Create a delta with a rounded minutes value, as the times might differ slightly
    return datetime.timezone(datetime.timedelta(minutes=offset))

def get_sunrise_sunset():
    # Always use UTC, since that's what Google gives us
    utc = datetime.timezone.utc

    gps_info = get_gps_info()
    if not gps_info:
        return [datetime.time(8, tzinfo=utc), datetime.time(20, tzinfo=utc)]

    # Ignore the tz offset from the server
    [sunrise, _] = gps_info['sunrise'].split(',')
    h, m = sunrise.split(':')
    sunrise = datetime.time(int(h), int(m), tzinfo=utc)
    h, m = gps_info['sunset'].split(':')
    sunset = datetime.time(int(h), int(m), tzinfo=utc)
    return [sunrise, sunset]

def get_schedule_cache():
    global SCHEDULE_CACHE
    if SCHEDULE_CACHE is None:
        refresh_cache()
    return SCHEDULE_CACHE

# Check whether a schedule entry is from an actual schedule, or from
# an event trigger. These are overloaded to the same backend structure,
# since most of the handling is the same, but are handled separately in
# the frontend. Thus we sort them based on their frontend usage.
def is_entry_trigger(entry):
    return entry['condition']['type'] not in {'specific', 'sunrise', 'sunset'}

def get_all_entries():
    return get_schedule_cache()

def get_schedule_entries():
    return [entry for entry in get_schedule_cache() if not is_entry_trigger(entry)]

def get_trigger_entries():
    return [entry for entry in get_schedule_cache() if is_entry_trigger(entry)]

def refresh_cache():
    global SCHEDULE_CACHE, TRIGGER_MAPPINGS, TRIGGER_FN_MAPPINGS
    with db.db_session() as session:
        SCHEDULE_CACHE = []
        # Convert old-style zwave to new generic style
        for entry in session.query_all(db.ScheduleEntry):
            for condition in entry.conditions:
                if condition.get('type') == 'zwave_scene':
                    scene_id = condition.pop('zwave_scene_id', 1)
                    condition['type'] = 'zwave_generic'
                    condition['zwave_key'] = ('scene', scene_id, 0)
                    # Force update
                    session.flag_modified(entry, 'conditions')

            SCHEDULE_CACHE.append(convert_entry_to_json(entry))

    # Update trigger map
    TRIGGER_MAPPINGS = collections.defaultdict(list)
    TRIGGER_FN_MAPPINGS = collections.defaultdict(list)
    for entry in get_trigger_entries():
        condition = entry['condition']
        cond_type = condition.get('type')
        if cond_type in {'level_on', 'level_off', 'level_change'}:
            address = condition.get('address') or 'all'
            channel, addr_type, addr_id = dali.parse_device_nice_addr(address)
            if addr_type in {'single', 'passive', 'virtual-device'}:
                if cond_type == 'level_change':
                    trigger_type = 'change'
                else:
                    trigger_type = (condition['type'] == 'level_on')
                trigger_key = ('dali', channel, addr_id, trigger_type)
                TRIGGER_MAPPINGS[trigger_key].append(entry)
        elif cond_type == 'dali_scene':
            scene = condition.get('dali_scene', 0)
            trigger_key = ('dali', 'scene', scene)
            TRIGGER_MAPPINGS[trigger_key].append(entry)
        elif cond_type in {'bcast_level_on', 'bcast_level_off'}:
            on = cond_type == 'bcast_level_on'
            trigger_key = ('dali', 'bcast', on)
            TRIGGER_MAPPINGS[trigger_key].append(entry)
        elif cond_type == 'startup':
            trigger_key = ('startup',)
            TRIGGER_MAPPINGS[trigger_key].append(entry)
        elif cond_type in {'zwave_scene', 'zwave_generic'}:
            node_id = condition.get('zwave_node_id', 2)
            zwave_key = tuple(condition.get('zwave_key', ()))

            # Check for comparisons in the zwave key. If the key ends with
            # 'cmp_gt' or 'cmp_lt', the first part of the tuple is used as a key,
            # and we create a function that does an extra comparison when the
            # even is triggered. For example, when trigger has a zwave_key of
            # ('sensor-multilevel', 'cmp_gt', 5), it is looked up by the key
            # ('zwave', node_id, ('sensor-multilevel',)) in the
            # TRIGGER_FN_MAPPINGS table, which contains a list of functions
            # and entries, where the function must return True for the entry
            # to actually trigger.
            # This data model (i.e. looking at the last two values of the key)
            # is a bit weird, and is mostly used to keep the front end logic
            # simple, with the key elements roughly descending a hierarchy.
            if len(zwave_key) > 2 and zwave_key[-2] in {'cmp_gt', 'cmp_lt'}:
                comparison = zwave_key[-2]
                comparison_value = zwave_key[-1]
                zwave_key = zwave_key[:-2]
                trigger_key = ('zwave', node_id, zwave_key)
                # Add an extra function to bind the comparison variables. This is
                # to deal with weird Python lexical scoping: we want to capture
                # the value of comparison[_value] *right now*, but a bare lambda
                # will hold on to the binding at the function scope, and
                # comparison[_value] might get overwritten by another trigger in
                # the loop. So create a wrapper that has new local variables.
                def make_cmp(comparison, value):
                    if comparison == 'cmp_gt':
                        return lambda key, v: v > value
                    if comparison == 'cmp_lt':
                        return lambda key, v: v < value
                    assert False
                fn_entry = (make_cmp(comparison, comparison_value), entry)
                TRIGGER_FN_MAPPINGS[trigger_key].append(fn_entry)
            else:
                trigger_key = ('zwave', node_id, zwave_key)
                TRIGGER_MAPPINGS[trigger_key].append(entry)

# Context manager to handle the trigger reentrant lock, and yield the already-held
# status, so we can safely cancel recursive triggers. Would be nice if RLock provided this...
@contextlib.contextmanager
def trigger_lock():
    global TRIGGER_LOCK, INSIDE_TRIGGER
    # XXX grab the DALI lock here first. This is to prevent possible deadlocks
    # in the following situation: an entry is triggered with multiple actions,
    # one action happens, this triggers some activity on the DALI bus, the
    # monitor thread reads the DALI commands, a new entry is triggered (trying
    # to grab this trigger lock), the original thread tries to perform the next
    # action by grabbing the DALI lock (this isn't a minimal reproduction, just
    # the easiest to trigger). So even though we won't always need the DALI
    # lock, just hold it the whole time the entry is being processed to prevent
    # this.
    with dali.get_dali_lock(None):
        with TRIGGER_LOCK:
            old = INSIDE_TRIGGER
            INSIDE_TRIGGER = True
            try:
                yield old
            finally:
                INSIDE_TRIGGER = old

def trigger_entry(entry, start_action=None):
    global TRIGGER_LOCK, INSIDE_TRIGGER, SCHEDULE_QUEUE

    with trigger_lock() as already_held:
        # Cancel any recursive triggers
        if already_held:
            return

        actions = entry['actions']

        range_str = ''
        if start_action is None:
            start_action = 0
        else:
            range_str = '[%s:]' % start_action

        LOG.info('Executing schedule(id=%d): cond=%s actions%s=%s',
                entry['id'], entry['condition'], range_str, actions[start_action:])
        
        for action_id in range(start_action, len(actions)):
            updated_status = True

            action = actions[action_id]
            action_type = action.get('type', 'level_set')
            address = action.get('address', (None, 'all', None))
            if action_type == 'level_set':
                level = action.get('level', 0)
                updated_status = dali.DUMB_DB.set_level(address, level, force_send=True)
            elif action_type in {'level_inc', 'level_dec'}:
                inc = 25 if action_type == 'level_inc' else -25
                updated_status = dali.DUMB_DB.set_dali_light_state(
                        address, {'level_inc_on': inc})
            elif action_type in {'level_min', 'level_max', 'level_off',
                    'level_step_up', 'level_step_down'}:
                updated_status = dali.DUMB_DB.set_dali_light_state(
                        address, {action_type: True})
            elif action_type in {'min_level_set', 'max_level_set',
                    'fade_up_set', 'fade_down_set'}:
                level = action.get('level', 0)
                # HACK
                attr = action_type.replace('_set', '')
                updated_status = dali.DUMB_DB.set_dali_light_state(address, {attr: level})
            elif action_type == 'color_set':
                color_temp_k = action.get('color_temp_k', 1700)
                updated_status = dali.DUMB_DB.set_color_temp(address, color_temp_k,
                        color_fade=True)
            elif action_type == 'copy_level':
                source = action.get('source_address', (None, 'all', None))
                level = None
                for light in dali.DUMB_DB.get_matching_lights(source):
                    level = (light['level'] if light.get('dev_on', True) else 0)
                    break
                if level is not None:
                    updated_status = dali.DUMB_DB.set_level(address, level, force_send=True)
            elif action_type in {'check_level_gte', 'check_level_lte'}:
                comp_level = action.get('level', 0)
                level = None
                for light in dali.DUMB_DB.get_matching_lights(address):
                    level = (light['level'] if light.get('dev_on', True) else 0)
                    break
                if (level is None or
                        (action_type == 'check_level_gte' and level < comp_level) or
                        (action_type == 'check_level_lte' and level > comp_level)):
                    break
            elif action_type == 'trigger_scene':
                scene_id = action['scene_id']
                dali.DUMB_DB.trigger_scene(scene_id, address=address)
            elif action_type == 'unix_socket_msg':
                message = action['unix_message']
                send_unix_message(message)
            elif action_type == 'delay':
                delay_minutes = action.get('delay_minutes', 0)
                # Check if this event is already in the queue, and remove it if so
                SCHEDULE_QUEUE = [qe for qe in SCHEDULE_QUEUE
                    if qe[1]['id'] != entry['id']]
                SCHEDULE_QUEUE.append((delay_minutes, entry, action_id + 1))
                break
            else:
                assert False, 'Unknown action %s' % action_type

            # Check if there wasn't a matching light for this schedule: blacklist it
            # for a rescan
            if updated_status is None:
                [channel, addr_type, addr_id] = dali.parse_device_nice_addr(address)
                if addr_type == 'single':
                    LOG.info('address %s:%s not found for schedule entry, rescanning' % (channel, addr_id))
                    dali.DUMB_DB.blacklist_address(channel, addr_id)

# Send a message to a local UNIX-domain socket
def send_unix_message(message):
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(API_EVENTS_SOCKET_PATH)
        sock.send(message.encode())
    except Exception as e:
        LOG.exception('got exception sending unix message (%r)', message)
    finally:
        sock.close()

# One step of the scheduler loop. This is broken out into its own function
# so we can use a different outer loop in the tests.
def run_schedule_step():
    global SCHEDULE_QUEUE

    # Get local timezone and UTC
    tz = get_tz()
    utc = datetime.timezone.utc
    # Get the current time and convert to UTC for comparison
    local_now = util.now().replace(second=0, microsecond=0, tzinfo=tz)
    now = local_now.astimezone(utc).timetz()
    [sunrise, sunset] = get_sunrise_sunset()

    # Process any delayed entries on the queue. Copy the entries first
    # because the queue can be modified during this processing
    queue_entries = SCHEDULE_QUEUE
    SCHEDULE_QUEUE = []
    for [delay, entry, start_action] in queue_entries:
        delay -= 1
        if delay <= 0:
            trigger_entry(entry, start_action=start_action)
        else:
            SCHEDULE_QUEUE.append([delay, entry, start_action])

    for entry in get_schedule_entries():
        # Get the time that this schedule entry happens at, as a time-of-day
        # in UTC, and an offset (that can only be applied on a datetime)
        condition = entry['condition']
        if condition['type'] == 'specific':
            offset = 12 if condition['time']['ampm'] == 'pm' else 0
            hour = int(condition['time']['hour']) % 12 + offset
            ctime = datetime.time(hour, int(condition['time']['minute']))
            ctime = ctime.replace(tzinfo=tz)
            offset = datetime.timedelta()
        elif condition['type'] in {'sunrise', 'sunset'}:
            offset = datetime.timedelta(minutes=condition['offset']['minutes'])
            if condition['offset']['direction'] == 'before':
                offset = -offset
            ctime = sunrise if condition['type'] == 'sunrise' else sunset
        # Other condition types are handled elsewhere. These are external
        # triggers
        else:
            assert False

        # Add the condition's time to the current date, and convert to UTC
        base = datetime.datetime.combine(util.today(), ctime)
        ctime = (base + offset).astimezone(utc).timetz()

        weekday = util.ALL_WEEKDAYS[base.weekday()]
        if weekday not in condition.get('weekdays', util.ALL_WEEKDAYS):
            continue

        # Check if this entry should be triggered, and run all its actions if so
        if ctime.replace(second=0, microsecond=0) == now:
            trigger_entry(entry)

    # Trigger rescans gradually starting at 12 pm/am. This is rather annoying
    # but Murray wants a rolling scan
    if local_now.hour % 12 in (0, 1):
        delta_minutes = (local_now.hour % 12) * 60 + local_now.minute
        # If this is a minute we're doing a rolling scan on, sleep a random
        # amount based on the MAC address. This is so busses with multiple
        # pis don't all scan at once.
        if 0 <= delta_minutes <= 64:
            mac = get_mac_address()
            # Use an amount from 0-16 seconds so we don't risk skipping
            # a minute
            byte = int(mac[-2:], 16)
            time.sleep(byte / 16)

            # Check which busses are active at the beginning of each rescan
            if delta_minutes == 0:
                dali.DUMB_DB.init_busses()

            # Scan a single short address on all active busses, one per minute
            if 0 <= delta_minutes < 64:
                for bus in dali.DUMB_DB.iter_busses():
                    short_addr = delta_minutes
                    # See if this device lost a UPC, if so do a full rescan
                    addr = (bus.channel, 'single', short_addr)
                    had_upc = DEVICE_UPC_MAP.get(addr)
                    has_upc = False
                    for light in dali.DUMB_DB.get_matching_lights(addr):
                        has_upc = (light.get('upc_code'))
                        break

                    quick = True
                    if had_upc and not has_upc:
                        quick = False
                    DEVICE_UPC_MAP[addr] = has_upc

                    dali.DUMB_DB.blacklist_address(bus.channel, short_addr,
                            quick=quick)
            elif delta_minutes == 64:
                dali.DUMB_DB.blacklist_passive_addresses()

    # More crap: restart lxpanel every Monday at 4am to combat memory leak
    # See: https://www.raspberrypi.org/forums/viewtopic.php?t=267015
    if local_now.weekday() == 0 and local_now.hour == 4 and local_now.minute == 0:
        LOG.warning('Restarting lxpanel...')
        try:
            subprocess.check_call(['lxpanelctl', 'restart'])
        except subprocess.CalledProcessError:
            # The above command can fail sometimes with
            # "Can't connect to display: (null)", try brute force
            try:
                subprocess.check_call(['pkill', 'lxpanel'])
            except subprocess.CalledProcessError:
                pass

    # Sleep until the next minute. Get the current time again
    # since some time might have elapsed if we had to ping
    # the gps server
    time.sleep(61 - util.now().second)

# Dumb temporary debugging method
LIGHTS_WITH_UPC = set()
def upc_sanity_check():
    mac = util.get_mac_address()
    #if mac != 'b827ebefa86a':
    #    return
    bad = []
    try:
        for [key, light] in dali.DUMB_DB.lights.items():
            if light.get('upc_code'):
                LIGHTS_WITH_UPC.add(key)
            else:
                if key in LIGHTS_WITH_UPC:
                    LIGHTS_WITH_UPC.remove(key)
                    bad.append(dali.get_device_nice_addr(light))

        if bad:
            LOG.error('Lights lost UPCs! %s', bad)
            reason = 'lostupcs-%s' % ','.join(bad)
            response = requests.post('https://me.atxled.com/why.php?value=%s&'
                    'mac=%s' % (reason, mac))
            if response.status_code != 200:
                LOG.info('could not send watchdog fail message [%s]: %s',
                        response.status_code, response.text)
    except Exception as e:
        LOG.exception('error updating UPC map')

def run_schedule(use_fan_control):
    while True:
        try:
            #upc_sanity_check()

            run_schedule_step()

            # Turn on the fan if the Pi is getting hot
            if use_fan_control:
                check_temp()

            # Send a heartbeat with a bunch of info every 5 minutes
            heartbeat()
        except Exception:
            LOG.exception('SCHEDULING THREAD GOT ERROR!')
            # Sleep until the next minute
            time.sleep(61 - util.now().second)

# Check the temperature and turn the onboard fan on if it's >50C
ONBOARD_FAN_STATE = None
def check_temp():
    global ONBOARD_FAN_STATE
    temp = float(util.get_temp())
    state = int(temp > 50)
    if state != ONBOARD_FAN_STATE:
        on_off = ['off', 'on'][state]
        ONBOARD_FAN_STATE = state
        import RPi.GPIO as GPIO
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        for port in [7, 12]:
            GPIO.setup(port, GPIO.OUT)
            GPIO.output(port, state)

# Get estimated power usage from PSEs or just from light levels
def estimate_power_usage():
    n_leds = {}
    for dev in dali.DUMB_DB.load_topology:
        addr = '%s_s_%s' % (dev['channel'], dev['short_addr'])
        lr = dev['led_counts_lr']
        if lr:
            n_leds[addr] = lr[0] + lr[1]
        elif dev.get('led_count_cct'):
            n_leds[addr] = dev['led_count_cct']

    pse_power = power = 0
    found = False
    for dev in dali.DUMB_DB.get_devices_state():
        if dali.device_is_pse4d(dev):
            found = True
            if dev['dev_on']:
                pse_power += ((dev['level'] - 200) * 10 if dev['level'] > 200
                        else dev['level'])
        elif dev['dev_on']:
            addr = dali.get_device_nice_addr(dev)
            n = n_leds.get(addr, 4)
            scale = (10. ** (3 * dev['level'] / 254)) / 1000.
            power += .660 * 9 * scale * n
    return int(pse_power if found else power)

# Get a bunch of possibly-useful data and send it to Murray
def heartbeat():
    global HEARTBEAT_PING_TIME, HEARTBEAT_MINUTES
    # First, check if we actually want to send a heartbeat
    if not config.SITE_SETTINGS.heartbeat_interval:
        return
    HEARTBEAT_MINUTES -= 1
    if HEARTBEAT_MINUTES > 0:
        return
    HEARTBEAT_MINUTES = config.SITE_SETTINGS.heartbeat_interval

    # Helper function for the actual web request, since we might need to send two
    def send(args):
        global HEARTBEAT_PING_TIME
        if HEARTBEAT_PING_TIME is not None:
            args['p'] = int(HEARTBEAT_PING_TIME * 1000)
        url = 'http://sens.wifi-soft.com/sensors/services/datalogger?%s' % urllib.parse.urlencode(args)
        with util.time_execution() as t:
            resp = requests.get(url)
            if not (200 <= resp.status_code < 300):
                LOG.error('got error sending heartbeat: %s', resp.status_code)
                return False
        HEARTBEAT_PING_TIME = t.time
        return True

    # Get GPS pos
    gps = get_gps_info()
    [lat, lng] = gps['latlng'] if gps.get('latlng') else ['', '']

    # Get a bunch of misc info
    wifi_status = wifi.get_wpa_status()
    zpds_version = util.get_zpds_version()
    uptime = util.get_uptime()
    temp = util.get_temp()

    # Get the various hw/fw versions and power status.
    # This gets some information we don't use but whatevz
    _ = dali.DUMB_DB.get_status(log=False)

    # Get device counts. We overload a decibel histogram thingy so this is a bit weird
    n_good_devices = len(dali.DUMB_DB.lights)
    n_bad_devices = len(dali.DUMB_DB.missing_devices)
    n_total_devices = max(n_good_devices + n_bad_devices, 1)
    pct_bad_devices = int((100 * n_bad_devices + .5) / n_total_devices)
    device_counts = [0, 100 - pct_bad_devices, 0, 0, pct_bad_devices, n_total_devices]
    device_counts = ','.join(map(str, device_counts))

    args = collections.OrderedDict((
        ('t', temp),
        ('h', 50),
        ('r', dali.DUMB_DB.channels),
        ('l', estimate_power_usage()),
        ('db', LAST_COLOR_SENT // 100),
        ('w', zpds_version),
        ('mac', get_mac_address()),
        ('lat', lat),
        ('long', lng),
        ('rssi', wifi_status.get('signal_level')),
        ('F', 2),
        ('up', uptime),
        ('n', device_counts),
    ))
    if dali.DUMB_DB.hw_version and dali.DUMB_DB.fw_version:
        args['v'] = '%s.%02d' % (dali.DUMB_DB.hw_version, dali.DUMB_DB.fw_version)
    if dali.DUMB_DB.hat_power_voltages:
        [args['h'], args['s']] = dali.DUMB_DB.hat_power_voltages
        args['f'] = dali.DUMB_DB.bus_voltage
        args['m'] = dali.DUMB_DB.bus_current_0v

    # Send a first request if this device hasn't sent one before: this heartbeat system
    # was designed to have a power-on test for new devices at the factory in China.
    # Not this device though, so we fake some data that passes the test and send it
    if not config.SITE_SETTINGS.heartbeat_init_sent:
        init_args = args.copy()
        init_args.update(t=30, h=50, r=0, l=200, f=1844, F=1, e='1.7.0.0', m=2000, rssi=-72)
        send(init_args)

        config.SITE_SETTINGS.heartbeat_init_sent = True
        with db.db_session() as session:
            session.upsert(db.SiteSettings, {}, heartbeat_init_sent=True)

    send(args)

################################################################################
## Trigger entrypoints #########################################################
################################################################################

def on_off_listener(channel, addr_id, on_off, trigger_level=False):
    if dali.LAST_STATUS_CMD_TIME is not None and util.get_time() < dali.LAST_STATUS_CMD_TIME + 90:
        return

    keys = [on_off]
    if trigger_level:
        keys.append('change')
    for key in keys:
        trigger_key = ('dali', channel, addr_id, key)
        if trigger_key in TRIGGER_MAPPINGS:
            for entry in TRIGGER_MAPPINGS[trigger_key]:
                trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'dali_on_off', 'channel': channel,
        'short_address': addr_id, 'device_on': on_off})

def level_change_listener(channel, addr_id, level):
    if dali.LAST_STATUS_CMD_TIME is not None and util.get_time() < dali.LAST_STATUS_CMD_TIME + 90:
        return
    trigger_key = ('dali', channel, addr_id, 'change')
    if trigger_key in TRIGGER_MAPPINGS:
        for entry in TRIGGER_MAPPINGS[trigger_key]:
            trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'dali_level_change', 'channel': channel,
        'short_address': addr_id, 'level': level})

def color_change_listener(color_temp_k):
    global LAST_COLOR_SENT
    LAST_COLOR_SENT = color_temp_k

def dali_scene_listener(scene):
    trigger_key = ('dali', 'scene', scene)
    if trigger_key in TRIGGER_MAPPINGS:
        for entry in TRIGGER_MAPPINGS[trigger_key]:
            trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'dali_scene', 'scene': scene})

def bcast_listener(channel, level):
    # XXX ignore channel
    #trigger_key = ('dali', 'bcast', channel, level > 0)
    trigger_key = ('dali', 'bcast', level > 0)
    if trigger_key in TRIGGER_MAPPINGS:
        for entry in TRIGGER_MAPPINGS[trigger_key]:
            trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'dali_bcast', 'channel': channel,
        'level': level})

def startup_listener():
    trigger_key = ('startup',)
    if trigger_key in TRIGGER_MAPPINGS:
        for entry in TRIGGER_MAPPINGS[trigger_key]:
            trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'startup'})

# HACK: monkey patch the above listeners into the dali module so they get called
# whenever a relevant event happens. This is mostly to avoid a circular dependency...
dali.ON_OFF_LISTENER = on_off_listener
dali.LEVEL_CHANGE_LISTENER = level_change_listener
dali.COLOR_CHANGE_LISTENER = color_change_listener
dali.SCENE_LISTENER = dali_scene_listener
dali.BCAST_LISTENER = bcast_listener
dali.STARTUP_LISTENER = startup_listener

def zwave_listener(node_id, key, values, fn_value=None):
    trigger_key = ('zwave', node_id, key)
    if trigger_key in TRIGGER_MAPPINGS:
        for entry in TRIGGER_MAPPINGS[trigger_key]:
            trigger_entry(entry)
    # Function mappings: these have an extra condition checked at trigger time.
    # For each (function, entry) pair in the TRIGGER_FN_MAPPINGS table for this
    # trigger key, we call the function with the trigger key and the fn_value
    # argument supplied to this function, and only if this function succeeds do
    # we trigger the entry.
    if trigger_key in TRIGGER_FN_MAPPINGS:
        for [fn, entry] in TRIGGER_FN_MAPPINGS[trigger_key]:
            # Check if we should trigger this entry
            if fn(trigger_key, fn_value):
                trigger_entry(entry)

    # Push event to listeners
    TRIGGER_LISTENER.push({'event_type': 'zwave', 'node': node_id,
        'key': key, 'values': values})

# HACK: monkey patch the zwave listener as above
zwave.ZWAVE_LISTENER = zwave_listener

ENTRY_SCHEMA = schema_obj({
    'id': {'type': 'integer'},
    'name': util.JSONSCHEMA_STR_OR_NULL,
    'actions': {
        'type': 'array',
        'items': schema_obj({
            'type': {'type': 'string', 'enum': ['level_set', 'level_inc', 'level_dec',
                'level_min', 'level_max', 'level_off', 'min_level_set',
                'max_level_set', 'level_step_up', 'level_step_down',
                'fade_up_set', 'fade_down_set', 'color_set', 'copy_level',
                'trigger_scene', 'delay', 'check_level_gte', 'check_level_lte',
                'unix_socket_msg']},
            'address': {'type': 'string'},
            'source_address': {'type': 'string'}, # For copy_level
            'level': {'type': 'integer', 'minimum': 0, 'maximum': 255},
            'color_temp_k': {'type': 'integer', 'minimum': 1700, 'maximum': 6500},
            'scene_id': {'type': 'integer', 'minimum': 0, 'maximum': 15},
            'delay_minutes': {'type': 'integer', 'minimum': 1},
            'unix_message': {'type': 'string', 'minLength': 0, 'maxLength': 64},
        }),
    },
    'condition': schema_obj({
        'type': {'type': 'string', 'enum': ['specific', 'sunrise', 'sunset',
            'level_on', 'level_off', 'bcast_level_on', 'bcast_level_off',
            'level_change', 'dali_scene', 'zwave_scene', 'zwave_generic',
            'startup']},
        'address': util.JSONSCHEMA_STR_OR_NULL,
        'dali_scene': {'type': 'integer', 'minimum': 0, 'maximum': 15},
        'zwave_node_id': {'type': 'integer', 'minimum': 0, 'maximum': 255},
        'zwave_key': {
            'type': 'array',
            'minItems': 1,
            'maxItems': 5,
            'items': { 'oneOf': [
                {'type': 'number'},
                {'type': 'string', 'minLength': 0, 'maxLength': 64},
            ]},
        },
        'offset': schema_obj({
            'direction': {'type': 'string', 'enum': ['before', 'after']},
            'minutes': {'type': 'integer', 'minimum': 0, 'maximum': 24*60}
        }),
        'time': schema_obj({
            'hour': {'type': 'string', 'pattern': r'^\d|1[012]$'},
            'minute': {'type': 'string', 'pattern': r'^[0-5]\d$'},
            'ampm': {'type': 'string', 'enum': ['am', 'pm']}
        }),
        'weekdays': {
            'type': 'array',
            'items': {'type': 'string', 'enum': util.ALL_WEEKDAYS},
        },
    }),
    'last_triggered': util.JSONSCHEMA_STR_OR_NULL,
})

ENTRIES_SCHEMA = {
    'type': 'object',
    'propertyNames': {'pattern': r'^\d+$'},
    'additionalProperties': ENTRY_SCHEMA,
}

def convert_entry_to_json(entry):
    return {
        'id': entry.id,
        'name': entry.name,
        'actions': entry.actions,
        'condition': entry.conditions[0] if entry.conditions else None,
        'last_triggered': entry.last_triggered,
    }

@json_route(app, '/api/entries', output_schema=ENTRIES_SCHEMA)
def get_schedule_entries_api():
    return {entry['id']: entry for entry in get_schedule_entries()}

@json_route(app, '/api/triggers', output_schema=ENTRIES_SCHEMA)
def get_trigger_entries_api():
    return {entry['id']: entry for entry in get_trigger_entries()}

def upsert_schedule_entry(data, id=None):
    util.validate_json(data, ENTRY_SCHEMA)
    if 'id' in data:
        del data['id']
    if 'condition' in data:
        data['conditions'] = [data.pop('condition')]
    with db.db_session() as session:
        LOG.info('upsert_schedule_entry(id=%s): %s', id, data)
        entry = session.upsert(db.ScheduleEntry, {'id': id}, **data)
        refresh_cache()
        return convert_entry_to_json(entry)

@app.route('/api/entries', methods=['PUT'])
@json_route(app, '/api/entries/<int:id>', methods=['POST'])
def upsert_schedule_entry_api(id=None):
    return upsert_schedule_entry(flask.request.json, id=id)

@json_route(app, '/api/entries/<int:id>', methods=['DELETE'])
def delete_schedule_entry(id):
    with db.db_session() as session:
        session.delete_all(db.ScheduleEntry, id=id)
        refresh_cache()
    return {}

@json_route(app, '/api/entries/<int:id>/trigger', methods=['POST'])
def trigger_schedule_entry(id):
    for entry in get_all_entries():
        if entry['id'] == id:
            trigger_entry(entry)
            return {'ok': True}
    return {'ok': False}

@app.route('/export')
def export_schedule():
    schedule = {
        'exported_at': str(util.now()),
        'entries': get_schedule_entries()
    }
    schedule_json = io.BytesIO(json.dumps(schedule, indent=4).encode('utf-8'))
    return flask.send_file(schedule_json, as_attachment=True,
            cache_timeout=0, attachment_filename='schedule.json')

@app.route('/import', methods=['POST'])
def import_schedule():
    for f in flask.request.files.values():
        try:
            data = json.load(f)
        except Exception as e:
            LOG.warning('error in schedule import: %s' % e)
            flask.abort(400)
        for entry in data['entries']:
            upsert_schedule_entry(entry, id=None)
        return util.redirect('/dali/schedule/')

@app.route('/')
def get_schedule_page():
    return flask.render_template('schedule.html', page='schedule')

SCHEDULE_THREAD = None
def start_schedule_thread(use_fan_control=True):
    global SCHEDULE_THREAD
    SCHEDULE_THREAD = threading.Thread(target=run_schedule, args=(use_fan_control,),
            daemon=True, name='Scheduler')
    SCHEDULE_THREAD.start()

def reset_all_info():
    global SCHEDULE_CACHE, TRIGGER_MAPPINGS
    SCHEDULE_CACHE = None
    TRIGGER_MAPPINGS = {}
