import base64
import functools
import json
import os
import random
import socket
import threading
import time

import flask
from werkzeug.security import safe_str_cmp

import config
import dali
import db
import util

LOG = util.get_logger('hue')

app = flask.Blueprint('hue', __name__, static_folder=None)

################################################################################
## Utils #######################################################################
################################################################################

SCHEMA_INT_STR = {'type': 'string', 'pattern': r'^[0-9]*$'}

def get_bridge_id():
    mac = util.get_mac_address().upper()
    return '%sFFFE%s' % (mac[:6], mac[6:])

def get_base_config():
    mac = ':'.join(util.chunked(util.get_mac_address(), 2))
    return {
        'apiversion': '1.65.0',
        'bridgeid': get_bridge_id(),
        'datastoreversion': '87',
        'factorynew': False,
        'mac': mac,
        'modelid': 'BSB002',
        #'name': config.site_settings.site_name,
        'name': 'Philips hue',
        'replacesbridgeid': None,
        'starterkitid':'',
        'swversion': '1967113020'
    }

def get_full_config():
    return {
        **get_base_config(),
        'UTC': timestamp(),
        'backup': {
            'errorcode': 0,
            'status': 'idle'
        },
        'dhcp': True,
        'gateway': '192.168.0.1',
        'internetservices': {
            'internet': 'connected',
            'remoteaccess': 'connected',
            'swupdate': 'connected',
            'time': 'connected'
        },
        'ipaddress': util.get_ip_address(),
        'linkbutton': False,
        'localtime': timestamp(),
        'netmask': '255.255.255.0',
        'portalconnection': 'connected',
        'portalservices': True,
        'portalstate': {
            'communication': 'disconnected',
            'incoming': False,
            'outgoing': True,
            'signedon': True
        },
        'proxyaddress': 'none',
        'proxyport': 0,
        'swupdate': {
            'checkforupdate': False,
            'devicetypes': {
                'bridge': False,
                'lights': [],
                'sensors': []
            },
            'notify': True,
            'text': '',
            'updatestate': 0,
            'url': ''
        },
        'swupdate2': {
            'autoinstall': {
                'on': True
            }
        },
        'timezone': util.get_timezone(),
        'zigbeechannel': 25,
    }

def timestamp():
    return util.now().isoformat()[:-6]

def generate_unique_id():
    with db.db_session() as session:
        for hc in session.query_all(db.HueConfig):
            id = hc.unique_id_seq
            hc.unique_id_seq = id + 1
            break
        # No config table yet, create it
        else:
            id = 0
            hc = session.insert(db.HueConfig, unique_id_seq=1)

    id_bytes = [id >> x & 0xFF for x in [16, 8, 0]]
    return '00:17:88:01:00:%02x:%02x:%02x-0b' % (*id_bytes,)

################################################################################
## Auth stuff ##################################################################
################################################################################

LINK_BUTTON_TIME = None
def get_link_button_status():
    global LINK_BUTTON_TIME
    if LINK_BUTTON_TIME is not None:
        t = util.get_time()
        if t - LINK_BUTTON_TIME < 30:
            return True
        LINK_BUTTON_TIME = None
    return False

def push_link_button():
    global LINK_BUTTON_TIME
    LINK_BUTTON_TIME = util.get_time()

def create_new_user(name, key=None):
    if key is None:
        if not get_link_button_status():
            raise util.APIError('unauthorized')
        key = base64.b16encode(os.urandom(16)).decode('ascii').lower()
    user_id = key[:8]
    password = key[8:]
    with db.db_session() as session:
        session.upsert(db.HueUser, {'user_id': user_id},
                password=password, name=name)
    return key

# Check authentication. The Hue protocol uses a big hex string as part of the
# path for REST queries. To avoid timing attacks, we use the first 8 digits as
# a 32-bit username (which should be pretty unique), and the rest as a password
# with constant-time compares.
def check_auth(user_key):
    user_id = user_key[:8]
    password = user_key[8:]
    with db.db_session() as session:
        for user in session.query_all(db.HueUser, user_id=user_id):
            if safe_str_cmp(user.password, password):
                return
    raise util.APIError('unauthorized')

def auth_route(app, *paths, **kwargs):
    def wrap(fn):
        nonlocal paths
        paths = ['/api/<string:user>' + path for path in paths]

        @util.json_route(app, *paths, **kwargs)
        @functools.wraps(fn)
        def inner(user, **kwargs):
            check_auth(user)
            return fn(**kwargs)
        return inner
    return wrap

################################################################################
## Config ######################################################################
################################################################################

@util.json_route(app, '/api/config',
        '/api/nouser/config')
def get_init_config():
    return get_base_config()

@auth_route(app, '/config')
def get_config():
    return get_full_config()

@auth_route(app, '')
def get_base_info():
    return {'config': get_full_config()}

@app.route('/description.xml')
def get_description_xml():
    ip = util.get_ip_address()
    mac = util.get_mac_address()
    return flask.render_template('description.xml', ip_address=ip, mac_address=mac)

################################################################################
## Lights ######################################################################
################################################################################

LIGHT_SCHEMA = util.schema_obj({
    'name': {'type': 'string'},
    'config': util.schema_obj({'archetype': {'type': 'string'}}),
    'on': {'type': 'boolean'},
    'bri': {'type': 'integer', 'minimum': 0, 'maximum': 255},
    'ct': {'type': 'integer', 'minimum': 1, 'maximum': 1000},
})

def light_state_to_hue(db_device, state):
    addr = dali.get_device_nice_addr(state)
    result = {
        'manufacturername': 'Philips',
        'modelid': 'ATX-LED',
        'name': dali.get_device_hue_name(state),
        'state': {
            'on': state.get('dev_on', (state['level'] > 0)),
            'bri': state['level'],
            'ct': 1000000 / state.get('color_temp_k', 4000),
            'colormode': 'ct',
            'reachable': True,
        },
        'swversion': '1.46.13_r26312',
        'type': 'ATX LED Light',
        'uniqueid': db_device.unique_id,
    }
    if db_device.config:
        result['config'] = db_device.config
    return result

def get_hue_db_light(session, address):
    address = dali.get_nice_addr(*address)
    for db_light in session.query_all(db.HueLight, address=address):
        return db_light
    # No light, create a new one
    return session.insert(db.HueLight, address=address,
            unique_id=generate_unique_id())

def get_dali_group_hue_state(db_device, channel, group_id):
    group = dali.DUMB_DB.get_group_state(channel, group_id)
    return light_state_to_hue(db_device, group)

def get_light_state(id):
    with db.db_session() as session:
        for db_light in session.query_all(db.HueLight, id=id):
            address = db_light.address
            [channel, addr_type, addr_id] = dali.parse_device_nice_addr(address)
            # Check for group address
            if addr_type == 'group':
                return get_dali_group_hue_state(db_light, channel, addr_id)

            for light in dali.DUMB_DB.get_matching_lights(db_light.address):
                if not light.get('hue_hidden'):
                    return light_state_to_hue(db_light, light)
    return None

# Update hue-only parameters: some data we only keep track of for Hue
# compatibility
def set_light_db_state(data, *db_lights):
    for db_light in db_lights:
        if 'config' in data:
            db_light.config = data['config']

def set_light_state(data, *addresses):
    new_state = {}

    # Name
    if 'name' in data:
        new_state['hue_name'] = data['name']
    # On/off
    if 'on' in data:
        new_state['dev_on'] = data['on']
    # Brightness
    if 'bri' in data:
        new_state['level'] = int(data['bri'])
    # Color temp
    if 'ct' in data:
        color_temp_mired = data['ct']
        color_temp_k = 1000000 / color_temp_mired
        new_state['color_temp_k'] = color_temp_k

    # Update state. Always send a bus update if we're only updating the
    # level, even if there's not a device at that address (and we'll
    # rescan it below)
    force_send = all(k in {'name', 'bri'} for k in new_state.keys())
    for address in addresses:
        light_data = dali.DUMB_DB.set_dali_light_state(address,
                new_state, force_send=force_send)

        # If there was no device at this address, flag the address to rescan it
        if light_data is None:
            [channel, addr_type, addr_id] = dali.parse_device_nice_addr(
                    address)
            if addr_type == 'single':
                dali.DUMB_DB.blacklist_address(channel, addr_id)

@auth_route(app, '/lights')
def get_lights():
    dali.ensure_scanned()
    state = []
    with db.db_session() as session:
        # Add normal lights
        for light in dali.DUMB_DB.get_all_lights_state():
            if not light.get('hue_hidden'):
                db_device = get_hue_db_light(session, light['address'])
                state.append(light_state_to_hue(db_device, light))
        # Add named groups
        for [[channel, group_id], [name, hidden]] in dali.DUMB_DB.group_info.items():
            if name and not hidden:
                address = (channel, 'group', group_id)
                db_device = get_hue_db_light(session, address)
                state.append(get_dali_group_hue_state(db_device, channel, group_id))

    return {'%s' % (i + 1): s for [i, s] in enumerate(state)}

@auth_route(app, '/lights/<int:light>')
def get_light(light):
    dali.ensure_scanned()
    light = get_light_state(light)
    if light:
        return light
    raise util.APIError('Unknown light %s' % light, code=404)

# XXX not sure what this does
@auth_route(app, '/lights', methods=['POST'])
def post_light_state():
    return {}

@auth_route(app, '/lights/<int:light>',
        '/lights/<int:light>/state',
       methods=['PUT'],)#        input_schema=LIGHT_SCHEMA)
def put_light(light):
    dali.ensure_scanned()
    state = flask.request.get_json()
    print(state)
    address = None
    with db.db_session() as session:
        for db_light in session.query_all(db.HueLight, id=light):
            set_light_db_state(state, db_light)
            address = db_light.address
            break
    if address:
        set_light_state(state, address)
        return {}
    raise util.APIError('Unknown light %s' % light, code=404)

# XXX not sure what this does
@auth_route(app, '/lights/new')
def get_lights_new():
    return {'lastscan': timestamp()}

################################################################################
## Groups ######################################################################
################################################################################

GROUP_SCHEMA = util.schema_obj({
    'name': {'type': 'string'},
    'lights': {'type': 'array', 'items': SCHEMA_INT_STR},
    'type': {'type': 'string'},
    'class': {'type': 'string'},
    **LIGHT_SCHEMA['properties'],
})

# Take a HueGroup from the database and gather info about all the lights
def get_group_state(group):
    return {
        'class': group.cls,
        'lights': [str(l) for l in group.light_ids],
        'name': group.name,
        'type': group.type,
        'state': {
            'all_on': False,
            'any_on': False,
        },
    }

def upsert_group(group_id, data):
    if group_id is None:
        args = {}
    else:
        args = {'id': group_id}
    # Pull out data for the upsert
    kwargs = {}
    if 'name' in data:
        kwargs['name'] = data.pop('name')
    if 'class' in data:
        kwargs['class'] = data.pop('class')
    if 'type' in data:
        kwargs['type'] = data.pop('type')
    if 'config' in data:
        kwargs['config'] = data.pop('config')
    if 'lights' in data:
        kwargs['light_ids'] = [int(l) for l in data.pop('lights')]
    if kwargs:
        with db.db_session() as session:
            row = session.upsert(db.HueGroup, args, **kwargs)
            return row.id

@auth_route(app, '/groups')
def get_groups():
    dali.ensure_scanned()
    with db.db_session() as session:
        return {str(g.id): get_group_state(g)
                for g in session.query_all(db.HueGroup)}

@auth_route(app, '/groups/<int:group>')
def get_group(group):
    dali.ensure_scanned()
    with db.db_session() as session:
        for g in session.query_all(db.HueGroup, id=group):
            return get_group_state(g)
    raise util.APIError('Unknown group %s' % group, code=404)

@auth_route(app, '/groups/<int:group>', methods=['PUT'],
        input_schema=GROUP_SCHEMA)
def put_group(data, group):
    dali.ensure_scanned()
    upsert_group(group, data)
    addresses = []
    with db.db_session() as session:
        # XXX do a real join
        for g in session.query_all(db.HueGroup, id=group):
            for light in g.light_ids:
                for db_light in session.query_all(db.HueLight, id=light):
                    set_light_db_state(data, db_light)
                    addresses.append(db_light.address)
    if addresses:
        set_light_state(data, *addresses)
        return {}
    raise util.APIError('Unknown group %s' % group, code=404)

@auth_route(app, '/groups', methods=['POST'], input_schema=GROUP_SCHEMA)
def post_group(data):
    upsert_group(None, data)

@auth_route(app, '/groups/<int:group>/action', methods=['PUT'],
        input_schema=GROUP_SCHEMA)
def put_group_action(data, group):
    dali.ensure_scanned()
    addresses = []
    with db.db_session() as session:
        # XXX do a real join
        for g in session.query_all(db.HueGroup, id=group):
            for light in g.light_ids:
                for db_light in session.query_all(db.HueLight, id=light):
                    set_light_db_state(data, db_light)
                    addresses.append(db_light.address)
    if not addresses:
        raise util.APIError('Unknown group %s' % group, code=404)
    set_light_state(data, *addresses)
    return {}

################################################################################
## Scenes ######################################################################
################################################################################

SCENE_SCHEMA = util.schema_obj({
    'type': {'type': 'string'},
    'name': {'type': 'string'},
    'recycle': {'type': 'boolean'},
    'group': SCHEMA_INT_STR,
    'lightstates': {
        'type': 'object',
        'propertyNames': SCHEMA_INT_STR,
        'additionalProperties': LIGHT_SCHEMA,
    },
    'appdata': util.schema_obj({
        'version': {'type': 'integer'},
        'data': {'type': 'string'}
    }),
})

def get_scene_state(scene):
    return {
        'group': str(scene.group),
        'name': scene.name,
        'type': scene.type,
        'lightstates': scene.state,
    }

@auth_route(app, '/scenes')
def get_scenes():
    dali.ensure_scanned()
    with db.db_session() as session:
        return {str(s.id): get_scene_state(s)
                for s in session.query_all(db.HueScene)}

@auth_route(app, '/scenes/<int:scene>')
def get_scene(scene):
    dali.ensure_scanned()
    with db.db_session() as session:
        for s in session.query_all(db.HueScene, id=scene):
            return get_scene_state(s)
    raise util.APIError('Unknown scene %s' % scene, code=404)

@auth_route(app, '/scenes', methods=['POST'], input_schema=SCENE_SCHEMA)
def post_scene(data):
    with db.db_session() as session:
        row = session.insert(db.HueScene, name=data['name'],
                type=data['type'], group=int(data['group']),
                state=data['lightstates'])
        return [{'success': {'id': str(row.id)}}]

################################################################################
## Sensors #####################################################################
################################################################################

# XXX not sure what this does
@auth_route(app, '/sensors/new')
def get_sensors_new():
    return {'lastscan': timestamp()}

################################################################################
## SSDP ########################################################################
################################################################################

# Deal with SSDP: some devices use this as part of UPnP to find Hue bridges.
# This is a rather crappy implementation, we aren't trying to be
# too robust or complete
def run_ssdp_server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', 1900))
    # Binary form of 239.255.255.250, SSDP multicast address
    multicast_addr = b'\xef\xff\xff\xfa\x00\x00\x00\x00'
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, multicast_addr)

    while True:
        try:
            [data, address] = sock.recvfrom(4096)

            # Not totally sure of the logic behind sleeping, but diyhue does it,
            # and seems reasonable as a crappy DoS prevention
            time.sleep(.5)

            if data.startswith(b'M-SEARCH * HTTP/1.1') and b'ssdp:discover' in data:
                ip = util.get_ip_address()
                mac = util.get_mac_address()
                bridge = get_bridge_id()

                root = 'upnp:rootdevice'
                uuid = 'uuid:2f402f80-da50-11e1-9b23-%s' % mac
                usn_root = '%s::%s' % (uuid, root)
                schema = 'urn:schemas-upnp-org:device:basic:1'

                # Send three packets with different ST/USN values. No idea what
                # these mean or why three are necessary, but that's what diyhue does
                resps = [[uuid, usn_root], [uuid, uuid], [schema, uuid]]

                for [st, usn] in resps:
                    resp = '''HTTP/1.1 200 OK
HOST: 239.255.255.250:1900
EXT:
CACHE-CONTROL: max-age=100
LOCATION: http://{ip}:80/description.xml
SERVER: Linux/3.14.0 UPnP/1.0 IpBridge/1.20.0
hue-bridgeid: {bridge}
ST: {st}
USN: {usn}
'''.format(ip=ip, bridge=bridge, st=st, usn=usn)

                    sock.sendto(resp.encode('ascii'), address)
        except Exception:
            LOG.exception('got exception in ssdp server')
            time.sleep(30)

################################################################################
## Init stuff ##################################################################
################################################################################

# Grab all the useful stuff from diyhue's config.json and convert it to
# our system. Most of the info is random crap we probably don't need...
def import_from_diyhue():
    try:
        with open('/home/pi/atxled/user-data/config.json') as f:
            config = json.load(f)
    except Exception:
        return

    for [key, user] in config['config']['whitelist'].items():
        if len(key) == 32:
            create_new_user(user['name'], key=key)

    with db.db_session() as session:
        for [id, light] in config['lights_address'].items():
            id = int(id)
            session.upsert(db.HueLight, {'id': id},
                    address=light['light_nr'])

        for [id, group] in config['groups'].items():
            id = int(id)
            light_ids = [int(l) for l in group['lights']]
            session.upsert(db.HueGroup, {'id': id}, name=group['name'],
                    cls=group['class'], type=group['type'], light_ids=light_ids)

def init_hue():
    import_from_diyhue()

    threading.Thread(target=run_ssdp_server, daemon=True, name='ssdp-server').start()
