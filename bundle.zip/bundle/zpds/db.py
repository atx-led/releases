from sqlalchemy import text
from sqlalchemy import Column, Integer, Float, String, BINARY, DateTime
from sqlalchemy.dialects.sqlite import JSON

import util
# Import some handy nuggets of code from common/common_db.py, which is symlinked
# into this directory so we can pretend Python packaging isn't terrible.
# Some of these are only used externally: SQL_NAMING_CONVENTION by alembic,
# db_session by most db-using code, and init_db for server/test startup
from common_db import (SQL_NAMING_CONVENTION, NiceBase, Base, BoolColumn,
        db_session, init_db, init_mem_db, is_holding_db_lock)

class SiteSettings(NiceBase, Base):
    # XXX this table is also used by cron-boom, so don't modify it without
    # updating reload_config() there
    __tablename__ = 'site_settings'
    site_name = Column(String(128))
    send_power_on_level = BoolColumn('send_power_on_level')
    manage_failover = BoolColumn('manage_failover')
    failover_level = Column(Integer, default=128)
    heartbeat_interval = Column(Integer)
    heartbeat_init_sent = BoolColumn('heartbeat_init_sent')
    enable_backups = BoolColumn('enable_backups', default=False)
    backup_notification_seen = BoolColumn('backup_notification_seen')
    dataplicity_key = Column(String(128))
    api_token = Column(String(128))

class VirtualDevice(NiceBase, Base):
    __tablename__ = 'virtual_devices'
    channel_id = Column(Integer)
    dali_addr_short = Column(Integer)
    groups = Column(JSON)
    name = Column(String(64))
    n_dmx_devices = Column(Integer, server_default=text('1'))

class VirtualGroup(NiceBase, Base):
    __tablename__ = 'virtual_groups'
    channel_id = Column(Integer)
    group_id = Column(Integer)
    devices = Column(JSON)
    name = Column(String(64))
    level = Column(Integer)

class Group(NiceBase, Base):
    __tablename__ = 'groups'
    channel_id = Column(Integer)
    group_id = Column(Integer)
    name = Column(String(64))
    hue_hidden = BoolColumn('hue_hidden', default=True)

class Device(NiceBase, Base):
    __tablename__ = 'devices'
    channel_id = Column(Integer)
    dali_addr_short = Column(Integer)
    serial_number = Column(Integer)
    upc_code = Column(Integer)
    name = Column(String(64))
    hue_name = Column(String(64))
    hue_hidden = BoolColumn('hue_hidden')
    color_k_min = Column(Integer)
    color_k_max = Column(Integer)
    color_cct_min = Column(Integer)
    color_cct_max = Column(Integer)
    rgb_power_scale = Column(Float)

class PassiveDevice(NiceBase, Base):
    __tablename__ = 'passive_devices'
    channel_id = Column(Integer)
    dali_addr_short = Column(Integer)
    name = Column(String(64))

class ZWaveNode(NiceBase, Base):
    __tablename__ = 'zwave_nodes'
    home_id = Column(Integer)
    node_id = Column(Integer)
    name = Column(String(64))
    hidden = BoolColumn('hidden')
    data = Column(JSON)

class SerialNumberSeq(Base):
    __tablename__ = 'serial_number_seq'
    serial_number_seq = Column(Integer, primary_key=True)

class GPSCache(NiceBase, Base):
    __tablename__ = 'gps_cache'
    gps_info = Column(JSON)

class ScheduleEntry(NiceBase, Base):
    __tablename__ = 'schedule_entries'
    name = Column(String(64))
    # These defaults probably shouldn't be here, but oh well...
    conditions = Column(JSON, default=[{
        'type': 'specific',
        'offset': {'direction': 'before', 'minutes': 0},
        'time': {'hour': '12', 'minute': '00', 'ampm': 'am'},
        'weekdays': util.ALL_WEEKDAYS}])
    actions = Column(JSON, default=[{'address': 'all', 'level': 0,
        'scene_id': 0, 'delay_minutes': 1}])
    last_triggered = Column(DateTime)

class Scene(NiceBase, Base):
    __tablename__ = 'scenes'
    name = Column(String(64))
    visible = BoolColumn('visible', default=True)
    state = Column(JSON)

class DeviceBank5Data(NiceBase, Base):
    __tablename__ = 'device_bank_5_data'
    upc_code = Column(Integer)
    fw_version = Column(Integer)
    hw_version = Column(Integer)
    serial_nb = Column(Integer)
    bank_5_data = Column(BINARY(64))

class HueConfig(NiceBase, Base):
    __tablename__ = 'hue_config'
    unique_id_seq = Column(Integer)

class HueUser(NiceBase, Base):
    __tablename__ = 'hue_users'
    name = Column(String(64))
    user_id = Column(String(64))
    password = Column(String(64))

class HueLight(NiceBase, Base):
    __tablename__ = 'hue_lights'
    unique_id = Column(String(64))
    address = Column(String(64))
    config = Column(JSON)

class HueGroup(NiceBase, Base):
    __tablename__ = 'hue_groups'
    name = Column(String(64))
    cls = Column(String(64))
    type = Column(String(64))
    light_ids = Column(JSON)
    config = Column(JSON)

class HueScene(NiceBase, Base):
    __tablename__ = 'hue_scenes'
    name = Column(String(64))
    type = Column(String(64))
    group = Column(Integer)
    state = Column(JSON)
    app_data = Column(JSON)
