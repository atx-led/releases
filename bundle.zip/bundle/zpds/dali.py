import collections
import contextlib
import json
import math
import queue
import random
import sys
import threading
import time

import config
import dali_cmds
import db
import util
import zwave
from dali_cmds import DALI_ATTRS

LOG = util.get_logger('dali')

MAX_CHANNELS = 4
MAX_SCENES = 16
MAX_BUTTONS = 8

# Config
FAILOVER_STATUS = 0
LAST_STATUS_CMD_TIME = None

ON_OFF_LISTENER = None
LEVEL_CHANGE_LISTENER = None
COLOR_CHANGE_LISTENER = None
SCENE_LISTENER = None
BCAST_LISTENER = None
STARTUP_LISTENER = None

GLOBAL_LOCK = threading.RLock()

# Stuff for the DALI monitor thread
DALI_THREADS = []
STOP_THREADS = False
PULSE_LIGHTS = False

# Stuff for the LED status thread
DALI_STATUS = util.Object(d_status=0, hat_voltages=[0, 0])

# Get a lock to control the DALI bus as a context manager (like
# 'with get_dali_lock(): ...'), but allow a single thread to acquire/release
# multiple times. That way, we can nest these locks freely to group DALI
# commands into "transactions" within a thread, but a different thread will
# have to wait until the outermost lock is released before doing anything on
# the bus. Generally each high-level DALI operation (e.g. "assign addresses",
# which can take hundreds or thousands of DALI commands) will have its entire
# algorithm inside this lock; DALI has a lot of weird implicit state and we
# don't want some other thread going around sending out commands that might
# mess up that state, or not reach a device, etc.
# XXX this will be per-channel, but we're just ignoring the channel for now
_DALI_LOCK = threading.RLock()
_DALI_PRIORITY_LOCK = threading.RLock()
_DALI_THREAD_LOCALS = threading.local()
@contextlib.contextmanager
def get_dali_lock(channel):
    inside_lock = getattr(_DALI_THREAD_LOCALS, 'inside_lock', False)

    # Basic priority mechanism: we prioritize all threads that aren't explicitly
    # marked as low priority (for now just the monitor thread). We do this with
    # two locks: a high-priority thread will take the priority lock before trying
    # to take the regular lock, while the low-priority thread will take the regular
    # lock, but release it if the priority lock is held (indicating the high-priority
    # thread is waiting)
    is_low_priority = getattr(_DALI_THREAD_LOCALS, 'is_low_priority', False)
    if not is_low_priority:
        with _DALI_PRIORITY_LOCK:
            with _DALI_LOCK:
                # Check for db/DALI lock ordering: if this lock wasn't already
                # held, the db lock must not be held. This is to guard against
                # deadlocks: if a piece of code needs both the db and DALI locks,
                # the DALI lock must be acquired first.
                if not inside_lock:
                    assert not db.is_holding_db_lock(), 'bad lock ordering'

                _DALI_THREAD_LOCALS.inside_lock = True
                try:
                    yield
                finally:
                    _DALI_THREAD_LOCALS.inside_lock = inside_lock
    else:
        # Low priority threads might give up their time slice of holding the
        # lock, so keep looping til we get a free low-priority slice
        while True:
            with _DALI_LOCK:
                # We're already inside a nested lock, just keep the lock, since
                # we can't actually give up our time slice. Otherwise, we
                # can get a deadlock.
                if inside_lock:
                    # Don't need to modify inside_lock here, it's True before/after
                    yield
                    break

                # Ensure db/DALI lock ordering. See comment above.
                assert not db.is_holding_db_lock(), 'bad lock ordering'

                # Check if the high priority thread is waiting. If not,
                # we're good to go
                got_lock = _DALI_PRIORITY_LOCK.acquire(blocking=False)
                if got_lock:
                    # We don't actually want to hold the high-priority lock
                    _DALI_PRIORITY_LOCK.release()
                    _DALI_THREAD_LOCALS.inside_lock = True
                    try:
                        yield
                    finally:
                        _DALI_THREAD_LOCALS.inside_lock = False
                    break

# If we don't have any known lights, make sure to do a quick synchronous
# scan of the bus to see which lights respond, so we can get an accurate
# count for the client
def ensure_scanned(quick=False, rescan=False):
    try:
        return DUMB_DB.ensure_scanned(rescan=rescan, quick=quick)
    except Exception as e:
        return None

class SerialBus:
    def __init__(self):
        self.buffer = [[] for i in range(MAX_CHANNELS)]
        self.low_pri_buf = []
        self.lock = threading.RLock()
        try:
            import serial
            # Set a timeout of .2 seconds. This is pretty quick, and can cause a bit
            # of overhead from lots of read calls, but this is also our max latency
            # for sending synchronous DALI commands i.e.: the monitor thread tries
            # to read with a timeout of X, the sending thread can't acquire the lock
            # until the read times out.
            self.conn = serial.Serial(port='/dev/ttyS0', baudrate=19200,
                    parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS, timeout=.2)

            # XXX
            old_write = self.conn.write
            self.conn.write = lambda buf, is_resend=False: old_write(buf)

        except Exception as e:
            LOG.exception('Could not open serial connection: %s', e)
            # XXX Return something that throws reasonable errors
            self.conn = None

    def _read_line(self, allow_blank=False):
        with self.lock:
            line = ''
            byte = self.conn.read(1).decode('ascii')
            if allow_blank and byte == '':
                return ''
            ct = 0
            while byte != '\n':
                # Sanity checks: make sure we're not getting a crazy long line,
                # or waiting forever for the end of a partial packet
                if byte:
                    ct = 0
                    line += byte
                    if len(line) > 30:
                        raise RuntimeError('GOT CRAZY LINE: %s' % repr(line))
                else:
                    ct += 1
                    if ct > 10:
                        raise RuntimeError('GOT INCOMPLETE PACKET: %s' % repr(line))
                byte = self.conn.read(1).decode('ascii')
            return line

    def read_line_low_pri(self, allow_blank=False):
        if self.low_pri_buf:
            r = self.low_pri_buf.pop(0)
        else:
            r = self._read_line(allow_blank=allow_blank)
        return r

    def enqueue(self, channel, lines):
        with self.lock:
            prefix = '' if not channel else str(channel)
            for line in lines:
                self.low_pri_buf.append(prefix + line)

    def read_line(self, channel, allow_blank=False):
        with self.lock:
            while not self.buffer[channel]:
                line = self._read_line(allow_blank=allow_blank)
                if not line:
                    assert allow_blank
                    return ''
                ch = 0
                if line[0].isdigit():
                    ch = int(line[0])
                    line = line[1:]
                self.buffer[ch].append(line)
            return self.buffer[channel].pop(0)

    def write_raw(self, channel, data, is_resend=False):
        with self.lock:
            prefix = '' if not channel else str(channel)
            self.conn.write((prefix + data).encode('ascii'), is_resend=is_resend)

    def write(self, channel, cmd, allow_blank=False):
        with self.lock:
            self.write_raw(channel, cmd)
            if channel is None:
                return self._read_line()
            return self.read_line(channel, allow_blank=allow_blank)

    # XXX Just flush all input to sync up, we might be ignoring some stuff.
    # This is rather crappy, we should definitely be handling this better
    def reset_input_buffer(self):
        self.conn.reset_input_buffer()
        self.buffer = [[] for i in range(MAX_CHANNELS)]
        self.low_pri_buf = []

def get_addr_0(address):
    if isinstance(address, int):
        address = (None, 'single', address)
    elif isinstance(address, str):
        address = parse_device_nice_addr(address)
    channel, addr_type, addr_id = address
    if addr_type in ('single', 'passive', 'virtual-device'):
        assert 0 <= addr_id < 64
        addr = (addr_id << 1)
    elif addr_type in ('group', 'virtual-group'):
        assert 0 <= addr_id < 16
        addr = 0x80 | (addr_id << 1)
    elif addr_type == 'all':
        addr = 0xFE
    else:
        assert False
    return addr

def get_addr_1(addr):
    return get_addr_0(addr) | 1

def get_device_name(device):
    name = device.get('dev_name')
    if name:
        return name
    channel, addr_type, addr_id = device['address']
    if addr_type == 'virtual-group':
        dev_type = 'Virtual Group'
    elif addr_type == 'virtual-device':
        dev_type = 'DMX Device'
    else:
        dev_type = 'Switch'
    ch_str = ' (Channel %s)' % (channel + 1) if channel else ''
    return '%s %s%s' % (dev_type, addr_id, ch_str)

def get_device_hue_name(device):
    hue_name = device.get('hue_name')
    if hue_name:
        return hue_name
    return get_device_name(device)

ADDRESS_TYPE_PREFIX = {
    'single': 's',
    'passive': 'p',
    'group': 'g',
    'virtual-group': 'v',
    'virtual-device': 'd', # d for DMX
    'zwave': 'z',
}
INV_ADDRESS_TYPE_PREFIX = {v: k for k, v in ADDRESS_TYPE_PREFIX.items()}

def get_nice_addr(channel, addr_type, addr_id):
    if addr_type == 'all':
        return 'all'
    prefix = ADDRESS_TYPE_PREFIX[addr_type]
    return '%s_%s_%s' % (channel, prefix, addr_id)

def get_device_nice_addr(device):
    channel, addr_type, addr_id = device['address']
    return get_nice_addr(channel, addr_type, addr_id)

def parse_device_nice_addr(nice_addr):
    if not isinstance(nice_addr, str):
        return nice_addr
    if nice_addr == 'all':
        return (None, 'all', None)
    # XXX backwards compatibility with old single channel addresses
    if nice_addr.count('_') == 1:
        addr_prefix, addr_id = nice_addr.split('_')
        channel = 0
    else:
        channel, addr_prefix, addr_id = nice_addr.split('_')
        channel = int(channel)
    addr_type = INV_ADDRESS_TYPE_PREFIX[addr_prefix]
    addr_id = int(addr_id)
    return (channel, addr_type, addr_id)

def device_is_atxled(device):
    return device.get('upc_code') in dali_cmds.ATX_UPC_TABLE

def device_is_dr2f(device):
    return device.get('upc_code') in {dali_cmds.DR2F16_UPC, dali_cmds.DR2F32_UPC,
            dali_cmds.DR2G32_UPC}

def device_is_dr2f32(device):
    return device.get('upc_code') in {dali_cmds.DR2F32_UPC, dali_cmds.DR2G32_UPC}

def device_is_dr2g32(device):
    return device.get('upc_code') == dali_cmds.DR2G32_UPC

def device_is_dr1g(device):
    return device.get('upc_code') == dali_cmds.DR1G_UPC

def device_is_dr1_pir(device):
    return device.get('upc_code') == dali_cmds.DR1_PIR_UPC

def device_is_dali8b(device):
    return device.get('upc_code') in {dali_cmds.DALI_8B_UPC, dali_cmds.DALI_IO16_UPC,
            dali_cmds.DALI_RELAY8_UPC}

def device_is_dali_io16(device):
    return device.get('upc_code') == dali_cmds.DALI_IO16_UPC

def device_is_relay8(device):
    return device.get('upc_code') == dali_cmds.DALI_RELAY8_UPC

def device_is_pse4d(device):
    return device.get('upc_code') == dali_cmds.PSE_4D_UPC

def device_is_pir(device):
    if 'n_way' not in device:
        return False
    return device['n_way'] in {3, 4, 5}

# Color temp conversion
def convert_k_cct(device, k):
    [k_min, k_max] = [device['color_k_min'], device['color_k_max']]
    [cct_min, cct_max] = [device['color_cct_min'], device['color_cct_max']]
    cct = int(util.scale(k, k_min, k_max, cct_min, cct_max))
    return util.clip(cct, cct_min, cct_max)

def convert_cct_k(device, cct):
    [k_min, k_max] = [device['color_k_min'], device['color_k_max']]
    [cct_min, cct_max] = [device['color_cct_min'], device['color_cct_max']]
    k = int(util.scale(cct, cct_min, cct_max, k_min, k_max))
    return util.clip(k, k_min, k_max)

# DALI Hat tables

POWER_MODE_CURRENT_DICT = {
    0: 'Off',
    1: '80 mA',
    3: '180 mA',
}
POWER_MODE_LOCKED_DICT = {
    0: 'Auto',
    4: 'Locked',
}
# Ugh Murray designs shit so weirdly. The 3-bit value sent by the hat has
# independent current/locked bits, but the q command we send to the hat has
# different meanings: the low two bits are the same if the value is <4, but
# values 4 and 5 are repurposed: 4 unsets bit 3, 5 sets it. WTF??
POWER_MODE_LOCKED_REMAP = {
    0: 4,
    4: 5,
}

# Schemas for various JSON objects

ADDR_REGEX = '^[0-9]+_[a-z]_[0-9]+$'

SCENE_SCHEMA = util.schema_obj({
    'name': {'type': 'string'},
    'visible': {'type': 'boolean'},
    'state': {
        'propertyNames': {'pattern': ADDR_REGEX},
        'additionalProperties': util.schema_obj({
            'dev_on': {'type': 'boolean'},
            'send_level': {'type': 'boolean'},
            'level': {'type': 'integer', 'minimum': 0, 'maximum': 255},
            'send_color': {'type': 'boolean'},
            'color_temp_k': {'type': 'integer', 'minimum': 1000, 'maximum': 7000},
            'color_rgbw': {'type': 'array', 'length': {'minimum': 3, 'maximum': 6},
                'items': {'minimum': 0, 'maximum': 255}},
        }),
    }
})

BUTTON_SEND_MODES = {
    1: 'single',
    2: 'group',
    4: 'scene',
    8: 'all',
}
BUTTON_INV_SEND_MODES = {v: k for [k, v] in BUTTON_SEND_MODES.items()}

BUTTON_LED_MODES = {
    0: 'off',
    1: 'master',
    2: 'dest',
    3: 'on_off',
}
BUTTON_INV_LED_MODES = {v: k for [k, v] in BUTTON_LED_MODES.items()}

BUTTON_SCHEMA = util.schema_obj({
    'id': {'type': 'integer', 'minimum': 0, 'maximum': MAX_BUTTONS - 1},
    'address': {'type': 'integer', 'minimum': 0, 'maximum': 63},
    'send_mode': {'type': 'string', 'enum': list(BUTTON_INV_SEND_MODES.keys())},
    'pairwise': {'type': 'boolean'},
    'led_mode': {'type': 'string', 'enum': list(BUTTON_INV_LED_MODES.keys())},
    'momentary': {'type': 'boolean'},
    'undo': {'type': 'boolean'},
})

BUTTON_LIST_SCHEMA = {
    'type': 'array',
    'items': BUTTON_SCHEMA,
    'length': {'minimum': 1, 'maximum': 8},
}

# Instead of an actual database for now, just a class that mimics one. This is
# ephemeral!
class DumbDB:
    def __init__(self):
        self.serial_device = SerialBus()
        # Pretty event stream for DALI log websocket
        self.dali_events = util.EventStream(history=2000)
        self.reset_all_info()

    def init_from_db(self):
        # Get both the DALI lock and the db lock. We only occasionally need
        # the DALI lock, but it must be acquired before the db lock so do it
        # first always
        with get_dali_lock(None), db.db_session() as session:
            # Initialize virtual devices
            self.virtual_devices = {i: {} for i in range(MAX_CHANNELS)}
            for vd in session.query_all(db.VirtualDevice):
                try:
                    args = {'groups': vd.groups, 'fail_level': vd.n_dmx_devices}
                    if vd.name:
                        args['dev_name'] = vd.name
                    self.set_virtual_device(vd.channel_id, vd.dali_addr_short, args)
                except Exception as e:
                    LOG.error('got error initializing virtual device: %s', e)

            # Initialize virtual groups
            self.virtual_groups = {i: {} for i in range(MAX_CHANNELS)}
            for vg in session.query_all(db.VirtualGroup):
                self.set_virtual_group(vg.channel_id, vg.group_id, vg.name,
                        vg.devices, update_db=False)

            # Initialize scenes
            self.scenes = {}
            for scene in session.query_all(db.Scene):
                self.scenes[scene.id] = self.scene_to_json(scene)

            # Initialize groups
            self.group_info = {}
            for group in session.query_all(db.Group):
                key = (group.channel_id, group.group_id)
                self.group_info[key] = (group.name, group.hue_hidden)

    def reset_all_info(self):
        self.channels = 1
        self.busses = {}
        self.active_busses = None
        # The set of active busses at the last address scan, so we can
        # easily check if we need to clear devices from inactive busses
        #self.last_active_busses = None

        self.has_scanned = False
        self.lights = {}
        self.conflict_addresses = set()
        self.zwave_lights = {}
        self.group_info = {}
        self.delayed_blacklist = []
        self.blacklist_all_addresses()
        self.missing_devices = {}
        self.passive_devices = {i: {} for i in range(MAX_CHANNELS)}
        self.passive_groups = {i: set() for i in range(MAX_CHANNELS)}
        self.virtual_devices = {i: {} for i in range(MAX_CHANNELS)}
        self.virtual_groups = {i: {} for i in range(MAX_CHANNELS)}
        self.scenes = {}
        self.load_topology = []
        self.dr2g_topology = {}
        self.pse_topology = []

        # Event stream for websockets
        self.state_changes = util.EventStream()
        self.group_state_changes = util.EventStream()
        self.broadcast_state_changes = util.EventStream()

        # Status info
        self.bus_voltage = '0'
        self.bus_current_0v = '0'
        self.dali_q_status = None

    # Blacklist handling: this is for flagging addresses that should be
    # rescanned. If quick=True, the address is sorta 'half-blacklisted'. That
    # is, we query its status, and if it's there we're good--we don't force a
    # full attribute scan
    def blacklist_address(self, channel, short_addr, quick=False):
        assert 0 <= short_addr < 64
        # Atomically add this entry to the blacklist if the address isn't there
        # already
        with get_dali_lock(None):
            if not any(sa == short_addr
                    for [sa, q] in self.address_blacklist[channel]):
                self.address_blacklist[channel].append((short_addr, quick))

    def blacklist_all_addresses(self, *addresses, quick=False):
        # Queue of addresses that the monitor thread will do a full scan on.
        # Set a max of 2*max-possible-addresses just for a sanity check
        self.full_scan_addresses = queue.Queue(maxsize=2*MAX_CHANNELS*64)
        with get_dali_lock(None):
            self.address_blacklist = {i: [(a, quick) for a in range(64)]
                    for i in range(MAX_CHANNELS)}
            self.do_passive_address_scan = True

    def blacklist_passive_addresses(self):
        with get_dali_lock(None):
            self.do_passive_address_scan = True

    # Mark an address to be scanned later once the light has had time to reset
    def delay_blacklist(self, channel, address, is_atxled, set_level=None):
        self.delayed_blacklist.append((util.get_time() + 5, 0,
                channel, address, is_atxled, set_level))

    def update_bus_active_status(self, channel, status):
        if status.startswith('D2'):
            self.active_busses.add(channel)
        elif channel in self.active_busses:
            self.active_busses.remove(channel)
        # Update DALI_STATUS so the LED thread can flash lights or whatever
        if channel == 0 and len(status) >= 2 and status[1].isdigit():
            DALI_STATUS.d_status = int(status[1])

    def init_busses(self):
        with get_dali_lock(None):
            self.serial_device.reset_input_buffer()
            self.read_version(log=False)

            if set(self.busses) != set(range(self.channels)):
                self.busses = {}
                for channel in range(self.channels):
                    self.busses[channel] = DALIBus(self.serial_device, channel,
                            self.dali_events)
                self.active_busses = None

            # Detect active busses
            # XXX work around firmware bug in hats with version 32 fw.
            # The D command will short the bus out for a short time and it
            # will totally freak out other DALI devices.
            if self.hw_type not in {1, 7} or self.fw_version != 32:
                self.active_busses = set()

                for channel in range(self.channels):
                    status = self.send_conf_command('d\n', 'D', channel=channel)
                    self.update_bus_active_status(channel, status)
            # Otherwise just assume all busses are active. We should get a bus
            # failure message later if a bus fails. Because we track that, we
            # don't want to reset the active busses all the time, only when we
            # don't have any other information.
            elif self.active_busses is None:
                self.active_busses = set(range(self.channels))

    def iter_busses(self):
        for channel, bus in self.busses.items():
            if channel in self.active_busses:
                yield bus

    def update_q_status(self, status=None, log=True):
        self.bus_voltage = '0'
        self.bus_current_0v = '0'
        self.dali_q_status = [['error', 'could not read status']]
        try:
            if status is None:
                status = self.send_conf_command('q\n', 'Q', log=log)
            LOG.debug('got DALI power status %r', status)
            if not status:
                return
            current = int(status[1])
            locked = current & 4
            current &= 3

            self.power_mode_current = current
            self.power_mode_locked = locked
            mode_str = '%s (%s)' % (POWER_MODE_CURRENT_DICT[current],
                    POWER_MODE_LOCKED_DICT[locked].lower())

            def convert(s):
                return '%.3f' % (int(s) / 1000)

            self.bus_voltage = convert(status[2:7])
            self.bus_current_0v = convert(status[7:10])
            self.dali_q_status = [
                ['internal DALI power',     mode_str],
                ['voltage',                 self.bus_voltage + 'V'],
                ['current (at 0v)',         self.bus_current_0v + 'A'],
                ['current (at 6v, peak)',   convert(status[10:14]) + 'A'],
                ['current (at 6v, final)',  convert(status[14:17]) + 'A'],
            ]
        except Exception:
            LOG.exception('got exception getting power status')

    def read_version(self, log=True):
        HW_TYPE_NAME = {
            None: 'AL-DALI-HAT v1 with DALI power',
            1: 'AL-DALI-HAT v2 with DALI power',
            2: 'AL-DALI-HAT-I2 Isolated 2 channel',
            4: 'AL-DALI-HAT-I4 Isolated 4 channel',
            3: 'AL-DALI-Pi SML v',
            5: 'AL-DALI-PI-T1 DALI, 2x Relay',
            6: 'AL-DALI-Pi with DMX and 2nd DALI',
            7: 'AL-PoE-Pi SML v10 with DMX + 2x DALI',
        }
        self.channels = 1
        self.hw_version = '???'
        self.fw_version = None
        self.hw_type = None
        self.power_mode_current = None
        self.power_mode_locked = None
        self.has_power_opts = False
        try:
            versions = self.send_conf_command('v\n', 'V', log=log)
            LOG.debug('got version %r', versions)
            if versions:
                self.hw_version = versions[1:3]
                self.fw_version = int(versions[3:5])
                if len(versions) >= 7:
                    self.hw_type = int(versions[5:7])
                    if self.hw_type in {1, 2, 4}:
                        self.channels = self.hw_type
                    elif self.hw_type == 3:
                        self.channels = 1
                    elif self.hw_type in {6, 7}:
                        self.channels = 2

                    # Check if we can set the bus power mode for the hat
                    if self.hw_type in {1, 3, 6, 7}:
                        self.has_power_opts = True

                    # Special code for the tester hardware: at boot we turn pin
                    # 33 on to turn on the green onboard LED, unconditionally.
                    # But for tester hardware, this pin is actually mapped to a
                    # relay, so just turn it back off in that case
                    if self.hw_type == 5:
                        import RPi.GPIO as GPIO
                        GPIO.setwarnings(False)
                        GPIO.setmode(GPIO.BOARD)
                        GPIO.setup(33, GPIO.OUT)
                        GPIO.output(33, 0)
        except Exception:
            LOG.exception('got exception getting version')
        self.hw_type_name = HW_TYPE_NAME.get(self.hw_type, str(self.hw_type))

    def read_dali_power_status(self, log=True, force=False):
        self.dali_power_status = [['error', 'could not read status']]
        try:
            can_read_voltage = self.hw_type not in {None, 0, 2, 4, 6}
            # Read power status for hats that support it
            if can_read_voltage:
                # Send one Q command at startup, so we always have some data
                if self.dali_q_status is None or force:
                    self.update_q_status(status=None, log=log)

                # For firmware version >= 14, there's a q status command that can be
                # performed without disrupting the bus, so use that every time
                elif (self.fw_version or 0) >= 0x14:
                    status = self.send_conf_command('q6\n', 'Q', log=log)
                    self.update_q_status(status=status)

                # Otherwise, self.dali_power_status is updated passively as the hat
                # sends q updates.
                self.dali_power_status = self.dali_q_status
            # Read power status for old hats and 2/4 channel hats
            else:
                self.bus_current_0v = '100'

                STATE_DICT = {
                    '0': 'No power',
                    '1': 'Bus current too high, cannot drive to zero',
                    '2': 'Power OK',
                    '3': 'Unknown'
                }
                self.dali_power_status = []
                # XXX work around firmware bug in hats before version 33.
                # The D command will short the bus out for a short time and it
                # will totally freak out other DALI devices. This conditional should
                # not do anything, since HW types 1/7 should go through the
                # alternative voltage read code path above, but "belt and
                # suspenders" as Murray says
                if self.hw_type not in {1, 7} or self.fw_version != 32:
                    for c in range(self.channels):
                        status = self.send_conf_command('d\n', 'D', channel=c, log=log)
                        if len(status) >= 2:
                            self.dali_power_status.append(['state (channel %d)' % (c + 1),
                                STATE_DICT[status[1]]])
                            # Set bus voltage for 1-channel hats. Apparently the
                            # multi-channel hats have a more complicated formula
                            if self.channels == 1:
                                self.bus_voltage = '15' if status[1] == '2' else '0'

        except Exception as e:
            LOG.exception('got exception getting power status')

    def set_dali_power_mode(self, current, locked):
        assert current in {0, 1, 3}
        assert locked in {0, 4}
        LOG.info('set_dali_power_mode: current=%s, locked=%s', current, locked)
        self.send_cmd_raw('q%d\n' % current, channel=0, allow_blank=True)

        # Yuck, see comment above for the remap
        locked = POWER_MODE_LOCKED_REMAP[locked]
        self.send_cmd_raw('q%d\n' % locked, channel=0, allow_blank=True)

    def update_hat_power_status(self, status=None, log=True):
        global FAILOVER_STATUS
        try:
            if status is None:
                status = self.send_conf_command('p\n', 'P', log=log)
            LOG.debug('got hat power status %r', status)
            if not status:
                return
            self.hat_power_voltages = [int(status[1:4]) / 10, int(status[4:7]) / 10]

            # Update DALI_STATUS so the LED thread can flash lights or whatever
            DALI_STATUS.hat_voltages = self.hat_power_voltages

            # Check for failover: any power supply going below 46V
            if config.SITE_SETTINGS.manage_failover:
                level = None
                if any(v < 46 for v in self.hat_power_voltages):
                    level = config.SITE_SETTINGS.failover_level
                # No failure: go back to normal mode if we're in failover mode
                elif FAILOVER_STATUS < 255:
                    level = 255
                if level is not None:
                    FAILOVER_STATUS = level
                    for bus in self.iter_busses():
                        with get_dali_lock(bus.channel):
                            bus.send_normal_cmd(0xA3, level & 255)
                            bus.send_normal_cmd(0xFF, 0x31)
        except Exception as e:
            LOG.exception('got exception getting power status')

    def read_hat_power_status(self, log=True):
        self.hat_power_voltages = None
        self.hat_power_status = [['error', 'could not read status']]
        try:
            # Read power for old hats
            if self.hw_type is None:
                import RPi.GPIO as GPIO
                GPIO.setmode(GPIO.BOARD)
                GPIO.setup(29, GPIO.IN)
                GPIO.setup(31, GPIO.IN)
                VOLTAGES = [0, 48]
                self.hat_power_voltages = [
                    VOLTAGES[(GPIO.input(31) != 0)],
                    VOLTAGES[(GPIO.input(29) != 0)],
                ]
                self.hat_power_status = [
                    ['primary power', self.hat_power_voltages[0]],
                    ['secondary power', self.hat_power_voltages[1]],
                ]
            # Read power for new hats through p command
            else:
                self.update_hat_power_status(status=None, log=log)
                self.hat_power_status = [
                    ['voltage A', '%4.1fV' % self.hat_power_voltages[0]],
                    ['voltage B', '%4.1fV' % self.hat_power_voltages[1]],
                ]
                # Read PoE power sources
                if self.hw_type == 7:
                    pins = {'B': [31, 37], 'C': [29, 15, 13]}
                    DESC = ['not detected', 'good']

                    import RPi.GPIO as GPIO
                    GPIO.setmode(GPIO.BOARD)
                    for [connector, pins] in sorted(pins.items()):
                        for [i, pin] in enumerate(pins):
                            GPIO.setup(pin, GPIO.IN)
                            status = DESC[GPIO.input(pin)]
                            self.hat_power_status.append(
                                ['%s%s' % (connector, i+1), status])

        except Exception as e:
            LOG.exception('got exception getting power status')

    def get_status(self, log=True):
        with get_dali_lock(None):
            self.serial_device.reset_input_buffer()
            self.read_version(log=log)
            self.read_dali_power_status(log=log)
            self.read_hat_power_status(log=log)

        return {'hw_version': self.hw_version, 'fw_version': self.fw_version,
                'channels': self.channels, 'hw_type': self.hw_type_name,
                'dali_power_status': self.dali_power_status,
                'hat_power_status': self.hat_power_status}

    def read_device_power_status(self):
        def fix_up_nones(d):
            return {k: '-' if v is None else v for k, v in d.items()}

        self.ensure_scanned()
        total_on = 0
        total_energy = 0
        total_avg_power = 0
        total_max_power = 0
        bus_details = {}
        for bus in self.iter_busses():
            bus_details[bus.channel] = {}
            for short_addr in range(64):
                devices = list(self.get_matching_lights((bus.channel,
                        'single', short_addr)))
                if not devices:
                    continue
                [device] = devices

                status = None
                if device_is_atxled(device):
                    status = bus.read_device_power_status(short_addr,
                            is_dr2f32=device_is_dr2f32(device))
                if not status:
                    status = {}
                else:
                    if device_is_pir(device):
                        status['energy_used'] = 0
                    total_on += status['time_on']
                    total_energy += status['energy_used']
                    if status['max_power']:
                        total_avg_power += status['avg_power']
                        total_max_power += status['max_power']
                status['name'] = get_device_name(device)
                bus_details[bus.channel][short_addr] = fix_up_nones(status)

        effective_dim = None
        if total_max_power > 0:
            effective_dim = 100 * total_avg_power / total_max_power
            effective_dim = '%.0f%%' % effective_dim
        return fix_up_nones({'total_on': total_on, 'total_energy': total_energy,
                'effective_dim': effective_dim, 'bus_details': bus_details})

    @util.with_lock(GLOBAL_LOCK)
    def read_load_topology_gen(self):
        result = []

        total = len(self.lights.values())
        complete = 0
        for light in self.lights.values():
            # Filter for DR2F/DR2G/DR1PIR
            if not (device_is_dr2f32(light) or device_is_dr1_pir(light)):
                continue

            channel = light['channel']
            bus = self.busses[channel]

            count_lr = bus.read_dr2_led_count(light['short_addr'])

            # If CCT mode, average together left/right counts
            mode = light.get('driver_mode')
            count_cct = None
            if mode == 3 and count_lr:
                count_cct = (count_lr[0] + count_lr[1]) // 2
                count_lr = None

            has_fan = False
            mem = bus.read_dev_mem(light['short_addr'], 0x531, 1)
            if len(mem) == 1 and mem[0] == 4:
                has_fan = True

            peak_watts = None
            mem = bus.read_dev_mem(light['short_addr'], 0x40A, 1)
            if len(mem) == 1:
                peak_watts = mem[0]

            result.append({
                'channel': channel,
                'short_addr': light['short_addr'],
                'light': light,
                'led_counts_lr': count_lr,
                'led_count_cct': count_cct,
                'has_fan': has_fan,
                'peak_watts': peak_watts,
            })

            complete += 1
            yield (complete, total)

        self.load_topology = result

    @util.with_lock(GLOBAL_LOCK)
    def read_dr2g_topology_gen(self):
        result = {}
        for bus in self.iter_busses():
            channel = bus.channel
            # Collect all devices that are DR2Gs on this bus
            dr2gs = [light['short_addr'] for light in self.lights.values()
                    if light['channel'] == channel and
                    (device_is_dr1g(light) or device_is_dr2g32(light) or
                        device_is_dr1_pir(light) or
                        (device_is_dr2f32(light) and light.get('hw_version', 0) >= 4))]

            # Helpers to read voltage input/wattage from a light
            def read_light_voltage(short_addr):
                mem = bus.read_dev_mem(short_addr, 0x40E, 2)
                if len(mem) == 2:
                    return dali_cmds.int_from_mem(mem, big_endian=False)
            def read_light_power(short_addr):
                mem = bus.read_dev_mem(short_addr, 0x410, 4)
                if len(mem) == 4:
                    right = dali_cmds.int_from_mem(mem[0:2], big_endian=False)
                    left  = dali_cmds.int_from_mem(mem[2:4], big_endian=False)
                    # XXX just add left/right for now
                    return left + right

            # Turn all the lights on this bus off, and read a baseline voltage
            # from each light
            self.set_level('all', 0)
            baseline_v = {short_addr: read_light_voltage(short_addr)
                    for short_addr in dr2gs}

            branches = []
            related = {}

            info = {}

            complete = 0
            total = len(dr2gs)
            yield (complete, total)

            # Turn on each DR2G by itself in sequence
            for short_addr in dr2gs:
                if not baseline_v[short_addr]:
                    continue
                address = (channel, 'single', short_addr)
                self.set_level(address, 254)

                # Read LED count
                led_count = bus.read_dr2_led_count(short_addr)

                # Wait for any fade to be done by reading the status byte
                for i in range(100):
                    resp = bus.send_normal_cmd(get_addr_1(address), 0x90)
                    if resp and resp[0] == 'J':
                        status = int(resp[1:3], 16)
                        if not status & 0x10:
                            break
                    time.sleep(.2)
                time.sleep(1)

                # Read baseline wattage for all lights with only one light on
                baseline_w = read_light_power(short_addr)
                # Read voltage/wattage to determine distance
                on_v = read_light_voltage(short_addr)

                if not on_v or not baseline_w:
                    self.set_level(address, 0)
                    continue

                base_v = baseline_v[short_addr]
                baseline_w /= 1000
                base_v /= 1000
                on_v /= 1000

                current = baseline_w / on_v
                delta_v = base_v - on_v
                resistance = delta_v / current

                # XXX deal with number of connectors
                n_connectors = 0
                resistance -= .04 * (2 + n_connectors)

                distance = resistance / .013

                info[short_addr] = {
                    'watts': baseline_w,
                    'voltage': on_v,
                    'led_count': led_count,
                    'distance': distance,
                }

                related[short_addr] = {short_addr}

                # Read power usage from every DR2G on the bus to see what
                # lights have wiring in common
                for other in dr2gs:
                    if other == short_addr or not baseline_v[other]:
                        continue

                    on_v = read_light_voltage(other)
                    if on_v:
                        base_v = baseline_v[other]
                        base_v /= 1000
                        on_v /= 1000
                        delta_v = base_v - on_v
                        if delta_v > .3:
                            related[short_addr].add(other)

                self.set_level(address, 0)

                # Yield a progress update
                complete += 1
                yield (complete, total)

            # Merge all related sets, assuming the transitive closure of lights
            # that appear in the same run gives us the full runs. There should
            # generally not be much actual merging, since aside from errors all
            # lights should show a voltage difference if and only if a light on
            # the same run is on
            runs = {}
            while related:
                [short_addr, rel] = related.popitem()
                this = rel.copy()
                work = list(rel)
                while work:
                    other = work.pop()
                    new = None
                    if other in related:
                        new = related.pop(other) - this
                    elif other in runs:
                        new = runs.pop(other) - this
                    if new:
                        work.extend(new)
                        this.update(new)
                runs[short_addr] = this

            # Sort each branch by distance and merge it into the tree
            channel_runs = []
            for [short_addr, rel] in runs.items():
                run = []
                # For all the shared lights on this run, sort them by distance,
                # and add them to the tree. This particular run of lights is a
                # single branch of the tree, from root to tip, and after we
                # merge all of them together, we should get a single tree
                for addr in sorted(rel, key=lambda a: info[a]['distance']):
                    a = str(addr)
                    data = info[addr]

                    name = None
                    count_lr = data['led_count']
                    count_cct = None

                    # Look up name/driver mode
                    key = (channel, addr)
                    if key in self.lights:
                        light = self.lights[key]
                        name = get_device_name(light)
                        mode = light.get('driver_mode')
                        # If CCT mode, average together left/right counts
                        if mode == 3 and count_lr:
                            count_cct = (count_lr[0] + count_lr[1]) // 2
                            count_lr = None
                    count = (sum(count_lr) if count_lr else 0) + (count_cct or 0)

                    data.update({
                        'dev_name': name,
                        'address': addr,
                        'led_counts_lr': count_lr,
                        'led_count_cct': count_cct,
                        'led_count': count,
                    })
                    run.append(data)

                channel_runs.append(run)

            channel_runs.sort(key=lambda run: run[0]['address'])
            result[channel] = channel_runs
        self.dr2g_topology = result

    @util.with_lock(GLOBAL_LOCK)
    def read_pse_topology_gen(self):
        CHANNEL_MAP = 'DCBA'

        result = []

        # Find PSE-4D devices. Do this first so we can get a total count.
        pse4ds = {}
        for bus in self.iter_busses():
            channel = bus.channel
            pse4ds[channel] = [light['short_addr']
                    for light in self.lights.values()
                    if light['channel'] == channel and device_is_pse4d(light)]
        total = sum(len(pses) for pses in pse4ds.values())

        count = 0
        for bus in self.iter_busses():
            channel = bus.channel
            for pse_addr in pse4ds[channel]:
                devices = []
                # Read bank 6, yielding a progress update in between each half
                watts_mem = bus.read_dev_mem(pse_addr, 0x600, 64)
                yield (count, total)
                channels_mem = bus.read_dev_mem(pse_addr, 0x640, 64)
                yield (count + 1, total)
                count += 2

                # If we got a full bank 6 read, create some nice JSON objects
                # with all the devices with non-zero wattage
                if len(watts_mem) == 64 and len(channels_mem) == 64:
                    devices = [{'addr': addr, 'watts': watts, 'channel':
                        CHANNEL_MAP[channel]}
                        for [addr, [watts, channel]] in
                            enumerate(zip(watts_mem, channels_mem))
                            if watts > 0]
                    result.append({
                        'channel': channel,
                        'pse_addr': pse_addr,
                        'devices': devices,
                    })

        self.pse_topology = result

    # Read the power status of all PSE-4D devices on the bus
    def read_pse_status(self):
        result = []
        for bus in self.iter_busses():
            channel = bus.channel
            # Find PSE-4D devices
            pse4ds = [light['short_addr']
                    for light in self.lights.values()
                    if light['channel'] == channel and device_is_pse4d(light)]

            for pse_addr in pse4ds:
                # Read device memory for power status
                power_mem = bus.read_dev_mem(pse_addr, 0x407, 24)
                status_mem = bus.read_dev_mem(pse_addr, 0x711, 10)
                if len(power_mem) == 24 and len(status_mem) == 10:
                    # Convert from 2-byte little endian shorts
                    shorts = [dali_cmds.int_from_mem(power_mem[i:i+2],
                        big_endian=False) for i in range(0, 24, 2)]
                    # ...then pull out into sensible values
                    vin = shorts[0:4]
                    vout = shorts[4:8]
                    current = shorts[8:12]

                    # ...and reverse the lists since Murray put the values in
                    # the opposite order
                    vin = vin[::-1]
                    vout = vout[::-1]
                    current = current[::-1]

                    # Likewise for the status memory
                    shorts = [dali_cmds.int_from_mem(status_mem[i:i+2],
                        big_endian=False) for i in range(0, 10, 2)]
                    [alt_v, vac_16, gfci, vin_max, watts] = shorts

                    result.append({
                        'channel': channel,
                        'pse_addr': pse_addr,
                        'vin': vin,
                        'vout': vout,
                        'current': current,
                        'alt_v': alt_v,
                        'vac_16': vac_16,
                        'gfci': gfci,
                        'vin_max': vin_max,
                        'watts': watts,
                    })

        return result

    def restore_ups_defaults(self):
        for bus in self.iter_busses():
            bus.send_normal_cmd(0xA3FF)
            bus.send_normal_cmd(0xFF31)

    def get_all_device_db_entries(self, session, channel_id=None, short_addr=None,
            serial_nb=None):
        devices = []
        for device in reversed(list(sorted(session.query_all(db.Device),
                key=lambda d: d.updated_at))):
            if ((serial_nb and serial_nb != 0xFFFFFFFF and
                serial_nb == device.serial_number) or
                    (channel_id is not None and channel_id == device.channel_id and
                    short_addr is not None and short_addr == device.dali_addr_short)):
                devices.append(device)
        return devices

    def scan_zwave_nodes(self):
        self.zwave_lights = zwave.scan_zwave_nodes()

    # Scan all addresses in the address blacklist. The blacklist keeps track of
    # addresses that might have changed or need to be re-scanned for whatever
    # reason (like the user hitting "rescan addresses" in the web ui). After an
    # device is found at an address here, the address is added to the
    # 'full_scan_addresses' list, which is always picked up by the monitor thread
    # (we never make UI threads wait for the slow full scans that get all the
    # random settings/UPCs/serials/etc). This whole process is done with minimal
    # locking, because it might be done in the background, and we don't want to
    # make normal DALI operations (say, turning on a light) unresponsive. Right
    # now there's actually a good chance this function will be run in two threads
    # at once--if the main UI thread starts a scan, it will be queueing addresses
    # for the full scan, and when the monitor thread notices this, before scanning
    # them, it will make sure the quick address scanning is done here. This is
    # maybe a bit weird, but shouldn't be a correctness issue.
    def scan(self):
        with get_dali_lock(None):
            self.init_busses()
            busses = [(bus, self.address_blacklist[bus.channel])
                    for bus in self.iter_busses()]

            # HACK: remove all lights from non-active busses. Should probably
            # think of something better here, but it doesn't matter much. For
            # now this is just to pass the multi-bus test
            # XXX disabled for now since this was possibly getting triggered
            # spuriously causing lights to disappear
            #if self.active_busses != self.last_active_busses:
            #    self.lights = {light_key: light for [light_key, light] in
            #            self.lights.items() if light_key[0] in self.active_busses}
            #self.last_active_busses = self.active_busses

        # All busses are inactive: return an error
        if len(self.active_busses) == 0:
            return -1

        for [bus, blacklist] in busses:
            channel = bus.channel
            ch_str = ' (Channel %s)' % (channel + 1) if channel else ''

            # Keep a list of devices we found. We do a batched database update
            # at the end, so the database lock is held for a minimal amount of
            # time. We also wait to enqueue addresses for a full scan by the
            # monitor thread until after the normal scan, so the monitor thread
            # isn't trying to scan while we're here
            found_devices = []

            while True:
                # Try to get a value from the blacklist (atomically)
                with get_dali_lock(None):
                    if not blacklist:
                        break
                    (short_addr, quick) = blacklist.pop(0)

                light_key = (channel, short_addr)

                # Scan this address
                try:
                    [has_conflict, level] = util.retry_fn('scan', lambda:
                            bus.detect_address(short_addr, 0xA0), retries=10)
                # Don't actually throw if it failed three times in a row,
                # just log an error
                except AssertionError as e:
                    LOG.exception('got exception during scan')
                    continue

                # Update conflicted address set. We ignore any lights that might
                # be conflicted, since we can't really communicate with them.
                if has_conflict:
                    if light_key in self.lights:
                        del self.lights[light_key]
                    self.conflict_addresses.add(light_key)
                    continue
                elif light_key in self.conflict_addresses:
                    self.conflict_addresses.remove(light_key)

                # No response: remove this address from the lights too
                if level is None:
                    if light_key in self.lights:
                        del self.lights[light_key]
                    continue

                name = 'Switch %s%s' % (short_addr, ch_str)

                # This is the main 'new device' object. At some point we should
                # use objects instead of dictionaries, but that's a big change
                device = {
                    'channel': channel,
                    'address': (channel, 'single', short_addr),
                    'dev_name': name,
                    'short_addr': short_addr,
                    'is_passive': False,
                    'is_button': False,
                    'is_io_device': False,
                    'is_relay_device': False,
                    'has_color_temp': False,
                    'color_temp_k': 4000,
                    'color_rgbw': [0, 0, 0, 0],
                    'dev_on': level > 0,
                    'level': level,
                    # This default is a bit weird. Lights are hidden from hue
                    # by default according to this value, but the default for
                    # the database is not hidden. This means that previously
                    # created devices (before the introduction of the hide
                    # feature) won't change without intervention. But new
                    # devices first created here will be hidden by default.
                    # XXX nevermind
                    'hue_hidden': True,
                }

                # Update the main lights dict
                if light_key not in self.lights:
                    self.lights[light_key] = device
                else:
                    # If the light already exists, don't override anything but the
                    # level/on/off status
                    old = self.lights[light_key]
                    old['level'] = level
                    old['dev_on'] = level > 0

                found_devices.append((light_key, quick))

            # For normal lights, reconcile names etc. from the database for each
            # light we found, and queue it up for a full scan if not in quick mode
            with get_dali_lock(None), db.db_session() as session:
                for [light_key, quick] in found_devices:
                    device = self.lights[light_key]

                    self.reconcile_db_device(session, device, direction='read')

                    if not quick:
                        self.full_scan_addresses.put(light_key)

        self.scan_zwave_nodes()

        return len(self.lights) + len(self.zwave_lights)

    def assign_addresses_gen(self, assign_random=False, quick=False, randomize=True):
        new_devices = total_devices = 0
        self.init_busses()
        n_busses = len(list(self.iter_busses()))
        # XXX this could be parallelized
        for [n, bus] in enumerate(self.iter_busses()):
            gen = bus.assign_addresses_gen(assign_random=assign_random, quick=quick,
                    randomize=randomize)
            new = total = 0
            for item in gen:
                if isinstance(item, str):
                    new = total = 0
                    yield item
                    continue
                [min_hi_byte, n_written, n_serials, new, total, addrs] = item
                # Yield a progress update
                num = n * 256 + min_hi_byte + 64 * (n_written / (n_serials + 1))
                den = n_busses * 256 + 64
                progress = int(100. * num / den)
                yield (progress, new_devices + new, total_devices + total, addrs)

            new_devices += new
            total_devices += total

            # In quick mode, only blacklist the new addresses
            if quick:
                for short_addr in sorted(bus.new_addresses):
                    self.blacklist_address(bus.channel, short_addr)

        # Notify the monitor thread that the bus information is different, so it
        # will rescan
        if not quick:
            self.blacklist_all_addresses()

    # For the old non-generator interface, just consume the generator and return
    # the last (new, total) values
    def assign_addresses(self, assign_random=False, quick=False, randomize=True):
        gen = self.assign_addresses_gen(assign_random=assign_random, quick=quick,
                randomize=randomize)
        new = total = 0
        for [_, new, total, _] in gen:
            pass
        return (new, total)

    # Reconcile information from the database for the given device, either
    # reading the db and updating the device or vice versa. We do a bit of db
    # maintenance here too, cleaning up old/redundant entries, to deal with the
    # dumb old way we handled the device table. Previously, we'd add more rows
    # in the table with partial information, so there could be a row without a
    # serial number, and a device could potentially have e.g. a different name
    # before/after scanning the full info to get the device serial number.
    def reconcile_db_device(self, session, device, direction=None):
        assert direction in {'read', 'write'}
        read = (direction == 'read')
        channel = device['channel']
        short_addr = device['short_addr']
        serial_nb = device.get('serial_nb')

        # Get all potential matches--these are ordered by update time, so we
        # want the first for reading data from, but we keep all entries around
        entries = self.get_all_device_db_entries(session, channel_id=channel,
                short_addr=short_addr, serial_nb=serial_nb)
        db_device = entries[0] if entries else None

        if read:
            if 'rgb_power_scale' not in device:
                device['rgb_power_scale'] = 1.9
            if db_device:
                if db_device.name:
                    device['dev_name'] = db_device.name
                device['hue_name'] = db_device.hue_name
                device['hue_hidden'] = db_device.hue_hidden
                if db_device.rgb_power_scale:
                    device['rgb_power_scale'] = db_device.rgb_power_scale

            # Set color temp range values from the db or to the default
            for [attr, [default, minimum, maximum]] in (
                    dali_cmds.COLOR_RANGE_ATTRS.items()):
                value = db_device and getattr(db_device, attr, None)
                if value is None:
                    value = default
                device[attr] = util.clip(value, minimum, maximum)
        else:
            # Create a new entry if none existed and we're writing
            if not db_device:
                db_device = db.Device(channel_id=channel, dali_addr_short=short_addr,
                        serial_number=serial_nb)
                session.add(db_device)

            # Update name and Hue stuff
            db_device.name = device['dev_name']
            if 'hue_name' in device:
                db_device.hue_name = device['hue_name']
            if 'hue_hidden' in device:
                db_device.hue_hidden = device['hue_hidden']

            # Update color attributes
            for [attr, [_, minimum, maximum]] in dali_cmds.COLOR_RANGE_ATTRS.items():
                if attr in device:
                    value = device[attr]
                    assert minimum <= value <= maximum
                    setattr(db_device, attr, value)
            if 'rgb_power_scale' in device:
                db_device.rgb_power_scale = device['rgb_power_scale']

        # Update all identifying info if there's a relevant entry
        if db_device:
            db_device.channel_id = channel
            db_device.dali_addr_short = short_addr
            db_device.serial_number = serial_nb
            upc_code = device.get('upc_code')
            if upc_code:
                db_device.upc_code = upc_code

        # If there are redundant entries, delete them.
        if len(entries) > 1:
            for entry in entries[1:]:
                session.delete(entry)

        session.flush()

    def update_missing_devices(self):
        with db.db_session() as session:
            self.missing_devices = {}
            for db_device in session.query_all(db.Device):
                light_key = (db_device.channel_id, db_device.dali_addr_short)
                if light_key not in self.lights:
                    self.missing_devices[light_key] = db_device.name

    # Run a full scan of all the DALI information we care about, updating
    # our "database" with the current state. This is done while only taking
    # the narrowest possible locks, so that we mostly leave the bus open
    # for other actions, since this function might take a while
    def full_scan(self):
        with get_dali_lock(None):
            if (not any(self.address_blacklist[bus.channel]
                    for bus in self.iter_busses()) and self.full_scan_addresses.empty()):
                return {}
            do_passive_scan = self.do_passive_address_scan
            self.do_passive_address_scan = False
        # Run the basic scan to see which addresses are populated. Those that are
        # (and don't have the 'quick' flag set in the address blacklist) are pushed
        # to the full_scan_addresses queue to be scanned below. Don't need to
        # initialize the busses since we just did above.
        self.scan()
        if do_passive_scan:
            self.scan_passive_devices()
        if self.full_scan_addresses.empty():
            self.update_missing_devices()
            return {}

        LOG.info('Running full scan...')

        # Keep a list of addresses scanned to do a batch database read at the end
        found_devices = []

        while not self.full_scan_addresses.empty():
            light_key = self.full_scan_addresses.get()
            [channel, short_addr] = light_key

            light = self.lights.get(light_key)
            if not light:
                continue

            bus = self.busses[channel]

            # Retry loop: try up to ten times to get data from this light
            attrs = util.retry_fn('scan', lambda:
                    bus.get_full_info_from_short_addr(light, short_addr),
                    retries=10)

            self.set_dali_light_state(light['address'], attrs,
                    update_bus=False)

            found_devices.append(light_key)

        # For this light set, reconcile names etc. from the database for each
        # light we found, and queue it up for a full scan if not in quick mode
        with get_dali_lock(None), db.db_session() as session:
            for light_key in found_devices:
                device = self.lights[light_key]
                self.reconcile_db_device(session, device, direction='read')

            # Once we're done scanning, update the set of missing devices for
            # each channel
            self.update_missing_devices()

        LOG.info('Done scan.')
        return self.lights

    def scan_passive_devices(self):
        # Also, query each address/group for passive status
        for bus in self.iter_busses():
            channel = bus.channel
            ch_str = ' (Channel %s)' % (channel + 1) if channel else ''

            with get_dali_lock(channel):
                self.passive_devices[channel] = {}
                self.passive_groups[channel] = set()
                # Start with a broadcast passive query, as a quick check
                # to save time if there aren't any
                resp = bus.send_normal_cmd(0xFF, 0xAB,
                        allow_conflict=True)
                if resp and resp[0] in {'X', 'J'}:
                    # Query short addresses
                    with db.db_session() as session:
                        for addr in range(64):
                            address = (channel, 'single', addr)
                            resp = bus.send_normal_cmd(get_addr_1(address), 0xAB,
                                    allow_conflict=True)
                            if resp and resp[0] in {'X', 'J'}:
                                # Try reading a name from the database
                                name = None
                                for db_device in session.query_all(db.PassiveDevice,
                                        channel_id=channel, dali_addr_short=addr):
                                    name = db_device.name
                                    break

                                name = name or 'Passive Switch or Button %s%s' % (
                                        addr, ch_str)

                                self.passive_devices[channel][addr] = {
                                    'channel': channel,
                                    'address': (channel, 'passive', addr),
                                    'short_addr': addr,
                                    'is_passive': True,
                                    'is_button': False,
                                    'is_io_device': False,
                                    'is_relay_device': False,
                                    'dev_name': name,
                                    'dev_on': False,
                                    'level': 0,
                                }

                    # Query groups
                    for group in range(16):
                        address = (channel, 'group', group)
                        resp = bus.send_normal_cmd(get_addr_1(address), 0xAB,
                                allow_conflict=True)
                        if resp and resp[0] in {'X', 'J'}:
                            self.passive_groups[channel].add(group)

    def ensure_scanned(self, rescan=False, quick=False):
        n_devices = 0
        # Take a lock to make sure we don't scan multiple times if we get a
        # bunch of requests on startup, but don't hold it while we scan
        with GLOBAL_LOCK:
            do_scan = (not self.has_scanned or rescan)
            if rescan:
                self.blacklist_all_addresses(quick=quick)

        if do_scan:
            n_devices = self.scan()
            self.has_scanned = True

        return n_devices

    def reset_light_levels(self):
        for bus in self.iter_busses():
            bus.send_normal_cmd(0xFF, 0x26)
        self.scan()

    def get_devices_state(self):
        yield from self.lights.values()
        yield from self.zwave_lights.values()

    def get_passive_devices_state(self, passive_exclusive=False):
        for [channel, lights] in self.passive_devices.items():
            # With passive_exclusive, only yield passive address that don't have
            # normal lights at those addresses
            if passive_exclusive:
                for [addr, light] in lights.items():
                    if (channel, addr) in self.lights:
                        continue
                    yield light
            else:
                yield from lights.values()

    def get_button_devices_state(self):
        for device in self.lights.values():
            if device['is_button']:
                yield device

    def get_virtual_devices_state(self):
        vds = []
        # Add virtual devices
        for channel, channel_vds in self.virtual_devices.items():
            for short_addr, device in sorted(channel_vds.items()):
                device = device.copy()
                device['dev_name'] = get_device_name(device)
                vds.append(device)
        return vds

    def get_virtual_groups_state(self):
        vgs = []
        # Add virtual groups
        for channel, channel_vgs in self.virtual_groups.items():
            for group_id, group in sorted(channel_vgs.items()):
                group = group.copy()
                group['dev_name'] = get_device_name(group)
                vgs.append(group)
        return vgs

    def get_zwave_devices_state(self):
        return self.zwave_lights.values()

    def get_all_lights_state(self):
        return [*self.get_devices_state(),
                *self.get_virtual_devices_state(),
                *self.get_virtual_groups_state()]

    def get_device_state(self, address):
        result = list(self.get_matching_lights(address))
        assert len(result) == 1, result
        device = result[0].copy()
        device['dev_name'] = get_device_name(device)
        return device

    def get_group_state(self, channel, group_id):
        # Look for a name for this group
        key = (channel, group_id)
        [hue_name, hue_hidden] = self.group_info.get(key, (None, True))
        ch_str = ' (Channel %s)' % (channel + 1) if channel else ''
        name = 'Group %s%s' % (group_id, ch_str)

        group = {
            'address': (channel, 'group', group_id),
            'dev_name': name,
            'hue_name': hue_name,
            'hue_hidden': hue_hidden,
            'dev_on': False,
            'level': 0,
            'color_temp_k': 4000,
            'device_ids': [],
            'device_names': [],
        }
        lights = list(self.get_devices_state())
        if channel in self.virtual_devices:
            lights += list(self.virtual_devices[channel].values())
        for light in lights:
            if light['channel'] != channel:
                continue
            if 'groups' in light and group_id in light['groups']:
                group['dev_on'] = max(light['dev_on'], group['dev_on'])
                if light['dev_on']:
                    group['level'] = max(light['level'], group['level'])
                group['device_ids'].append(light['short_addr'])
                group['device_names'].append(get_device_name(light))
                if 'color_temp_k' in light:
                    group['color_temp_k'] = max(light['color_temp_k'],
                            group['color_temp_k'])

        # Kinda hacky: add a fake device name if there are passive devices in
        # this group
        # XXX device_id of -1 is maybe bad, but we're not doing anything with
        # the ids now
        if group_id in self.passive_groups[channel]:
            group['device_ids'].append(-1)
            group['device_names'].append('(AL-WS-010v)')

        return group

    def get_all_groups_state(self, discard_empty=True):
        groups = []
        for bus in self.iter_busses():
            for group_id in range(16):
                state = self.get_group_state(bus.channel, group_id)
                if discard_empty and not state['device_ids']:
                    continue

                state.update({
                    'channel': bus.channel,
                    'group_id': group_id,
                })
                groups.append(state)

        return groups

    def get_broadcast_state(self):
        dev_on = False
        level = 0
        for light in self.get_devices_state():
            if light['dev_on']:
                dev_on = True
                level = max(light['level'], level)
        return {
            'address': (None, 'all', None),
            'dev_name': 'All lights',
            'dev_on': dev_on,
            'level': level,
        }

    # This function is kinda inefficient in that it gathers info for
    # all lights for the broadcast/group info that it just discards
    def get_all_addresses(self):
        device_sets = [
            ['All', [self.get_broadcast_state()]],
            ['Groups', self.get_all_groups_state()],
            ['Lights', self.get_devices_state()],
            ['Buttons', self.get_passive_devices_state(passive_exclusive=True)],
            ['Virtual Devices', sum([list(vd.values()) for _, vd in
                self.get_virtual_devices().items()], [])],
            ['Virtual Groups', sum([list(vg.values()) for _, vg in
                self.get_virtual_groups().items()], [])],
        ]

        result = {}
        for key, devices in device_sets:
            result[key] = []
            for device in devices:
                result[key].append({
                    'key': get_device_nice_addr(device),
                    'value': get_device_name(device),
                })
        return result

    def get_active_channels(self):
        return list(sorted(self.active_busses))

    def get_matching_busses(self, address):
        [channel, addr_type, _] = parse_device_nice_addr(address)
        if channel is None:
            yield from self.iter_busses()
        elif addr_type != 'zwave':
            yield self.busses[channel]

    # Parse a dali command
    def get_matching_lights(self, address):
        channel, addr_type, addr_id = parse_device_nice_addr(address)
        if addr_type == 'single':
            light_key = (channel, addr_id)
            if light_key in self.lights:
                yield self.lights[light_key]
        elif addr_type == 'passive':
            if addr_id in self.passive_devices[channel]:
                yield self.passive_devices[channel][addr_id]
        elif addr_type == 'group':
            for light in self.get_devices_state():
                if (light['channel'] == channel and
                        'groups' in light and addr_id in light['groups']):
                    yield light
            # Also check for any virtual devices in the group
            if channel in self.virtual_devices:
                for device in self.virtual_devices[channel].values():
                    if 'groups' in device and addr_id in device['groups']:
                        yield device
        elif addr_type == 'virtual-device':
            if (channel in self.virtual_devices and
                    addr_id in self.virtual_devices[channel]):
                yield self.virtual_devices[channel][addr_id]
        elif addr_type == 'virtual-group':
            if (channel in self.virtual_groups and
                    addr_id in self.virtual_groups[channel]):
                yield self.virtual_groups[channel][addr_id]
        elif addr_type == 'zwave':
            if addr_id in self.zwave_lights:
                yield self.zwave_lights[addr_id]
        elif addr_type == 'all':
            yield from self.get_devices_state()
        else:
            assert False, 'bad address: %s' % (address,)

    @util.with_lock(GLOBAL_LOCK)
    def set_dali_light_state(self, address, state, update_bus=True,
            update_db=True, force_send=False, color_fade=False):
        # Convert all parameters to the right types before we do anything else
        for key, value in state.items():
            if key in DALI_ATTRS:
                state[key] = DALI_ATTRS[key].type(value)

        address = parse_device_nice_addr(address)

        LOG.info('set_dali_light_state(%r): %s', address, state)

        # Keep track of which groups might change for websocket events
        groups_touched = set()
        groups_updated = set()
        # First, check for setting certain attributes on a group (just name
        # for now). Normally, setting an attribute on a group sets that on
        # each light individiually, but we want to intercept these changes
        # and store the state separately, not affecting the normal lights.
        if address[1] == 'group' and any(attr in state for attr in
                ['dev_name', 'hue_name', 'hue_hidden']):
            assert update_db
            with db.db_session() as session:
                [channel, _, group_id] = address
                # Get the hue_name or dev_name, hue takes priority
                key = (channel, group_id)
                [name, hidden] = self.group_info.get(key, (None, True))
                if 'dev_name' in state:
                    name = state.pop('dev_name')
                if 'hue_name' in state:
                    name = state.pop('hue_name')
                if 'hue_hidden' in state:
                    hidden = state.pop('hue_hidden')
                self.group_info[key] = (name, hidden)
                session.upsert(db.Group, {'channel_id': channel,
                    'group_id': group_id}, name=name, hue_hidden=hidden)

        # Helper function to munge a command to use DALI all/group commands
        # when appropriate. We keep track of munging for each channel, since
        # the all/group commands only affect one channel.
        munge_state = [{} for i in range(MAX_CHANNELS)]
        def munge_address(this_channel, orig_addr, light, addr, orig_attr, value):
            if (orig_attr in {'level', 'color_temp_k'} or
                    (orig_attr == 'dev_on' and value == False)):
                [_, addr_type, _] = parse_device_nice_addr(orig_addr)

                if addr_type in {'all', 'group'}:
                    # Check for color temperature broadcast changes. It's hard
                    # to have consistent behavior here, since each light
                    # can have its own color range, so we'd only want to send
                    # out a CCT value to all the lights that would use the same
                    # CCT value after scaling. That's not quite feasible, and
                    # we don't want to check all the lights' scales here, etc.,
                    # so we just send the CCT of the first light we see as an
                    # all/group command. If a later light has a different CCT,
                    # we send that individually to override the broadcast.

                    if orig_attr == 'color_temp_k':
                        cct = convert_k_cct(light, value)
                        if orig_attr in munge_state[this_channel]:
                            # Does the broadcasted CCT match this one?
                            if munge_state[this_channel][orig_attr] == cct:
                                return None
                            # No match: send CCT individually
                            return addr
                        munge_state[this_channel][orig_attr] = cct
                        return orig_addr
                    # For other attributes that don't need overriding, just see
                    # if we've already 
                    elif orig_attr in munge_state[this_channel]:
                        return None
                    # Normal attribute, not previously sent: munge to the broadcast
                    # address and save the state in munge_state
                    else:
                        munge_state[this_channel][orig_attr] = True
                        return orig_addr
            return addr

        def send_bus_update(bus, light, addr, attr_data, attr, value):
            # Send out the proper DALI command to set this value
            if attr_data.set_cmd:
                assert isinstance(value, int) and 0 <= value < 256
                bus.send_normal_cmd(0xA3, value)
                bus.send_normal_cmd(get_addr_1(addr), attr_data.set_cmd,
                        send_twice=True)
            elif attr_data.mem_range is not None:
                [channel, addr_type, addr_id] = addr
                assert addr_type == 'single'
                # Handle physical color values of left/right channels for DR2F32
                if attr in {'color_k_left', 'color_k_right'}:
                    assert device_is_dr2f32(light)
                    value = (5000 - value) / 13
                    value = util.clip(int(value+.5), 0, 177)
                elif attr == 'dim_to_warm':
                    value = util.scale(value, 0, 4.5, 0, 15)
                    value = 0xF0 | util.clip(int(value), 0, 15)
                bus.write_dev_mem_range(addr_id, attr_data.mem_bank,
                        attr_data.mem_range, value,
                        big_endian=attr_data.big_endian)
            elif attr == 'level':
                bus.set_level(addr, value)
            elif attr == 'color_temp_k':
                assert light
                cct = convert_k_cct(light, value)
                bus.set_save_cct(addr, cct, color_fade=color_fade)
            elif attr == 'color_rgbw':
                if light['has_color_rgb']:
                    bus.set_save_rgbw(addr, value, light.get('rgb_power_scale', 1.9))
            elif attr in {'dev_name', 'hue_name', 'hue_hidden', 'rgb_power_scale'}:
                # Don't need to do anything here
                pass
            else:
                assert 0, 'Unsupported attribute: %s' % attr

        result = []
        for light in self.get_matching_lights(address):
            light_addr = light['address']
            channel, addr_type, addr_id = light_addr

            if addr_type == 'zwave':
                bus = None
            else:
                bus = self.busses[channel]

            if 'groups' in light:
                for group in light['groups']:
                    groups_touched.add((channel, group))

            # Copy the main state change dictionary, so we can make
            # per-device modifications
            data = state.copy()

            attr_override = {}

            # Some special cases for on/off and level setting
            if 'level' in data:
                level = data['level']
                # If level and dev_on are both sent, dev_on takes precedence.
                # These should generally match... perhaps we should check?
                dev_on = data.pop('dev_on', None)
                if dev_on == False:
                    level = 0

                # If we're only setting the level to 0, instead of actually setting
                # the level to 0, turn the device off, so we remember the old level
                if level == 0:
                    del data['level']
                    data['dev_on'] = False

            # Keep old on/off status for triggers
            old_dev_on = light['dev_on']

            # More annoying logic for on/off/level setting! Yay!
            # Mark an override for dev_on to transform it to a level setting.
            # The override only changes the actual bus command used, not the
            # attribute update for the device
            if 'dev_on' in data:
                assert 'level' not in data
                value = data['dev_on']
                level = light.get('level')
                if not level:
                    light['level'] = level = 0xFE
                if not value:
                    level = 0
                # Now just treat this as a level set command for the
                # actual bus update
                attr_override['dev_on'] = ('level', level)

            # After we've munged the level/on/off stuff, see if we want to also
            # set the power-on level to match the new level
            if (config.SITE_SETTINGS.send_power_on_level and
                    not device_is_atxled(light) and 'power_on_level' not in data):
                if 'level' in data:
                    data['fail_level'] = data['power_on_level'] = data['level']
                if 'dev_on' in attr_override:
                    attr, value = attr_override['dev_on']
                    assert attr == 'level'
                    data['fail_level'] = data['power_on_level'] = value

            for attr, value in sorted(data.items()):
                # Special attributes, handled manually below
                if attr in dali_cmds.SPECIAL_ATTRS:
                    continue
                elif attr not in DALI_ATTRS:
                    assert 0, 'Unknown attribute: %s' % attr
                attr_data = DALI_ATTRS[attr]

                orig_attr = attr

                # Fix level_inc commands to refer to the actual level
                if attr == 'level_inc' or attr == 'level_inc_on':
                    # For level_inc_on, only make adjustments if the light is on
                    if attr == 'level_inc_on' and not light['dev_on']:
                        continue
                    level = light['level']
                    # XXX min/max power level
                    value = max(0, min(254, level + value))
                    attr = 'level'

                # Skip color commands for lights that don't support them
                # XXX this is sort of risky in general, and right now the
                # 'has_color_temp' and 'color_temp_k' are set at the same time,
                # so it can fail. So just send it anyways
                #if attr == 'color_temp_k' and not light.get('has_color_temp'):
                #    continue

                light[attr] = value

                if attr in attr_override:
                    attr, value = attr_override[attr]
                # Also, update on/off state from level changes
                elif attr == 'level':
                    light['dev_on'] = (value > 0)

                if not update_bus:
                    continue

                # Handle zwave
                if addr_type == 'zwave':
                    zwave.send_node_state(addr_id, attr, value)
                    continue

                dest_addr = munge_address(channel, address, light, light_addr,
                        orig_attr, value)
                if not dest_addr:
                    continue

                send_bus_update(bus, light, dest_addr, attr_data, attr, value)

            # Groups need some special handling
            if 'groups' in data and data['groups'] is not None:
                groups = data.pop('groups')
                if update_bus:
                    old_groups = light.get('groups')
                    for group_id in range(16):
                        # Get the old membership status, if we know it
                        old_status = (old_groups is not None and
                                group_id in old_groups)
                        new_status = (group_id in groups)
                        if old_status != new_status:
                            bus.update_device_group(light_addr, group_id,
                                    new_status, old_status)

                        groups_updated.add((channel, group_id))

                light['groups'] = groups

            # Button configuration also needs special handling. This is kinda
            # annoying since we want to diff against the old attribute values
            # and only send the changes
            if 'buttons' in data:
                assert light['is_button']
                old_value = light['buttons']
                value = data.pop('buttons')
                if update_bus:
                    bus.update_button_device_buttons(addr_id, old_value, value)
                light['buttons'] = value

            db_needs_update = False

            # Handle DALI min/max/off/up/down commands. These aren't really
            # key/value attributes, just an instantaneous command.
            # XXX do another munge_address thingy here to send in bulk
            if 'level_min' in data:
                data.pop('level_min')
                light['level'] = 1
                light['dev_on'] = True
                bus.set_level_min(addr_id)
            elif 'level_max' in data:
                data.pop('level_max')
                light['level'] = 254
                light['dev_on'] = True
                bus.set_level_max(addr_id)
            elif 'level_off' in data:
                data.pop('level_off')
                light['dev_on'] = False
                bus.set_level_off(addr_id)
            elif 'level_step_up' in data:
                data.pop('level_step_up')
                if light['dev_on']:
                    light['level'] = min(light['level'] + 1, 254)
                bus.step_level_up(addr_id)
            elif 'level_step_down' in data:
                data.pop('level_step_down')
                if light['dev_on']:
                    light['level'] = max(light['level'] - 1, 1)
                bus.step_level_down(addr_id)

            # Update color temp ranges
            if any(attr in data for attr in dali_cmds.COLOR_RANGE_ATTRS):
                for [attr, [_, minimum, maximum]] in (
                        dali_cmds.COLOR_RANGE_ATTRS.items()):
                    if attr in data:
                        value = util.clip(int(data[attr]), minimum, maximum)
                        light[attr] = value
                        data[attr] = value
                if update_db:
                    db_needs_update = True

            # If the DR2F driver mode changes, flag the address to get
            # re-scanned. This command apparently changes some internal states
            # (like dev_type) and it's easier to just rescan it. Only do this
            # if we're not updating the bus, to avoid infinite recursion
            if 'driver_mode' in data and update_bus:
                self.blacklist_address(channel, addr_id)

            # Do some extra checks to see if we need to update the DB
            if update_db:
                if any(attr in data
                        for attr in ['dev_name', 'hue_name', 'hue_hidden',
                            'rgb_power_scale']):
                    db_needs_update = True

                if addr_type == 'virtual-device':
                    db_needs_update = True

            # Update database if necessary
            if db_needs_update:
                with db.db_session() as session:
                    if addr_type in {'single', 'button'}:
                        self.reconcile_db_device(session, light, direction='write')
                    elif addr_type == 'passive':
                        name = light.get('dev_name')
                        session.upsert(db.PassiveDevice, {'channel_id': channel,
                                'dali_addr_short': addr_id}, name=name)
                    elif addr_type == 'virtual-device':
                        name = light.get('dev_name')
                        n_dmx_devices = light.get('fail_level', 1)
                        groups = light.get('groups', [])
                        session.upsert(db.VirtualDevice, {'channel_id': channel,
                                'dali_addr_short': addr_id}, name=name,
                                n_dmx_devices=n_dmx_devices, groups=groups)
                    elif addr_type == 'virtual-group':
                        session.upsert(db.VirtualGroup, {'channel_id': channel,
                            'group_id': addr_id}, name=data['dev_name'])

            # Notify any listeners of this update. We do this after the
            # preprocessing above so we get more "sane" updates on the
            # client side, with minimal interpretation needed to get the
            # state of every device.
            nice_data = {'channel': channel, 'short_addr': addr_id,
                    'dev_on': light['dev_on'], 'level': light['level'],
                    'address': light['address'], 'dev_name': get_device_name(light)}
            nice_data.update(data)
            self.state_changes.push([get_device_nice_addr(light), nice_data])

            # Check for an on/off change and pass it off to the trigger handler
            if ON_OFF_LISTENER and old_dev_on != light['dev_on']:
                ON_OFF_LISTENER(channel, addr_id, light['dev_on'],
                        trigger_level='level' not in state)
            if LEVEL_CHANGE_LISTENER and 'level' in state:
                LEVEL_CHANGE_LISTENER(channel, addr_id, light['level'])
            if COLOR_CHANGE_LISTENER and 'color_temp_k' in state:
                COLOR_CHANGE_LISTENER(state['color_temp_k'])

            result.append(light)

        if self.group_state_changes.has_listeners():
            for (channel, group_id) in (groups_touched | groups_updated):
                new_state = self.get_group_state(channel, group_id)
                group_addr = get_nice_addr(channel, 'group', group_id)
                self.group_state_changes.push([group_addr, new_state])

        if self.broadcast_state_changes.has_listeners():
            new_state = self.get_broadcast_state()
            self.broadcast_state_changes.push(('all', new_state))

        # Last resort sending: for some things like schedules, we want to make
        # sure the commands go out even if the light doesn't seem to currently
        # be on the bus.
        if not result and force_send:
            # Ugh, find relevant busses
            channel = address[0]
            if channel is not None and channel in self.active_busses:
                busses = [self.busses[channel]]
            else:
                busses = list(self.busses.values())

            for bus in busses:
                for attr, value in sorted(state.items()):
                    if attr in DALI_ATTRS:
                        attr_data = DALI_ATTRS[attr]
                        send_bus_update(bus, None, address, attr_data, attr, value)

        # Irritating: if there were no matching lights, check if this was a single
        # light address, and try to trigger some events if so. Passive buttons
        # otherwise have no way of triggering events. We don't keep track of state,
        # so if you put a 010v on a trigger and mess with the slider you'll get
        # a million events
        if not result and 'level' in state:
            [channel, addr_type, addr_id] = address
            if addr_type == 'single':
                if ON_OFF_LISTENER:
                    ON_OFF_LISTENER(channel, addr_id, state['level'] > 0,
                            trigger_level=False)
                if LEVEL_CHANGE_LISTENER:
                    LEVEL_CHANGE_LISTENER(channel, addr_id, state['level'])

        # Munge the result based on the address given: return None if there were
        # no matching lights, a single dict for single addressing mode, or a
        # list otherwise
        if not result:
            return None
        _, addr_type, _ = parse_device_nice_addr(address)
        if addr_type in ('single', 'passive', 'virtual-device'):
            assert len(result) == 1
            return result[0]
        return result

    def set_level(self, address, level, update_bus=True, force_send=False):
        state = {'level': level}
        return self.set_dali_light_state(address, state, update_bus=update_bus,
                force_send=force_send)

    def set_color_temp(self, address, color_temp_k, update_bus=True,
            color_fade=False):
        state = {'color_temp_k': color_temp_k}
        return self.set_dali_light_state(address, state, update_bus=update_bus,
                color_fade=color_fade)

    def set_color_rgbw(self, address, color_rgbw, update_bus=True):
        state = {'color_rgbw': color_rgbw}
        return self.set_dali_light_state(address, state, update_bus=update_bus)

    def set_level_inc(self, address, inc, update_bus=True):
        return self.set_dali_light_state(address, {'level_inc': inc},
                update_bus=update_bus)

    def toggle_on_off(self, address):
        # Get previous state. If any lights for this address are on, we
        # treat all lights as on (so groups go from "some on" to "all off"
        # instead of "all on")
        on = any(light['dev_on'] for light in self.get_matching_lights(address))
        new_state = {'dev_on': not on}
        return self.set_dali_light_state(address, new_state)

    # Scenes

    def scene_to_json(self, scene):
        name = scene.name or 'Scene %s' % scene.id
        return {'id': scene.id, 'name': name, 'state': scene.state,
                'visible': scene.visible}

    def get_scenes(self):
        return self.scenes

    def set_scene(self, scene_id, name, state, update_bus=True,
            visible=True, set_visible=True):
        # Get both the DALI lock and the db lock. We only occasionally need
        # the DALI lock, but it must be acquired before the db lock so do it
        # first always
        with get_dali_lock(None), db.db_session() as session:
            # Get database arguments from parameters, and validate
            kwargs = {}
            if name:
                kwargs['name'] = name
            if state:
                kwargs['state'] = state
            if set_visible:
                kwargs['visible'] = visible
            util.validate_json(kwargs, SCENE_SCHEMA)

            # If we're changing the scene, send any DALI commands to
            # change the state
            if state and update_bus:
                if scene_id in self.scenes:
                    old_state = self.scenes[scene_id]['state']
                else:
                    old_state = {}

                # Remove devices from scene
                for address in old_state:
                    if address not in state:
                        [channel, addr_type, addr_id] = (
                                parse_device_nice_addr(address))
                        if channel not in self.busses:
                            continue
                        bus = self.busses[channel]
                        bus.remove_scene(address, scene_id)

                # Update level/color temp for scene
                for address in state:
                    if state[address] != old_state.get(address):
                        [channel, addr_type, addr_id] = (
                                parse_device_nice_addr(address))
                        if channel not in self.busses:
                            continue
                        bus = self.busses[channel]
                        level = (state[address]['level']
                                if state[address].get('dev_on', True) else 0)
                        # Ugh, get color temp. We have to search for a
                        # light with this address to get the min/max/etc
                        # values to map this to a CCT...
                        color_temp_k = state[address].get('color_temp_k', None)
                        cct = None
                        if color_temp_k is not None:
                            for light in self.get_matching_lights(address):
                                if light['has_color_temp']:
                                    cct = convert_k_cct(light, color_temp_k)
                        if not state[address].get('send_color', True):
                            cct = 700

                        # If level is 255, that means to not change the level.
                        # We transmit the 255 normally to tell the light not
                        # to change, but we also have to remove the level
                        # from the state of the scene so we don't change the
                        # level later when the scene is triggered
                        if level == 255:
                            del state[address]['level']
                        if not state[address].get('send_level', True):
                            level = 255

                        bus.set_scene_level(address, scene_id,
                                level=level, cct=cct)

            scene = session.upsert(db.Scene, {'id': scene_id}, **kwargs)
            self.scenes[scene_id] = self.scene_to_json(scene)
            return self.scenes[scene_id]

    def capture_scene(self, scene_id):
        # Gather state of all lights
        whitelist_attrs = {'dev_on', 'level', 'color_temp_k', 'color_rgbw'}
        state = {}
        for light in self.get_devices_state():
            address = get_device_nice_addr(light)
            state[address] = {k: v for k, v in light.items() if k in whitelist_attrs}
            state[address]['send_level'] = True
            state[address]['send_color'] = True

        # Capture the scene on all busses. Hopefully our state is in sync, but
        # the DALI lights are the source of truth for now.
        with get_dali_lock(None):
            for bus in self.iter_busses():
                bus.set_scene_level('all', scene_id)

        return self.set_scene(scene_id, None, state, update_bus=False)

    def read_scenes(self):
        states = [collections.defaultdict(dict) for i in range(16)]
        n = len(self.lights)
        for [i, light] in enumerate(self.lights.values()):
            address = get_device_nice_addr(light)
            bus = self.busses[light['channel']]
            scene_levels = bus.read_scene_levels(light['short_addr'])
            for [scene, [level, cct]] in enumerate(scene_levels):
                s = states[scene][address]
                s['dev_on'] = (level is not None and level > 0)
                s['level'] = level or 0
                s['send_level'] = (level is not None and level != 255)
                s['color_temp_k'] = convert_cct_k(light, cct) if cct is not None else 1000
                s['send_color'] = (cct is not None and cct >= 700)

            yield (i, n)

        for scene in range(16):
            self.set_scene(scene, None, states[scene], update_bus=False,
                    set_visible=False)

    def delete_scene(self, scene_id):
        if scene_id in self.scenes:
            old_state = self.scenes[scene_id]['state']

            with get_dali_lock(None):
                # Remove devices from scene
                for address in old_state:
                    (channel, addr_type, addr_id) = parse_device_nice_addr(address)
                    bus = self.busses[channel]
                    bus.remove_scene(address, scene_id)

            with db.db_session() as session:
                session.delete_all(db.Scene, id=scene_id)

            del self.scenes[scene_id]

    def trigger_scene(self, scene_id, update_bus=True, address='all'):
        with get_dali_lock(None):
            # Trigger the scene on all relevant lights
            if update_bus:
                for bus in self.get_matching_busses(address):
                    bus.trigger_scene(address, scene_id)

            # Trigger any triggers for this scene
            if SCENE_LISTENER:
                SCENE_LISTENER(scene_id)

            if scene_id not in self.scenes:
                return

            scene_state = self.scenes[scene_id]['state']

            # Get a list of lights the scene command was for, if it was on the bus
            new_scene = {}
            for light in self.get_matching_lights(address):
                addr = get_device_nice_addr(light)
                if addr in scene_state:
                    new_scene[addr] = scene_state[addr]
            scene_state = new_scene

            # Update the internal state, without updating the bus
            for [light, state] in scene_state.items():
                if 'send_level' in state:
                    if not state['send_level'] and 'level' in state:
                        del state['level']
                    del state['send_level']
                if 'send_color' in state:
                    if not state['send_color'] and 'color_temp_k' in state:
                        del state['color_temp_k']
                    del state['send_color']
                self.set_dali_light_state(light, state, update_bus=False)

    # Virtual device stuff

    def get_virtual_devices(self):
        # Only return virtual devices for active busses
        return {channel: vd for channel, vd in self.virtual_devices.items()
                if channel in self.active_busses}

    def set_virtual_device(self, channel, short_addr, data, update_db=True):
        assert 0 <= channel < MAX_CHANNELS
        assert 0 <= short_addr < 64

        address = (channel, 'virtual-device', short_addr)
        # Create a virtual device entry if needed
        if short_addr not in self.virtual_devices[channel]:
            self.virtual_devices[channel][short_addr] = {
                'channel': channel,
                'short_addr': short_addr,
                'address': address,
                'dev_name': None,
                'groups': [],
                'passive': False,
                'dev_on': False,
                'level': 0,
                'fail_level': 1,
            }
            # HACK: set groups=[] as a dummy to make sure the db gets updated
            if 'groups' not in data:
                data['groups'] = []

        if channel not in self.active_busses:
            LOG.info('ignoring set_virtual_device(%s, %s), channel not active',
                    channel, short_addr)
            raise util.APIError('Channel %s not active' % (channel + 1))

        return self.set_dali_light_state(address, data, update_db=update_db)

    def delete_virtual_device(self, channel, short_addr):
        assert 0 <= channel < MAX_CHANNELS
        assert 0 <= short_addr < 64
        del self.virtual_devices[channel][short_addr]
        with db.db_session() as session:
            session.delete_all(db.VirtualDevice, channel_id=channel,
                    dali_addr_short=short_addr)

    def check_virtual_device_fail_level(self, address):
        (channel, addr_type, addr_id) = address
        # If the fail level is queried for a virtual device, we can't respond in
        # time reliably given the strict timing of DALI. So when we get a matching
        # query, send out a 'set fail level' command for the given address.
        if addr_type == 'single' and addr_id in self.virtual_devices[channel]:
            fail_level = self.virtual_devices[channel][addr_id]['fail_level']
            data = {'fail_level': fail_level}
            address = (channel, 'virtual-device', addr_id)
            self.set_dali_light_state(address, data)

    # Virtual group stuff

    def get_virtual_groups(self):
        # Only return virtual groups for active busses
        return {channel: vg for channel, vg in self.virtual_groups.items()
                if channel in self.active_busses}

    def set_virtual_group(self, channel, group_id, name, devices, update_db=True):
        group = self.virtual_groups[channel].get(group_id)
        if group is None:
            group = {
                'channel': channel,
                'address': (channel, 'virtual-group', group_id),
                'dev_name': name,
                'devices': [],
                'dev_on': False,
                'level': 0
            }
            self.virtual_groups[channel][group_id] = group
        if name:
            group['dev_name'] = name

        old_devices = group['devices']

        if channel not in self.active_busses:
            LOG.info('ignoring set_virtual_group(%s, %s), channel not active',
                    channel, group_id)
        else:
            # Loop over all short addresses, and send add/remove group commands
            # for any addresses that need it
            for short_addr in sorted({*devices, *old_devices}):
                address = (channel, 'single', short_addr)
                if len(list(self.get_matching_lights(address))):
                    continue

                bus = self.busses[channel]
                bus.update_device_group(short_addr, group_id,
                        (short_addr in devices), (short_addr in old_devices))

        group['devices'] = devices
        LOG.info('set_virtual_group(%s, %s): %s', channel, group_id, group)

        if update_db:
            with db.db_session() as session:
                update_args = {'devices': devices, 'level': group['level']}
                if name:
                    update_args['name'] = name
                session.upsert(db.VirtualGroup, {'channel_id': channel,
                    'group_id': group_id}, **update_args)

    # Virtual N-way stuff

    def get_virtual_n_way_groups(self):
        virtual_n_way = []
        candidates = {channel: collections.defaultdict(list)
                for channel in range(MAX_CHANNELS)}
        bad = {channel: set() for channel in range(MAX_CHANNELS)}

        # Find candidate groups for virtual n-way. Lights must be ATX-LED and
        # in 'group mode': when they have an address < 16 they broadcast
        # changes with group commands. Furthermore they each must have the
        # same set of group assignments: only other candidate lights with the
        # same group assignments.
        for light in self.lights.values():
            channel = light['channel']
            addr = light['short_addr']
            groups = frozenset(light.get('groups', []))
            if (addr < 16 and device_is_atxled(light) and addr in groups
                    and len(groups) > 1):
                candidates[channel][groups].append(light)
            # Track all groups that have a light >16 in them
            elif addr >= 16:
                bad[channel].update(groups)

        for [channel, cands] in candidates.items():
            if cands:
                LOG.info('test virtual group: ch=%s addresses=%s exclude=%s',
                        channel, list(cands.keys()), bad[channel])
            for [group, lights] in cands.items():
                if (group == set(light['short_addr'] for light in lights) and
                        not any(g in bad[channel] for g in group)):
                    id = 'n_%s' % '_'.join(map(str, group))
                    name = 'Virtual Group %s' % min(group)
                    virtual_n_way.append({
                        'id': id,
                        'channel': channel,
                        'name': name,
                        'device_ids': list(group),
                        'device_names': [get_device_name(light) for light in lights],
                    })

        return virtual_n_way

    def update_virtual_n_way(self, channel, addresses):
        with get_dali_lock(channel):
            # Collect free addresses 0..15
            used_addresses = {addr for [ch, addr] in self.lights.keys()
                    if ch == channel}
            group_counts = collections.Counter(group
                    for [[ch, addr], device] in self.lights.items()
                    for group in device.get('groups', []) if ch == channel)
            used_groups = set(group_counts)
            free_addresses = set(range(64)) - used_addresses

            # Keep separate sets of addresses that are free in the 0..15 and
            # 16..63 ranges. We might need to shuffle addresses from the first
            # to the second group to make room
            free_addresses_48 = (free_addresses & set(range(16, 64)))
            free_addresses_16 = (free_addresses & set(range(16))) - used_groups

            # Find addresses that are used in the 0-15 range but don't need
            # to be (i.e. they're not in a virtual n-way group apparently).
            # This is a bit sketchy, since this changes the behavior of the
            # switch (it will now broadcast as a single instead of a group).
            # But virtual n-way is already a bit sketchy, not to mention the
            # address < 16 == group broadcast feature. And Murray says users
            # will have to deal with that themselves if they really care.
            # We remove the single group from this light and reassign it,
            # in that order, since after reassigning we can't communicate
            # til after a rescan.
            for [[ch, addr], light] in self.lights.items():
                if ch == channel and addr < 16 and addr not in addresses:
                    # Check that there's only one group at most, and if
                    # there is one, that it shares the address, and no
                    # other lights are in it
                    groups = set(light.get('groups', []))
                    if not groups or (groups == {addr} and group_counts[addr] == 1):
                        if not free_addresses_48:
                            raise util.APIError('Not enough free addresses')

                        # Remove all groups (there's at most one, with the
                        # same address as the light's short address)
                        address = (channel, 'single', addr)
                        self.set_dali_light_state(address, {'groups': []})

                        # Pick a new address and move this light
                        new_addr = free_addresses_48.pop()
                        self.reassign_address(channel, addr, new_addr)
                        free_addresses_16.add(addr)

            # Get addresses that do/don't need reassignment, check numbers
            final_addresses = {addr for addr in addresses if addr < 16}
            to_reassign = {addr for addr in addresses if addr >= 16}
            if len(to_reassign) > len(free_addresses_16):
                raise util.APIError('Not enough free addresses')

            # Choose which addresses to reassign first. This is a bit weird,
            # since our reassignment code currently requires a rescan to
            # get the new info (it's conservative about saving info). This
            # means we can't update the device's groups right after a
            # reassignment, so we update the groups beforehand.
            reassigns = []
            for addr in sorted(to_reassign):
                new_addr = min(free_addresses_16)
                free_addresses_16.remove(new_addr)
                final_addresses.add(new_addr)
                reassigns.append((addr, new_addr))

            # Reset groups of all devices in the new group
            assert all(0 <= addr < 16 for addr in final_addresses)
            groups = list(sorted(final_addresses))

            for addr in addresses:
                address = (channel, 'single', addr)
                self.set_dali_light_state(address, {'groups': groups})

            # Remove all other devices from each of the given groups
            for [[ch, addr], device] in self.lights.items():
                if ch != channel or addr in addresses:
                    continue
                if any(g in groups for g in device.get('groups', [])):
                    new_groups = [g for g in device.get('groups', []) if g not in groups]
                    address = (channel, 'single', addr)
                    self.set_dali_light_state(address, {'groups': new_groups})

            # Now reassign the addresses
            for [addr, new_addr] in reassigns:
                self.reassign_address(channel, addr, new_addr)

    # Get the number of devices in 'autodetect' and 'possibly fixed' modes
    def query_unknown_driver_modes(self):
        n_auto = n_fixed = 0
        for light in self.lights.values():
            driver_mode = light.get('driver_mode')
            if driver_mode == 0:
                n_auto += 1
            elif driver_mode == 8:
                n_fixed += 1
        return [n_auto, n_fixed]

    # For all devices with an 'unknown' driver mode ('autodetect' and
    # 'possibly fixed'), set them to the detected mode. That is, the
    # light by default will be in autodetect mode, but if calibration
    # doesn't detect CCT lights, it will temporarily set itself to
    # 'possibly fixed' mode. This fix will move 'autodetect' to CCT and
    # 'possibly fixed' to fixed.
    def fix_unknown_driver_modes(self):
        for light in self.lights.values():
            driver_mode = light.get('driver_mode')
            if driver_mode == 0:
                self.set_dali_light_state(light['address'], {'driver_mode': 3})
            elif driver_mode == 8:
                self.set_dali_light_state(light['address'], {'driver_mode': 4})

    def reassign_address(self, channel, old_addr, new_addr):
        bus = self.busses[channel]
        LOG.info('reassign address: ch=%d old=%d new=%d',
                channel, old_addr, new_addr)
        new_addr_1 = get_addr_1(new_addr) if new_addr != 255 else new_addr
        bus.send_normal_cmd(0xA3, new_addr_1)
        bus.send_normal_cmd(get_addr_1(old_addr), 0x80, send_twice=True)

        # Update db for the new address, or delete the entry if unassigning
        with db.db_session() as session:
            for db_device in self.get_all_device_db_entries(session,
                    channel_id=channel, short_addr=old_addr):
                if new_addr == 255:
                    session.delete(db_device)
                else:
                    db_device.dali_addr_short = new_addr

            # Also do the same thing for passive devices
            for db_device in session.query_all(db.PassiveDevice,
                    channel_id=channel, dali_addr_short=old_addr):
                if new_addr == 255:
                    session.delete(db_device)
                else:
                    db_device.dali_addr_short = new_addr

        # Blacklist the old/new addresses to rescan them
        self.blacklist_address(channel, old_addr)
        if new_addr != 255:
            self.blacklist_address(channel, new_addr)

    def send_cmd_raw(self, cmd, channel=None, allow_blank=False, log=True):
        with get_dali_lock(channel):
            response = self.serial_device.write(channel, cmd,
                    allow_blank=allow_blank)
            self.update_from_dali_cmd(cmd, direction='send', log=log,
                    channel=channel)
            if response:
                self.update_from_dali_cmd(response, direction='recv',
                        log=log, channel=channel)
            return response

    def read_line_raw(self, channel=None, allow_blank=False, log=True):
        response = self.serial_device.read_line(channel, allow_blank=allow_blank)
        if response:
            self.update_from_dali_cmd(response, direction='recv',
                    log=log, channel=channel)
        return response

    # Send a command, then read responses until one starts with expected_prefix.
    # It will only read up to 5 lines, re-queueing non-matches, except the last
    def send_conf_command(self, cmd, expected_prefix, channel=0, log=False):
        with get_dali_lock(channel):
            resp = self.send_cmd_raw(cmd, channel=channel, allow_blank=True, log=log)
            lines = []
            for i in range(10):
                if resp.startswith(expected_prefix):
                    break
                lines.append(resp)
                resp = self.read_line_raw(channel=channel, allow_blank=True, log=log)
            else:
                lines.append(resp)
                resp = ''

        # Add responses that don't match back to the read buffer
        if lines:
            self.serial_device.enqueue(channel, lines)

        return resp

    def update_from_dali_cmd(self, cmd, direction='recv', log=True, channel=0):
        global FAILOVER_STATUS, LAST_STATUS_CMD_TIME

        if not cmd:
            return

        orig_cmd = cmd
        if cmd[0].isdigit():
            channel = int(cmd[0])
            cmd = cmd[1:]

        # ugh
        if channel is None:
            channel = 0

        if not cmd:
            LOG.error('got bogus line!? cmd=%r', orig_cmd)
            return

        # Slightly HACKish: make sure this command shows up in the log
        # for the appropriate bus
        if log and channel in self.busses:
            self.busses[channel].push_event(direction, cmd)

        if cmd[0] == 'Q':
            self.update_q_status(status=cmd)
        elif cmd[0] == 'P':
            self.update_hat_power_status(status=cmd)
        elif cmd[0] == 'D':
            self.update_bus_active_status(channel, cmd)

        elif cmd[0].lower() in {'h', 't'}:
            cmd_hi = int(cmd[1:3], 16)
            cmd_lo = int(cmd[3:5], 16)

            # Interpret first byte
            (addr_type, addr_id) = dali_cmds.parse_dali_addr(cmd_hi)
            address = (channel, addr_type, addr_id)

            level = None

            # Direct level set command
            if cmd_hi & 1 == 0:
                level = cmd_lo
            # Other commands--make sure high byte isn't a special command
            elif cmd_hi & 0xE0 not in {0xA0, 0xC0}:
                if cmd_lo in dali_cmds.LEVEL_CMDS:
                    level = dali_cmds.LEVEL_CMDS[cmd_lo]
                elif cmd_lo in dali_cmds.LEVEL_INC_CMDS:
                    level_inc = dali_cmds.LEVEL_INC_CMDS[cmd_lo]
                    self.set_level_inc(address, level_inc, update_bus=False)
                # Handle color set command
                elif cmd_lo == 0xE2:
                    # Kinda hacky: rely on each channel's state tracking for dtr/dtr1
                    ds = self.busses[channel].dali_state
                    cct = ds['dtr1'] << 8 | ds['dtr']

                    # Also hacky: find the devices that this command is
                    # addressing, and for each one convert CCT -> K based on
                    # its interpolation values
                    for device in self.get_matching_lights(address):
                        color_temp_k = convert_cct_k(device, cct)
                        self.set_color_temp(device['address'], color_temp_k,
                                update_bus=False)
                # Handle group changes
                elif cmd_lo & 0xF0 in {0x60, 0x70}:
                    add = cmd_lo & 0xF0 == 0x60
                    group_id = cmd_lo & 0x0F
                    for device in self.get_matching_lights(address):
                        groups = [g for g in device.get('groups', [])
                                if g != group_id]
                        if add:
                            groups.append(group_id)
                        self.set_dali_light_state(device['address'],
                                {'groups': groups}, update_bus=False)
                # Handle scene triggers
                elif cmd_lo & 0xF0 == 0x10:
                    scene = cmd_lo & 0x0F
                    self.trigger_scene(scene, update_bus=False, address=address)
                # Check for status queries: in this case, we assume it's
                # likely from a PSE-4D doing a power reading, and we disable
                # triggers from arc levels for 90 seconds. Just record the time
                # here, the actual logic is in schedule.py
                elif cmd_lo == 0x90:
                    LAST_STATUS_CMD_TIME = util.get_time()
                # Check for failover set from another device
                elif cmd_lo == 0x31:
                    FAILOVER_STATUS = self.busses[channel].dali_state['dtr']
                # Check for queries of fail level, which has special (hacky) meaning
                # for virtual devices
                elif cmd_lo == 0xA4:
                    self.check_virtual_device_fail_level(address)
                # DALI reset command: blacklist any relevant addresses
                elif cmd_lo == 0x20:
                    for light in self.get_matching_lights(address):
                        self.delay_blacklist(light['channel'],
                                light['short_addr'], device_is_atxled(light))

            # If we got a level set command, update the database
            if level is not None:
                self.set_level(address, level, update_bus=False)
                if addr_type == 'all' and BCAST_LISTENER:
                    BCAST_LISTENER(channel, level)

            # Blacklist this address to rescan it if we don't have a known device
            #if addr_type == 'single':
            #    if not any(True for device in self.get_matching_lights(address)):
            #        self.blacklist_address(channel, addr_id)

    def listen_all_busses(self):
        return self.dali_events.listen()

DUMB_DB = DumbDB()

class DALIBus:
    def __init__(self, serial_device, channel, dali_events):
        self.serial_device = serial_device
        self.channel = channel

        self.reset_dali_state()

        # The event stream for DALI log websocket. We keep a reference to the
        # last event we added, so we can mutate it. Kinda dirty, but with
        # multiple busses pushing to the same queue this is pretty much the
        # cleanest/fastest way.
        self.dali_events = dali_events
        self.last_event = None

        self.last_write_time = {}

    def reset_dali_state(self):
        # Basic/imperfect state tracking, purely for making nicer logs
        self.dali_state = {'dtr': None, 'dtr1': None, 'dtr2': None}

    def push_event(self, direction, msg):
        msg = msg.strip()
        ts = time.strftime('%Y%m%d %H:%M:%S')
        replace = False
        data = {'ts': ts, 'dir': direction, 'raw': msg, 'address': '',
                'send_desc': '', 'recv_raw': '', 'recv_desc': '',
                'channel': self.channel}
        if msg.lower().startswith(('h', 't')):
            cmd = int(msg[1:], 16)
            addr, cmd_str = dali_cmds.pretty_dali_cmd_str(cmd,
                    state=self.dali_state)
            data['address'] = addr
            data['send_desc'] = cmd_str
        elif msg.lower().startswith(('n', 'j')):
            # Tack this response onto the last one if possible. We copy the last
            # event (with the old seq id), update it, and send it again, so
            # clients can amend the old one
            if self.last_event:
                data = self.last_event
                if data['send_desc'] and not data['recv_raw']:
                    data['recv_raw'] = msg
                    replace = True
            data['recv_desc'] = (int(msg[1:], 16)
                    if msg.lower().startswith('j') else '-')

        # Get a sequence ID if we're not replacing the old event
        if not replace:
            data['seq'] = self.dali_events.allocate_seq()

        # Push this event to history/any listeners, and save it for possible
        # amending on a response
        self.dali_events.push(data, replace=replace)
        self.last_event = data

    # Raw serial access

    def read_line(self, allow_blank=False, log=True):
        line = self.serial_device.read_line(self.channel, allow_blank=allow_blank)
        if line and log:
            self.push_event('recv', line)
        return line

    def prepare_cmd(self, cmd_hi, cmd_lo=None, *, bits=16, send_twice=False):
        # Choose a command prefix based on size/send_twice
        prefix = dali_cmds.DALI_PACKET_PREFIX[bits]
        if send_twice:
            assert bits == 16
            prefix = 't'

        # We support sending commands as one short or two bytes. Decide what to do.
        if cmd_lo is None:
            assert 0 <= cmd_hi < (1 << bits), (cmd_hi, 1 << bits)
            cmd = cmd_hi
        else:
            assert bits == 16
            assert 0 <= cmd_lo < (1 << 8)
            assert 0 <= cmd_hi < (1 << 8)
            cmd = (cmd_hi << 8) | cmd_lo

        n_digits = 2 * ((bits + 7) >> 3)
        return '%s%0*X\n' % (prefix, n_digits, cmd)

    def send_cmd_sync(self, cmd_hi, cmd_lo=None, *, bits=16, send_twice=False, log=True):
        line = self.prepare_cmd(cmd_hi, cmd_lo, bits=bits, send_twice=send_twice)
        with get_dali_lock(self.channel):
            self.serial_device.write_raw(self.channel, line)
            if log:
                self.push_event('send', line)
            if send_twice:
                _ = self.read_line(log=log)
            return self.read_line(log=log)

    # A wrapper around send_cmd_sync() that tries to be more robust. Most DALI commands
    # will result in a response of either N or Jxx. If we receive something else, we
    # can queue it up, or resend the command if needed.
    def send_normal_cmd(self, cmd_hi, cmd_lo=None, send_twice=False,
            allow_conflict=False):
        with get_dali_lock(self.channel):
            # Keep a buffer of unmatched input to queue up
            lines = []
            last_resp = None
            cmd = self.prepare_cmd(cmd_hi, cmd_lo, send_twice=send_twice)
            self.serial_device.write_raw(self.channel, cmd)
            self.push_event('send', cmd)
            REPS = 5
            i = 0
            already_resent = False
            while i < REPS:
                i += 1
                # Read a response line. We always allow blank lines here, because
                # otherwise we might deadlock if the hat is misbehaving. This hasn't
                # been seen to my knowledge, but defensive programming y'know.
                resp = self.read_line(allow_blank=True)
                resend = False
                # Got a normal response
                if resp and resp[0] in {'N', 'J'}:
                    # Check if we're sending twice, and check responses if so
                    if send_twice:
                        if last_resp:
                            if last_resp == resp:
                                break
                            resend = True
                            last_resp = None
                        else:
                            last_resp = resp
                    else:
                        break
                # Check for send/receive collision, and resend if so
                elif resp and resp[0] in {'X', 'Z'}:
                    # Some APIs want to see conflicts, so break in that case.
                    # We only return receive conflicts (as in, we got more than
                    # one response), but always retry on send conflicts (as in,
                    # somebody else was sending when we tried to)
                    if allow_conflict and resp[0] == 'X':
                        assert not send_twice
                        break
                    LOG.info('got conflict (%s) sending %r, sending again', resp, cmd)
                    last_resp = None
                    resend = True
                elif resp:
                    lines.append(resp)

                resp = None
                if resend and not already_resent:
                    self.serial_device.write_raw(self.channel, cmd, is_resend=True)
                    REPS += 1 + send_twice
                    already_resent = True

        # Add responses that don't match back to the read buffer
        if lines:
            self.serial_device.enqueue(self.channel, lines)

        return resp

    # Convenience functions

    def set_level(self, address, level):
        level = max(0, min(level, 254))
        self.send_normal_cmd(get_addr_0(address), level)

    def set_level_off(self, address):
        self.send_normal_cmd(get_addr_1(address), 0x00)

    def set_level_min(self, address):
        self.send_normal_cmd(get_addr_1(address), 0x06)

    def set_level_max(self, address):
        self.send_normal_cmd(get_addr_1(address), 0x05)

    def step_level_up(self, address):
        self.send_normal_cmd(get_addr_1(address), 0x03)

    def step_level_down(self, address):
        self.send_normal_cmd(get_addr_1(address), 0x04)

    def set_cct(self, address, cct):
        with get_dali_lock(self.channel):
            # Set DTR1/DTR to 2-byte cct
            self.send_normal_cmd(0xC3, cct >> 8)
            self.send_normal_cmd(0xA3, cct & 255)
            # Set mode 8, broadcast 'set cct'
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xE7)

    def set_save_cct(self, address, cct, color_fade=False):
        with get_dali_lock(self.channel):
            if not color_fade:
                self.send_normal_cmd(get_addr_1(address), 0x03)
            self.set_cct(address, cct)
            # Set mode 8, broadcast 'save cct'
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xE2)

    def set_save_rgbw(self, address, rgbwaf, power):
        with get_dali_lock(self.channel):
            # Re-weight the color channels to sum to 254, if they
            # are more than 100 total.
            total = sum(rgbwaf)
            if total > 253:
                exp = -math.log2(total / 254)
                scale = pow(power, exp)
                rgbwaf = [int(x * scale) for x in rgbwaf]
                assert all(0 <= x <= 254 for x in rgbwaf)
                #assert 0 < sum(rgbwaf) <= 254

            # Zero-pad the rgbwaf value to 6 channels
            rgbwaf = (rgbwaf + [0] * 6)[:6]
            [r, g, b, w, a, f] = rgbwaf

            # Set DTR 0/1/2 to RGB, send 'set RGB'
            self.send_normal_cmd(0xA3, r)
            self.send_normal_cmd(0xC3, g)
            self.send_normal_cmd(0xC5, b)
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xEB)
            # Set DTR to W, send 'set W'
            self.send_normal_cmd(0xA3, w)
            self.send_normal_cmd(0xC3, a)
            self.send_normal_cmd(0xC5, f)
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xEC)
            # Set weird unknown RGB-related attribute
            self.send_normal_cmd(0xA3, 0x80)
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xED)
            # Set mode 8, broadcast 'save cct'
            self.send_normal_cmd(0xC108)
            self.send_normal_cmd(get_addr_1(address), 0xE2)

    def set_dtr(self, dtr_0, dtr_1=None, force=False):
        if dtr_1 is None:
            dtr_1 = dtr_0 >> 8
            dtr_0 = dtr_0 & 255
        # Only send dtr changes if the old value is different
        if force or dtr_0 != self.dali_state['dtr']:
            _ = self.send_normal_cmd(0xA3, dtr_0)
            self.dali_state['dtr'] = dtr_0
        if force or dtr_1 != self.dali_state['dtr1']:
            _ = self.send_normal_cmd(0xC3, dtr_1)
            self.dali_state['dtr1'] = dtr_1

    def read_dtr_0(self, addr_1):
        dtr_0 = self.send_normal_cmd(addr_1, 0x98)
        if dtr_0[0] == 'J':
            return int(dtr_0[1:3], 16)

    def read_dtr_1(self, addr_1):
        dtr_0 = self.send_normal_cmd(addr_1, 0x9C)
        if dtr_0[0] == 'J':
            return int(dtr_0[1:3], 16)

    def read_dt8_value(self, addr_1, cmd, rgb_channel=None):
        if rgb_channel:
            self.send_normal_cmd(0xA3, rgb_channel)
        self.send_normal_cmd(0xC108)
        resp = self.send_normal_cmd(addr_1, cmd)
        if resp and resp[0] == 'J':
            return int(resp[1:3], 16)

    # HACK: check if this memory address needs a delay before the value has
    # settled--we require 10s for writes to land in EEPROM
    def check_mem_range_readable(self, short_addr, mem_addr, n_bytes):
        mem_keys = [(short_addr, mem_addr + i) for i in range(n_bytes)]
        # Get the time since the most recent write
        now = util.get_time()
        delta = min(now - self.last_write_time.get(key, -10) for key in mem_keys)
        if 0 <= delta < 10:
            delta = 10 - delta
            addr = mem_addr & 255
            bank = mem_addr >> 8
            LOG.info('pause %.3fs to read from s=%s, mem_addr=[%s:%s->%s]',
                    delta, short_addr, bank, addr, addr + n_bytes - 1)
            time.sleep(delta)
        for key in mem_keys:
            if key in self.last_write_time:
                del self.last_write_time[key]

    def read_dev_mem(self, short_addr, mem_addr, n_bytes):
        with get_dali_lock(self.channel):
            # Check the write times of all addresses in this range. We do this first
            # before setting DTR, as that needs to happen within 200ms of the reads
            self.check_mem_range_readable(short_addr, mem_addr, n_bytes)

            # Set DTR:DTR1 to the given address
            self.set_dtr(mem_addr)

            addr = get_addr_1(short_addr)
            # Read bytes until we hit n_bytes, or the device doesn't respond
            # memory addresses from there
            mem = []
            for i in range(n_bytes):
                # Loop until we get a clear good/no good signal, up to 10 times
                for _ in range(10):
                    # Read [DTR1:DTR] and increment DTR
                    x = self.send_normal_cmd(addr, 0xC5, allow_conflict=True)
                    if x and x[0] not in {'X', 'Z'}:
                        break
                    # Before resending the read, reset DTR since it's in an unknown state
                    self.set_dtr(mem_addr + i, force=True)
                # Didn't get a clear answer: just bail
                else:
                    break

                if not x or x[0] != 'J':
                    break
                mem.append(int(x[1:3], 16))
            return mem

    def write_dev_mem(self, short_addr, mem_addr, mem):
        with get_dali_lock(self.channel):
            addr = get_addr_1(short_addr)
            # Write each byte in mem starting at mem_addr
            for i, byte in enumerate(mem):
                # HACK: set the write time for this memory address, so we can
                # delay if necessary before reading it--we require 10s for
                # writes to land in EEPROM
                memory_key = (short_addr, mem_addr)
                self.last_write_time[memory_key] = util.get_time()

                # Set DTR:DTR1 to the address of this byte
                dtr_0 = (mem_addr + i) & 255
                dtr_1 = (mem_addr + i) >> 8
                _ = self.send_normal_cmd(0xA3, dtr_0)
                _ = self.send_normal_cmd(0xC3, dtr_1)

                # Write enable for this address, then send the byte
                _ = self.send_normal_cmd(addr, 0x81, send_twice=True)
                _ = self.send_normal_cmd(0xC7, byte)

                if dtr_1 == 0:
                    time.sleep(.2)

    def write_dev_mem_range(self, short_addr, bank, mem_range, value,
            big_endian=True):
        [lo, hi] = mem_range
        mem_bytes = dali_cmds.mem_from_int(value, hi - lo,
                big_endian=big_endian)
        lo |= bank << 8
        self.write_dev_mem(short_addr, lo, mem_bytes)

    # Send an add to/remove from group command to this device if needed
    def update_device_group(self, short_addr, group, new_status, old_status):
        if old_status is None or new_status != old_status:
            cmd = 0x60 if new_status else 0x70 # 6=add, 7=remove
            cmd |= group
            self.send_normal_cmd(get_addr_1(short_addr), cmd, send_twice=True)

    def set_scene_level(self, address, scene_id, level=None, cct=None):
        # Set a manual level if one is given, otherwise use the "capture
        # level to DTR" command
        if cct is not None:
            # Actually change the light's color. This is kinda weird, but the DR2
            # uses the current color for scenes, not the CCT register. And
            # Murray is fine with the color changing...
            # Unless of course, they're removing the CCT value, in which case this
            # doesn't matter? I don't really understand this
            if cct == 700:
                self.set_cct(address, cct)
            else:
                self.set_save_cct(address, cct)
        if level is not None:
            self.send_normal_cmd(0xA3, level)
        else:
            self.send_normal_cmd(get_addr_1(address), 0x21, send_twice=True)
        assert 0 <= scene_id < 16
        cmd = 0x40 | scene_id
        self.send_normal_cmd(get_addr_1(address), cmd, send_twice=True)

    def read_scene_levels(self, address):
        addr_1 = get_addr_1(address)
        result = []
        for scene in range(16):
            level = None
            cct = None
            x = self.send_normal_cmd(addr_1, 0xB0 | scene)
            if x and x[0] == 'J':
                level = int(x[1:3], 16)
            dtr_0 = self.read_dtr_0(addr_1)
            dtr_1 = self.read_dtr_1(addr_1)
            if dtr_0 is not None and dtr_1 is not None:
                cct = dtr_0 | dtr_1 << 8
            result.append((level, cct))
        return result

    def remove_scene(self, address, scene_id):
        assert 0 <= scene_id < 16
        cmd = 0x50 | scene_id
        self.send_normal_cmd(get_addr_1(address), cmd, send_twice=True)

    def trigger_scene(self, address, scene_id):
        assert 0 <= scene_id < 16
        cmd = 0x10 | scene_id
        self.send_normal_cmd(get_addr_1(address), cmd)

    # DALI button device (AL-WS-DALI-1/2/3/4/8B)
    # This sets attributes on the device dictionary, and due to a peculiarity
    # of where this is called from, takes an additional dictionary of new
    # attributes that will be set on the light, that we need some info from
    # here, mainly the UPC code that was probably just read from the device.

    def read_button_device_info(self, device, new_attrs):
        [channel, addr_type, addr_id] = device['address']

        # Read number of buttons
        n_buttons = self.read_dev_mem(addr_id, 16, 1)
        if not n_buttons:
            return
        [n_buttons] = n_buttons
        if not n_buttons:
            n_buttons = 8
        n_buttons = min(n_buttons, 8)

        # Read mode attributes etc. from memory
        mode_bytes = self.read_dev_mem(addr_id, 21, 2*n_buttons)
        if len(mode_bytes) != 2*n_buttons:
            return

        buttons = []
        for btn_id in range(n_buttons):
            mode = mode_bytes[btn_id*2]
            addr = mode_bytes[btn_id*2 + 1]

            # Get send mode by matching the lowest set bit. For some reason
            # there are four individual bits for each mode, rather than a
            # two bit enumeration
            send_mode = mode & -mode
            send_mode = BUTTON_SEND_MODES.get(send_mode, 'single')

            undo = False
            if send_mode == 'scene':
                undo = bool(addr & 16)
                addr &= 15

            pairwise = bool(mode & 16)

            led_mode = BUTTON_LED_MODES[mode >> 5 & 3]

            momentary = bool(mode & 0x80)

            # Ignoring the momentary bit for now

            buttons.append({
                'id': btn_id,
                'address': addr,
                'send_mode': send_mode,
                'pairwise': pairwise,
                'led_mode': led_mode,
                'momentary': momentary,
                'undo': undo,
            })

        base_name = 'DALI-8B'
        if device_is_dali_io16(new_attrs):
            base_name = 'DALI-IO16'
            device['is_io_device'] = True
        elif device_is_relay8(new_attrs):
            base_name = 'DALI-Relay8'
            device['is_relay_device'] = True

        ch_str = ' (Channel %s)' % (self.channel + 1) if self.channel else ''
        name = '%s device %s%s' % (base_name, addr_id, ch_str)

        device['n_buttons'] = n_buttons
        device['buttons'] = buttons
        device['is_button'] = True
        device['dev_name'] = name

    # Convert a JSON object for a single button's settings into a two-byte
    # configuration value and write it to memory
    def update_button_device_button(self, short_addr, btn_id, value):
        assert value['id'] == btn_id

        send_mode = value.get('send_mode', 'single')
        send_mode = BUTTON_INV_SEND_MODES[send_mode]

        led_mode = value.get('led_mode', 'off')
        led_mode = BUTTON_INV_LED_MODES[led_mode]

        pairwise = int(value.get('pairwise', False))

        momentary = int(value.get('momentary', True))

        mode_byte = send_mode | pairwise << 4 | led_mode << 5 | momentary << 7

        address = value.get('address', 0)
        if value.get('send_mode') == 'scene':
            undo = int(value.get('undo', True))
            address |= undo << 4

        mem = [mode_byte, address]
        mem_addr = btn_id*2 + 21

        self.write_dev_mem(short_addr, mem_addr, mem)

    # Update a DALI-8B device (or other similar device) by writing to memory
    # in the root address. This is a bit annoying
    def update_button_device_buttons(self, short_addr, old_value, value):
        util.validate_json(value, BUTTON_LIST_SCHEMA)
        assert len(old_value) == len(value)

        for [i, [old_btn, new_btn]] in enumerate(zip(old_value, value)):
            if old_btn != new_btn:
                self.update_button_device_button(short_addr, i, new_btn)

    # Scan a single address for the presence of a device using the 'get
    # current level' command. We also check for conflicts on this address,
    # indicating multiple devices with the same address (probably). Return a
    # tuple (has_conflict, current_level)
    def detect_address(self, address, scan_cmd):
        # Only take the lock inside each loop iteration, not outside it, so
        # that detect_addresses() can be iterated in a low-priority, yielding
        # fashion. We run the risk of a transaction reassigning addresses in
        # the middle, but oh well. Any consumers of this generator can get
        # the lock themselves if they need to.
        with get_dali_lock(self.channel):
            x = self.send_normal_cmd(get_addr_1(address), scan_cmd,
                    allow_conflict=True)
            if x and x[0] == 'J':
                # Get level
                return (False, int(x[1:3], 16))
            if x and x[0] == 'X':
                return (True, None)
        return (False, None)

    # Address detection: sequentially query every short address and check for a
    # response. We get the current brightness level at the same time.
    def detect_addresses(self, blacklist=None, scan_cmd=0xA0):
        if not blacklist:
            blacklist = range(64)

        for i in blacklist:
            try:
                [has_conflict, level] = util.retry_fn('scan',
                        lambda: self.detect_address(i, scan_cmd), retries=10)
            # Don't actually throw if it failed three times in a row, just log
            except AssertionError as e:
                LOG.exception('got exception during scan')
                continue
            if level is not None or has_conflict:
                yield (i, level)

    def detect_passive_addresses(self):
        yield from self.detect_addresses(scan_cmd=0xAB)

    def get_full_info_from_short_addr(self, device, short_addr):
        addr_1 = get_addr_1(short_addr)
        attrs = {}

        # Reset dali state so we don't assume anything about DTR
        self.reset_dali_state()

        # Read first 16 bytes of memory, and pull out attributes
        mem = self.read_dev_mem(short_addr, 0x0000, 16)

        # Get fade up/down time, which are two 4 bit values
        # queried with one command
        x = self.send_normal_cmd(addr_1, 0xA5)
        if x and x[0] == 'J':
            x = int(x[1:3], 16)
            attrs['fade_up'] = (x >> 4) & 0xF
            attrs['fade_down'] = x & 0xF

        # Grab all the single-byte attributes that we can get with one command
        for attr, attr_data in DALI_ATTRS.items():
            if attr_data.get_cmd:
                # Annoying: deal with possible bug in some 010v and DR2Fs:
                # responding as device type 8 requires an "enable device type
                # 8" first
                if attr == 'dev_type':
                    self.send_normal_cmd(0xC108)

                x = self.send_normal_cmd(addr_1, attr_data.get_cmd)
                if x and x[0] == 'J':
                    attrs[attr] = int(x[1:3], 16)
                else:
                    assert x is None or x == 'N', 'got bogus response "%s"' % x
            elif (attr_data.mem_range is not None and not attr_data.dr2f_only and
                    not attr_data.write_only):
                lo, hi = attr_data.mem_range
                mem_bytes = mem[lo:hi]
                if len(mem_bytes) == (hi - lo):
                    attrs[attr] = dali_cmds.int_from_mem(mem_bytes,
                            big_endian=attr_data.big_endian)

        # If this is a DALI-8B, read extended button info
        if device_is_dali8b(attrs):
            self.read_button_device_info(device, attrs)

        # If this is a DR2F, read extended options. This is a tad messy...
        elif device_is_dr2f(attrs):
            for attr, attr_data in DALI_ATTRS.items():
                if (attr_data.mem_range is not None and attr_data.dr2f_only and
                        (device_is_dr2f32(attrs) or not attr_data.dr2f32_only)):
                    lo, hi = attr_data.mem_range
                    n_bytes = hi - lo
                    lo |= attr_data.mem_bank << 8
                    mem_bytes = self.read_dev_mem(short_addr, lo, n_bytes)
                    attrs[attr] = dali_cmds.int_from_mem(mem_bytes,
                            big_endian=attr_data.big_endian)
                    # Handle physical color values of left/right channels for DR2F32
                    if attr in {'color_k_left', 'color_k_right'}:
                        attrs[attr] = 5000 - attrs[attr] * 13
                    elif attr == 'dim_to_warm':
                        attrs[attr] = util.scale(attrs[attr] & 15, 0, 15, 0, 4.5)

        # Read extended options for DR1-PIR
        elif device_is_dr1_pir(attrs):
            # Read bytes 16-21, and pad with zeros so we can use normal addresses
            dr1_mem = self.read_dev_mem(short_addr, 0x0010, 9)
            dr1_mem = [0] * 16 + dr1_mem

            for [attr, attr_data] in DALI_ATTRS.items():
                if attr_data.mem_range is not None and attr_data.dr1pir_only:
                    addr = attr_data.mem_range[0]
                    assert addr in range(16, 25)
                    attrs[attr] = dr1_mem[addr]

        # Get color temp capability and color temp
        attrs['has_color_temp'] = False
        attrs['has_color_rgb'] = False
        if attrs.get('dev_type') in {8, 0xFF}:
            # Read basic color sttributes
            color_type = self.read_dt8_value(addr_1, 0xF9)
            ext_version = self.read_dt8_value(addr_1, 0xFF)

            # Override old ATX-LED devices with incomplete support (DR2/010v)
            if attrs['dev_type'] == 8 and ext_version == 209:
                color_status = 0x20
            # Query color status for normal devices
            else:
                color_status = self.read_dt8_value(addr_1, 0xF8)

            # Query current CCT color for lights that support it. We use
            # the CCT bit of the color_status byte instead of color_type since
            # e.g. the MiBoxer has physical connections that enable RGB or CCT,
            # thus is only in one mode or the other and can't be switched in DALI.
            #if color_type and color_type & 0x02:
            if color_status and color_status & 0x20:
                attrs['has_color_temp'] = True

                resp = self.read_dt8_value(addr_1, 0xFA, rgb_channel=226)
                if resp is not None:
                    dtr_0 = self.read_dtr_0(addr_1)
                    dtr_1 = self.read_dtr_1(addr_1)
                    if dtr_0 is not None and dtr_1 is not None:
                        cct = dtr_0 | dtr_1 << 8
                        attrs['color_temp_k'] = convert_cct_k(device, cct)

            # Query current RGB color for lights that support it
            if color_type and color_type & 0xD0:
                n_channels = color_type >> 5
                # Read each RGBWAF channel depending on number of channels
                values = []
                for i in range(n_channels):
                    channel_id = i + 9 # RGBWAF channels are 9..14
                    value = self.read_dt8_value(addr_1, 0xFA, rgb_channel=channel_id)
                    if value is None or value == 255:
                        break
                    values.append(value)
                if len(values) == n_channels:
                    attrs['has_color_rgb'] = True
                    attrs['rgb_n_channels'] = n_channels
                    attrs['color_rgbw'] = values

            # XXX figure out how to query current color for RGB

        # Pull out 1 bits from the group bitsets to get a list of
        # groups this light is in
        groups = dali_cmds.int_from_attrs(attrs, 'group_8_15', 'group_0_7')
        if groups is not None:
            attrs['groups'] = [x for x in range(16) if groups & (1 << x)]

        return attrs

    def read_device_power_status(self, short_addr, is_dr2f32=False):
        level = self.send_normal_cmd(get_addr_1(short_addr), 0xA0)
        if level and level[0] != 'J':
            return None
        level = int(level[1:3], 16)

        mem = self.read_dev_mem(short_addr, 0x0403, 10)
        if len(mem) < 6:
            return None
        # Pad mem so the indices below are equal to addresses
        mem = [0]*3 + mem
        # Convert memory values to integers. Murray used little endian for
        # these values. Dammit!
        time_up = dali_cmds.int_from_mem(mem[3:5], big_endian=False)
        time_on = dali_cmds.int_from_mem(mem[5:7], big_endian=False)
        avg_power = max_power = eff_dim = None
        if is_dr2f32:
            energy_used = dali_cmds.int_from_mem(mem[7:9], big_endian=False) / 10
            if len(mem) == 13:
                energy_used += mem[12] / 1000
                avg_power = mem[9]
                max_power = mem[10]
                eff_dim = '%.2f' % (avg_power * 100 / max(max_power, 1))
        else:
            energy_used = .024 * dali_cmds.int_from_mem(mem[7:9], big_endian=False)
        return {'time_up': time_up, 'time_on': time_on, 'energy_used': energy_used,
                'avg_power': avg_power, 'max_power': max_power, 'eff_dim': eff_dim}

    def read_dr2_led_count(self, short_addr):
        mem = self.read_dev_mem(short_addr, 0x52C, 2)
        if len(mem) == 2:
            [left, right] = mem
            return (left // 3, right // 3)
        return None

    def search_logic(self, cmd, lo):
        hi = 255
        while lo < hi:
            mid = (lo + hi) // 2
            _ = self.send_normal_cmd(cmd, mid)
            resp = self.send_cmd_sync(0xA900)
            if resp != 'N':
                hi = mid
            else:
                lo = mid + 1
                # If we've matched here, the last comparison value of this byte
                # is off by one in the devices. Send the final value of the
                # byte to get ready for the next part
                if lo == hi:
                    _ = self.send_normal_cmd(cmd, lo)
        return lo

    # Address assignment algorithm ("DHCP"). We use the DALI protocol's
    # weird-ish algorithm for discovering devices and assigning short addresses
    # to them. It works by telling each device to pick a three-byte random
    # number, then using binary search to successively find the lowest number
    # that a device will respond to. We take care to not overwrite a device's
    # ID if it's already been assigned (and doesn't overlap with another
    # device's ID), so that we can safely add more devices to a bus and keep
    # track of which device is which. In assign_random mode, we drop all IDs
    # and assign random numbers to some devices, for setting up a "weird" state
    # before generating test traces
    def assign_addresses_gen(self, assign_random=False, quick=False, randomize=True):
        with get_dali_lock(self.channel):
            passive_addresses = set(addr for addr, level in
                    self.detect_passive_addresses())

            # We start numbering from 16 because ATX-LED uses 0-15 for pseudo-groups
            available_addresses = [i for i in range(16, 64)
                    if i not in passive_addresses]
            LOG.info('ASSIGNING ADDRESSES quick=%s random=%s', quick, assign_random)

            devices_without_serial_number = set()
            seen_serial_numbers = set()

            new_addrs = []

            # First off, detect any existing addresses. We have to do this
            # before any of the random scanning so we know what addresses are
            # free to assign. We just re-sort the available addresses to put
            # assigned addresses at the end, since we could have two devices
            # on the same address, and only one of them can keep it.
            old_addrs = set()
            for [addr, level] in self.detect_addresses():
                # Also, as a weird-ish hack (or totally normal behavior, what's
                # the difference?), unassign any addresses with conflicts
                if level is None:
                    DUMB_DB.reassign_address(self.channel, addr, 0xFF)
                else:
                    old_addrs.add(addr)

            # In quick mode, we're not reassigning all devices, so don't allow
            # colliding with another address at all
            if quick:
                available_addresses = [a for a in available_addresses
                        if a not in old_addrs]
            else:
                available_addresses.sort(key=lambda a: a in old_addrs)
            used_addrs = set()

            # Reset all short addresses if assigning randomly
            if assign_random:
                self.send_normal_cmd(0xA3FF)
                self.send_normal_cmd(0xFF80, send_twice=True)

            # Initialize and randomize. A5FF only adds devices without short
            # addresses, but we can't use that if we want to handle address
            # collisions. So only use it if "quick" mode is enabled.
            init_cmd = 0xA5FF if quick else 0xA500
            self.send_normal_cmd(init_cmd, send_twice=True)
            if randomize:
                self.send_normal_cmd(0xA700, send_twice=True)

            new_devices = total_devices = 0
            self.new_addresses = set()

            min_hi_byte = 0
            last_long_addr = None
            addr_reset = False
            # Loop continuously while there are still devices responding in the
            # DALI search mode
            while min_hi_byte < 256:
                # Reset the low bytes to 0xFF so that they'll compare properly
                _ = self.send_normal_cmd(0xB3FF)
                _ = self.send_normal_cmd(0xB5FF)

                # On the first few iterations of a quick assignment, see if
                # there are any lights at all. This is an optimization for when
                # there are few lights without addresses.
                if quick and total_devices < 4:
                    _ = self.send_normal_cmd(0xB1FF)
                    resp = self.send_normal_cmd(0xA900, allow_conflict=True)
                    if resp == 'N':
                        break

                # Do a binary search of each byte of the search address in
                # sequence. We narrow the search range of the high byte for
                # each device, since we're finding each device in increasing
                # order
                long_addr = []
                for [i, min_value] in enumerate([min_hi_byte, 0, 0]):
                    cmd = 0xB1 + 2*i
                    long_addr.append(self.search_logic(cmd, min_value))
                    yield (min_hi_byte + i/3, 0, 0, new_devices, total_devices, new_addrs)

                # Check for infinite loops. If we encounter the same device
                # twice in a row, we start the search over from zero. If it
                # happens again, we just stop--things are too screwy.
                if long_addr == last_long_addr:
                    if not addr_reset:
                        LOG.warning('got duplicate long address %s! '
                                'starting over', long_addr)
                        min_hi_byte = 0
                        addr_reset = True
                        # Make this device withdraw from search again
                        _ = self.send_normal_cmd(0xAB00, send_twice=True)
                        continue
                    else:
                        LOG.warning('got duplicate long address %s again! '
                                'bailing', long_addr)
                        break
                else:
                    min_hi_byte = long_addr[0]
                    addr_reset = False
                last_long_addr = long_addr

                # Check if any devices match. If not, we're done
                resp = self.send_normal_cmd(0xA900, allow_conflict=True)

                if resp == 'N':
                    break

                # See if this device has a short address already programmed
                short_addr = None
                write_short_addr = True
                has_short_addr = False
                resp = self.send_normal_cmd(0xBB00)
                if resp and resp[0] == 'J' and resp[1:3] != 'FF':
                    short_addr = int(resp[1:3], 16) >> 1
                    if short_addr in used_addrs:
                        short_addr = None
                    else:
                        used_addrs.add(short_addr)
                        write_short_addr = False
                        has_short_addr = True
                LOG.info('found device at %s, short addr %s (%s)', long_addr,
                        short_addr, resp)

                # If this is a new device, or the old address collides, find a
                # free address
                if short_addr is None:
                    for j in available_addresses:
                        if j not in used_addrs:
                            short_addr = j
                            used_addrs.add(short_addr)
                            break
                    else:
                        yield ("couldn't assign a short address, "
                                "too many devices")
                        break

                LOG.info(' used %s', used_addrs)

                # If we assigned a new address, write it out
                if write_short_addr:
                    # In assign_random mode, only save ~half the addresses
                    if not assign_random or random.randint(0, 1):
                        LOG.info('  assigning short addr %s', short_addr)
                        _ = self.send_normal_cmd(0xB7, get_addr_1(short_addr))
                        has_short_addr = True

                # Verify that the device has a serial number stored. If not,
                # assign a new one based on our sequence counter, so we
                # never get duplicates
                if has_short_addr:
                    current_serial_nb = self.read_dev_mem(short_addr, 0x000B, 4)
                    current_serial_nb = dali_cmds.int_from_mem(current_serial_nb)
                    if (not current_serial_nb or
                            current_serial_nb == 0xFFFFFFFF or
                            current_serial_nb in seen_serial_numbers):
                        devices_without_serial_number.add(short_addr)
                    else:
                        seen_serial_numbers.add(current_serial_nb)

                total_devices += 1
                if write_short_addr:
                    new_devices += 1
                    self.new_addresses.add(short_addr)
                    new_addrs.append(short_addr)

                # Make this device withdraw from search
                _ = self.send_normal_cmd(0xAB00, send_twice=True)

                # Yield a progress update
                yield (min_hi_byte, 0, len(devices_without_serial_number),
                        new_devices, total_devices, new_addrs)

            # Terminate the search process
            _ = self.send_normal_cmd(0xA100)

            # XXX HACK: in quick mode, blacklist addresses that we didn't know
            # about, but showed up in the initial scan. We didn't assign
            # addresses to them presumably, but we should still use the
            # information. Same with known addresses that didn't show up
            if quick:
                known_addrs = {short_addr for [channel, short_addr] in DUMB_DB.lights
                        if channel == self.channel}
                self.new_addresses.update(old_addrs ^ known_addrs)

            for [serial, n, total] in self.assign_serials_gen(
                    devices_without_serial_number,
                    seen_serial_numbers=seen_serial_numbers):
                yield (min_hi_byte, n, total, new_devices, total_devices, new_addrs)

    def assign_serials_gen(self, devices, seen_serial_numbers=set()):
        # Assign serial numbers to devices that don't have them (and have short
        # addresses so can be communicated with)
        with db.db_session() as session:
            # Get the latest serial number
            serial_nb_seq = None
            for sn in session.query_all(db.SerialNumberSeq):
                serial_nb_seq = sn.serial_number_seq

            # No serial number stored, base the initial one on the MAC
            if not serial_nb_seq:
                mac_address = int(util.get_mac_address(), 16) & 0xFFFFFF
                # Make sure serial numbers in this scheme cannot overlap with
                # the old scheme by adding 64, the maximum
                serial_nb_seq = (mac_address << 8) + 64

            for [n, short_addr] in enumerate(sorted(devices)):
                # Make sure this serial number is unused
                while serial_nb_seq in seen_serial_numbers:
                    serial_nb_seq += 1

                serial_nb = serial_nb_seq
                LOG.info('writing serial %08x to address %s', serial_nb, short_addr)
                serial_nb_seq += 1
                self.write_dev_mem_range(short_addr, 0, (0x0B, 0x0F), serial_nb)

                # Yield a progress update
                yield (serial_nb, n+1, len(devices))

            # Write the latest serial number to the database
            session.upsert(db.SerialNumberSeq, {}, serial_number_seq=serial_nb_seq)

    # Generate a stream of values for a stress test, either sending or receiving.
    # This is structured as a coroutine that accepts (n_packets, mode) tuples
    # so the receiving end can resynchronize for the next packet.
    def stress_test_gen(self):
        # Based on xxhash
        def hash_value(x):
            # Chop off high bits to match C uint32_t code
            def u32(x):
                return x & 0xFFFFFFFF
            x = u32(x * 0xC2B2AE3D)
            x = u32(x << 17 | x >> 15)
            x ^= x >> 15
            x = u32(x * 0x85EBCA77)
            x ^= x >> 13
            x = u32(x * 0x165667B1)
            x ^= x >> 16
            return x

        # XXX Coordinate this value with firmware, or read it from the bus
        n_packets = 0
        # A bit to track whether we're generating a sequence ID or hash
        mode = 1

        while True:
            if mode == 1:
                resp = yield (1, 24, n_packets)
            else:
                hashed = hash_value(n_packets)
                length = [8, 16, 24, 25][hashed & 3]
                hashed >>= 2
                hashed = hashed & (1 << length - 1) - 1
                n_packets -= 1
                n_packets &= 0x7FFFFF

                resp = yield (0, length, hashed)

            # Synchronize values if requested
            if resp:
                if resp[0] is not None:
                    mode = resp[0]
                if resp[1] is not None:
                    n_packets = resp[1]

            mode ^= 1

    # Continuously receive packets from a device in 'stress test' mode, that
    # will keep sending 8/16/24/25 bit packets in a specific sequence. The
    # test will run until <timeout> consecutive blank reads occur. This function
    # is a generator, which yields status updates (either errors, or a counter
    # of packets processed)
    def recv_stress_test_gen(self, timeout=50):
        def check(msg, actual, expected):
            if actual != expected:
                yield (True, 'got wrong %s at n=%s, actual=%s, expected=%s' % (
                        msg, n_packets, actual, expected))

        # XXX Coordinate this value with firmware, or read it from the bus
        n_packets = 0
        n_received = 0
        n_blanks = 0

        last_values = None
        stress_values = iter(self.stress_test_gen())

        with get_dali_lock(self.channel):
            while True:
                # Receive one packet
                data = self.read_line(allow_blank=True, log=False)
                if not data:
                    # Check for timeout
                    n_blanks += 1
                    if n_blanks > timeout:
                        break
                    continue
                n_blanks = 0

                # Interpret packet
                try:
                    size = dali_cmds.DALI_PACKET_SIZE[data[0]]
                    value = int(data[1:], 16)
                    this_mode = value & 1
                    value >>= 1
                    n_received += 1
                except Exception:
                    yield (True, 'got bad packet: %r' % data)
                    continue

                # Get expected values based on last values
                [exp_mode, exp_length, exp_value] = stress_values.send(last_values)

                # Check packet against expectation
                last_values = [this_mode, None]
                yield from check('length', size, exp_length)
                yield from check('mode', this_mode, exp_mode)
                if this_mode == 1:
                    yield from check('sequence', value, exp_value)
                    last_values[1] = exp_value
                    n_packets = exp_value
                else:
                    yield from check('hash', value, exp_value)

                yield (False, n_received)

    def send_stress_test_gen(self):
        # XXX Coordinate this value with firmware, or read it from the bus
        n_packets = 0
        n_received = 0
        n_blanks = 0

        last_values = None
        stress_values = iter(self.stress_test_gen())

        # Just hold a lock indefinitely. This is dumb and will probably
        # break other things
        with get_dali_lock(self.channel):
            while True:
                try:
                    [mode, length, value] = stress_values.send(last_values)

                    value = mode | (value << 1)

                    self.send_cmd_sync(value, bits=length)
                except Exception as e:
                    yield (True, 'got %s: %s' % (type(e), e))
                    continue

                n_packets += 1

                yield (False, n_packets)

# Used by the "pulse lights" function, send out a command on every bus
# unconditionally. This is used for debugging the wiring in a house
def force_broadcast_level(level):
    cmd = 'h%04X\n' % (0xFE00 | level)
    for channel in range(DUMB_DB.channels):
        DUMB_DB.send_cmd_raw(cmd, channel=channel)

# Background thread for monitoring the DALI bus when we're not directly using it.
def run_monitor_thread():
    global DUMB_DB, STOP_THREADS, PULSE_LIGHTS

    # Mark this thread as low-priority for bus locking purposes, by setting
    # a flag in thread-local memory
    _DALI_THREAD_LOCALS.is_low_priority = True

    first_run = True

    pulse_count = 0
    pulse_on = False

    while not STOP_THREADS:
        try:
            # At startup, make sure to scan the current state of the bus
            if first_run:
                DUMB_DB.init_from_db()
                DUMB_DB.ensure_scanned()
                # Also, check the power levels, in case we need to set
                # failover mode
                DUMB_DB.update_hat_power_status(status=None)
                first_run = False

                # Run any triggers that happen on start up
                STARTUP_LISTENER()

            # If requested, run a low-priority scan over the DALI bus, asking
            # all devices about their current state. This is run on startup,
            # and when things like address assignment happen, that might
            # drastically change the state of the bus.
            DUMB_DB.full_scan()

            # Check if we should pulse the lights
            if PULSE_LIGHTS:
                # Reset to 5 minutes of pulsing on first round
                if not pulse_count:
                    pulse_count = 5*60

                level = 230 if pulse_on else 25
                force_broadcast_level(level)

                time.sleep(1)
                pulse_on = not pulse_on
                pulse_count -= 1
            # Reset status if done or requested to stop. We detect this with XOR,
            # so we only reset if we were just pulsing
            if (pulse_count != 0) ^ PULSE_LIGHTS:
                PULSE_LIGHTS = False
                pulse_count = 0
                # Set to 100% briefly so the default level when turning
                # the lights back on isn't 10%
                force_broadcast_level(254)
                force_broadcast_level(0)

            # See if we can read any traffic from other devices on the bus
            with get_dali_lock(None):
                data = DUMB_DB.serial_device.read_line_low_pri(allow_blank=True)

                if data:
                    # Update the dumb-db state from the DALI packet, making
                    # sure to ignore errors from malformed packets
                    try:
                        DUMB_DB.update_from_dali_cmd(data)
                    except AssertionError:
                        LOG.exception('got exception interpreting DALI traffic')

            # See if there's any lights we should rescan after a delay. This
            # happens after we see a "reset" command on the bus. If it's an ATX-LED
            # device, we read the DALI status byte every 5 seconds to see if the
            # light is ready, otherwise we just wait 5 seconds.
            if DUMB_DB.delayed_blacklist:
                blacklist = DUMB_DB.delayed_blacklist
                DUMB_DB.delayed_blacklist = []
                for item in blacklist:
                    [t, n, channel, address, is_atxled, set_level] = item
                    # If it hasn't been 5 seconds, keep the item for later
                    if t > util.get_time():
                        DUMB_DB.delayed_blacklist.append(item)
                        continue
                    # ATX-LED: check status bit first
                    if is_atxled:
                        bus = DUMB_DB.busses[channel]
                        resp = bus.send_normal_cmd(get_addr_1(address), 0x90)
                        if resp and resp[0] == 'J':
                            status = int(resp[1:3], 16)
                            # In reset state: send a 10% level command to trigger
                            # calibration
                            if status & 0x20:
                                resp = bus.set_level(address, 20)
                            # Done calibration: turn back off and scan
                            elif status & 0xA0 == 0:
                                resp = bus.set_level(address, 0)
                                DUMB_DB.blacklist_address(channel, address)
                                continue
                        # Add 5 seconds to time and put back in the queue. We
                        # cap the number of retries at 20.
                        t += 5
                        n += 1
                        if n < 20:
                            DUMB_DB.delayed_blacklist.append((t, n,
                                    channel, address, is_atxled, set_level))
                    else:
                        address = (channel, 'single', address)
                        DUMB_DB.set_level(address, set_level)
                        DUMB_DB.blacklist_address(channel, address)

        except Exception as e:
            LOG.exception('MONITOR THREAD GOT ERROR! Waiting 30sec...')
            time.sleep(30)

    LOG.info('Monitor thread exiting...')

# Background thread for updating the hat's onboard LEDs for current DALI status
def run_led_status_thread():
    global DALI_STATUS, STOP_THREADS

    # GPIO ports
    AMBER_PORT = 32
    GREEN_PORT = 33

    # Initialize GPIO
    import RPi.GPIO as GPIO

    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    for port in [AMBER_PORT, GREEN_PORT]:
        GPIO.setup(port, GPIO.OUT)

    amber_flash = 0
    green_flash = 0

    # Loop forever, updating the LEDs to reflect current DALI status
    while not STOP_THREADS:
        try:
            # Update amber light (DALI voltage) from any D commands received
            amber = 0
            if DALI_STATUS.d_status == 2:
                amber = 1
                amber_flash = 0
            elif DALI_STATUS.d_status in {1, 4}:
                amber = amber_flash
                amber_flash ^= 1
            GPIO.output(AMBER_PORT, amber)

            # Update green light (hat voltage)
            green = 0
            power_good = sum(p >= 44 for p in DALI_STATUS.hat_voltages)
            if power_good == 2:
                green = 1
                green_flash = 0
            elif power_good == 1:
                green = green_flash
                green_flash ^= 1
            GPIO.output(GREEN_PORT, green)

            time.sleep(1)
        except Exception:
            LOG.exception('LED thread got exception! sleeping')
            time.sleep(60)

def start_monitor_threads(use_led_thread=True):
    global DALI_THREADS, STOP_THREADS
    # Stop any running thread before restarting
    if DALI_THREADS:
        STOP_THREADS = True
        for t in DALI_THREADS:
            t.join()
        STOP_THREADS = False

    threads = [run_monitor_thread]
    if use_led_thread:
        threads.append(run_led_status_thread)

    for fn in threads:
        t = threading.Thread(target=fn, daemon=True)
        t.start()
        DALI_THREADS.append(t)
