import json
import threading
import time
import urllib

import flask
import requests

import config
import dali
import util

LOG = util.get_logger('cloud')

app = flask.Blueprint('cloud', __name__, static_folder=None)

SERVER_URL = 'https://api.atxled.com'

LISTENER_THREAD = None

class CloudListener(threading.Thread):
    def run(self):
        self.stop = False

        # XXX temporary debugging code to get thread PID, copied from SO
        import ctypes
        libc = ctypes.cdll.LoadLibrary('libc.so.6')
        SYS_gettid = 224
        pid = libc.syscall(SYS_gettid)
        LOG.info('cloud thread starting at PID %s', pid)

        # Tell diyhue to ignore Alexa. We just do this unconditionally on
        # startup since I'm lazy
        try:
            url = 'http://localhost/mark-alexa-enabled'
            requests.post(url)
        except Exception:
            LOG.exception('error notifying diyhue of alexa')

        headers = {'api-token': config.SITE_SETTINGS.api_token}

        # Helper to report device data and other misc. metadata
        def report():
            devices = [light
                    for light in dali.DUMB_DB.get_all_lights_state()
                    if not light.get('hue_hidden')
                    ]
            rep_url = '%s/api/devices/report' % SERVER_URL
            data = {'pi_name': config.SITE_SETTINGS.site_name,
                    'devices': devices}
            resp = requests.post(rep_url, headers=headers, json=data)
            LOG.info('reported %s devices to cloud', len(devices))

        # Report initial device state on startup
        dali.ensure_scanned()
        report()

        url = '%s/api/messages/listen' % SERVER_URL
        x = 0
        while True:
            try:
                with requests.get(url, headers=headers, stream=True) as f:
                    for item in f.iter_content(chunk_size=None):
                        if self.stop:
                            LOG.info('worker thread stopping by request!')
                            return

                        if not item:
                            x += 1
                            if x % 10 == 0:
                                LOG.info('cloud got empty message')
                            continue
                        try:
                            item = json.loads(item)
                        except Exception:
                            LOG.info('bad json: %s', item)
                            raise
                        if not item:
                            x += 1
                            if x % 10 == 0:
                                LOG.info('cloud got empty message')
                            continue
                        LOG.info('got %s', item)

                        tp = item.get('type')
                        # Handle the message we received
                        if tp == 'set-state':
                            dali.DUMB_DB.set_dali_light_state(item['address'],
                                    item['state'])
                        elif tp == 'get-devices':
                            report()
                        else:
                            LOG.error('got bad message type (%s): %s', tp, item)

            except Exception:
                LOG.exception('cloud listener thread got exception, sleeping 30s')
                time.sleep(30)

def init_cloud():
    global LISTENER_THREAD

    config.update_site_settings()
    if not config.SITE_SETTINGS.api_token:
        return

    if LISTENER_THREAD:
        LISTENER_THREAD.stop = True
    LISTENER_THREAD = CloudListener(daemon=True, name='Cloud Listener')
    LISTENER_THREAD.start()

################################################################################
## Web routes ##################################################################
################################################################################

@app.route('/', methods=['GET', 'POST'])
def get_cloud_page():
    # Form post: unregister the device
    if flask.request.method == 'POST' and config.SITE_SETTINGS.api_token:
        headers = {'api-token': config.SITE_SETTINGS.api_token}
        url = '%s/api/devices/unregister' % SERVER_URL
        try:
            data = requests.post(url, headers=headers).json()
            assert data['ok']
            config.update_site_settings(api_token=None)
            if LISTENER_THREAD:
                LISTENER_THREAD.stop = True
            flask.flash('Successfully unregistered.')
        except Exception:
            flask.flash('Internal error')

    # If they're registered already, get status of linked accounts
    clients = None
    if config.SITE_SETTINGS.api_token:
        headers = {'api-token': config.SITE_SETTINGS.api_token}
        url = '%s/api/cloud/status' % SERVER_URL
        try:
            data = requests.get(url, headers=headers).json()
            clients = data['clients']
        except Exception:
            pass

    return flask.render_template('cloud.html', page='cloud', clients=clients)

@app.route('/register', methods=['POST'])
def register():
    # Get a preregistration token. We forward the user to the api.atxled.com
    # site to actually register (so we can immediately set a cookie for future
    # OAuth use and they don't have to log in separately there). But we want
    # some basic protection for registration, and to link this Pi to the
    # registration, so get a token to forward along to the registration URL.
    url = '%s/api/preregister/get-token' % SERVER_URL
    mac = util.get_mac_address()
    # Kinda hacky: we rely on our nginx config to properly set the Host header
    host_url = flask.request.headers['Host']
    resp = requests.post(url, json={'mac_address': mac,
        'pi_name': config.SITE_SETTINGS.site_name, 'host_url': host_url})

    try:
        assert resp.status_code == 200
        data = resp.json()
        token = data['token']
    except Exception:
        LOG.exception('error during preregistration')
        return flask.render_template('error.html', page='error')

    # Forward to the API site
    url = '%s/cloud/register?token=%s' % (SERVER_URL, token)
    return flask.redirect(url)

@app.route('/registration-complete', methods=['GET'])
def registration_complete():
    # We do a sorta-dirty thing here and forward to this URL from the api server
    # with the API token, thus use a GET request to post data!!! OMG!
    try:
        token = util.get_query_string()['token']
        # Basic reload protection
        if token != config.SITE_SETTINGS.api_token:
            config.update_site_settings(api_token=token)
            init_cloud()
    except Exception:
        return flask.render_template('error.html', page='error')

    return flask.render_template('cloud-complete.html', page='cloud')
